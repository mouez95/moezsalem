/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { NotificationModal, NotificationSectionTab } from './components/NotificationModal';
import { ToastNotification } from './components/ToastNotification';
import { WeeklyConcoursModal } from './components/WeeklyConcoursModal';
import { PWAInstallButton, OfflineIndicator } from './components/PWAInstallControls';
import { PromosportIntroStage } from './components/PromosportIntroStage';
import { FloatingGrilleAlertBadge, FloatingGrilleAlertData } from './components/FloatingGrilleAlertBadge';
import {
  PromosportGrille,
  NotificationSettings,
  ToastAlert,
  WeeklyConcours,
  AppSettings,
  LiveNotificationItem,
  NotificationTargetTab,
  ParticipantProfile,
  SlipMessageRecord,
} from './types/promosport';
import {
  loadParticipantProfileSync,
  restoreParticipantProfileAsync,
  registerParticipant,
  verifyRegisteredParticipant,
  syncPendingParticipantToServer,
  clearActiveParticipantSession,
} from './services/participantService';
import {
  fetchParticipantMessages,
  subscribeParticipantMessageStream,
  loadSeenMessageIds,
  markMessageIdsSeen,
} from './services/slipMessagesService';
import {
  INITIAL_GRILLES,
  INITIAL_WEEKLY_CONCOURS,
  fetchPromosportSyncState,
  fetchPromosportLiveMatchesScan,
  archiveConcoursToGrille,
  mergeGrilleArchives,
} from './services/promosportData';
import { evaluateConcoursRealTime, isConcoursCompletelyFinished } from './services/matchLiveService';
import { mergeConcoursPreservingScores } from './services/liveFootballFeed';
import { ensureDesktopPushSubscribed } from './services/webPushClient';
import {
  translateCompetitionToArabic,
  translateTeamToArabic,
  translateTeamToFrench,
} from './services/teamTranslationService';
import {
  loadSettings,
  saveSettings,
  loadAppSettings,
  saveAppSettings,
  loadUserSlips,
  buildConcoursAlertSignature,
  loadLastNotifiedSignature,
  saveLastNotifiedSignature,
  loadCachedConcours,
  saveCachedConcours,
  loadCachedGrilles,
  saveCachedGrilles,
  loadNotifiedWinnersMap,
  saveNotifiedWinnersSignature,
  loadLiveScanEnabled,
  loadLiveNotificationsLog,
  saveLiveNotificationsLog,
  clearLiveNotificationsLog,
  loadGeneralNotificationsLog,
  saveGeneralNotificationsLog,
  clearGeneralNotificationsLog,
} from './services/storageService';
import { syncAppChangesToWorkspace } from './services/offlineExportService';
import { audioService } from './services/audioService';
import { formatUtcPlusOneShortTime } from './services/timeUtils';

const LANGUAGE_STORAGE_KEY = 'promosport_display_language_v1';

export default function App() {
  const [lang, setLang] = useState<'AR' | 'FR'>(() => {
    try {
      return localStorage.getItem(LANGUAGE_STORAGE_KEY) === 'FR' ? 'FR' : 'AR';
    } catch {
      return 'AR';
    }
  });
  const langRef = useRef<'AR' | 'FR'>(lang);
  langRef.current = lang;

  useEffect(() => {
    try {
      localStorage.setItem(LANGUAGE_STORAGE_KEY, lang);
    } catch {
      // Ignore private-mode storage restrictions.
    }
    if (typeof document !== 'undefined') {
      document.documentElement.lang = lang === 'AR' ? 'ar' : 'fr';
    }
  }, [lang]);

  const [grilles, setGrilles] = useState<PromosportGrille[]>(() =>
    mergeGrilleArchives(loadCachedGrilles(), INITIAL_GRILLES)
  );
  const grillesRef = useRef<PromosportGrille[]>(grilles);
  grillesRef.current = grilles;

  // App Settings state (editable App Name, Package ID, Phone, Rates)
  const [appSettings, setAppSettings] = useState<AppSettings>(() => loadAppSettings());

  // Main Screen: خانة القصاصة is the primary screen after intro
  const [weeklyConcours, setWeeklyConcours] = useState<WeeklyConcours>(
    () => loadCachedConcours(INITIAL_WEEKLY_CONCOURS.number) || INITIAL_WEEKLY_CONCOURS
  );

  // Keep appSettings.concoursNumber synced strictly with the active new concours number
  useEffect(() => {
    if (!weeklyConcours?.number) return;
    setAppSettings((prev) => {
      if (prev.concoursNumber === weeklyConcours.number) return prev;
      const updated = { ...prev, concoursNumber: weeklyConcours.number };
      saveAppSettings(updated);
      return updated;
    });
  }, [weeklyConcours?.number]);
  const [weeklyConcoursTab, setWeeklyConcoursTab] = useState<'grille' | 'tirage' | 'live' | 'settings' | 'apk'>('grille');
  const [highlightedTab, setHighlightedTab] = useState<NotificationTargetTab | null>(null);
  const navHighlightTimerRef = useRef<number | null>(null);

  const [settings, setSettings] = useState<NotificationSettings>(() => loadSettings());
  const [isNotificationsOpen, setIsNotificationsOpen] = useState<boolean>(false);
  const [notificationModalSection, setNotificationModalSection] = useState<NotificationSectionTab>('general');

  const prevLiveSnapshotRef = useRef<
    Record<number, { status: string; home: string; away: string; hasScore: boolean; delayed: boolean }> | null
  >(null);
  const activeConcoursRef = useRef<WeeklyConcours>(weeklyConcours);
  activeConcoursRef.current = weeklyConcours;
  const lastActivePrizeRef = useRef({
    concoursNumber: weeklyConcours.number,
    value: String(weeklyConcours.cagnotteEstimate || '').trim(),
  });

  // One-time permanent participant registration (shown ONLY on the very first app open)
  const [participantProfile, setParticipantProfile] = useState<ParticipantProfile | null>(() =>
    loadParticipantProfileSync()
  );
  const participantProfileRef = useRef<ParticipantProfile | null>(participantProfile);
  participantProfileRef.current = participantProfile;
  const isRegistrationPending = participantProfile === null;

  useEffect(() => {
    if (!participantProfile) {
      let active = true;
      void restoreParticipantProfileAsync().then((restored) => {
        if (active && restored) {
          setParticipantProfile(restored);
        }
      });
      return () => {
        active = false;
      };
    }
    if (!participantProfile.syncedToServer) {
      void syncPendingParticipantToServer(participantProfile);
    }
    return undefined;
  }, [participantProfile]);

  const handleRegisterParticipant = useCallback(
    async (baseName: string) => {
      const res = await registerParticipant(baseName, langRef.current);
      if (res.ok && res.profile) {
        setParticipantProfile(res.profile);
        setShowLandingIntro(true);
        setLandingClosing(false);
      }
      return res;
    },
    []
  );

  const handleVerifyRegisteredParticipant = useCallback(
    async (fullNameInput: string) => {
      const res = await verifyRegisteredParticipant(fullNameInput, langRef.current);
      if (res.ok && res.profile) {
        setParticipantProfile(res.profile);
        setShowLandingIntro(true);
        setLandingClosing(false);
      }
      return res;
    },
    []
  );

  const handleReturnToRegistration = useCallback(async () => {
    await clearActiveParticipantSession();
    setParticipantProfile(null);
    setSentMessages([]);
    setReceivedMessages([]);
    setMessagesUnreadCount(0);
    setOpenMessagesLogSignal(0);
    setShowLandingIntro(true);
    setLandingClosing(false);
  }, []);

  // Show clean 3D Promosport logo + fiery spinning ball + radiant gilded MB landing stage on app open
  const [showLandingIntro, setShowLandingIntro] = useState<boolean>(true);
  const [landingClosing, setLandingClosing] = useState<boolean>(false);
  const [introEntryPhase, setIntroEntryPhase] = useState<'idle' | 'waiting' | 'descending'>('idle');
  const enterTimerRef = useRef<number | null>(null);
  const settleTimerRef = useRef<number | null>(null);

  // Strict 2-section scoping:
  // القسم الأول: خانة المباشر يفعل ويظهر في القسم وحده
  // القسم الثاني: بقية الخانات مع الصفحة الرئيسية وحدها
  const isLiveTabActive = !isRegistrationPending && !showLandingIntro && weeklyConcoursTab === 'live';
  const isLiveTabActiveRef = useRef<boolean>(isLiveTabActive);
  isLiveTabActiveRef.current = isLiveTabActive;

  // Section 1 state (Live tab ONLY)
  const [liveToastAlert, setLiveToastAlert] = useState<ToastAlert | null>(null);
  const [liveFloatingAlert, setLiveFloatingAlert] = useState<FloatingGrilleAlertData | null>(null);
  const [liveNotifications, setLiveNotifications] = useState<LiveNotificationItem[]>(() =>
    loadLiveNotificationsLog()
  );
  const [liveUnreadCount, setLiveUnreadCount] = useState<number>(() =>
    loadLiveNotificationsLog().length
  );
  const liveNotificationIdsRef = useRef(new Set(loadLiveNotificationsLog().map((item) => item.id)));

  // Section 2 state (Home Page + Remaining Tabs ONLY: القصاصة / Tirage / APK)
  const [generalToastAlert, setGeneralToastAlert] = useState<ToastAlert | null>(null);
  const [generalFloatingAlert, setGeneralFloatingAlert] = useState<FloatingGrilleAlertData | null>(null);
  const [generalNotifications, setGeneralNotifications] = useState<LiveNotificationItem[]>(() =>
    loadGeneralNotificationsLog()
  );
  const [generalUnreadCount, setGeneralUnreadCount] = useState<number>(() =>
    loadGeneralNotificationsLog().length
  );
  const generalNotificationIdsRef = useRef(new Set(loadGeneralNotificationsLog().map((item) => item.id)));

  const hasRequestedPermissionRef = useRef<boolean>(false);
  const prevLiveCatalogScoresRef = useRef<Record<string, { home: number; away: number; status: string }> | null>(null);

  // Slip Messaging (سجل الرسائل) real-time state
  const [sentMessages, setSentMessages] = useState<SlipMessageRecord[]>([]);
  const [receivedMessages, setReceivedMessages] = useState<SlipMessageRecord[]>([]);
  const [messagesUnreadCount, setMessagesUnreadCount] = useState<number>(0);
  const [messagesServerError, setMessagesServerError] = useState<string | null>(null);
  const [openMessagesLogSignal, setOpenMessagesLogSignal] = useState<number>(0);
  const seenMessageIdsRef = useRef<Set<string>>(new Set());
  const activeSeenOwnerRef = useRef<string | null>(null);

  // Keep each section's transient popups strictly confined to its own section and suppressed during registration
  useEffect(() => {
    if (isRegistrationPending) {
      setGeneralToastAlert(null);
      setGeneralFloatingAlert(null);
      setLiveToastAlert(null);
      setLiveFloatingAlert(null);
      return;
    }
    if (isLiveTabActive) {
      setGeneralToastAlert(null);
      setGeneralFloatingAlert(null);
    } else {
      setLiveToastAlert(null);
      setLiveFloatingAlert(null);
    }
  }, [isLiveTabActive, isRegistrationPending]);

  // Section 1 logger: Live tab ONLY (أهداف، انطلاق، نهاية المباريات المباشرة)
  const appendLiveNotification = useCallback(
    (
      item: Omit<LiveNotificationItem, 'timestamp' | 'createdAtMs'>,
      options?: { silent?: boolean }
    ) => {
      if (liveNotificationIdsRef.current.has(item.id)) return;
      liveNotificationIdsRef.current.add(item.id);
      const nowMs = Date.now();
      const entry: LiveNotificationItem = {
        ...item,
        targetTab: 'live',
        timestamp: `${formatUtcPlusOneShortTime(nowMs)} +1`,
        createdAtMs: nowMs,
      };
      setLiveNotifications((prev) => {
        const next = [entry, ...prev].slice(0, 60);
        saveLiveNotificationsLog(next);
        return next;
      });
      setLiveUnreadCount((count) => count + 1);
      if (!options?.silent && participantProfileRef.current !== null && isLiveTabActiveRef.current) {
        setLiveToastAlert({
          id: entry.id,
          title: entry.title,
          message: entry.message,
          type: item.kind === 'goal' ? 'golden' : 'result',
          targetTab: 'live',
          timestamp: entry.timestamp,
        });
      }
    },
    []
  );

  // Section 2 logger: Home page + Remaining Tabs ONLY (القصاصات الجديدة، الجوائز الكبرى، المرابيح، التحديثات)
  const appendGeneralNotification = useCallback(
    (
      item: Omit<LiveNotificationItem, 'timestamp' | 'createdAtMs'>,
      options?: { silent?: boolean }
    ) => {
      if (generalNotificationIdsRef.current.has(item.id)) return;
      generalNotificationIdsRef.current.add(item.id);
      const nowMs = Date.now();
      const targetTab: NotificationTargetTab =
        item.targetTab === 'tirage' || item.targetTab === 'apk' || item.targetTab === 'messages'
          ? item.targetTab
          : 'grille';
      const entry: LiveNotificationItem = {
        ...item,
        targetTab,
        timestamp: `${formatUtcPlusOneShortTime(nowMs)} +1`,
        createdAtMs: nowMs,
      };
      setGeneralNotifications((prev) => {
        const next = [entry, ...prev].slice(0, 60);
        saveGeneralNotificationsLog(next);
        return next;
      });
      setGeneralUnreadCount((count) => count + 1);
      if (!options?.silent && participantProfileRef.current !== null && !isLiveTabActiveRef.current) {
        const type: ToastAlert['type'] =
          item.kind === 'grille'
            ? 'grille'
            : item.kind === 'cagnotte'
              ? 'cagnotte'
              : item.kind === 'system'
                ? 'system'
                : 'result';
        setGeneralToastAlert({
          id: entry.id,
          title: entry.title,
          message: entry.message,
          type,
          targetTab,
          timestamp: entry.timestamp,
        });
      }
    },
    []
  );

  const handleClearLiveNotifications = useCallback(() => {
    setLiveNotifications([]);
    setLiveUnreadCount(0);
    liveNotificationIdsRef.current.clear();
    setLiveToastAlert(null);
    setLiveFloatingAlert(null);
    clearLiveNotificationsLog();
  }, []);

  const handleClearGeneralNotifications = useCallback(() => {
    setGeneralNotifications([]);
    setGeneralUnreadCount(0);
    generalNotificationIdsRef.current.clear();
    setGeneralToastAlert(null);
    setGeneralFloatingAlert(null);
    clearGeneralNotificationsLog();
  }, []);

  const handleMarkLiveNotificationsRead = useCallback(() => {
    setLiveUnreadCount(0);
  }, []);

  const handleScanEnabledChange = useCallback((enabled: boolean) => {
    if (!enabled) {
      prevLiveCatalogScoresRef.current = null;
    }
  }, []);

  const handleEnterGrilleFromLogo = useCallback(() => {
    if (participantProfileRef.current === null) return;
    if (!showLandingIntro || landingClosing) return;
    audioService.playClick();
    audioService.playGoldenRipple();
    setOpenMessagesLogSignal(0);
    setLandingClosing(true);

    if (enterTimerRef.current) window.clearTimeout(enterTimerRef.current);
    if (settleTimerRef.current) window.clearTimeout(settleTimerRef.current);

    enterTimerRef.current = window.setTimeout(() => {
      setShowLandingIntro(false);
      setLandingClosing(false);
      setIntroEntryPhase('descending');
      settleTimerRef.current = window.setTimeout(() => {
        setIntroEntryPhase('idle');
      }, 1150);
    }, 260);
  }, [showLandingIntro, landingClosing]);

  // MB icon in Grille header returns cleanly to the opening showcase stage
  const handleReturnToIntroFromMb = useCallback(() => {
    if (enterTimerRef.current) window.clearTimeout(enterTimerRef.current);
    if (settleTimerRef.current) window.clearTimeout(settleTimerRef.current);
    audioService.playClick();
    audioService.playGoldenRipple();
    setOpenMessagesLogSignal(0);
    setLandingClosing(false);
    setShowLandingIntro(true);
  }, []);

  const navigateFromNotification = useCallback((targetTab: NotificationTargetTab) => {
    if (participantProfileRef.current === null) return;
    setLiveFloatingAlert(null);
    setLiveToastAlert(null);
    setGeneralFloatingAlert(null);
    setGeneralToastAlert(null);
    setShowLandingIntro(false);
    setLandingClosing(false);
    if (targetTab === 'messages') {
      setWeeklyConcoursTab('grille');
      setHighlightedTab('grille');
      setOpenMessagesLogSignal((prev) => prev + 1);
      setMessagesUnreadCount(0);
    } else {
      setOpenMessagesLogSignal(0);
      setWeeklyConcoursTab(targetTab);
      setHighlightedTab(targetTab);
    }
    if (navHighlightTimerRef.current !== null) {
      window.clearTimeout(navHighlightTimerRef.current);
    }
    navHighlightTimerRef.current = window.setTimeout(() => {
      setHighlightedTab(null);
      navHighlightTimerRef.current = null;
    }, 10_000);
  }, []);

  useEffect(() => {
    return () => {
      if (enterTimerRef.current) window.clearTimeout(enterTimerRef.current);
      if (settleTimerRef.current) window.clearTimeout(settleTimerRef.current);
      if (navHighlightTimerRef.current !== null) window.clearTimeout(navHighlightTimerRef.current);
    };
  }, []);

  // Silently ensure VAPID desktop Web Push subscription if already permitted
  useEffect(() => {
    void ensureDesktopPushSubscribed(false);
  }, []);

  // Keep audioService synchronized with all user sound choices & click interaction styles
  useEffect(() => {
    audioService.setSoundEnabled(settings.soundEnabled);
    audioService.setGoalSoundStyle(settings.goalSoundStyle);
    audioService.setClickSoundEnabled(settings.clickSoundEnabled);
    audioService.setClickSoundStyle(settings.clickSoundStyle);
  }, [
    settings.soundEnabled,
    settings.goalSoundStyle,
    settings.clickSoundEnabled,
    settings.clickSoundStyle,
  ]);

  // Helper to dispatch OS device push notification via Service Worker
  const emitPushIfEnabled = useCallback(
    (title: string, body: string, concoursNumber = 0, signature = '', customTag?: string, targetTab: NotificationTargetTab = 'grille') => {
      if (participantProfileRef.current === null) return;
      if (!settings.pushNotificationsEnabled || typeof window === 'undefined' || !('Notification' in window)) {
        return;
      }
      if (Notification.permission !== 'granted') return;

      const resolvedTag = customTag || `promosport-grille-${concoursNumber || 'live'}`;

      const dispatchViaNotificationApi = () => {
        try {
          const isFr = langRef.current === 'FR';
          const notif = new Notification(title, {
            body,
            icon: '/pwa-192x192.png',
            badge: '/pwa-192x192.png',
            dir: isFr ? 'ltr' : 'rtl',
            lang: isFr ? 'fr' : 'ar',
            tag: resolvedTag,
          });
          notif.onclick = () => {
            try {
              window.focus();
            } catch {
              // ignore focus errors
            }
            navigateFromNotification(targetTab);
            notif.close();
          };
        } catch {
          // ignore notification quota errors
        }
      };

      if ('serviceWorker' in navigator) {
        if (navigator.serviceWorker.controller) {
          navigator.serviceWorker.controller.postMessage({
            type: 'SHOW_NEW_GRILLE_NOTIFICATION',
            title,
            body,
            concoursNumber,
            signature,
            tag: resolvedTag,
            targetTab,
          });
          return;
        }
        navigator.serviceWorker.ready
          .then((registration) => {
            if (registration && typeof registration.showNotification === 'function') {
              const isFr = langRef.current === 'FR';
              return registration.showNotification(title, {
                body,
                icon: '/pwa-192x192.png',
                badge: '/pwa-192x192.png',
                dir: isFr ? 'ltr' : 'rtl',
                lang: isFr ? 'fr' : 'ar',
                tag: resolvedTag,
                silent: false,
                data: {
                  url: `/?openTab=${targetTab}`,
                  concoursNumber,
                  signature,
                  targetTab,
                },
              });
            }
            dispatchViaNotificationApi();
            return undefined;
          })
          .catch(() => {
            dispatchViaNotificationApi();
          });
      } else {
        dispatchViaNotificationApi();
      }
    },
    [settings.pushNotificationsEnabled, navigateFromNotification]
  );

  // Section 1 floating alert icon (strictly inside خانة المباشر وحدها)
  const triggerLiveFloatingAlert = useCallback(
    (concoursNumber: number, title: string, subtitle: string) => {
      if (participantProfileRef.current === null || !isLiveTabActiveRef.current) return;
      setLiveFloatingAlert({
        id: `live-beacon-${concoursNumber}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        concoursNumber,
        title,
        cagnotte: subtitle,
        createdAtMs: Date.now(),
      });
    },
    []
  );

  // Section 2 floating alert icon (strictly inside الصفحة الرئيسية وبقية الخانات وحدها)
  const triggerGeneralFloatingAlert = useCallback(
    (concoursNumber: number, title: string, subtitle: string, targetTab: NotificationTargetTab = 'grille') => {
      if (participantProfileRef.current === null || isLiveTabActiveRef.current) return;
      setGeneralFloatingAlert({
        id: `grille-beacon-${concoursNumber}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        concoursNumber,
        title,
        cagnotte: subtitle,
        targetTab,
        createdAtMs: Date.now(),
      });
    },
    []
  );

  // Handles any newly arrived slips in سجل الرسائل: always double-beeps & shows sender name on Home Page
  const processNewlyArrivedMessages = useCallback(
    (incomingList: SlipMessageRecord[], owner: ParticipantProfile) => {
      if (!incomingList.length) return;
      if (activeSeenOwnerRef.current !== owner.id) {
        activeSeenOwnerRef.current = owner.id;
        seenMessageIdsRef.current = loadSeenMessageIds(owner.id);
      }
      const unseen = incomingList.filter((m) => !seenMessageIdsRef.current.has(m.id));
      if (unseen.length === 0) return;

      const unseenIds = unseen.map((m) => m.id);
      unseenIds.forEach((id) => seenMessageIdsRef.current.add(id));
      markMessageIdsSeen(owner.id, unseenIds);

      // Always play double beep on new incoming slip(s) in سجل الرسائل
      audioService.playDoubleBeep();
      setMessagesUnreadCount((prev) => prev + unseen.length);

      const isFr = langRef.current === 'FR';
      unseen.forEach((msg) => {
        const title = isFr
          ? `Nouveau ticket reçu de ${msg.senderFullName}`
          : `قصاصة جديدة في سجل الرسائل من ${msg.senderFullName}`;
        const body = isFr
          ? `${msg.slipNumberLabel} • Concours #${msg.slip.grilleNumber} • ${msg.sentAtDisplay}`
          : `القصاصة ${msg.slipNumberLabel} (مسابقة #${msg.slip.grilleNumber}) • ${msg.sentAtDisplay}`;

        appendGeneralNotification(
          {
            id: `msg-${msg.id}`,
            kind: 'message',
            targetTab: 'messages',
            senderFullName: msg.senderFullName,
            title,
            message: body,
            scoreLabel: msg.slipNumberLabel,
          },
          { silent: true }
        );

        if (!isLiveTabActiveRef.current) {
          triggerGeneralFloatingAlert(msg.slip.grilleNumber, title, msg.senderFullName, 'messages');
          setGeneralToastAlert({
            id: `msg-toast-${msg.id}`,
            title,
            message: body,
            type: 'grille',
            targetTab: 'messages',
            timestamp: msg.sentAtDisplay,
          });
        }

        emitPushIfEnabled(
          title,
          body,
          msg.slip.grilleNumber,
          msg.id,
          `promosport-msg-${msg.id}`,
          'messages'
        );
      });
    },
    [appendGeneralNotification, triggerGeneralFloatingAlert, emitPushIfEnabled]
  );

  const syncMessagesFromServer = useCallback(async () => {
    const profile = participantProfileRef.current;
    if (!profile) return;
    const result = await fetchParticipantMessages(profile);
    if (!result.ok) {
      setMessagesServerError(result.error || 'تعذر الاتصال بخادم الرسائل.');
      return;
    }
    setMessagesServerError(null);
    setSentMessages(result.sent);
    setReceivedMessages(result.received);
    processNewlyArrivedMessages(result.received, profile);
  }, [processNewlyArrivedMessages]);

  const handleMarkMessagesRead = useCallback(() => {
    setMessagesUnreadCount(0);
    setGeneralUnreadCount(0);
  }, []);

  const handleSlipMessageSent = useCallback((record: SlipMessageRecord) => {
    setSentMessages((prev) => [record, ...prev.filter((m) => m.id !== record.id)]);
  }, []);

  useEffect(() => {
    if (!participantProfile) {
      activeSeenOwnerRef.current = null;
      seenMessageIdsRef.current = new Set();
      setSentMessages([]);
      setReceivedMessages([]);
      setMessagesUnreadCount(0);
      setMessagesServerError(null);
      return undefined;
    }

    activeSeenOwnerRef.current = participantProfile.id;
    seenMessageIdsRef.current = loadSeenMessageIds(participantProfile.id);

    void syncMessagesFromServer();

    const unsubscribeStream = subscribeParticipantMessageStream(
      participantProfile,
      (msg) => {
        setReceivedMessages((prev) => [msg, ...prev.filter((item) => item.id !== msg.id)]);
        const currentProfile = participantProfileRef.current;
        if (currentProfile) {
          processNewlyArrivedMessages([msg], currentProfile);
        }
      },
      () => {
        void syncMessagesFromServer();
      }
    );

    const intervalId = window.setInterval(() => {
      void syncMessagesFromServer();
    }, 12000);

    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        void syncMessagesFromServer();
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);

    return () => {
      unsubscribeStream();
      window.clearInterval(intervalId);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [participantProfile?.id, syncMessagesFromServer, processNewlyArrivedMessages]);

  // Announces a genuinely new grille or update (Section 2: الصفحة الرئيسية وبقية الخانات وحدها)
  const triggerNewGrilleAnnouncement = useCallback(
    (
      concours: WeeklyConcours,
      options?: { forceTest?: boolean; customTitle?: string; customBody?: string }
    ) => {
      if (participantProfileRef.current === null && !options?.forceTest) {
        return false;
      }
      const signature = buildConcoursAlertSignature(concours);
      const lastSeenSig = loadLastNotifiedSignature();

      if (!options?.forceTest && lastSeenSig === signature) {
        return false;
      }
      const lastSeenNumber = Number(lastSeenSig?.split(':', 1)[0]);
      if (!options?.forceTest && lastSeenNumber === concours.number) {
        saveLastNotifiedSignature(signature, concours.number);
        return false;
      }

      if (!options?.forceTest) {
        saveLastNotifiedSignature(signature, concours.number);
      }

      const timeStr = `${formatUtcPlusOneShortTime()} +1`;
      const prevConcoursNumber = concours.number - 1;
      const isFr = langRef.current === 'FR';
      const title =
        options?.customTitle ||
        (isFr
          ? `Nouvelle grille N° ${concours.number} disponible`
          : `قصاصة جديدة رقم ${concours.number} في خانة القصاصة`);
      const message =
        options?.customBody ||
        (isFr
          ? `La grille #${concours.number} (${concours.cagnotteEstimate}) est prête — la grille précédente #${prevConcoursNumber} est affichée dans Tirage.`
          : `القصاصة #${concours.number} (${concours.cagnotteEstimate}) جاهزة الآن — والقصاصة السابقة #${prevConcoursNumber} ظاهرة في خانة Tirage.`);

      appendGeneralNotification({
        id: `grille-${concours.number}-${options?.forceTest ? Date.now() : signature}`,
        kind: 'grille',
        targetTab: 'grille',
        title,
        message,
        scoreLabel: concours.cagnotteEstimate,
      });

      if (!isLiveTabActiveRef.current) {
        triggerGeneralFloatingAlert(concours.number, title, concours.cagnotteEstimate);
        setGeneralToastAlert({
          id: `new-grille-${concours.number}-${Date.now()}`,
          title,
          message,
          type: 'grille',
          targetTab: 'grille',
          timestamp: timeStr,
        });
        if (settings.soundEnabled && settings.notificationSoundEnabled) {
          audioService.playTimedAlert(settings.notificationSoundStyle, settings.notificationSoundDurationSeconds);
        }
      }

      emitPushIfEnabled(
        title,
        message,
        concours.number,
        signature,
        `promosport-grille-${concours.number}`,
        'grille'
      );
      return true;
    },
    [settings.soundEnabled, settings.notificationSoundEnabled, settings.notificationSoundStyle, settings.notificationSoundDurationSeconds, emitPushIfEnabled, triggerGeneralFloatingAlert, appendGeneralNotification]
  );

  // Synchronizes active concours & Tirage archive from promosport-pronostic.com / /api/promosport/sync
  const syncFromServer = useCallback(
    async (isAuto = false, force = false) => {
      const payload = await fetchPromosportSyncState(force);
      const nowMs = Date.now();
      const timeStr = `${formatUtcPlusOneShortTime(nowMs)} +1`;

      const currentConcours = activeConcoursRef.current;
      let nextConcours = payload.activeConcours;

      // Auto-rollover: immediately adopt any newer active grille from promosport-pronostic.com
      const didRollover = nextConcours.number > currentConcours.number;
      if (nextConcours.number < currentConcours.number) {
        nextConcours = currentConcours;
      }

      const prizeValue = String(nextConcours.cagnotteEstimate || '').trim();
      const previousPrize = lastActivePrizeRef.current;
      const hasUsablePrize = Boolean(prizeValue) && !/^(—|-|غير محدد|قيد التحديد الرسمي)$/i.test(prizeValue);
      if (previousPrize.concoursNumber === nextConcours.number && hasUsablePrize && previousPrize.value && previousPrize.value !== prizeValue && settings.notifyJackpotRollover) {
        const prizeTag = `jackpot-${nextConcours.number}-${prizeValue.replace(/\s+/g, '-')}`;
        const isFr = langRef.current === 'FR';
        const prizeTitle = isFr
          ? `Mise à jour de la cagnotte — Grille ${nextConcours.number}`
          : `تحديث قيمة الجائزة الكبرى — القصاصة ${nextConcours.number}`;
        const prizeMessage = isFr
          ? `Nouvelle cagnotte estimée : ${prizeValue}`
          : `القيمة الجديدة للجائزة الكبرى: ${prizeValue}`;
        appendGeneralNotification({
          id: prizeTag,
          kind: 'cagnotte',
          targetTab: 'grille',
          title: prizeTitle,
          message: prizeMessage,
          scoreLabel: prizeValue,
        });
        if (!isLiveTabActiveRef.current) {
          triggerGeneralFloatingAlert(nextConcours.number, prizeTitle, prizeValue);
          setGeneralToastAlert({
            id: prizeTag,
            title: prizeTitle,
            message: prizeMessage,
            type: 'cagnotte',
            targetTab: 'grille',
            timestamp: timeStr,
          });
          if (settings.soundEnabled && settings.notificationSoundEnabled) {
            audioService.playTimedAlert(settings.notificationSoundStyle, settings.notificationSoundDurationSeconds);
          }
        }
        emitPushIfEnabled(prizeTitle, prizeMessage, nextConcours.number, prizeTag, prizeTag, 'grille');
      }
      lastActivePrizeRef.current = { concoursNumber: nextConcours.number, value: prizeValue };

      const prevGrilles = grillesRef.current;
      let archivedList = mergeGrilleArchives(payload.grilles, prevGrilles);

      // Always move superseded active grille into Tirage on rollover, even if winnersCount / prizePerWinner haven't published yet
      if (didRollover || isConcoursCompletelyFinished(currentConcours, nowMs)) {
        const existing = archivedList.find((g) => g.number === currentConcours.number);
        const archivedCurrent = archiveConcoursToGrille(currentConcours, existing);
        archivedList = mergeGrilleArchives(archivedList, [archivedCurrent]);
      }

      // Strictly guarantee N-1 exists in Tirage archive whenever active concours is N
      const expectedPrevNum = nextConcours.number - 1;
      if (!archivedList.some((g) => g.number === expectedPrevNum)) {
        if (currentConcours.number === expectedPrevNum) {
          archivedList = mergeGrilleArchives(archivedList, [archiveConcoursToGrille(currentConcours)]);
        } else if (expectedPrevNum === INITIAL_WEEKLY_CONCOURS.number) {
          archivedList = mergeGrilleArchives(archivedList, [archiveConcoursToGrille(INITIAL_WEEKLY_CONCOURS)]);
        }
      }

      saveCachedGrilles(archivedList);

      setGrilles((prev) => {
        if (
          prev.length === archivedList.length &&
          prev.every(
            (pg, i) =>
              pg.number === archivedList[i].number &&
              pg.status === archivedList[i].status &&
              pg.cagnotte === archivedList[i].cagnotte &&
              pg.winnersCount === archivedList[i].winnersCount &&
              pg.prizePerWinner === archivedList[i].prizePerWinner &&
              pg.winnersFormatted === archivedList[i].winnersFormatted
          )
        ) {
          return prev;
        }
        return archivedList;
      });

      if (didRollover || nextConcours.number === currentConcours.number) {
        setWeeklyConcours((prev) => {
          const merged = didRollover
            ? nextConcours
            : mergeConcoursPreservingScores(prev, nextConcours);
          if (
            !didRollover &&
            prev.number === merged.number &&
            prev.matches.length === merged.matches.length &&
            prev.matches.every(
              (pm, idx) =>
                pm.status === merged.matches[idx].status &&
                pm.score === merged.matches[idx].score &&
                pm.liveMinute === merged.matches[idx].liveMinute &&
                pm.isDelayed === merged.matches[idx].isDelayed
            )
          ) {
            return prev;
          }
          saveCachedConcours(merged);
          return merged;
        });
      }

      if (didRollover) {
        setAppSettings((prev) => {
          if (prev.concoursNumber === nextConcours.number) return prev;
          const updatedSettings = { ...prev, concoursNumber: nextConcours.number };
          saveAppSettings(updatedSettings);
          return updatedSettings;
        });
        prevLiveSnapshotRef.current = null;
      }

      const expectedTiragePrev = nextConcours.number - 1;
      const isFrRollover = langRef.current === 'FR';
      const announcedNewGrille = settings.notifyNewGrille
        ? triggerNewGrilleAnnouncement(nextConcours, {
            customTitle: didRollover
              ? isFrRollover
                ? `Nouvelle grille N° ${nextConcours.number} dans Grille`
                : `قصاصة جديدة رقم ${nextConcours.number} في خانة القصاصة`
              : undefined,
            customBody: didRollover
              ? isFrRollover
                ? `Grille ${nextConcours.number} disponible (${nextConcours.cagnotteEstimate}) — grille précédente ${expectedTiragePrev} affichée dans Tirage.`
                : `ظهرت القصاصة ${nextConcours.number} في خانة القصاصة (${nextConcours.cagnotteEstimate}) — والقصاصة السابقة ${expectedTiragePrev} ظاهرة الآن في خانة Tirage.`
              : undefined,
          })
        : false;

      // Detect first publication of financial value ("القيمة المالية"), winnersCount ("عدد المرابيح"), and share ("نصيب كل فائز") on recent Tirage grille
      let announcedWinners = false;
      const notifiedWinners = loadNotifiedWinnersMap();
      const recentArchived = archivedList
        .filter((g) => g.number < nextConcours.number)
        .sort((a, b) => b.number - a.number);

      for (const g of recentArchived) {
        const hasPayoutsPublished =
          g.status === 'official' &&
          g.winnersFormatted &&
          g.winnersFormatted !== 'قيد التحديد الرسمي';
        const hasCagnottePublished = g.cagnotte > 0 && g.cagnotteFormatted !== 'قيد التحديد الرسمي';

        if (hasPayoutsPublished || hasCagnottePublished) {
          const winSig = `${g.number}:${g.cagnotte}:${g.winnersCount}:${g.prizePerWinner}:${g.status}`;
          const prevRecorded = notifiedWinners[g.number];
          const wasPendingInUi = prevGrilles.some((pg) => pg.number === g.number && pg.status === 'pending');

          if (prevRecorded !== winSig) {
            saveNotifiedWinnersSignature(g.number, winSig);
            const isNewestTirage = recentArchived[0]?.number === g.number;
            if ((isNewestTirage || wasPendingInUi) && settings.notifyOfficialResults && !announcedWinners) {
              announcedWinners = true;
              const isFrWin = langRef.current === 'FR';
              const wTitle = hasPayoutsPublished
                ? isFrWin
                  ? `Cagnotte & Gagnants officiels — Tirage ${g.number}`
                  : `إعلان القيمة المالية والمرابيح — القصاصة ${g.number}`
                : isFrWin
                  ? `Mise à jour de la cagnotte — Tirage ${g.number}`
                  : `تحديث القيمة المالية — القصاصة ${g.number}`;
              const wMsg = hasPayoutsPublished
                ? isFrWin
                  ? `Cagnotte : ${g.cagnotteFormatted} • Gagnants : ${g.winnersFormatted} • Part : ${g.prizePerWinnerFormatted}`
                  : `القيمة المالية: ${g.cagnotteFormatted} • المرابيح: ${g.winnersFormatted} • نصيب كل فائز: ${g.prizePerWinnerFormatted}`
                : isFrWin
                  ? `Cagnotte : ${g.cagnotteFormatted}`
                  : `القيمة المالية: ${g.cagnotteFormatted} — بقية القصاصة ثابتة كصورة مجمدة`;
              appendGeneralNotification({
                id: `winners-${g.number}-${winSig}`,
                kind: 'winners',
                targetTab: 'tirage',
                title: wTitle,
                message: wMsg,
                scoreLabel: g.cagnotteFormatted,
              });
              if (!isLiveTabActiveRef.current) {
                triggerGeneralFloatingAlert(
                  g.number,
                  wTitle,
                  hasPayoutsPublished
                    ? `${g.cagnotteFormatted} | ${g.winnersFormatted} | ${g.prizePerWinnerFormatted}`
                    : g.cagnotteFormatted,
                  'tirage'
                );
                setGeneralToastAlert({
                  id: `winners-${g.number}-${Date.now()}`,
                  title: wTitle,
                  message: wMsg,
                  type: 'result',
                  targetTab: 'tirage',
                  timestamp: timeStr,
                });
                if (settings.soundEnabled && settings.notificationSoundEnabled) {
                  audioService.playTimedAlert(settings.notificationSoundStyle, settings.notificationSoundDurationSeconds);
                }
              }
              emitPushIfEnabled(wTitle, wMsg, g.number, winSig, `promosport-winners-${g.number}`, 'tirage');
            }
          }
        }
      }

      if (!announcedNewGrille && !announcedWinners && isAuto && settings.notifyOfficialResults) {
        const isFrSync = langRef.current === 'FR';
        const title = isFrSync ? 'Synchronisation réussie' : 'تحيين دوري ناجح';
        const message = isFrSync
          ? `Mise à jour auto (${settings.checkIntervalMinutes} min) — Grille ${nextConcours.number} (${nextConcours.cagnotteEstimate}).`
          : `تحديث دوري (كل ${settings.checkIntervalMinutes} دقيقة) — القصاصة ${nextConcours.number} (${nextConcours.cagnotteEstimate}).`;
        appendGeneralNotification({
          id: `sync-${nextConcours.number}-${Date.now()}`,
          kind: 'system',
          targetTab: 'grille',
          title,
          message,
          scoreLabel: nextConcours.cagnotteEstimate,
        });
        if (!isLiveTabActiveRef.current) {
          triggerGeneralFloatingAlert(nextConcours.number, title, nextConcours.cagnotteEstimate);
          setGeneralToastAlert({
            id: `sync-${Date.now()}`,
            title,
            message,
            type: 'result',
            targetTab: 'grille',
            timestamp: timeStr,
          });
          if (settings.soundEnabled) {
            audioService.playChime();
          }
        }
        emitPushIfEnabled(title, message, nextConcours.number);
      }
    },
    [
      settings.notifyNewGrille,
      settings.notifyOfficialResults,
      settings.notifyJackpotRollover,
      settings.checkIntervalMinutes,
      settings.soundEnabled,
      settings.notificationSoundEnabled,
      settings.notificationSoundStyle,
      settings.notificationSoundDurationSeconds,
      emitPushIfEnabled,
      triggerNewGrilleAnnouncement,
      triggerGeneralFloatingAlert,
      appendGeneralNotification,
    ]
  );

  // Initial sync with server on mount & handle deep-link ?openGrille=1 / ?openSettings=1 (after registration)
  useEffect(() => {
    void syncFromServer(false, true);

    try {
      const params = new URLSearchParams(window.location.search);
      if (participantProfileRef.current !== null) {
        if (params.get('openSettings') === '1') {
          setWeeklyConcoursTab('settings');
          setShowLandingIntro(false);
          params.delete('openSettings');
        } else if (['grille', 'tirage', 'live', 'apk'].includes(params.get('openTab') || '')) {
          const targetTab = params.get('openTab') as NotificationTargetTab;
          navigateFromNotification(targetTab);
          params.delete('openTab');
        } else if (params.get('openGrille') === '1') {
          navigateFromNotification('grille');
          params.delete('openGrille');
        }
        const nextUrl =
          window.location.pathname + (params.toString() ? `?${params.toString()}` : '') + window.location.hash;
        window.history.replaceState({}, '', nextUrl);
      }
    } catch {
      // ignore URL parsing errors
    }
  }, []);

  // Automatically ensure device Notification permission & listen for wake-from-idle + Service Worker messages
  useEffect(() => {
    const requestPermissionOnFirstGesture = () => {
      if (participantProfileRef.current === null) return;
      if (hasRequestedPermissionRef.current) return;
      hasRequestedPermissionRef.current = true;
      if (settings.pushNotificationsEnabled && typeof window !== 'undefined' && 'Notification' in window) {
        void ensureDesktopPushSubscribed(Notification.permission === 'default')
          .then(({ permission }) => {
            if (permission === 'granted') {
              const current = activeConcoursRef.current;
              const sig = buildConcoursAlertSignature(current);
              saveLastNotifiedSignature(sig, current.number);
            }
          })
          .catch(() => {});
      }
    };

    if (!isRegistrationPending) {
      window.addEventListener('pointerdown', requestPermissionOnFirstGesture, { once: true, passive: true });
    }

    const handleWakeSync = () => {
      if (document.visibilityState === 'visible') {
        void syncFromServer(false, true);
      }
    };

    const handleFocusOrOnline = () => {
      void syncFromServer(false, true);
    };

    document.addEventListener('visibilitychange', handleWakeSync);
    window.addEventListener('focus', handleFocusOrOnline);
    window.addEventListener('online', handleFocusOrOnline);

    const handleSwMessage = (event: MessageEvent) => {
      const data = event.data;
      if (!data || typeof data !== 'object') return;
      if (data.type === 'OPEN_NOTIFICATION_TARGET') {
        const targetTab = ['grille', 'tirage', 'live', 'apk'].includes(data.targetTab)
          ? (data.targetTab as NotificationTargetTab)
          : 'grille';
        navigateFromNotification(targetTab);
      } else if (data.type === 'OPEN_GRILLE_FROM_NOTIFICATION') {
        navigateFromNotification('grille');
      } else if (data.type === 'NEW_GRILLE_DETECTED' && data.concours) {
        setWeeklyConcours(data.concours as WeeklyConcours);
        if (settings.notifyNewGrille) {
          triggerNewGrilleAnnouncement(data.concours as WeeklyConcours, { forceTest: true });
          if (typeof data.signature === 'string') {
            saveLastNotifiedSignature(data.signature, (data.concours as WeeklyConcours).number);
          }
        }
      }
    };

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.addEventListener('message', handleSwMessage);
    }

    return () => {
      window.removeEventListener('pointerdown', requestPermissionOnFirstGesture);
      document.removeEventListener('visibilitychange', handleWakeSync);
      window.removeEventListener('focus', handleFocusOrOnline);
      window.removeEventListener('online', handleFocusOrOnline);
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.removeEventListener('message', handleSwMessage);
      }
    };
  }, [isRegistrationPending, settings.pushNotificationsEnabled, settings.notifyNewGrille, syncFromServer, triggerNewGrilleAnnouncement, navigateFromNotification]);

  // Reactive live goal, kickoff & full-time monitor whenever concours updates
  useEffect(() => {
    const now = Date.now();
    const evaluated = evaluateConcoursRealTime(weeklyConcours, now);
    const timeStr = `${formatUtcPlusOneShortTime(now)} +1`;

    const nextSnapshot: Record<
      number,
      { status: string; home: string; away: string; hasScore: boolean; delayed: boolean }
    > = {};
    evaluated.matches.forEach((m) => {
      const hasScore =
        !m.isDelayed &&
        m.scoreHome !== undefined &&
        m.scoreAway !== undefined &&
        /^\d+$/.test(String(m.scoreHome)) &&
        /^\d+$/.test(String(m.scoreAway));
      nextSnapshot[m.id] = {
        status: m.status,
        home: hasScore ? String(m.scoreHome) : '',
        away: hasScore ? String(m.scoreAway) : '',
        hasScore,
        delayed: Boolean(m.isDelayed),
      };
    });

    const prevSnapshot = prevLiveSnapshotRef.current;
    if (prevSnapshot) {
      for (const m of evaluated.matches) {
        const prev = prevSnapshot[m.id];
        const curSnap = nextSnapshot[m.id];
        if (!prev || !curSnap || curSnap.delayed) continue;

        const curH = Number(curSnap.home || 0);
        const curA = Number(curSnap.away || 0);
        const prevH = Number(prev.home || 0);
        const prevA = Number(prev.away || 0);

        // 1. Live Goal Scored Event (only on verified score increase)
        if (
          curSnap.hasScore &&
          (m.status === 'live' || (prev.status === 'live' && m.status === 'finished')) &&
          ((prev.hasScore && (curH > prevH || curA > prevA)) || (!prev.hasScore && (curH > 0 || curA > 0)))
        ) {
          const isFr = langRef.current === 'FR';
          const hTeam = isFr
            ? translateTeamToFrench(m.homeTeam, m.homeTeamFr)
            : translateTeamToArabic(m.homeTeam, m.homeTeamFr);
          const aTeam = isFr
            ? translateTeamToFrench(m.awayTeam, m.awayTeamFr)
            : translateTeamToArabic(m.awayTeam, m.awayTeamFr);
          const title = isFr
            ? `BUT ! (${hTeam} ${curSnap.home} - ${curSnap.away} ${aTeam})`
            : `هدف مسجل الآن! (${hTeam} ${curSnap.home} - ${curSnap.away} ${aTeam})`;
          const message = isFr
            ? `Direct instantané • ${m.liveMinute || "1'"} — Grille N° ${evaluated.number}`
            : `تحديث فوري مباشر • الدقيقة ${m.liveMinute || "1'"} — القصاصة رقم ${evaluated.number}`;
          const goalTag = `goal-${evaluated.number}-${m.id}-${curSnap.home}-${curSnap.away}`;
          appendLiveNotification({
            id: goalTag,
            kind: 'goal',
            targetTab: 'live',
            title,
            message,
            scoreLabel: `${curSnap.home} - ${curSnap.away}`,
          });
          if (isLiveTabActiveRef.current) {
            triggerLiveFloatingAlert(evaluated.number, title, `${curSnap.home} - ${curSnap.away}`);
            setLiveToastAlert({
              id: `goal-${m.id}-${Date.now()}`,
              title,
              message,
              type: 'golden',
              targetTab: 'live',
              timestamp: timeStr,
            });
            if (settings.soundEnabled && settings.goalSoundEnabled) audioService.playTimedAlert(settings.goalSoundStyle, settings.goalSoundDurationSeconds);
          }
          emitPushIfEnabled(title, message, evaluated.number, goalTag, goalTag, 'live');
        }
        // 2. Kickoff Started Event (strictly from verified live feed)
        else if (prev.status === 'scheduled' && m.status === 'live' && curSnap.hasScore) {
          const isFr = langRef.current === 'FR';
          const hTeam = isFr
            ? translateTeamToFrench(m.homeTeam, m.homeTeamFr)
            : translateTeamToArabic(m.homeTeam, m.homeTeamFr);
          const aTeam = isFr
            ? translateTeamToFrench(m.awayTeam, m.awayTeamFr)
            : translateTeamToArabic(m.awayTeam, m.awayTeamFr);
          const title = isFr
            ? `Coup d'envoi #${m.id} : ${hTeam} vs ${aTeam}`
            : `انطلاق المقابلة #${m.id}: ${hTeam} ضد ${aTeam}`;
          const message = isFr
            ? `Match commencé (${curSnap.home} - ${curSnap.away}) avec suivi en direct.`
            : `بدأت المقابلة الآن (${curSnap.home} - ${curSnap.away}) مع التحديث المباشر.`;
          const kickoffTag = `kickoff-${evaluated.number}-${m.id}`;
          appendLiveNotification({
            id: kickoffTag,
            kind: 'kickoff',
            targetTab: 'live',
            title,
            message,
            scoreLabel: `${curSnap.home} - ${curSnap.away}`,
          });
          if (isLiveTabActiveRef.current) {
            triggerLiveFloatingAlert(
              evaluated.number,
              title,
              isFr ? `En direct ${curSnap.home} - ${curSnap.away}` : `مباشر الآن ${curSnap.home} - ${curSnap.away}`
            );
            setLiveToastAlert({
              id: `kickoff-${m.id}-${Date.now()}`,
              title,
              message,
              type: 'result',
              targetTab: 'live',
              timestamp: timeStr,
            });
            if (settings.soundEnabled && settings.notificationSoundEnabled) audioService.playTimedAlert(settings.notificationSoundStyle, settings.notificationSoundDurationSeconds);
          }
          emitPushIfEnabled(title, message, evaluated.number, kickoffTag, kickoffTag, 'live');
        }
        // 3. Match Full-Time Event (strictly from verified finished score)
        else if (prev.status !== 'finished' && m.status === 'finished' && curSnap.hasScore) {
          const isFr = langRef.current === 'FR';
          const hTeam = isFr
            ? translateTeamToFrench(m.homeTeam, m.homeTeamFr)
            : translateTeamToArabic(m.homeTeam, m.homeTeamFr);
          const aTeam = isFr
            ? translateTeamToFrench(m.awayTeam, m.awayTeamFr)
            : translateTeamToArabic(m.awayTeam, m.awayTeamFr);
          const title = isFr
            ? `Fin du match #${m.id} : ${hTeam} ${curSnap.home} - ${curSnap.away} ${aTeam}`
            : `نهاية المقابلة #${m.id}: ${hTeam} ${curSnap.home} - ${curSnap.away} ${aTeam}`;
          const message = isFr
            ? `Score final : ${m.result || '-'} • Concours N° ${evaluated.number}`
            : `النتيجة النهائية: ${m.result || '-'} • مسابقة رقم ${evaluated.number}`;
          const ftTag = `ft-${evaluated.number}-${m.id}`;
          if (settings.notifyOfficialResults) {
            appendLiveNotification({
              id: ftTag,
              kind: 'result',
              targetTab: 'live',
              title,
              message,
              scoreLabel: `${curSnap.home} - ${curSnap.away}`,
            });
            if (isLiveTabActiveRef.current) {
              triggerLiveFloatingAlert(evaluated.number, title, `FT ${curSnap.home} - ${curSnap.away}`);
              setLiveToastAlert({
                id: `ft-${m.id}-${Date.now()}`,
                title,
                message,
                type: 'result',
                targetTab: 'live',
                timestamp: timeStr,
              });
              if (settings.soundEnabled && settings.notificationSoundEnabled) audioService.playTimedAlert(settings.notificationSoundStyle, settings.notificationSoundDurationSeconds);
            }
            emitPushIfEnabled(title, message, evaluated.number, ftTag, ftTag, 'live');
          }
        }
      }
    }

    prevLiveSnapshotRef.current = nextSnapshot;
  }, [weeklyConcours, settings.soundEnabled, settings.goalSoundEnabled, settings.goalSoundStyle, settings.goalSoundDurationSeconds, settings.notificationSoundEnabled, settings.notificationSoundStyle, settings.notificationSoundDurationSeconds, settings.notifyOfficialResults, emitPushIfEnabled, triggerLiveFloatingAlert, appendLiveNotification]);

  // Lightweight 10-second live sync polling (replaces heavy 1-second timer)
  useEffect(() => {
    const syncId = window.setInterval(() => {
      void syncFromServer(false, false);
    }, 10000);
    return () => window.clearInterval(syncId);
  }, [syncFromServer]);

  // Background watcher for live goal alerts across the real-time matches catalog (respects scanEnabled toggle)
  useEffect(() => {
    let active = true;
    const pollLiveCatalogGoals = async () => {
      if (!loadLiveScanEnabled()) return;
      try {
        const scan = await fetchPromosportLiveMatchesScan(false);
        if (!active || !scan || !Array.isArray(scan.matches)) return;

        const nextScores: Record<string, { home: number; away: number; status: string }> = {};
        const prevScores = prevLiveCatalogScoresRef.current;
        const timeStr = `${formatUtcPlusOneShortTime()} +1`;

        for (const m of scan.matches) {
          if (!m.hasVerifiedScore || m.scoreHome === undefined || m.scoreAway === undefined) continue;
          const homeStr = String(m.scoreHome).trim();
          const awayStr = String(m.scoreAway).trim();
          if (!/^\d+$/.test(homeStr) || !/^\d+$/.test(awayStr)) continue;
          const curH = Number(homeStr);
          const curA = Number(awayStr);
          const matchKey = m.siteMatchId || `${m.id}-${m.homeTeam}`;
          nextScores[matchKey] = { home: curH, away: curA, status: m.status };

          if (prevScores && prevScores[matchKey] && m.status === 'live') {
            const prev = prevScores[matchKey];
            if (curH > prev.home || curA > prev.away) {
              const isFr = langRef.current === 'FR';
              const hTeam = isFr
                ? translateTeamToFrench(m.homeTeam, m.homeTeamFr)
                : translateTeamToArabic(m.homeTeam, m.homeTeamFr);
              const aTeam = isFr
                ? translateTeamToFrench(m.awayTeam, m.awayTeamFr)
                : translateTeamToArabic(m.awayTeam, m.awayTeamFr);
              const leagueAr = m.leagueName
                ? translateCompetitionToArabic(m.leagueName, m.leagueName)
                : 'المباريات المباشرة';
              const scoreLabel = `${curH} - ${curA}`;
              const title = isFr
                ? `BUT EN DIRECT ! ${hTeam} ${scoreLabel} ${aTeam}`
                : `هدف مباشر! ${hTeam} ${scoreLabel} ${aTeam}`;
              const message = isFr
                ? `${m.leagueName || 'Matchs en direct'} • ${m.liveMinute || "1'"}`
                : `${leagueAr} • الدقيقة ${m.liveMinute || "1'"}`;
              const goalTag = `live-goal-${matchKey}-${curH}-${curA}`;

              appendLiveNotification({
                id: goalTag,
                kind: 'goal',
                targetTab: 'live',
                title,
                message,
                scoreLabel,
                leagueLabel: m.leagueName,
              });
              if (isLiveTabActiveRef.current) {
                triggerLiveFloatingAlert(activeConcoursRef.current.number, title, scoreLabel);
                setLiveToastAlert({
                  id: `${goalTag}-${Date.now()}`,
                  title,
                  message,
                  type: 'golden',
                  targetTab: 'live',
                  timestamp: timeStr,
                });
                if (settings.soundEnabled && settings.goalSoundEnabled) audioService.playTimedAlert(settings.goalSoundStyle, settings.goalSoundDurationSeconds);
              }
              emitPushIfEnabled(title, message, activeConcoursRef.current.number, goalTag, goalTag, 'live');
            }
          }
        }

        prevLiveCatalogScoresRef.current = nextScores;
      } catch {
        // ignore transient network errors
      }
    };

    void pollLiveCatalogGoals();
    const id = window.setInterval(() => {
      void pollLiveCatalogGoals();
    }, 25000);

    return () => {
      active = false;
      window.clearInterval(id);
    };
  }, [appendLiveNotification, emitPushIfEnabled, settings.soundEnabled, settings.goalSoundEnabled, settings.goalSoundStyle, settings.goalSoundDurationSeconds, triggerLiveFloatingAlert]);

  // Periodic automated sync check for new concours based on checkIntervalMinutes (15 / 30 / 60 min)
  useEffect(() => {
    if (!settings.autoUpdateActive) return;

    const intervalMs = settings.checkIntervalMinutes * 60 * 1000;
    const intervalId = setInterval(() => {
      void syncFromServer(true, true);
    }, intervalMs);

    return () => clearInterval(intervalId);
  }, [settings.autoUpdateActive, settings.checkIntervalMinutes, syncFromServer]);

  // Auto-record any appSettings, notificationSettings, concours, or slips updates into workspace & Capacitor ZIP state
  const hasInitializedWorkspaceSyncRef = useRef(false);
  useEffect(() => {
    if (!hasInitializedWorkspaceSyncRef.current) {
      hasInitializedWorkspaceSyncRef.current = true;
      return;
    }
    const timer = window.setTimeout(() => {
      void syncAppChangesToWorkspace({
        appSettings,
        notificationSettings: settings,
        userSlips: loadUserSlips(),
        concours: weeklyConcours,
      });
    }, 650);
    return () => window.clearTimeout(timer);
  }, [appSettings, settings, weeklyConcours]);

  const handleImmediateUpdateSettings = useCallback((newSettings: NotificationSettings) => {
    setSettings(newSettings);
    saveSettings(newSettings);
    audioService.setSoundEnabled(newSettings.soundEnabled);
    audioService.setGoalSoundStyle(newSettings.goalSoundStyle);
    audioService.setClickSoundEnabled(newSettings.clickSoundEnabled);
    audioService.setClickSoundStyle(newSettings.clickSoundStyle);
  }, []);

  const handleSaveSettings = (newSettings: NotificationSettings) => {
    handleImmediateUpdateSettings(newSettings);
    const isFr = langRef.current === 'FR';

    const savedPayload = {
      id: `saved-${Date.now()}`,
      title: isFr ? 'Paramètres enregistrés et activés' : 'تم حفظ وتفعيل منظومة التحديثات بنجاح',
      message: isFr
        ? `${
            newSettings.autoUpdateActive
              ? `Vérification auto toutes les ${newSettings.checkIntervalMinutes} min`
              : 'Mise à jour auto désactivée'
          } • Direct actif en continu.`
        : `${
            newSettings.autoUpdateActive
              ? `فحص القصاصات الجديدة كل ${newSettings.checkIntervalMinutes} دقيقة`
              : 'التحديث التلقائي للقصاصات متوقف'
          } • التحديث المباشر كل ثانية مفعل دوماً.`,
      timestamp: `${formatUtcPlusOneShortTime()} +1`,
    };

    if (isLiveTabActiveRef.current) {
      setLiveToastAlert({ ...savedPayload, type: 'system', targetTab: 'live' });
    } else {
      setGeneralToastAlert({ ...savedPayload, type: 'system', targetTab: 'grille' });
    }
  };

  const handleTriggerTestAlert = (section: NotificationSectionTab) => {
    setIsNotificationsOpen(false);
    const isFr = langRef.current === 'FR';
    if (section === 'live') {
      const timeStr = `${formatUtcPlusOneShortTime()} +1`;
      const title = isFr ? 'Test Alerte Direct — BUT !' : 'تجربة تنبيه المباشر — هدف مباشر!';
      const message = isFr
        ? 'Test notification Section 1 (active uniquement dans Direct).'
        : 'تجربة إشعار القسم الأول (مفعل ويظهر في خانة المباشر وحدها).';
      appendLiveNotification(
        {
          id: `test-live-${Date.now()}`,
          kind: 'goal',
          targetTab: 'live',
          title,
          message,
          scoreLabel: '1 - 0',
        },
        { silent: true }
      );
      setShowLandingIntro(false);
      setWeeklyConcoursTab('live');
      setLiveFloatingAlert({
        id: `test-live-beacon-${Date.now()}`,
        concoursNumber: weeklyConcours.number,
        title,
        cagnotte: '1 - 0',
        createdAtMs: Date.now(),
      });
      setLiveToastAlert({
        id: `test-live-toast-${Date.now()}`,
        title,
        message,
        type: 'golden',
        targetTab: 'live',
        timestamp: timeStr,
      });
      if (settings.soundEnabled && settings.goalSoundEnabled) {
        audioService.playTimedAlert(settings.goalSoundStyle, settings.goalSoundDurationSeconds);
      }
      return;
    }

    if (isLiveTabActiveRef.current) {
      setWeeklyConcoursTab('grille');
    }
    triggerNewGrilleAnnouncement(weeklyConcours, {
      forceTest: true,
      customTitle: isFr
        ? `Nouvelle grille N° ${weeklyConcours.number} disponible`
        : `إشعار قصاصة جديدة رقم ${weeklyConcours.number} في خانة القصاصة`,
      customBody: isFr
        ? `Cagnotte ${weeklyConcours.cagnotteEstimate} • Tirage précédent #${weeklyConcours.number - 1} dans Tirage.`
        : `الجائزة الكبرى ${weeklyConcours.cagnotteEstimate} • القصاصة السابقة #${weeklyConcours.number - 1} ظاهرة في خانة Tirage.`,
    });
  };

  const handleStableRefreshSync = useCallback(() => {
    return syncFromServer(false, true);
  }, [syncFromServer]);

  const handleCloseModalToGrille = useCallback(() => {
    setWeeklyConcoursTab('grille');
  }, []);

  const handleUpdateAppSettings = useCallback((updated: AppSettings) => {
    setAppSettings(updated);
    saveAppSettings(updated);
  }, []);

  const handleOpenNotifications = useCallback((section?: NotificationSectionTab) => {
    const resolvedSection: NotificationSectionTab =
      section ?? (isLiveTabActiveRef.current ? 'live' : 'general');
    setNotificationModalSection(resolvedSection);
    if (resolvedSection === 'live') {
      setLiveUnreadCount(0);
    } else {
      setGeneralUnreadCount(0);
    }
    setIsNotificationsOpen(true);
  }, []);

  const handleOpenLiveNotification = useCallback((item: LiveNotificationItem) => {
    const targetTab = item.targetTab || (
      item.kind === 'message'
        ? 'messages'
        : item.kind === 'grille' || item.kind === 'cagnotte'
        ? 'grille'
        : item.kind === 'winners'
          ? 'tirage'
          : 'live'
    );
    if (targetTab === 'live') {
      setLiveUnreadCount(0);
    } else {
      setGeneralUnreadCount(0);
      if (targetTab === 'messages') {
        setMessagesUnreadCount(0);
      }
    }
    navigateFromNotification(targetTab);
  }, [navigateFromNotification]);

  const activeFloatingAlert = isLiveTabActive ? liveFloatingAlert : generalFloatingAlert;
  const activeToastAlert = isLiveTabActive ? liveToastAlert : generalToastAlert;

  return (
    <div className="relative w-full screen-h-full overflow-hidden bg-[#020612] select-none">
      {/* First-Open One-Time Registration Page OR Home Page (الصفحة الرئيسية) */}
      <PromosportIntroStage
        active={isRegistrationPending || showLandingIntro}
        isClosing={landingClosing}
        mode={isRegistrationPending ? 'register' : 'home'}
        participantProfile={participantProfile}
        onRegisterParticipant={handleRegisterParticipant}
        onVerifyRegisteredParticipant={handleVerifyRegisteredParticipant}
        onReturnToRegistration={handleReturnToRegistration}
        onEnterGrille={handleEnterGrilleFromLogo}
        lang={lang}
        onChangeLang={setLang}
        liveNotifications={generalNotifications}
        onClearNotifications={handleClearGeneralNotifications}
        onOpenNotification={handleOpenLiveNotification}
      />

      {/* Main App Interface */}
      {!isRegistrationPending && !showLandingIntro && (
        <WeeklyConcoursModal
          isOpen={true}
          asMainPage={true}
          onClose={handleCloseModalToGrille}
          onOpenIntroStage={handleReturnToIntroFromMb}
          lang={lang}
          onChangeLang={setLang}
          concours={weeklyConcours}
          onUpdateConcours={setWeeklyConcours}
          grilles={grilles}
          onRefreshSync={handleStableRefreshSync}
          initialTab={weeklyConcoursTab}
          highlightedTab={highlightedTab}
          onTabChange={setWeeklyConcoursTab}
          externalEntryPhase={introEntryPhase}
          appSettings={appSettings}
          onUpdateAppSettings={handleUpdateAppSettings}
          onOpenNotifications={handleOpenNotifications}
          liveNotifications={liveNotifications}
          liveUnreadCount={liveUnreadCount}
          generalUnreadCount={generalUnreadCount}
          onClearLiveNotifications={handleClearLiveNotifications}
          onMarkLiveNotificationsRead={handleMarkLiveNotificationsRead}
          onAppendLiveNotification={appendLiveNotification}
          onScanEnabledChange={handleScanEnabledChange}
          onOpenLiveNotification={handleOpenLiveNotification}
          participantProfile={participantProfile}
          sentMessages={sentMessages}
          receivedMessages={receivedMessages}
          messagesServerError={messagesServerError}
          messagesUnreadCount={messagesUnreadCount}
          openMessagesLogSignal={openMessagesLogSignal}
          onMarkMessagesRead={handleMarkMessagesRead}
          onRefreshMessages={syncMessagesFromServer}
          onSlipMessageSent={handleSlipMessageSent}
          onMessagesChanged={syncMessagesFromServer}
        />
      )}

      {/* Alerts, Notifications & Install Prompts are completely hidden during first-open Registration Page */}
      {!isRegistrationPending && (
        <>
          {/* 10-Second Animated Floating Alert Icon (strictly scoped: Section 1 in المباشر, Section 2 in الصفحة الرئيسية وبقية الخانات) */}
          <FloatingGrilleAlertBadge
            alert={activeFloatingAlert}
            lang={lang}
            onOpenGrille={() => {
              if (isLiveTabActive) {
                navigateFromNotification('live');
              } else {
                const target = generalFloatingAlert?.targetTab || generalToastAlert?.targetTab || 'grille';
                navigateFromNotification(target);
              }
            }}
            onExpire={() => {
              if (isLiveTabActive) {
                setLiveFloatingAlert(null);
              } else {
                setGeneralFloatingAlert(null);
              }
            }}
          />

          {/* Section-scoped Toast Alert (Section 1 in المباشر, Section 2 in الصفحة الرئيسية وبقية الخانات) */}
          {activeToastAlert && (
            <ToastNotification
              alert={activeToastAlert}
              lang={lang}
              onDismiss={() => {
                if (isLiveTabActive) {
                  setLiveToastAlert(null);
                } else {
                  setGeneralToastAlert(null);
                }
              }}
              durationSeconds={settings.durationSeconds}
              onOpen={() => {
                if (!activeToastAlert) return;
                const target = activeToastAlert.targetTab || (
                  activeToastAlert.type === 'grille' || activeToastAlert.type === 'cagnotte'
                    ? 'grille'
                    : activeToastAlert.type === 'golden'
                      ? 'live'
                      : 'tirage'
                );
                navigateFromNotification(target);
              }}
            />
          )}

          {/* Divided Notification System Modal (القسم الأول: خانة المباشر وحدها | القسم الثاني: بقية الخانات مع الصفحة الرئيسية) */}
          <NotificationModal
            isOpen={isNotificationsOpen}
            onClose={() => setIsNotificationsOpen(false)}
            lang={lang}
            onChangeLang={setLang}
            settings={settings}
            onImmediateApply={handleImmediateUpdateSettings}
            onSaveSettings={handleSaveSettings}
            onTriggerTestAlert={handleTriggerTestAlert}
            initialSection={notificationModalSection}
            liveNotifications={liveNotifications}
            generalNotifications={generalNotifications}
            onClearLiveNotifications={handleClearLiveNotifications}
            onClearGeneralNotifications={handleClearGeneralNotifications}
            onOpenNotificationItem={handleOpenLiveNotification}
          />

          {/* PWA Install Prompt & Offline Indicator */}
          <PWAInstallButton
            lang={lang}
            onOpenInstallHub={() => {
              setWeeklyConcoursTab('apk');
            }}
          />
          <OfflineIndicator lang={lang} />
        </>
      )}
    </div>
  );
}
