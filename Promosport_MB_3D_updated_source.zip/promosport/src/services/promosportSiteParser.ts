/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import type { PromosportGrille, PromosportMatch, WeeklyConcours, WeeklyConcoursMatch } from '../types/promosport';
import { computeResultSign } from './matchLiveService';
import { convertTunisTimeToUtc, formatUtcDateString } from './timeUtils';
import { translateCompetitionToArabic, translateTeamToArabic } from './teamTranslationService';

export const PROMOSPORT_PRONOSTIC_HOME_URL = 'https://www.promosport-pronostic.com/welcome/promosport';
export const PROMOSPORT_PRONOSTIC_GRILLE_URL = 'https://www.promosport-pronostic.com/welcome/promo_pronostic?jeux=Promosport';
export const PROMOSPORT_PRONOSTIC_MATCHS_URL = 'https://www.promosport-pronostic.com/welcome/promo_matchs';
export const PROMOSPORT_PRONOSTIC_RAPID_URL = 'https://www.promosport-pronostic.com/welcome/getmatchid_rapid';
export const PROMOSPORT_PRONOSTIC_RESULT_URL = (grilleNumber: number) =>
  `https://www.promosport-pronostic.com/welcome/promo_result?grille=${grilleNumber}&jeux=Promosport`;

const DELAYED_STATUS_TOKENS = new Set([
  'PST',
  'PPD',
  'DEL',
  'DELAYED',
  'POSTPONED',
  'SUSP',
  'SUS',
  'SUSPENDED',
  'CANC',
  'CAN',
  'CANCELLED',
  'CANCELED',
  'ABD',
  'ABANDONED',
  'INT',
  'INTERRUPTED',
  'REPORTE',
  'ANNULE',
  'RETARDE',
]);

const TEAM_CODE_MAP: Record<string, string> = {
  'Wales': 'WAL',
  'Portugal': 'PT',
  'Poland': 'PL',
  'Sweden': 'SE',
  'Denmark': 'DK',
  'Norway': 'NO',
  'Rep. Of Ireland': 'IE',
  'Kosovo': 'XK',
  'Hungary': 'HU',
  'Northern Ireland': 'GB-NIR',
  'Ukraine': 'UA',
  'Georgia': 'GE',
  'Bosnia & Herzegovina': 'BA',
  'Bosnia and Herzegovina': 'BA',
  'Romania': 'RO',
  'Congo': 'CG',
  'Comoros': 'KM',
  'Mauritania': 'MR',
  'Burkina Faso': 'BF',
  'Rwanda': 'RW',
  'Mali': 'ML',
  'Botswana': 'BW',
  'Uganda': 'UG',
  'Liberia': 'LR',
  'Cape Verde Islands': 'CV',
  'Cape Verde': 'CV',
  'Niger': 'NE',
  'Morocco': 'MA',
  'Maroc': 'MA',
  'Spain': 'ES',
  'England': 'GB-ENG',
  'Belgium': 'BE',
  'Italy': 'IT',
  'France': 'FR',
  'Türkiye': 'TR',
  'Turkey': 'TR',
  'Croatia': 'HR',
  'Czechia': 'CZ',
  'Czech Republic': 'CZ',
  'Belarus': 'BY',
  'Albania': 'AL',
  'Cyprus': 'CY',
  'Montenegro': 'ME',
  'Latvia': 'LV',
  'Armenia': 'AM',
  'Algeria': 'DZ',
  'Austria': 'AT',
  'Tunisia': 'TN',
  'Tunisie': 'TN',
  'Egypt': 'EG',
  'Egypte': 'EG',
  'Germany': 'DE',
  'Allemagne': 'DE',
  'Netherlands': 'NL',
  'Pays Bas': 'NL',
  'Switzerland': 'CH',
  'Suisse': 'CH',
  'Greece': 'GR',
  'Grece': 'GR',
  'Scotland': 'GB-SCT',
  'Ecosse': 'GB-SCT',
  'Granada CF': 'GRA',
  'Las Palmas': 'LPA',
  'Eibar': 'EIB',
  'Cadiz': 'CAD',
  'Eldense': 'ELD',
  'Sabadell': 'SAB',
  'Tenerife': 'TEN',
  'AD Ceuta FC': 'CEU',
  'Ceuta': 'CEU',
  'Oviedo': 'OVI',
  'Real Oviedo': 'OVI',
  'Girona': 'GIR',
  'Mallorca': 'MAL',
  'Cordoba': 'COR',
  'Real Sociedad II': 'RSOB',
  'Real Sociedad B': 'RSOB',
  'Sporting Gijon': 'GIJ',
  'Almeria': 'ALM',
  'FC Andorra': 'AND',
};

function decodeHtmlEntities(str: string): string {
  return String(str || '')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&nbsp;/gi, ' ')
    .trim();
}

export function normalizeSiteToken(name: string): string {
  return decodeHtmlEntities(name)
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/rep\.?\s*of\s*/g, '')
    .replace(/republic\s+of\s+/g, '')
    .replace(/[^a-z0-9\u0600-\u06ff]/g, '');
}

const NORMALIZED_TEAM_CODE_MAP: Record<string, string> = Object.entries(TEAM_CODE_MAP).reduce(
  (acc, [name, code]) => {
    acc[normalizeSiteToken(name)] = code;
    return acc;
  },
  {} as Record<string, string>
);

function translateTeamToAr(frName: string): string {
  const clean = decodeHtmlEntities(frName);
  return translateTeamToArabic(clean, clean);
}

function translateCompetitionToAr(compFr: string): string {
  const clean = decodeHtmlEntities(compFr);
  return translateCompetitionToArabic(clean, clean);
}

function getLogoCode(frName: string): string {
  const clean = decodeHtmlEntities(frName);
  if (TEAM_CODE_MAP[clean]) return TEAM_CODE_MAP[clean];
  const norm = normalizeSiteToken(clean);
  if (NORMALIZED_TEAM_CODE_MAP[norm]) return NORMALIZED_TEAM_CODE_MAP[norm];
  return clean.replace(/[^a-zA-Z0-9]/g, '').slice(0, 3).toUpperCase() || 'CLUB';
}

function formatTndNumber(val: number): string {
  if (!Number.isFinite(val) || val <= 0) return '0 DT';
  const rounded = Math.round(val * 1000) / 1000;
  const hasDecimals = Math.abs(rounded - Math.round(rounded)) > 0.0001;
  const [intPart, decPart] = (hasDecimals ? rounded.toFixed(3) : String(Math.round(rounded))).split('.');
  const spacedInt = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  return decPart ? `${spacedInt},${decPart} DT` : `${spacedInt} DT`;
}

function isDelayedToken(rawStatus: string): boolean {
  const clean = decodeHtmlEntities(rawStatus)
    .toUpperCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^A-Z]/g, '');
  return DELAYED_STATUS_TOKENS.has(clean);
}

async function fetchTextSafe(url: string, timeoutMs = 6000): Promise<string | null> {
  try {
    const controller = new AbortController();
    const tid = setTimeout(() => controller.abort(), timeoutMs);
    const res = await fetch(url, {
      signal: controller.signal,
      cache: 'no-store',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36',
        Accept: 'text/html,application/json,*/*',
      },
    });
    clearTimeout(tid);
    if (!res.ok) return null;
    return await res.text();
  } catch {
    return null;
  }
}

export interface SiteRapidMatchEntry {
  match_id: string;
  min?: string;
  st?: string;
  live?: string;
  conf?: string;
  bb1?: string | number;
  bb2?: string | number;
  bh1?: string | number;
  bh2?: string | number;
  time?: string;
}

export async function fetchRapidLiveMap(): Promise<Map<string, SiteRapidMatchEntry>> {
  const map = new Map<string, SiteRapidMatchEntry>();
  try {
    const raw = await fetchTextSafe(PROMOSPORT_PRONOSTIC_RAPID_URL, 5500);
    if (!raw) return map;
    const rows = JSON.parse(raw) as SiteRapidMatchEntry[];
    if (!Array.isArray(rows)) return map;
    for (const r of rows) {
      if (r && r.match_id) {
        map.set(String(r.match_id), r);
      }
    }
  } catch {
    // Ignore transient rapid endpoint failure
  }
  return map;
}

export interface ParsedPromoMatchRow {
  matchId: string;
  homeTeam: string;
  awayTeam: string;
  kickoffTime: string;
  statusText: string;
  isDelayed: boolean;
  isFinished: boolean;
  isLive: boolean;
  scoreHome?: string;
  scoreAway?: string;
  liveMinute?: string;
}

export function parsePromoMatchsHtml(html: string): ParsedPromoMatchRow[] {
  const rows: ParsedPromoMatchRow[] = [];
  if (!html) return rows;

  const seenIds = new Set<string>();
  const homeAnchorRegex = /equipe_home(\d+)[^>]*>([^<]{1,120})<\/span>/gi;
  let matchAnchor: RegExpExecArray | null;

  while ((matchAnchor = homeAnchorRegex.exec(html)) !== null) {
    const id = matchAnchor[1];
    if (!id || seenIds.has(id)) continue;

    const startIdx = matchAnchor.index;
    const chunk = html.slice(startIdx, startIdx + 1350);

    const homeTeam = decodeHtmlEntities(matchAnchor[2]);
    const awayMatch = chunk.match(new RegExp(`equipe_away${id}[^>]*>([^<]{1,120})<\\/span>`, 'i'));
    const awayTeam = awayMatch ? decodeHtmlEntities(awayMatch[1]) : '';
    if (!homeTeam || !awayTeam) continue;

    const liveMatch = chunk.match(new RegExp(`live_matchid${id}"[^>]*>([^<]{0,60})<\\/span>`, 'i'));
    const pstMatch = !liveMatch
      ? chunk.match(/<div class="pn-ms"><span[^>]*>(PST|PPD|DEL|CANC|SUSP|ABD|AWD|Reporté|Annulé)<\/span><\/div>/i)
      : null;

    if (!liveMatch && !pstMatch) continue;
    seenIds.add(id);

    // Locate kickoff time near matchId
    const koIdx = html.indexOf(`retrieveid${id}`, Math.max(0, startIdx - 500));
    let kickoffTime = '';
    if (koIdx > -1 && koIdx < startIdx + 1400) {
      const snippet = html.slice(koIdx, koIdx + 120);
      const koM = snippet.match(/data-ko="([^"]+)"/) || snippet.match(/>([^<]+)</);
      if (koM) kickoffTime = decodeHtmlEntities(koM[1]);
    }

    if (pstMatch && !liveMatch) {
      rows.push({
        matchId: id,
        homeTeam,
        awayTeam,
        kickoffTime,
        statusText: pstMatch[1],
        isDelayed: true,
        isFinished: false,
        isLive: false,
      });
      continue;
    }

    const scoreMatch = chunk.match(new RegExp(`score_matchid${id}[^>]*>([^<]{0,40})<\\/b>`, 'i'));
    const rawScoreText = scoreMatch ? decodeHtmlEntities(scoreMatch[1]) : '';
    const scoreNums = rawScoreText.match(/^(\d+)\s*[-:]\s*(\d+)$/);

    const statusText = decodeHtmlEntities(liveMatch![1]);
    const delayed = isDelayedToken(statusText);
    const finished = !delayed && /^(FT|AET|PEN)$/i.test(statusText.trim());
    const live = !delayed && !finished && /^(1H|2H|HT|ET|LIVE|\d+'?)$/i.test(statusText.trim());

    rows.push({
      matchId: id,
      homeTeam,
      awayTeam,
      kickoffTime,
      statusText,
      isDelayed: delayed,
      isFinished: finished,
      isLive: live,
      scoreHome: !delayed && scoreNums ? scoreNums[1] : undefined,
      scoreAway: !delayed && scoreNums ? scoreNums[2] : undefined,
      liveMinute: live ? statusText.trim() : undefined,
    });
  }

  return rows;
}

export interface ParsedHomeGrilleCard {
  number: number;
  isOpen: boolean;
  dateTimeRaw: string; // e.g. "17/11/2026 20:00"
  cagnotteNum: number;
  winnersCount: number | null; // null if not yet published
}

export function parseHomeGrillesSummary(homeHtml: string): {
  openGrille: ParsedHomeGrilleCard | null;
  resultGrilles: ParsedHomeGrilleCard[];
} {
  const empty = { openGrille: null, resultGrilles: [] as ParsedHomeGrilleCard[] };
  if (!homeHtml) return empty;

  const startIdx = homeHtml.indexOf('id="jeu-Promosport"');
  if (startIdx < 0) return empty;
  const nextSectionIdx = homeHtml.indexOf('id="jeu-Promo7"', startIdx);
  const sectionHtml = homeHtml.slice(startIdx, nextSectionIdx > startIdx ? nextSectionIdx : startIdx + 12000);

  let openGrille: ParsedHomeGrilleCard | null = null;
  const resultGrilles: ParsedHomeGrilleCard[] = [];

  const cardRegex = /<a\s+class="rc\s+(rc-open|rc-res)"[^>]*>([\s\S]*?)<\/a>/gi;
  for (const m of sectionHtml.matchAll(cardRegex)) {
    const kind = m[1];
    const body = m[2];
    const numMatch = body.match(/Grille\s+N[°o]?\s*(\d+)/i) || body.match(/<b>(\d+)<\/b>/i);
    if (!numMatch) continue;
    const number = Number(numMatch[1]);
    const dateMatch = body.match(/<small>([^<]+)<\/small>/i);
    const dateTimeRaw = dateMatch ? decodeHtmlEntities(dateMatch[1]) : '';
    const cagMatch = body.match(/<strong>([\d\s.,]+)\s*(?:TND|DT)?<\/strong>/i);
    const cagnotteNum = cagMatch
      ? Number(cagMatch[1].replace(/\s/g, '').replace(',', '.')) || 0
      : 0;
    const winMatch = body.match(/Gagnants?\s*:\s*(\d+)/i);
    const winnersCount = winMatch ? Number(winMatch[1]) : null;

    const card: ParsedHomeGrilleCard = {
      number,
      isOpen: kind === 'rc-open',
      dateTimeRaw,
      cagnotteNum,
      winnersCount,
    };

    if (kind === 'rc-open') {
      if (!openGrille || card.number > openGrille.number) {
        openGrille = card;
      }
    } else {
      resultGrilles.push(card);
    }
  }

  return { openGrille, resultGrilles };
}

export function parseActiveConcoursFromPromoPronostic(
  html: string,
  openCard: ParsedHomeGrilleCard | null
): WeeklyConcours | null {
  if (!html) return null;

  const numMatch =
    html.match(/Promosport\s+N[°o]?\s*(\d{3,4})/i) ||
    html.match(/ng=(\d{3,4})/i);
  const number = Number(numMatch?.[1] || openCard?.number || 0);
  if (!number) return null;

  const gdateMatch = html.match(/id="gdate"[^>]*>([^<]+)<\/span>/i);
  const rawGdate = gdateMatch
    ? decodeHtmlEntities(gdateMatch[1])
    : openCard?.dateTimeRaw || '';
  const dtParts = rawGdate.match(/(\d{2})\/(\d{2})\/(\d{4})\s+(\d{2}:\d{2})/);
  const dd = dtParts?.[1] || '17';
  const mm = dtParts?.[2] || '11';
  const yyyy = dtParts?.[3] || '2026';
  const closeHHMM = dtParts?.[4] || '20:00';
  const dateDashes = `${dd}-${mm}-${yyyy}`;
  const closingFormatted = `${dd}/${mm}/${yyyy} à ${closeHHMM}`;

  const matches: WeeklyConcoursMatch[] = [];

  // Primary: structured embedded JS array `var M=[...];`
  const mArrayMatch = html.match(/var\s+M\s*=\s*(\[[\s\S]*?\]);/);
  if (mArrayMatch) {
    try {
      const parsedM = JSON.parse(mArrayMatch[1]) as Array<
        [
          string, // 0: competition
          string, // 1: time e.g. "19:45:00"
          string, // 2: homeTeam
          string, // 3: awayTeam
          [number | string, number | string, number | string], // 4: site probs
          [number, number, number]?, // 5: subscriber probs
          string?, // 6: home img url
          string?, // 7: away img url
          string?, // 8: optional custom date
        ]
      >;

      parsedM.slice(0, 13).forEach((row, idx) => {
        const compFr = decodeHtmlEntities(row[0] || 'Football');
        const rawTime = decodeHtmlEntities(row[1] || closeHHMM);
        const timeHHMM = rawTime.slice(0, 5);
        const homeFr = decodeHtmlEntities(row[2] || `Team ${idx + 1}A`);
        const awayFr = decodeHtmlEntities(row[3] || `Team ${idx + 1}B`);
        const probs = row[4] || [33, 34, 33];

        let matchDateDashes = dateDashes;
        let isoDate = `${yyyy}-${mm}-${dd}`;
        if (row[8]) {
          const customDateMatch = String(row[8]).match(/(\d{2})\/(\d{2})(?:\/(\d{4}))?/);
          if (customDateMatch) {
            const cd = customDateMatch[1];
            const cm = customDateMatch[2];
            const cy = customDateMatch[3] || yyyy;
            matchDateDashes = `${cd}-${cm}-${cy}`;
            isoDate = `${cy}-${cm}-${cd}`;
          }
        }

        const kickoffMs = Date.parse(`${isoDate}T${timeHHMM}:00Z`);

        matches.push({
          id: idx + 1,
          dayTime: rawTime,
          competition: translateCompetitionToAr(compFr),
          competitionFr: compFr,
          homeTeam: translateTeamToAr(homeFr),
          homeTeamFr: homeFr,
          homeLogo: getLogoCode(homeFr),
          awayTeam: translateTeamToAr(awayFr),
          awayTeamFr: awayFr,
          awayLogo: getLogoCode(awayFr),
          date: Number.isFinite(kickoffMs) ? formatUtcDateString(kickoffMs) : matchDateDashes,
          time: rawTime,
          kickoffTimestamp: Number.isFinite(kickoffMs) ? kickoffMs : 0,
          status: 'scheduled',
          score: '- - -',
          result: null,
          prob1: Number(probs[0]) || 33,
          probX: Number(probs[1]) || 34,
          prob2: Number(probs[2]) || 33,
        });
      });
    } catch {
      // Fallback to article parsing below
    }
  }

  // Secondary HTML <article class="mc"> parser
  if (matches.length === 0) {
    const mcMatches = html.matchAll(/<article class="mc">([\s\S]*?)<\/article>/gi);
    let idx = 0;
    for (const mc of mcMatches) {
      if (idx >= 13) break;
      const body = mc[1];
      const smallM = body.match(/<small>([^<]+)<\/small>/i);
      const smallParts = smallM ? decodeHtmlEntities(smallM[1]).split('·').map((s) => s.trim()) : [];
      const compFr = smallParts[0] || 'Football';
      const rawTime = smallParts[1] || closeHHMM;
      const timeHHMM = rawTime.slice(0, 5);
      const hTeamM = body.match(/<b class="h">([^<]+)<\/b>/i);
      const aTeamM = body.match(/<b class="a">([^<]+)<\/b>/i);
      if (!hTeamM || !aTeamM) continue;
      const homeFr = decodeHtmlEntities(hTeamM[1]);
      const awayFr = decodeHtmlEntities(aTeamM[1]);
      const emMatches = [...body.matchAll(/<em>(\d+)\s*%<\/em>/gi)].map((x) => Number(x[1]));
      const kickoffMs = Date.parse(`${yyyy}-${mm}-${dd}T${timeHHMM}:00Z`);

      idx += 1;
      matches.push({
        id: idx,
        dayTime: rawTime,
        competition: translateCompetitionToAr(compFr),
        competitionFr: compFr,
        homeTeam: translateTeamToAr(homeFr),
        homeTeamFr: homeFr,
        homeLogo: getLogoCode(homeFr),
        awayTeam: translateTeamToAr(awayFr),
        awayTeamFr: awayFr,
        awayLogo: getLogoCode(awayFr),
        date: dateDashes,
        time: rawTime,
        kickoffTimestamp: Number.isFinite(kickoffMs) ? kickoffMs : 0,
        status: 'scheduled',
        score: '- - -',
        result: null,
        prob1: emMatches[0] || 33,
        probX: emMatches[1] || 34,
        prob2: emMatches[2] || 33,
      });
    }
  }

  if (matches.length === 0) return null;

  return {
    number,
    category: 'international',
    title: `Promosport : Concours N° ${number}`,
    season: 'Saison 2026-2027',
    fullDateFormatted: `du ${closingFormatted}`,
    dateStr: dateDashes,
    closingTimeStr: closingFormatted,
    cagnotteEstimate:
      openCard && openCard.cagnotteNum > 0
        ? formatTndNumber(openCard.cagnotteNum)
        : 'تُحدد عند السحب',
    sourceUrl: `${PROMOSPORT_PRONOSTIC_GRILLE_URL}&ng=${number}`,
    matches,
  };
}

export function parseGrilleResultHtml(
  html: string,
  grilleNumber: number,
  summaryCard?: ParsedHomeGrilleCard | null
): PromosportGrille | null {
  if (!html) return null;

  const h1Match = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
  const subDateMatch = html.match(/Du\s+(\d{2}\/\d{2}\/\d{4}\s+\d{2}:\d{2})/i);
  const rawDateTime = summaryCard?.dateTimeRaw || subDateMatch?.[1] || '';
  const dtParts = rawDateTime.match(/(\d{2})\/(\d{2})\/(\d{4})\s+(\d{2}:\d{2})/);
  const dateFormatted = dtParts
    ? `${dtParts[1]}-${dtParts[2]}-${dtParts[3]} à ${dtParts[4]}`
    : `${grilleNumber}`;
  const isFinalHeader = h1Match ? /Résultats\s+finals/i.test(h1Match[1]) : false;

  const matches: PromosportMatch[] = [];
  const rowMatches = html.matchAll(/<article class="rr">([\s\S]*?)<\/article>/gi);

  for (const rm of rowMatches) {
    const body = rm[1];
    const numM = body.match(/class="rr-n">(\d+)</i);
    const id = numM ? Number(numM[1]) : matches.length + 1;
    const hTeamM = body.match(/class="rr-t h">[\s\S]*?<span class="nm">([^<]+)<\/span>/i);
    const aTeamM = body.match(/class="rr-t a">[\s\S]*?<span class="nm">([^<]+)<\/span>/i);
    if (!hTeamM || !aTeamM) continue;

    const homeFr = decodeHtmlEntities(hTeamM[1]);
    const awayFr = decodeHtmlEntities(aTeamM[1]);

    const champM = body.match(/championnat\/[^/]+\/\d+\/([^/]+)/i);
    const baseCompFr = champM ? decodeHtmlEntities(decodeURIComponent(champM[1])) : `Concours #${grilleNumber}`;
    const isHalfTimePick = /class="mt"[^>]*>1ère mi-temps</i.test(body);
    const compFr = isHalfTimePick ? `${baseCompFr} (1ère MT)` : baseCompFr;
    const compAr = isHalfTimePick
      ? `${translateCompetitionToAr(baseCompFr)} (الشوط 1)`
      : translateCompetitionToAr(baseCompFr);

    const scM = body.match(/class="rr-sc">([^<]+)<\/b>/i);
    const rsM = body.match(/class="rs">([1X2])<\/span>/i);
    const rawScore = scM ? decodeHtmlEntities(scM[1]) : '';
    const scorePair = rawScore.match(/(\d+)\s*[-:]\s*(\d+)/);

    const delayed = isDelayedToken(rawScore) || /PST|PPD|DEL|CANC|SUSP|Reporté/i.test(body);
    const cleanScore = !delayed && scorePair ? `${scorePair[1]} - ${scorePair[2]}` : '- - -';
    const resultSign: '1' | 'X' | '2' =
      rsM && (rsM[1] === '1' || rsM[1] === 'X' || rsM[1] === '2')
        ? rsM[1]
        : scorePair
        ? computeResultSign(Number(scorePair[1]), Number(scorePair[2]))
        : 'X';

    matches.push({
      id,
      homeTeam: translateTeamToAr(homeFr),
      homeTeamFr: homeFr,
      homeLogo: getLogoCode(homeFr),
      awayTeam: translateTeamToAr(awayFr),
      awayTeamFr: awayFr,
      awayLogo: getLogoCode(awayFr),
      competition: compAr,
      competitionFr: compFr,
      score: cleanScore,
      result: resultSign,
    });
  }

  if (matches.length === 0) return null;

  const cagnotte = summaryCard?.cagnotteNum || 0;
  const winnersCount = summaryCard?.winnersCount ?? null;
  const hasOfficialPayouts = cagnotte > 0 && winnersCount !== null;
  const isRollover = hasOfficialPayouts && winnersCount === 0;
  const prizePerWinner =
    hasOfficialPayouts && winnersCount! > 0
      ? Math.round((cagnotte / winnersCount!) * 1000) / 1000
      : 0;

  return {
    id: `grille-${grilleNumber}`,
    number: grilleNumber,
    date: dateFormatted,
    cagnotte,
    cagnotteFormatted: cagnotte > 0 ? formatTndNumber(cagnotte) : 'قيد التحديد الرسمي',
    winnersCount: winnersCount ?? 0,
    winnersFormatted:
      winnersCount === null
        ? 'قيد التحديد الرسمي'
        : winnersCount === 0
        ? '0 مرابيح (ترحيل)'
        : `${winnersCount} مرابيح`,
    prizePerWinner,
    prizePerWinnerFormatted:
      winnersCount === null
        ? 'قيد التحديد الرسمي'
        : winnersCount === 0
        ? 'ترحيل الجائزة (0 DT)'
        : formatTndNumber(prizePerWinner),
    isRollover,
    status: hasOfficialPayouts && isFinalHeader ? 'official' : hasOfficialPayouts ? 'official' : 'pending',
    sourceUrl: PROMOSPORT_PRONOSTIC_RESULT_URL(grilleNumber),
    matches: matches.slice(0, 13),
  };
}

/**
 * Enriches an active WeeklyConcours using https://www.promosport-pronostic.com live feeds:
 * - promo_matchs (resolves siteMatchId, kickoff times & PST/delayed flags)
 * - getmatchid_rapid (exact real-time 1H/HT/2H minute & verified live score by match_id)
 * - promo_result?grille={N}&jeux=Promosport (verified finished scores once posted)
 * Zero assumed/clock-forced scores!
 */
export async function enrichConcoursWithPromosportSiteLive(
  concours: WeeklyConcours
): Promise<{ concours: WeeklyConcours; matchedCount: number }> {
  const dateIsoMatch = concours.dateStr.match(/(\d{2})-(\d{2})-(\d{4})/);
  const targetIsoDate = dateIsoMatch
    ? `${dateIsoMatch[3]}-${dateIsoMatch[2]}-${dateIsoMatch[1]}`
    : '';

  const [rapidMap, matchsTodayHtml, matchsDateHtml, activeResultHtml] = await Promise.all([
    fetchRapidLiveMap(),
    fetchTextSafe(PROMOSPORT_PRONOSTIC_MATCHS_URL, 5500),
    targetIsoDate
      ? fetchTextSafe(`${PROMOSPORT_PRONOSTIC_MATCHS_URL}?datem=${targetIsoDate}`, 5500)
      : Promise.resolve(null),
    fetchTextSafe(PROMOSPORT_PRONOSTIC_RESULT_URL(concours.number), 5500),
  ]);

  const promoRows = [
    ...(matchsDateHtml ? parsePromoMatchsHtml(matchsDateHtml) : []),
    ...(matchsTodayHtml ? parsePromoMatchsHtml(matchsTodayHtml) : []),
  ];

  // Parse any published final results for the active concours itself (if games have already ended)
  const resultByIndex = new Map<number, PromosportMatch>();
  if (activeResultHtml) {
    const parsedActiveRes = parseGrilleResultHtml(activeResultHtml, concours.number, null);
    if (parsedActiveRes) {
      for (const rm of parsedActiveRes.matches) {
        if (rm.score && rm.score !== '- - -') {
          resultByIndex.set(rm.id, rm);
        }
      }
    }
  }

  let matchedCount = 0;

  const updatedMatches: WeeklyConcoursMatch[] = concours.matches.map((match) => {
    const mHomeTok = normalizeSiteToken(match.homeTeamFr || match.homeTeam);
    const mAwayTok = normalizeSiteToken(match.awayTeamFr || match.awayTeam);

    let resolvedSiteId = match.siteMatchId;
    let matchedPromoRow: ParsedPromoMatchRow | undefined;

    for (const row of promoRows) {
      const rHome = normalizeSiteToken(row.homeTeam);
      const rAway = normalizeSiteToken(row.awayTeam);
      if (
        (rHome === mHomeTok || (rHome.length >= 4 && mHomeTok.length >= 4 && (rHome.includes(mHomeTok) || mHomeTok.includes(rHome)))) &&
        (rAway === mAwayTok || (rAway.length >= 4 && mAwayTok.length >= 4 && (rAway.includes(mAwayTok) || mAwayTok.includes(rAway))))
      ) {
        resolvedSiteId = row.matchId;
        matchedPromoRow = row;
        break;
      }
    }

    // Check delayed / postponed condition — never display unverified or delayed scores!
    if (matchedPromoRow?.isDelayed) {
      return {
        ...match,
        siteMatchId: resolvedSiteId,
        isDelayed: true,
        status: 'scheduled',
        score: '- - -',
        scoreHome: undefined,
        scoreAway: undefined,
        liveMinute: undefined,
        result: null,
      };
    }

    // 1. Check live rapid JSON feed first (strict real-time 1H/HT/2H minute & score)
    const rapid = resolvedSiteId ? rapidMap.get(resolvedSiteId) : undefined;
    if (rapid && String(rapid.live) === '1' && Number(rapid.conf || 0) === 0) {
      const b1 = Number(rapid.bb1);
      const b2 = Number(rapid.bb2);
      if (Number.isFinite(b1) && Number.isFinite(b2)) {
        matchedCount += 1;
        const st = String(rapid.st || '').trim();
        const minuteStr =
          st === 'HT'
            ? 'HT'
            : rapid.min
            ? `${rapid.min}' ${st}`.trim()
            : st || "1'";

        return {
          ...match,
          siteMatchId: resolvedSiteId,
          isDelayed: false,
          status: 'live',
          scoreHome: String(b1),
          scoreAway: String(b2),
          score: `${b1} - ${b2}`,
          liveMinute: minuteStr,
          result: null,
        };
      }
    }

    // 2. Check promo_matchs row status (`FT` or active half score)
    if (matchedPromoRow) {
      if (
        matchedPromoRow.isFinished &&
        matchedPromoRow.scoreHome !== undefined &&
        matchedPromoRow.scoreAway !== undefined
      ) {
        matchedCount += 1;
        const h = Number(matchedPromoRow.scoreHome);
        const a = Number(matchedPromoRow.scoreAway);
        return {
          ...match,
          siteMatchId: resolvedSiteId,
          isDelayed: false,
          status: 'finished',
          scoreHome: matchedPromoRow.scoreHome,
          scoreAway: matchedPromoRow.scoreAway,
          score: `${matchedPromoRow.scoreHome} - ${matchedPromoRow.scoreAway}`,
          liveMinute: undefined,
          result: computeResultSign(h, a),
        };
      }

      if (
        matchedPromoRow.isLive &&
        matchedPromoRow.scoreHome !== undefined &&
        matchedPromoRow.scoreAway !== undefined
      ) {
        matchedCount += 1;
        return {
          ...match,
          siteMatchId: resolvedSiteId,
          isDelayed: false,
          status: 'live',
          scoreHome: matchedPromoRow.scoreHome,
          scoreAway: matchedPromoRow.scoreAway,
          score: `${matchedPromoRow.scoreHome} - ${matchedPromoRow.scoreAway}`,
          liveMinute: matchedPromoRow.liveMinute || 'LIVE',
          result: null,
        };
      }
    }

    // 3. Check if promo_result for active grille already has a verified final score
    const resRow = resultByIndex.get(match.id);
    if (
      resRow &&
      resRow.score &&
      resRow.score !== '- - -' &&
      normalizeSiteToken(resRow.homeTeamFr || resRow.homeTeam) === mHomeTok
    ) {
      const parts = resRow.score.split(/[-:]/).map((s) => s.trim());
      if (parts.length === 2 && /^\d+$/.test(parts[0]) && /^\d+$/.test(parts[1])) {
        matchedCount += 1;
        return {
          ...match,
          siteMatchId: resolvedSiteId,
          isDelayed: false,
          status: 'finished',
          scoreHome: parts[0],
          scoreAway: parts[1],
          score: `${parts[0]} - ${parts[1]}`,
          liveMinute: undefined,
          result: resRow.result,
        };
      }
    }

    return {
      ...match,
      siteMatchId: resolvedSiteId,
      isDelayed: false,
    };
  });

  return {
    concours: {
      ...concours,
      matches: updatedMatches,
    },
    matchedCount,
  };
}

export async function fetchPromosportPronosticFullScan(): Promise<{
  activeConcours: WeeklyConcours | null;
  grilles: PromosportGrille[];
}> {
  const [homeHtml, pronosticHtml] = await Promise.all([
    fetchTextSafe(PROMOSPORT_PRONOSTIC_HOME_URL, 6500),
    fetchTextSafe(PROMOSPORT_PRONOSTIC_GRILLE_URL, 6500),
  ]);

  const { openGrille, resultGrilles } = homeHtml
    ? parseHomeGrillesSummary(homeHtml)
    : { openGrille: null, resultGrilles: [] };

  let activeConcours = pronosticHtml
    ? parseActiveConcoursFromPromoPronostic(pronosticHtml, openGrille)
    : null;

  if (activeConcours) {
    const liveEnriched = await enrichConcoursWithPromosportSiteLive(activeConcours);
    activeConcours = liveEnriched.concours;
  }

  const expectedPrevNumber =
    activeConcours && activeConcours.number > 1 ? activeConcours.number - 1 : null;

  // Strictly guarantee the immediate previous grille (N - 1) is ALWAYS queried first alongside recent result cards
  const candidateNumbers: ParsedHomeGrilleCard[] = [];
  const seenNums = new Set<number>();

  if (expectedPrevNumber !== null) {
    const matchingPrevCard = resultGrilles.find((g) => g.number === expectedPrevNumber);
    candidateNumbers.push(
      matchingPrevCard || {
        number: expectedPrevNumber,
        isOpen: false,
        dateTimeRaw: '',
        cagnotteNum: 0,
        winnersCount: null,
      }
    );
    seenNums.add(expectedPrevNumber);
  }

  for (const g of resultGrilles) {
    if (activeConcours && g.number === activeConcours.number) continue;
    if (seenNums.has(g.number)) continue;
    candidateNumbers.push(g);
    seenNums.add(g.number);
    if (candidateNumbers.length >= 4) break;
  }

  const parsedGrilles: PromosportGrille[] = [];
  if (candidateNumbers.length > 0) {
    const htmlResults = await Promise.allSettled(
      candidateNumbers.map(async (card) => {
        const resHtml = await fetchTextSafe(PROMOSPORT_PRONOSTIC_RESULT_URL(card.number), 5500);
        const parsedRes = resHtml ? parseGrilleResultHtml(resHtml, card.number, card) : null;
        if (parsedRes && parsedRes.matches.length > 0) {
          return parsedRes;
        }

        // Strict fallback for immediate rollover (N - 1) before promo_result HTML is published on site
        if (expectedPrevNumber !== null && card.number === expectedPrevNumber) {
          const prevPronosticHtml = await fetchTextSafe(
            `${PROMOSPORT_PRONOSTIC_GRILLE_URL}&ng=${card.number}`,
            5500
          );
          const prevConcours = prevPronosticHtml
            ? parseActiveConcoursFromPromoPronostic(prevPronosticHtml, card)
            : null;
          if (prevConcours && prevConcours.matches.length > 0) {
            return {
              id: `grille-${prevConcours.number}`,
              number: prevConcours.number,
              date: prevConcours.closingTimeStr || prevConcours.fullDateFormatted.replace(/^du\s+/i, ''),
              cagnotte: card.cagnotteNum || 0,
              cagnotteFormatted:
                card.cagnotteNum > 0 ? formatTndNumber(card.cagnotteNum) : 'قيد التحديد الرسمي',
              winnersCount: card.winnersCount ?? 0,
              winnersFormatted:
                card.winnersCount !== null && card.winnersCount !== undefined
                  ? card.winnersCount === 0
                    ? '0 مرابيح (ترحيل)'
                    : `${card.winnersCount} مرابيح`
                  : 'قيد التحديد الرسمي',
              prizePerWinner: 0,
              prizePerWinnerFormatted: 'قيد التحديد الرسمي',
              isRollover: card.winnersCount === 0,
              status: 'pending' as const,
              sourceUrl: PROMOSPORT_PRONOSTIC_RESULT_URL(prevConcours.number),
              matches: prevConcours.matches.map((m) => ({
                id: m.id,
                homeTeam: m.homeTeam,
                homeTeamFr: m.homeTeamFr,
                homeLogo: m.homeLogo,
                awayTeam: m.awayTeam,
                awayTeamFr: m.awayTeamFr,
                awayLogo: m.awayLogo,
                competition: m.competition,
                competitionFr: m.competitionFr,
                score: '- - -',
                result: null,
              })),
            } satisfies PromosportGrille;
          }
        }
        return null;
      })
    );
    for (const r of htmlResults) {
      if (r.status === 'fulfilled' && r.value) {
        parsedGrilles.push(r.value);
      }
    }
  }

  return {
    activeConcours,
    grilles: parsedGrilles,
  };
}

const COUNTRY_AR_MAP: Record<string, string> = {
  World: 'دولي / عالمي',
  Europe: 'أوروبا',
  Africa: 'إفريقيا',
  Asia: 'آسيا',
  'South-America': 'أمريكا الجنوبية',
  'North-America': 'أمريكا الشمالية',
  Tunisia: 'تونس',
  Tunisie: 'تونس',
  Morocco: 'المغرب',
  Algeria: 'الجزائر',
  Egypt: 'مصر',
  'Saudi-Arabia': 'السعودية',
  'Saudi Arabia': 'السعودية',
  Qatar: 'قطر',
  UAE: 'الإمارات',
  Jordan: 'الأردن',
  Iraq: 'العراق',
  Kuwait: 'الكويت',
  Spain: 'إسبانيا',
  England: 'إنجلترا',
  Italy: 'إيطاليا',
  France: 'فرنسا',
  Germany: 'ألمانيا',
  Portugal: 'البرتغال',
  Netherlands: 'هولندا',
  Belgium: 'بلجيكا',
  Turkey: 'تركيا',
  Türkiye: 'تركيا',
  Greece: 'اليونان',
  Scotland: 'إسكتلندا',
  Switzerland: 'سويسرا',
  Austria: 'النمسا',
  Denmark: 'الدنمارك',
  Norway: 'النرويج',
  Sweden: 'السويد',
  Poland: 'بولندا',
  Romania: 'رومانيا',
  Croatia: 'كرواتيا',
  Serbia: 'صربيا',
  Ukraine: 'أوكرانيا',
  Russia: 'روسيا',
  Brazil: 'البرازيل',
  Argentina: 'الأرجنتين',
  Colombia: 'كولومبيا',
  Chile: 'تشيلي',
  Uruguay: 'أوروغواي',
  Mexico: 'المكسيك',
  USA: 'الولايات المتحدة',
  Japan: 'اليابان',
  'South-Korea': 'كوريا الجنوبية',
  Iran: 'إيران',
  Australia: 'أستراليا',
};

function translateCountryToAr(country: string): string {
  const clean = decodeHtmlEntities(country).trim();
  return COUNTRY_AR_MAP[clean] || clean;
}

const INVALID_LIVE_MATCH_TOKENS = new Set([
  'PST',
  'PPD',
  'DEL',
  'DELAYED',
  'POSTPONED',
  'SUSP',
  'SUS',
  'SUSPENDED',
  'CANC',
  'CAN',
  'CANCELLED',
  'CANCELED',
  'ABD',
  'ABANDONED',
  'AWD',
  'AWARDED',
  'WO',
  'INT',
  'INTERRUPTED',
  'REPORTE',
  'ANNULE',
  'RETARDE',
]);

function isInvalidOrCancelledStatus(rawStatus: string): boolean {
  const clean = decodeHtmlEntities(rawStatus)
    .toUpperCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^A-Z]/g, '');
  return INVALID_LIVE_MATCH_TOKENS.has(clean);
}

/**
 * Deterministic league priority order ("مع ترتيب الدوريات"):
 * 1. Major international & continental tournaments (UCL, UEL, World Cup, AFCON, Nations League)
 * 2. Tunisia & Maghreb / Arab competitions
 * 3. Top European leagues (Spain, England, Italy, Germany, France, Portugal, Netherlands, Belgium, Turkey, Greece)
 * 4. Rest of Europe & Americas & Asia
 * 5. Reserve / Youth (U21/U20/U19) / Women / lower amateur tiers ordered neatly below senior tiers
 */
export function getLeaguePriorityRank(countryName: string, leagueName: string): number {
  const c = countryName.toLowerCase().trim();
  const l = leagueName.toLowerCase().trim();

  const isYouthOrReserve =
    /\b(u17|u18|u19|u20|u21|u23|youth|junior|reserve|frauen|women|feminin|femenina|paraense)\b/i.test(l);
  const youthPenalty = isYouthOrReserve ? 400 : 0;

  // Major international & UEFA / CAF / FIFA competitions
  if (
    /champions league|europa league|conference league|nations league|world cup|africa cup|caf champions|caf confederation|copa america|euro\b|qualif/i.test(
      l
    )
  ) {
    return 10 + youthPenalty;
  }

  if (c === 'tunisia' || c === 'tunisie') return 20 + youthPenalty;
  if (c === 'world' || c === 'europe' || c === 'africa') return 35 + youthPenalty;

  // Top 5 European Football Nations
  if (c === 'england') {
    if (/premier league/.test(l) && !/cup|u21|2/.test(l)) return 50;
    if (/championship|fa cup|efl/.test(l)) return 60;
    return 75 + youthPenalty;
  }
  if (c === 'spain') {
    if (/laliga|la liga|primera/.test(l) && !/2|hypermotion/.test(l)) return 52;
    if (/segunda|hypermotion|copa del rey/.test(l)) return 62;
    return 78 + youthPenalty;
  }
  if (c === 'italy') {
    if (/serie a/.test(l)) return 54;
    if (/serie b|coppa italia/.test(l)) return 64;
    if (/serie c/.test(l)) return 80;
    return 95 + youthPenalty;
  }
  if (c === 'france') {
    if (/ligue 1/.test(l)) return 56;
    if (/ligue 2|coupe de france/.test(l)) return 66;
    return 84 + youthPenalty;
  }
  if (c === 'germany') {
    if (/bundesliga/.test(l) && !/2\.|frauen|3\./.test(l)) return 58;
    if (/2\. bundesliga|dfb/.test(l)) return 68;
    return 86 + youthPenalty;
  }

  // Arab & North African leagues
  if (['morocco', 'algeria', 'egypt', 'saudi-arabia', 'saudi arabia', 'qatar', 'uae'].includes(c)) {
    return 110 + youthPenalty;
  }

  // Secondary top European nations
  if (['portugal', 'netherlands', 'belgium', 'turkey', 'türkiye', 'greece', 'scotland', 'switzerland', 'austria'].includes(c)) {
    return 140 + youthPenalty;
  }

  // Nordic & Central/Eastern Europe
  if (['denmark', 'norway', 'sweden', 'poland', 'croatia', 'serbia', 'romania', 'ukraine', 'czech', 'hungary'].includes(c)) {
    return 180 + youthPenalty;
  }

  // Major Americas & Asia
  if (['brazil', 'argentina', 'usa', 'mexico', 'colombia', 'japan', 'south-korea'].includes(c)) {
    return 220 + youthPenalty;
  }

  return 300 + youthPenalty;
}

function isValidTeamLabel(name: string): boolean {
  const clean = decodeHtmlEntities(name).trim();
  if (!clean || clean.length < 2) return false;
  if (/[<>]/.test(clean)) return false;
  if (/^(tbd|unknown|null|undefined|test|n\/a|--+)$/i.test(clean)) return false;
  return true;
}

function parseVerifiedScorePair(raw: string): { home: string; away: string } | null {
  const clean = decodeHtmlEntities(raw).replace(/<[^>]+>/g, '').trim();
  const m = clean.match(/^(\d{1,2})\s*[-:]\s*(\d{1,2})$/);
  if (!m) return null;
  const h = Number(m[1]);
  const a = Number(m[2]);
  if (!Number.isFinite(h) || !Number.isFinite(a) || h < 0 || a < 0 || h > 30 || a > 30) {
    return null;
  }
  return { home: String(h), away: String(a) };
}

function parseProbabilitiesMapFromHomeHtml(
  homeHtml: string
): Map<string, { prob1: number; probX: number; prob2: number }> {
  const probMap = new Map<string, { prob1: number; probX: number; prob2: number }>();
  if (!homeHtml) return probMap;

  const t1Start = homeHtml.indexOf('id="table111"');
  if (t1Start < 0) return probMap;
  const t2Start = homeHtml.indexOf('id="table222"', t1Start);
  const t1Html = homeHtml.slice(t1Start, t2Start > t1Start ? t2Start : t1Start + 100000);

  const rowBlocks = t1Html.split('<div class="mj-row');
  for (let i = 1; i < rowBlocks.length; i++) {
    const block = rowBlocks[i];
    const idM = block.match(/equipe_home(\d+)/);
    if (!idM) continue;
    const matchId = idM[1];
    const pcs = [...block.matchAll(/class="mj-pc"\s+data-p="(\d+)"/gi)].map((m) => Number(m[1]));
    if (pcs.length >= 3) {
      probMap.set(matchId, {
        prob1: pcs[0] || 33,
        probX: pcs[1] || 34,
        prob2: pcs[2] || 33,
      });
    }
  }
  return probMap;
}

function parsePromoMatchsCatalogHtml(
  html: string,
  probMap: Map<string, { prob1: number; probX: number; prob2: number }>
): import('../types/promosport').SiteLiveMatch[] {
  const results: import('../types/promosport').SiteLiveMatch[] = [];
  if (!html) return results;

  const seenIds = new Set<string>();
  const nowDate = new Date();
  const todayIsoUtc = nowDate.toISOString().slice(0, 10);
  const todayStr = formatUtcDateString(nowDate);

  // Restrict strictly to panel-table1 (today's verified league-grouped schedule) before panel-table3 hidden templates
  const panel3Idx = html.indexOf('id="panel-table3"');
  const primaryHtml = panel3Idx > 0 ? html.slice(0, panel3Idx) : html;

  // Split into league blocks on `<div class="pn-hd">`
  const blocks = primaryHtml.split('<div class="pn-hd">');
  for (let b = 1; b < blocks.length; b++) {
    const block = blocks[b];
    const flagMatch = block.match(/<img[^>]*class="pn-fl"[^>]*src="([^"]+)"/i);
    const titleMatch = block.match(/<span>([^<]+)<\/span>/i);
    const leagueTitleRaw = titleMatch ? decodeHtmlEntities(titleMatch[1]) : 'World : Football';
    const colonIdx = leagueTitleRaw.indexOf(':');
    const countryName = colonIdx > -1 ? leagueTitleRaw.slice(0, colonIdx).trim() : 'World';
    const leagueName = colonIdx > -1 ? leagueTitleRaw.slice(colonIdx + 1).trim() : leagueTitleRaw;
    const leagueKey = `${countryName} : ${leagueName}`;
    const countryFlagUrl = flagMatch ? flagMatch[1] : undefined;
    const leagueOrderRank = getLeaguePriorityRank(countryName, leagueName);

    const rowChunks = block.split(/<div class="pn-row([^"]*)">/i);
    for (let r = 1; r < rowChunks.length; r += 2) {
      const rowAttrs = rowChunks[r] || '';
      const rowHtml = rowChunks[r + 1] || '';
      if (/hidden-row/i.test(rowAttrs)) continue;
      const homeM = rowHtml.match(/equipe_home(\d+)[^>]*>([^<]{1,120})<\/span>/i);
      if (!homeM) continue;
      const matchId = homeM[1];
      if (!matchId || seenIds.has(matchId)) continue;

      const awayM = rowHtml.match(new RegExp(`equipe_away${matchId}[^>]*>([^<]{1,120})<\\/span>`, 'i'));
      if (!awayM) continue;

      const homeFr = decodeHtmlEntities(homeM[2]);
      const awayFr = decodeHtmlEntities(awayM[1]);
      if (!isValidTeamLabel(homeFr) || !isValidTeamLabel(awayFr)) continue;
      if (normalizeSiteToken(homeFr) === normalizeSiteToken(awayFr)) continue;

      // Status detection (live_matchid during play, or pn-ms span e.g. "À venir" / "MT 0-1" / "FT")
      const liveM = rowHtml.match(new RegExp(`live_matchid${matchId}[^>]*>([^<]{0,60})<\\/span>`, 'i'));
      const pstM = !liveM
        ? rowHtml.match(/<div class="pn-ms"><span[^>]*>([^<]{1,40})<\/span><\/div>/i)
        : null;
      const rawStatus = decodeHtmlEntities((liveM ? liveM[1] : pstM?.[1]) || 'À venir').trim();

      // Strictly exclude postponed / cancelled / suspended / invalid matches
      if (isInvalidOrCancelledStatus(rawStatus)) continue;

      seenIds.add(matchId);

      // Extract crests, competition icon, URL, round, kickoff time
      const compImgM = rowHtml.match(/<img[^>]*class="pn-cp"[^>]*src="([^"]+)"/i);
      const jrM = rowHtml.match(/<a[^>]*class="pn-jr"[^>]*href="([^"]+)"[^>]*>([^<]*)<\/a>/i);
      const koM = rowHtml.match(
        new RegExp(`retrieveid${matchId}[^>]*(?:data-ko="([^"]*)")?[^>]*>([^<]*)<\\/span>`, 'i')
      );

      // Team crests inside pn-tm h and pn-tm a
      const homeBlockM = rowHtml.match(/<div class="pn-tm h">([\s\S]*?)<\/div>/i);
      const awayBlockM = rowHtml.match(/<div class="pn-tm a">([\s\S]*?)<\/div>/i);
      const homeCrestM = homeBlockM?.[1].match(/<img[^>]*src="([^"]+)"/i);
      const awayCrestM = awayBlockM?.[1].match(/<img[^>]*src="([^"]+)"/i);

      // Extract score: live/scheduled uses `score_matchid{id}`, while finished matches use `<b class="pn-sc c_score">H - A</b>`
      const liveScoreM = rowHtml.match(new RegExp(`score_matchid${matchId}[^>]*>([\\s\\S]*?)<\\/b>`, 'i'));
      const finishedScoreM = !liveScoreM
        ? rowHtml.match(/<b\s+class="pn-sc\s+c_score"[^>]*>([\s\S]*?)<\/b>/i)
        : null;
      const scoreM = liveScoreM || finishedScoreM;
      const scorePair = scoreM ? parseVerifiedScorePair(scoreM[1]) : null;

      const statusUpper = rawStatus.toUpperCase();
      const mtHalftimeMatch = rawStatus.match(/^MT\s+(\d{1,2})\s*[-:]\s*(\d{1,2})$/i);
      const isMtFinishedStatus = /^MT(?:\s+\d{1,2}\s*[-:]\s*\d{1,2})?$/i.test(statusUpper) && !liveM;
      const hasWinClass = /class="[^"]*\bwin\b/i.test(rowHtml);
      const isFinished =
        /^(FT|AET|PEN|TER|TERMINE|FINAL)$/i.test(statusUpper) ||
        Boolean(scorePair && (finishedScoreM || isMtFinishedStatus || hasWinClass) && !liveM);
      const isLive = !isFinished && /^(1H|2H|HT|ET|BT|P|LIVE|\d+'?)$/i.test(statusUpper);

      // Strict score validity: only keep score when match is actually live or finished
      const hasValidScore = Boolean(scorePair && (isLive || isFinished));
      const cleanScore = hasValidScore ? `${scorePair!.home} - ${scorePair!.away}` : '- - -';
      const parsedHalftimeScore = mtHalftimeMatch ? `${mtHalftimeMatch[1]} - ${mtHalftimeMatch[2]}` : undefined;

      // Extract kickoff HH:MM (promo_matchs outputs CET +01:00; convert strictly to UTC)
      const rawKo = koM ? decodeHtmlEntities(koM[1] || koM[2] || '').trim() : '';
      const koClean = /^\d{1,2}:\d{2}$/.test(rawKo) ? rawKo : '';
      const koUtc = koClean ? convertTunisTimeToUtc(koClean, todayIsoUtc) : null;
      const koMinNum = koM && /^\d{1,3}$/.test(decodeHtmlEntities(koM[2] || '').trim())
        ? decodeHtmlEntities(koM[2]).trim()
        : '';

      const liveMinute = isLive
        ? statusUpper === 'HT'
          ? 'HT'
          : koMinNum
          ? `${koMinNum}' ${rawStatus}`.trim()
          : rawStatus
        : undefined;

      const probs = probMap.get(matchId) || { prob1: 33, probX: 34, prob2: 33 };
      const compAr = `${translateCountryToAr(countryName)} : ${translateCompetitionToAr(leagueName)}`;
      const compFr = `${countryName} : ${leagueName}`;

      results.push({
        id: Number(matchId) || results.length + 1,
        siteMatchId: matchId,
        isDelayed: false,
        homeTeam: translateTeamToAr(homeFr),
        homeTeamFr: homeFr,
        homeLogo: getLogoCode(homeFr),
        homeCrestUrl: homeCrestM?.[1],
        awayTeam: translateTeamToAr(awayFr),
        awayTeamFr: awayFr,
        awayLogo: getLogoCode(awayFr),
        awayCrestUrl: awayCrestM?.[1],
        date: koUtc?.utcDate || todayStr,
        time: koUtc?.utcHHMM || koClean || rawKo || '--:--',
        dayTime: koUtc?.utcHHMM || koClean || rawKo || '--:--',
        kickoffTimestamp: koUtc?.timestampMs || 0,
        status: isFinished ? 'finished' : isLive ? 'live' : 'scheduled',
        score: cleanScore,
        scoreHome: hasValidScore ? scorePair!.home : undefined,
        scoreAway: hasValidScore ? scorePair!.away : undefined,
        halftimeScore: parsedHalftimeScore,
        competition: compAr,
        competitionFr: compFr,
        liveMinute,
        result:
          isFinished && hasValidScore
            ? computeResultSign(Number(scorePair!.home), Number(scorePair!.away))
            : null,
        prob1: probs.prob1,
        probX: probs.probX,
        prob2: probs.prob2,
        leagueKey,
        countryName,
        leagueName,
        countryFlagUrl,
        leagueLogoUrl: compImgM?.[1],
        roundLabel: jrM ? decodeHtmlEntities(jrM[2]) : undefined,
        matchUrl: jrM ? jrM[1] : undefined,
        statusCode: isFinished ? 'FT' : rawStatus,
        leagueOrderRank,
        hasVerifiedScore: hasValidScore,
      });
    }
  }

  return results;
}

/**
 * Applies moment-by-moment `getmatchid_rapid` live JSON updates onto cached match catalog.
 * Strictly suppresses invalid/unverified entries and keeps halftime (`bh1 - bh2`) & live minute synced.
 */
export function applyRapidToLiveMatches(
  baseMatches: import('../types/promosport').SiteLiveMatch[],
  rapidMap: Map<string, SiteRapidMatchEntry>
): import('../types/promosport').SiteLiveScanPayload {
  const updated: import('../types/promosport').SiteLiveMatch[] = [];

  for (const m of baseMatches) {
    const rapid = rapidMap.get(m.siteMatchId);
    if (rapid) {
      const st = String(rapid.st || '').trim().toUpperCase();
      if (isInvalidOrCancelledStatus(st)) {
        // Filter out matches that became postponed/cancelled/interrupted
        continue;
      }

      const b1 = Number(rapid.bb1);
      const b2 = Number(rapid.bb2);
      const hasValidRapidScore =
        Number.isFinite(b1) && Number.isFinite(b2) && b1 >= 0 && b2 >= 0 && b1 <= 30 && b2 <= 30;
      const isConfFinished = Number(rapid.conf || 0) > 0 || /^(FT|AET|PEN)$/i.test(st);
      const isRapidLive = String(rapid.live) === '1' && !isConfFinished;

      if (isRapidLive && hasValidRapidScore) {
        const minNum = Number(rapid.min || 0);
        const minuteStr =
          st === 'HT' ? 'HT' : minNum > 0 ? `${minNum}' ${st}`.trim() : st || "1'";
        const bh1 = Number(rapid.bh1);
        const bh2 = Number(rapid.bh2);
        const halftimeScore =
          minNum > 45 && Number.isFinite(bh1) && Number.isFinite(bh2) && bh1 >= 0 && bh2 >= 0
            ? `${bh1} - ${bh2}`
            : undefined;

        updated.push({
          ...m,
          status: 'live',
          statusCode: st || 'LIVE',
          scoreHome: String(b1),
          scoreAway: String(b2),
          score: `${b1} - ${b2}`,
          liveMinute: minuteStr,
          halftimeScore,
          hasVerifiedScore: true,
          result: null,
        });
        continue;
      }

      if (isConfFinished && hasValidRapidScore) {
        const bh1 = Number(rapid.bh1);
        const bh2 = Number(rapid.bh2);
        const halftimeScore =
          Number.isFinite(bh1) && Number.isFinite(bh2) && bh1 >= 0 && bh2 >= 0
            ? `${bh1} - ${bh2}`
            : m.halftimeScore;

        updated.push({
          ...m,
          status: 'finished',
          statusCode: st || 'FT',
          scoreHome: String(b1),
          scoreAway: String(b2),
          score: `${b1} - ${b2}`,
          liveMinute: undefined,
          halftimeScore,
          hasVerifiedScore: true,
          result: computeResultSign(b1, b2),
        });
        continue;
      }
    }

    updated.push(m);
  }

  // Re-index display IDs sequentially within sorted leagues
  const sorted = [...updated].sort((a, b) => {
    if (a.leagueOrderRank !== b.leagueOrderRank) {
      return a.leagueOrderRank - b.leagueOrderRank;
    }
    if (a.leagueKey !== b.leagueKey) {
      return a.leagueKey.localeCompare(b.leagueKey);
    }
    return (a.time || '').localeCompare(b.time || '');
  });

  const leagueMap = new Map<string, import('../types/promosport').SiteLiveLeagueSummary>();
  let liveCount = 0;

  for (const item of sorted) {
    if (item.status === 'live') liveCount += 1;
    let ls = leagueMap.get(item.leagueKey);
    if (!ls) {
      ls = {
        leagueKey: item.leagueKey,
        countryName: item.countryName,
        countryAr: translateCountryToAr(item.countryName),
        leagueName: item.leagueName,
        countryFlagUrl: item.countryFlagUrl,
        leagueLogoUrl: item.leagueLogoUrl,
        rank: item.leagueOrderRank,
        totalCount: 0,
        liveCount: 0,
      };
      leagueMap.set(item.leagueKey, ls);
    }
    ls.totalCount += 1;
    if (item.status === 'live') ls.liveCount += 1;
  }

  const leagues = Array.from(leagueMap.values()).sort((a, b) => {
    if (a.rank !== b.rank) return a.rank - b.rank;
    return a.leagueKey.localeCompare(b.leagueKey);
  });

  return {
    matches: sorted,
    leagues,
    liveCount,
    totalCount: sorted.length,
    scannedAt: new Date().toISOString(),
    sourceUrl: PROMOSPORT_PRONOSTIC_HOME_URL,
  };
}

/**
 * Full domain scan of https://www.promosport-pronostic.com/welcome/promosport + promo_matchs + getmatchid_rapid
 */
export async function scanPromosportLiveCatalogHtml(): Promise<
  import('../types/promosport').SiteLiveMatch[]
> {
  const [homeHtml, matchsHtml] = await Promise.all([
    fetchTextSafe(PROMOSPORT_PRONOSTIC_HOME_URL, 7500),
    fetchTextSafe(PROMOSPORT_PRONOSTIC_MATCHS_URL, 7500),
  ]);

  const probMap = homeHtml ? parseProbabilitiesMapFromHomeHtml(homeHtml) : new Map();
  if (!matchsHtml) return [];
  return parsePromoMatchsCatalogHtml(matchsHtml, probMap);
}

