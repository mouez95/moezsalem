/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import type { PromosportGrille, WeeklyConcours } from '../types/promosport';

function decodeBasicEntities(str: string): string {
  return String(str || '')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&nbsp;/gi, ' ')
    .replace(/[\u2B06\u2B07\uFE0F]/g, '') // Strip promotion arrows (⬆️ ⬇️)
    .replace(/\s+/g, ' ')
    .trim();
}

export function hasArabicLetters(str: string): boolean {
  return /[\u0600-\u06FF]/.test(str);
}

export function hasLatinLetters(str: string): boolean {
  return /[a-zA-Z\u00C0-\u024F]/.test(str);
}

function normalizeLookupKey(raw: string): string {
  return decodeBasicEntities(raw)
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/ß/g, 'ss')
    .replace(/ø/g, 'o')
    .replace(/æ/g, 'ae')
    .replace(/ł/g, 'l')
    .replace(/đ/g, 'd')
    .replace(/&/g, ' and ')
    .replace(/['’`.]/g, ' ')
    .replace(/[-_/]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function stripClubAffixes(normKey: string): string {
  return normKey
    .replace(/\b(fc|cf|sc|sv|vfb|vfl|tsg|fsv|spvgg|rb|ac|as|ss|ssc|us|rc|cd|ud|sd|ad|ca|rcd|cp|afc|bfc|lfc|cfc|thfc|cfc|nk|fk|sk|ik|bk|if|aif|rsc|krc|kaa|kv|fck|psv|bsc|ksc|efl|csc|osc|sco|aj|ogc|sm|stade)\b/g, ' ')
    .replace(/\b(1899|1860|1846|1904|1907|1909|1910|1911|1912|1913|1920|1948|04|05|07|09|96|98)\b/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Comprehensive Arabic translations for FIFA national teams & worldwide clubs
 * appearing in Promosport Tunisie grilles and live score feeds.
 */
export const RAW_TEAM_AR_DICTIONARY: Record<string, string> = {
  // === FIFA NATIONAL TEAMS (English + French Variants) ===
  'Tunisia': 'تونس',
  'Tunisie': 'تونس',
  'Morocco': 'المغرب',
  'Maroc': 'المغرب',
  'Algeria': 'الجزائر',
  'Algerie': 'الجزائر',
  'Egypt': 'مصر',
  'Egypte': 'مصر',
  'Libya': 'ليبيا',
  'Libye': 'ليبيا',
  'Mauritania': 'موريتانيا',
  'Mauritanie': 'موريتانيا',
  'Sudan': 'السودان',
  'Soudan': 'السودان',
  'Comoros': 'جزر القمر',
  'Comores': 'جزر القمر',
  'Congo': 'الكونغو',
  'RD Congo': 'الكونغو الديمقراطية',
  'DR Congo': 'الكونغو الديمقراطية',
  'Congo DR': 'الكونغو الديمقراطية',
  'Burkina Faso': 'بوركينا فاسو',
  'Rwanda': 'رواندا',
  'Mali': 'مالي',
  'Botswana': 'بوتسوانا',
  'Uganda': 'أوغندا',
  'Ouganda': 'أوغندا',
  'Liberia': 'ليبيريا',
  'Cape Verde': 'الرأس الأخضر',
  'Cape Verde Islands': 'الرأس الأخضر',
  'Cap-Vert': 'الرأس الأخضر',
  'Niger': 'النيجر',
  'Nigeria': 'نيجيريا',
  'Cameroon': 'الكاميرون',
  'Cameroun': 'الكاميرون',
  'Senegal': 'السنغال',
  'Ghana': 'غانا',
  'Ivory Coast': 'كوت ديفوار',
  "Cote d'Ivoire": 'كوت ديفوار',
  'Cote D ivoire': 'كوت ديفوار',
  'South Africa': 'جنوب إفريقيا',
  'Afrique du Sud': 'جنوب إفريقيا',
  'Guinea': 'غينيا',
  'Guinee': 'غينيا',
  'Equatorial Guinea': 'غينيا الاستوائية',
  'Guinee Equatoriale': 'غينيا الاستوائية',
  'Guinea-Bissau': 'غينيا بيساو',
  'Guinee Bissau': 'غينيا بيساو',
  'Zimbabwe': 'زيمبابوي',
  'Madagascar': 'مدغشقر',
  'Gambia': 'غامبيا',
  'Gambie': 'غامبيا',
  'Sierra Leone': 'سيراليون',
  'Benin': 'بنين',
  'Central African Republic': 'إفريقيا الوسطى',
  'Afrique Centrale': 'إفريقيا الوسطى',
  'Togo': 'توغو',
  'Gabon': 'الغابون',
  'Angola': 'أنغولا',
  'Zambia': 'زامبيا',
  'Zambie': 'زامبيا',
  'Kenya': 'كينيا',
  'Tanzania': 'تنزانيا',
  'Tanzanie': 'تنزانيا',
  'Mozambique': 'موزمبيق',
  'Namibia': 'ناميبيا',
  'Namibie': 'ناميبيا',
  'Ethiopia': 'إثيوبيا',
  'Malawi': 'مالاوي',
  'Burundi': 'بوروندي',
  'Chad': 'تشاد',
  'Tchad': 'تشاد',
  'Djibouti': 'جيبوتي',
  'Somalia': 'الصومال',
  'Eswatini': 'إسواتيني',
  'Lesotho': 'ليسوتو',
  'Mauritius': 'موريشيوس',
  'Seychelles': 'سيشل',
  'South Sudan': 'جنوب السودان',

  // Europe National Teams
  'France': 'فرنسا',
  'Prancis': 'فرنسا',
  'Spain': 'إسبانيا',
  'Espagne': 'إسبانيا',
  'England': 'إنجلترا',
  'Angleterre': 'إنجلترا',
  'Italy': 'إيطاليا',
  'Italie': 'إيطاليا',
  'Germany': 'ألمانيا',
  'Allemagne': 'ألمانيا',
  'Deutschland': 'ألمانيا',
  'Portugal': 'البرتغال',
  'Netherlands': 'هولندا',
  'Pays-Bas': 'هولندا',
  'Pays Bas': 'هولندا',
  'Holland': 'هولندا',
  'Belgium': 'بلجيكا',
  'Belgique': 'بلجيكا',
  'Croatia': 'كرواتيا',
  'Croatie': 'كرواتيا',
  'Turkey': 'تركيا',
  'Turquie': 'تركيا',
  'Türkiye': 'تركيا',
  'Turkiye': 'تركيا',
  'Switzerland': 'سويسرا',
  'Suisse': 'سويسرا',
  'Austria': 'النمسا',
  'Autriche': 'النمسا',
  'Denmark': 'الدنمارك',
  'Danemark': 'الدنمارك',
  'Norway': 'النرويج',
  'Norvege': 'النرويج',
  'Sweden': 'السويد',
  'Suede': 'السويد',
  'Poland': 'بولندا',
  'Pologne': 'بولندا',
  'Polandia': 'بولندا',
  'Ukraine': 'أوكرانيا',
  'Czechia': 'التشيك',
  'Czech Republic': 'التشيك',
  'Tcheque': 'التشيك',
  'Republique Tcheque': 'التشيك',
  'Greece': 'اليونان',
  'Grece': 'اليونان',
  'Scotland': 'إسكتلندا',
  'Ecosse': 'إسكتلندا',
  'Wales': 'ويلز',
  'Pays de Galles': 'ويلز',
  'Ireland': 'أيرلندا',
  'Irlande': 'أيرلندا',
  'Rep. Of Ireland': 'جمهورية أيرلندا',
  'Republic of Ireland': 'جمهورية أيرلندا',
  'Northern Ireland': 'أيرلندا الشمالية',
  'Irlande du Nord': 'أيرلندا الشمالية',
  'Hungary': 'المجر',
  'Hongrie': 'المجر',
  'Romania': 'رومانيا',
  'Roumanie': 'رومانيا',
  'Serbia': 'صربيا',
  'Serbie': 'صربيا',
  'Bosnia & Herzegovina': 'البوسنة والهرسك',
  'Bosnia and Herzegovina': 'البوسنة والهرسك',
  'Bosnie Herzegovine': 'البوسنة والهرسك',
  'Georgia': 'جورجيا',
  'Georgie': 'جورجيا',
  'Albania': 'ألبانيا',
  'Albanie': 'ألبانيا',
  'Finland': 'فنلندا',
  'Finlande': 'فنلندا',
  'Kosovo': 'كوسوفو',
  'Belarus': 'بيلاروسيا',
  'Bielorussie': 'بيلاروسيا',
  'Cyprus': 'قبرص',
  'Chypre': 'قبرص',
  'Montenegro': 'الجبل الأسود',
  'Latvia': 'لاتفيا',
  'Lettonie': 'لاتفيا',
  'Armenia': 'أرمينيا',
  'Armenie': 'أرمينيا',
  'Iceland': 'آيسلندا',
  'Islande': 'آيسلندا',
  'Slovakia': 'سلوفاكيا',
  'Slovaquie': 'سلوفاكيا',
  'Slovenia': 'سلوفينيا',
  'Slovenie': 'سلوفينيا',
  'Bulgaria': 'بلغاريا',
  'Bulgarie': 'بلغاريا',
  'North Macedonia': 'مقدونيا الشمالية',
  'Macedoine du Nord': 'مقدونيا الشمالية',
  'Russia': 'روسيا',
  'Russie': 'روسيا',
  'Estonia': 'إستونيا',
  'Estonie': 'إستونيا',
  'Lithuania': 'ليتوانيا',
  'Lituanie': 'ليتوانيا',
  'Moldova': 'مولدوفا',
  'Moldavie': 'مولدوفا',
  'Luxembourg': 'لوكسمبورغ',
  'Malta': 'مالطا',
  'Malte': 'مالطا',
  'Andorra': 'أندورا',
  'Andorre': 'أندورا',
  'Azerbaijan': 'أذربيجان',
  'Azerbaidjan': 'أذربيجان',
  'Kazakhstan': 'كازاخستان',
  'Faroe Islands': 'جزر فارو',
  'Gibraltar': 'جبل طارق',
  'Liechtenstein': 'ليختنشتاين',
  'San Marino': 'سان مارينو',

  // Americas & Asia & Oceania National Teams
  'Brazil': 'البرازيل',
  'Bresil': 'البرازيل',
  'Argentina': 'الأرجنتين',
  'Argentine': 'الأرجنتين',
  'Uruguay': 'أوروغواي',
  'Colombia': 'كولومبيا',
  'Colombie': 'كولومبيا',
  'Chile': 'تشيلي',
  'Chili': 'تشيلي',
  'Ecuador': 'الإكوادور',
  'Equateur': 'الإكوادور',
  'Peru': 'بيرو',
  'Perou': 'بيرو',
  'Paraguay': 'باراغواي',
  'Venezuela': 'فنزويلا',
  'Bolivia': 'بوليفيا',
  'Bolivie': 'بوليفيا',
  'USA': 'الولايات المتحدة',
  'United States': 'الولايات المتحدة',
  'Etats-Unis': 'الولايات المتحدة',
  'Mexico': 'المكسيك',
  'Mexique': 'المكسيك',
  'Canada': 'كندا',
  'Jamaica': 'جامايكا',
  'Jamaique': 'جامايكا',
  'Haiti': 'هايتي',
  'Costa Rica': 'كوستاريكا',
  'Panama': 'بنما',
  'Honduras': 'هندوراس',
  'El Salvador': 'السلفادور',
  'Guatemala': 'غواتيمالا',
  'Nicaragua': 'نيكاراغوا',
  'French Guyana': 'غويانا الفرنسية',
  'St. Vincent / Grenadines': 'سانت فنسنت والغرينادين',
  'Saint Martin': 'سانت مارتن',
  'Montserrat': 'مونتسرات',
  'Suriname': 'سورينام',
  'Trinidad and Tobago': 'ترينيداد وتوباغو',
  'Curacao': 'كوراساو',
  'Saudi Arabia': 'السعودية',
  'Arabie Saoudite': 'السعودية',
  'Qatar': 'قطر',
  'UAE': 'الإمارات',
  'United Arab Emirates': 'الإمارات',
  'Iraq': 'العراق',
  'Jordan': 'الأردن',
  'Jordanie': 'الأردن',
  'Oman': 'عمان',
  'Bahrain': 'البحرين',
  'Kuwait': 'الكويت',
  'Koweit': 'الكويت',
  'Syria': 'سوريا',
  'Syrie': 'سوريا',
  'Lebanon': 'لبنان',
  'Liban': 'لبنان',
  'Palestine': 'فلسطين',
  'Yemen': 'اليمن',
  'Iran': 'إيران',
  'Japan': 'اليابان',
  'Japon': 'اليابان',
  'South Korea': 'كوريا الجنوبية',
  'Coree du Sud': 'كوريا الجنوبية',
  'Korea Republic': 'كوريا الجنوبية',
  'Australia': 'أستراليا',
  'Australie': 'أستراليا',
  'China': 'الصين',
  'Chine': 'الصين',
  'Uzbekistan': 'أوزبكستان',
  'Indonesia': 'إندونيسيا',
  'Vietnam': 'فيتنام',
  'Thailand': 'تايلاند',
  'India': 'الهند',
  'New Zealand': 'نيوزيلندا',

  // === ENGLAND: PREMIER LEAGUE, CHAMPIONSHIP & LEAGUE ONE ===
  'Arsenal': 'أرسنال',
  'Aston Villa': 'أستون فيلا',
  'Bournemouth': 'بورنموث',
  'AFC Bournemouth': 'بورنموث',
  'Brentford': 'برينتفورد',
  'Brighton': 'برايتون',
  'Brighton & Hove Albion': 'برايتون',
  'Chelsea': 'تشيلسي',
  'Crystal Palace': 'كريستال بالاس',
  'Everton': 'إيفرتون',
  'Fulham': 'فولهام',
  'Ipswich': 'إيبسويتش تاون',
  'Ipswich Town': 'إيبسويتش تاون',
  'Leeds': 'ليدز يونايتد',
  'Leeds United': 'ليدز يونايتد',
  'Leeds Utd': 'ليدز يونايتد',
  'Leicester': 'ليستر سيتي',
  'Leicester City': 'ليستر سيتي',
  'Liverpool': 'ليفربول',
  'Man City': 'مانشستر سيتي',
  'Manchester City': 'مانشستر سيتي',
  'Man United': 'مانشستر يونايتد',
  'Man Utd': 'مانشستر يونايتد',
  'Manchester United': 'مانشستر يونايتد',
  'Manchester Utd': 'مانشستر يونايتد',
  'Newcastle': 'نيوكاسل يونايتد',
  'Newcastle United': 'نيوكاسل يونايتد',
  'Newcastle Utd': 'نيوكاسل يونايتد',
  'Nottingham Forest': 'نوتنغهام فورست',
  'Nottingham': 'نوتنغهام فورست',
  'Southampton': 'ساوثهامبتون',
  'Sunderland': 'سندرلاند',
  'Tottenham': 'توتنهام',
  'Tottenham Hotspur': 'توتنهام',
  'West Ham': 'وست هام يونايتد',
  'West Ham United': 'وست هام يونايتد',
  'Wolves': 'وولفرهامبتون',
  'Wolverhampton': 'وولفرهامبتون',
  'Wolverhampton Wanderers': 'وولفرهامبتون',
  'Burnley': 'بيرنلي',
  'Sheffield United': 'شيفيلد يونايتد',
  'Sheffield Utd': 'شيفيلد يونايتد',
  'Sheffield Wednesday': 'شيفيلد وينزداي',
  'Coventry': 'كوفنتري سيتي',
  'Coventry City': 'كوفنتري سيتي',
  'Middlesbrough': 'ميدلزبره',
  'Norwich': 'نورويتش سيتي',
  'Norwich City': 'نورويتش سيتي',
  'Blackburn': 'بلاكبيرن روفرز',
  'Blackburn Rovers': 'بلاكبيرن روفرز',
  'Watford': 'واتفورد',
  'West Brom': 'وست بروميتش',
  'West Bromwich Albion': 'وست بروميتش ألبيون',
  'Stoke': 'ستوك سيتي',
  'Stoke City': 'ستوك سيتي',
  'Swansea': 'سوانزي سيتي',
  'Swansea City': 'سوانزي سيتي',
  'Cardiff': 'كارديف سيتي',
  'Cardiff City': 'كارديف سيتي',
  'QPR': 'كوينز بارك رينجرز',
  'Queens Park Rangers': 'كوينز بارك رينجرز',
  'Millwall': 'ميلوول',
  'Hull': 'هال سيتي',
  'Hull City': 'هال سيتي',
  'Preston': 'بريستون نورث إند',
  'Preston North End': 'بريستون نورث إند',
  'Bristol City': 'بريستول سيتي',
  'Plymouth': 'بليموث أرجايل',
  'Plymouth Argyle': 'بليموث أرجايل',
  'Derby': 'ديربي كاونتي',
  'Derby County': 'ديربي كاونتي',
  'Portsmouth': 'بورتسموث',
  'Oxford United': 'أكسفورد يونايتد',
  'Luton': 'لوتون تاون',
  'Luton Town': 'لوتون تاون',
  'Birmingham': 'برمنغهام سيتي',
  'Birmingham City': 'برمنغهام سيتي',
  'Wrexham': 'ريكسهام',
  'Bolton': 'بولتون واندررز',
  'Bolton Wanderers': 'بولتون واندررز',
  'Peterborough': 'بيتربورو يونايتد',
  'Peterborough United': 'بيتربورو يونايتد',
  'Reading': 'ريدينغ',
  'Charlton': 'تشارلتون أثلتيك',
  'Blackpool': 'بلاكبول',
  'Huddersfield': 'هدرسفيلد تاون',
  'Barnsley': 'بارنسلي',
  'Wigan': 'ويغان أثلتيك',
  'London City Lionesses': 'لندن سيتي ليونيسيس',

  // === GERMANY: BUNDESLIGA & 2. BUNDESLIGA ===
  'Bayern Munich': 'بايرن ميونخ',
  'Bayern Munchen': 'بايرن ميونخ',
  'FC Bayern Munich': 'بايرن ميونخ',
  'Borussia Dortmund': 'بوروسيا دورتموند',
  'B. Dortmund': 'بوروسيا دورتموند',
  'Dortmund': 'بوروسيا دورتموند',
  'Bayer Leverkusen': 'باير ليفركوزن',
  'Leverkusen': 'باير ليفركوزن',
  'RB Leipzig': 'لايبزيغ',
  'Leipzig': 'لايبزيغ',
  'VfB Stuttgart': 'شتوتغارت',
  'Stuttgart': 'شتوتغارت',
  'Eintracht Frankfurt': 'آينتراخت فرانكفورت',
  'Frankfurt': 'آينتراخت فرانكفورت',
  'SC Freiburg': 'فرايبورغ',
  'Freiburg': 'فرايبورغ',
  'Union Berlin': 'أونيون برلين',
  '1. FC Union Berlin': 'أونيون برلين',
  '1899 Hoffenheim': 'هوفنهايم',
  'TSG Hoffenheim': 'هوفنهايم',
  'Hoffenheim': 'هوفنهايم',
  'Werder Bremen': 'فيردر بريمن',
  'VfL Wolfsburg': 'فولفسبورغ',
  'Wolfsburg': 'فولفسبورغ',
  'Borussia Monchengladbach': 'بوروسيا مونشنغلادباخ',
  'Monchengladbach': 'بوروسيا مونشنغلادباخ',
  'FC Augsburg': 'أوغسبورغ',
  'Augsburg': 'أوغسبورغ',
  'Mainz 05': 'ماينتس 05',
  'FSV Mainz 05': 'ماينتس 05',
  'Mainz': 'ماينتس',
  '1. FC Heidenheim': 'هايدنهايم',
  'Heidenheim': 'هايدنهايم',
  'VfL Bochum': 'بوخوم',
  'Bochum': 'بوخوم',
  'St. Pauli': 'سانت باولي',
  'FC St. Pauli': 'سانت باولي',
  'Holstein Kiel': 'هولشتاين كيل',
  'FC Koln': 'كولن',
  '1. FC Koln': 'كولن',
  'Cologne': 'كولن',
  'Hamburger SV': 'هامبورغ',
  'Hamburg': 'هامبورغ',
  'Hertha Berlin': 'هيرتا برلين',
  'Hertha BSC': 'هيرتا برلين',
  'FC Schalke 04': 'شالكه 04',
  'Schalke 04': 'شالكه 04',
  'Schalke': 'شالكه 04',
  'SV Elversberg': 'إلفرسبرغ',
  'Elversberg': 'إلفرسبرغ',
  'SC Paderborn 07': 'بادربورن',
  'Paderborn': 'بادربورن',
  'Fortuna Dusseldorf': 'فورتونا دوسلدورف',
  'Hannover 96': 'هانوفر 96',
  '1. FC Kaiserslautern': 'كايزرسلاوترن',
  'Kaiserslautern': 'كايزرسلاوترن',
  'Karlsruher SC': 'كارلسروه',
  '1. FC Nurnberg': 'نورنبرغ',
  'Nurnberg': 'نورنبرغ',
  '1. FC Magdeburg': 'ماغديبورغ',
  'Magdeburg': 'ماغديبورغ',
  'Greuther Furth': 'غرويتر فورت',
  'Darmstadt 98': 'دارمشتات',
  'SV Darmstadt 98': 'دارمشتات',
  'Eintracht Braunschweig': 'آينتراخت براونشفايغ',
  'Preussen Munster': 'برويسن مونستر',
  'SSV Ulm 1846': 'أولم',
  'Jahn Regensburg': 'ريغنسبورغ',

  // === SPAIN: LA LIGA & LALIGA2 ===
  'Real Madrid': 'ريال مدريد',
  'Barcelona': 'برشلونة',
  'FC Barcelona': 'برشلونة',
  'Atletico Madrid': 'أتلتيكو مدريد',
  'Athletic Bilbao': 'أتلتيك بلباو',
  'Athletic Club': 'أتلتيك بلباو',
  'Villarreal': 'فياريال',
  'Real Sociedad': 'ريال سوسيداد',
  'Real Sociedad II': 'ريال سوسيداد ب',
  'Real Sociedad B': 'ريال سوسيداد ب',
  'Real Betis': 'ريال بيتيس',
  'Betis': 'ريال بيتيس',
  'Sevilla': 'إشبيلية',
  'Sevilla FC': 'إشبيلية',
  'Valencia': 'فالنسيا',
  'Valencia CF': 'فالنسيا',
  'Rayo Vallecano': 'رايو فاليكانو',
  'Girona': 'جيرونا',
  'Girona FC': 'جيرونا',
  'Celta Vigo': 'سيلتا فيغو',
  'Osasuna': 'أوساسونا',
  'Getafe': 'خيتافي',
  'Espanyol': 'إسبانيول',
  'Alaves': 'ديبورتيفو ألافيس',
  'Deportivo Alaves': 'ديبورتيفو ألافيس',
  'Mallorca': 'مايوركا',
  'RCD Mallorca': 'مايوركا',
  'Las Palmas': 'لاس بالماس',
  'Leganes': 'ليغانيس',
  'Valladolid': 'بلد الوليد',
  'Real Valladolid': 'بلد الوليد',
  'Elche': 'إلتشي',
  'Levante': 'ليفانتي',
  'Racing Santander': 'راسينغ سانتاندير',
  'Real Zaragoza': 'ريال سرقسطة',
  'Zaragoza': 'ريال سرقسطة',
  'Sporting Gijon': 'سبورتينغ خيخون',
  'Oviedo': 'ريال أوفييدو',
  'Real Oviedo': 'ريال أوفييدو',
  'Cadiz': 'قادش',
  'Eibar': 'إيبار',
  'Almeria': 'ألميريا',
  'UD Almeria': 'ألميريا',
  'Granada': 'غرناطة',
  'Granada CF': 'غرناطة',
  'Tenerife': 'تينيريفي',
  'CD Tenerife': 'تينيريفي',
  'Cordoba': 'قرطبة',
  'Huesca': 'هويسكا',
  'Burgos': 'بورغوس',
  'Malaga': 'مالقا',
  'Deportivo La Coruna': 'ديبورتيفو لاكورونيا',
  'Castellon': 'كاستيون',
  'Cartagena': 'قرطاجنة',
  'FC Cartagena': 'قرطاجنة',
  'Eldense': 'إلدينسي',
  'Sabadell': 'ساباديل',
  'FC Andorra': 'أندورا',
  'AD Ceuta FC': 'سبتة',
  'Ceuta': 'سبتة',
  'Mirandes': 'ميرانديس',
  'Albacete': 'ألباسيتي',
  'Albacete II': 'ألباسيتي ب',
  'Racing Ferrol': 'راسينغ فيرول',
  'Real Union': 'ريال يونيون',
  'Barakaldo': 'باراكالدو',
  'Badajoz': 'باداخوز',
  'Alcoyano': 'ألكويانو',
  'Utebo': 'أوتيبو',

  // === ITALY: SERIE A & SERIE B ===
  'Inter': 'إنتر ميلان',
  'Inter Milan': 'إنتر ميلان',
  'Internazionale': 'إنتر ميلان',
  'AC Milan': 'ميلان',
  'Milan': 'ميلان',
  'Juventus': 'يوفنتوس',
  'Napoli': 'نابولي',
  'SSC Napoli': 'نابولي',
  'Atalanta': 'أتالانتا',
  'Lazio': 'لاتسيو',
  'SS Lazio': 'لاتسيو',
  'AS Roma': 'روما',
  'Roma': 'روما',
  'Fiorentina': 'فيورنتينا',
  'Bologna': 'بولونيا',
  'Torino': 'تورينو',
  'Udinese': 'أودينيزي',
  'Genoa': 'جنوى',
  'Cagliari': 'كالياري',
  'Parma': 'بارما',
  'Como': 'كومو',
  'Verona': 'هيلاس فيرونا',
  'Hellas Verona': 'هيلاس فيرونا',
  'Empoli': 'إمبولي',
  'Lecce': 'ليتشي',
  'Monza': 'مونزا',
  'Venezia': 'فينيزيا',
  'Sassuolo': 'ساسولو',
  'Pisa': 'بيزا',
  'Spezia': 'سبيزيا',
  'Cremonese': 'كريمونيزي',
  'Palermo': 'باليرمو',
  'Sampdoria': 'سامبدوريا',
  'Bari': 'باري',
  'Brescia': 'بريشيا',
  'Modena': 'مودينا',
  'Salernitana': 'ساليرنيتانا',
  'Frosinone': 'فروزينوني',
  'Ternana': 'تيرنانا',
  'Piacenza': 'بياتشينزا',
  'Ancona': 'أنكونا',
  'Lucchese': 'لوكيزي',
  'Pro Patria': 'برو باتريا',

  // === FRANCE: LIGUE 1 & LIGUE 2 ===
  'Paris SG': 'باريس سان جيرمان',
  'Paris Saint Germain': 'باريس سان جيرمان',
  'Paris Saint-Germain': 'باريس سان جيرمان',
  'PSG': 'باريس سان جيرمان',
  'Marseille': 'مارسيليا',
  'Olympique Marseille': 'أولمبيك مارسيليا',
  'Monaco': 'موناكو',
  'AS Monaco': 'موناكو',
  'Lille': 'ليل',
  'Lille OSC': 'ليل',
  'Lyon': 'ليون',
  'Olympique Lyon': 'أولمبيك ليون',
  'Olympique Lyonnais': 'أولمبيك ليون',
  'Nice': 'نيس',
  'OGC Nice': 'نيس',
  'Lens': 'لانس',
  'RC Lens': 'لانس',
  'Reims': 'ريمس',
  'Stade de Reims': 'ريمس',
  'Rennes': 'رين',
  'Stade Rennais': 'رين',
  'Strasbourg': 'ستراسبورغ',
  'RC Strasbourg': 'ستراسبورغ',
  'Brest': 'ستاد بريست',
  'Stade Brestois': 'ستاد بريست',
  'Toulouse': 'تولوز',
  'Auxerre': 'أوكسير',
  'Nantes': 'نانت',
  'Angers': 'أنجيه',
  'Saint-Etienne': 'سانت إتيان',
  'Saint Etienne': 'سانت إتيان',
  'Le Havre': 'لوهافر',
  'Montpellier': 'مونبلييه',
  'Lorient': 'لوريان',
  'Metz': 'ميتز',
  'Paris FC': 'باريس إف سي',
  'Guingamp': 'غانغون',
  'Caen': 'كان',
  'Bastia': 'باستيا',
  'Bordeaux': 'بوردو',
  'Ajaccio': 'أجاكسيو',
  'Clermont': 'كليرمون فوت',
  'Troyes': 'تروا',
  'Pau': 'باو',
  'Laval': 'لافال',
  'Amiens': 'أميان',
  'Rodez': 'روديز',
  'Grenoble': 'غرونوبل',
  'Red Star': 'ريد ستار',

  // === OTHER MAJOR EUROPEAN, ARAB & WORLD CLUBS ===
  // Portugal
  'Benfica': 'بنفيكا',
  'SL Benfica': 'بنفيكا',
  'Porto': 'بورتو',
  'FC Porto': 'بورتو',
  'Sporting CP': 'سبورتينغ لشبونة',
  'Sporting Lisbon': 'سبورتينغ لشبونة',
  'Braga': 'سبورتينغ براغا',
  'SC Braga': 'سبورتينغ براغا',
  'Vitoria Guimaraes': 'فيتوريا غيماريش',
  'Vitoria SC': 'فيتوريا غيماريش',
  'Boavista': 'بوافيشتا',
  'Famalicao': 'فاماليكاو',
  'Estoril': 'إشتوريل',
  'Rio Ave': 'ريو أفي',
  'Gil Vicente': 'جيل فيسنتي',
  'Moreirense': 'موريرينسي',
  'Santa Clara': 'سانتا كلارا',
  'Nacional': 'ناسيونال ماديرا',
  // Netherlands
  'Ajax': 'أياكس',
  'AFC Ajax': 'أياكس',
  'PSV': 'بي إس في آيندهوفن',
  'PSV Eindhoven': 'بي إس في آيندهوفن',
  'Feyenoord': 'فينورد',
  'AZ Alkmaar': 'ألكمار',
  'Twente': 'تفينتي',
  'FC Twente': 'تفينتي',
  'Utrecht': 'أوتريخت',
  'FC Utrecht': 'أوتريخت',
  'Heerenveen': 'هيرينفين',
  'Groningen': 'غرونينغن',
  'Sparta Rotterdam': 'سبارتا روتردام',
  'Go Ahead Eagles': 'غو أهيد إيغلز',
  // Belgium
  'Club Brugge': 'كلوب بروج',
  'Anderlecht': 'أندرلخت',
  'Union SG': 'يونيون سانت جيلواز',
  'Union St. Gilloise': 'يونيون سانت جيلواز',
  'Genk': 'جينك',
  'KRC Genk': 'جينك',
  'Gent': 'غينت',
  'Antwerp': 'رويال أنتويرب',
  'Standard Liege': 'ستاندار لييج',
  'Charleroi': 'شارلروا',
  'Cercle Brugge': 'سيركل بروج',
  // Scotland
  'Celtic': 'سلتيك',
  'Celtic FC': 'سلتيك',
  'Rangers': 'رينجرز',
  'Aberdeen': 'أبردين',
  'Hearts': 'هارتس',
  'Hibernian': 'هيبرنيان',
  'Dundee': 'دندي',
  'Motherwell': 'ماذرويل',
  // Turkey
  'Galatasaray': 'غلطة سراي',
  'Fenerbahce': 'فنربخشة',
  'Besiktas': 'بشكتاش',
  'Trabzonspor': 'طرابزون سبور',
  'Basaksehir': 'باشاك شهير',
  'Istanbul Basaksehir': 'إسطنبول باشاك شهير',
  'Samsunspor': 'سامسون سبور',
  'Kasimpasa': 'قاسم باشا',
  // Greece, Switzerland, Austria, Nordic, Eastern Europe
  'Olympiacos': 'أولمبياكوس',
  'PAOK': 'باوك سالونيكا',
  'AEK Athens': 'أيك أثينا',
  'Panathinaikos': 'باناثينايكوس',
  'Young Boys': 'يونغ بويز',
  'Basel': 'بازل',
  'FC Basel': 'بازل',
  'Servette': 'سيرفيت',
  'Lugano': 'لوغانو',
  'Zurich': 'زيورخ',
  'RB Salzburg': 'ريد بول سالزبورغ',
  'Salzburg': 'سالزبورغ',
  'Sturm Graz': 'شتورم غراتس',
  'Rapid Wien': 'رابيد فيينا',
  'Austria Wien': 'أوستريا فيينا',
  'LASK': 'لاسك لينز',
  'FC Copenhagen': 'كوبنهاغن',
  'Copenhagen': 'كوبنهاغن',
  'Midtjylland': 'ميدتييلاند',
  'Brondby': 'بروندبي',
  'Malmo FF': 'مالمو',
  'Malmo': 'مالمو',
  'Bodo/Glimt': 'بودو غليمت',
  'Molde': 'مولده',
  'Rosenborg': 'روزنبورغ',
  'Shakhtar Donetsk': 'شاختار دونيتسك',
  'Dynamo Kyiv': 'دينامو كييف',
  'Sparta Prague': 'سبارتا براغ',
  'Slavia Prague': 'سلافيا براغ',
  'Viktoria Plzen': 'فيكتوريا بلزن',
  'Dinamo Zagreb': 'دينامو زغرب',
  'Hajduk Split': 'هايدوك سبليت',
  'Crvena Zvezda': 'النجم الأحمر بلغراد',
  'Red Star Belgrade': 'النجم الأحمر بلغراد',
  'Partizan': 'بارتيزان بلغراد',
  'Slovan Bratislava': 'سلوفان براتيسلافا',
  'Ferencvaros': 'فيرينتسفاروشي',
  'FCSB': 'ستيوا بوخارست',
  'CFR Cluj': 'كلوج',
  'Ludogorets': 'لودوغوريتس',
  'Qarabag': 'قره باغ',
  'Legia Warsaw': 'ليغيا وارسو',
  'Lech Poznan': 'ليخ بوزنان',
  'FC Noah': 'نوح الأرميني',
  // Tunisian Ligue 1 / 2 & CAF/Arab/Americas Clubs
  'Esperance Tunis': 'الترجي الرياضي',
  'Esperance ST': 'الترجي الرياضي',
  'Club Africain': 'النادي الإفريقي',
  'Etoile du Sahel': 'النجم الساحلي',
  'CS Sfaxien': 'النادي الصفاقسي',
  'US Monastir': 'الاتحاد المنستيري',
  'Stade Tunisien': 'الملعب التونسي',
  'CA Bizertin': 'النادي البنزرتي',
  'Olympique Beja': 'الأولمبي الباجي',
  'US Ben Guerdane': 'اتحاد بن قردان',
  'ES Metlaoui': 'نجم المتلوي',
  'AS Soliman': 'مستقبل سليمان',
  'US Tataouine': 'اتحاد تطاوين',
  'EGS Gafsa': 'قوافل قفصة',
  'AS Gabes': 'مستقبل قابس',
  'ES Zarzis': 'الترجي الجرجيسي',
  'JS Omrane': 'شبيبة العمران',
  'AS Marsa': 'مستقبل المرسى',
  'Redeyef': 'الرديف',
  'Ksour Essef': 'قصور الساف',
  'Al Ahly': 'الأهلي',
  'Zamalek': 'الزمالك',
  'Wydad': 'الوداد الرياضي',
  'Raja Casablanca': 'الرجاء الرياضي',
  'Al Hilal': 'الهلال',
  'Al Nassr': 'النصر',
  'Al Ittihad': 'الاتحاد',
  'Los Angeles': 'لوس أنجلوس',
  'Los Angeles FC': 'لوس أنجلوس',
  'Fluminense': 'فلومينينسي',
  'Boca Juniors': 'بوكا جونيورز',
  'River Plate': 'ريفر بليت',
  'Flamengo': 'فلامنغو',
  'Palmeiras': 'بالميراس',
  'Inter Miami': 'إنتر ميامي',
  'Buriram United': 'بوريرام يونايتد',
};

const NORMALIZED_AR_MAP: Record<string, string> = {};
const STRIPPED_AR_MAP: Record<string, string> = {};
const ARABIC_TO_FR_MAP: Record<string, string> = {};

for (const [latin, ar] of Object.entries(RAW_TEAM_AR_DICTIONARY)) {
  const norm = normalizeLookupKey(latin);
  if (norm && !NORMALIZED_AR_MAP[norm]) {
    NORMALIZED_AR_MAP[norm] = ar;
  }
  const stripped = stripClubAffixes(norm);
  if (stripped && !STRIPPED_AR_MAP[stripped]) {
    STRIPPED_AR_MAP[stripped] = ar;
  }
  if (ar && !ARABIC_TO_FR_MAP[ar]) {
    ARABIC_TO_FR_MAP[ar] = latin;
  }
}

/**
 * Phonetic Latin -> Arabic transliteration safety net so no club name ever remains
 * unreadable English/French when the user selects Arabic (AR).
 */
function transliterateLatinWordToArabic(word: string): string {
  if (!word) return '';
  if (/^\d+$/.test(word)) return word;
  const upper = word.toUpperCase();
  if (upper === 'FC' || upper === 'CF' || upper === 'SC' || upper === 'AC' || upper === 'AS' || upper === 'CD' || upper === 'UD' || upper === 'SD' || upper === 'SV') {
    return '';
  }
  if (upper === 'II' || upper === 'B') return 'ب';
  if (upper === 'U21') return 'تحت 21';
  if (upper === 'U23') return 'تحت 23';
  if (upper === 'U19') return 'تحت 19';
  if (upper === 'W') return '(سيدات)';

  let s = word
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');

  // Common digraphs & football word endings
  s = s
    .replace(/united/g, 'يونايتد')
    .replace(/utd/g, 'يونايتد')
    .replace(/city/g, 'سيتي')
    .replace(/town/g, 'تاون')
    .replace(/rovers/g, 'روفرز')
    .replace(/wanderers/g, 'واندررز')
    .replace(/athletic/g, 'أثلتيك')
    .replace(/albion/g, 'ألبيون')
    .replace(/borough/g, 'بورو')
    .replace(/forest/g, 'فورست')
    .replace(/palace/g, 'بالاس')
    .replace(/real/g, 'ريال')
    .replace(/sporting/g, 'سبورتينغ')
    .replace(/olympique/g, 'أولمبيك')
    .replace(/saint/g, 'سانت')
    .replace(/tion/g, 'شن')
    .replace(/sion/g, 'جن')
    .replace(/sch/g, 'ش')
    .replace(/tch/g, 'تش')
    .replace(/ch/g, 'تش')
    .replace(/sh/g, 'ش')
    .replace(/th/g, 'ث')
    .replace(/ph/g, 'ف')
    .replace(/gh/g, 'غ')
    .replace(/kh/g, 'خ')
    .replace(/qu/g, 'كو')
    .replace(/ck/g, 'ك')
    .replace(/oo/g, 'و')
    .replace(/ou/g, 'و')
    .replace(/ee/g, 'ي')
    .replace(/ea/g, 'ي')
    .replace(/ai/g, 'اي')
    .replace(/ay/g, 'اي')
    .replace(/ei/g, 'اي')
    .replace(/ey/g, 'ي')
    .replace(/ng/g, 'نغ')
    .replace(/c(?=[eiy])/g, 'س');

  const charMap: Record<string, string> = {
    a: 'ا',
    b: 'ب',
    c: 'ك',
    d: 'د',
    e: 'ي',
    f: 'ف',
    g: 'غ',
    h: 'ه',
    i: 'ي',
    j: 'ج',
    k: 'ك',
    l: 'ل',
    m: 'م',
    n: 'ن',
    o: 'و',
    p: 'ب',
    q: 'ق',
    r: 'ر',
    s: 'س',
    t: 'ت',
    u: 'و',
    v: 'ف',
    w: 'و',
    x: 'كس',
    y: 'ي',
    z: 'ز',
  };

  let out = '';
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (/[\u0600-\u06FF0-9()]/.test(ch)) {
      out += ch;
    } else if (charMap[ch]) {
      // Avoid double consecutive Arabic letters from Latin doubles like 'll', 'ss', 'tt'
      const mapped = charMap[ch];
      if (out.endsWith(mapped) && mapped !== 'ل') continue;
      out += mapped;
    }
  }
  return out;
}

function transliterateLatinPhraseToArabic(phrase: string): string {
  const words = decodeBasicEntities(phrase)
    .split(/\s+/)
    .map(transliterateLatinWordToArabic)
    .filter(Boolean);
  return words.join(' ').trim() || phrase;
}

function lookupLatinToArabic(candidate: string): string | null {
  const clean = decodeBasicEntities(candidate);
  if (!clean) return null;
  if (hasArabicLetters(clean) && !hasLatinLetters(clean)) return clean;

  // Extract reserve / women / youth suffix tags before lookup
  let base = clean;
  let suffixAr = '';

  const womenMatch = base.match(/^(.*?)\s+(?:W|Women|Feminin|Féminin|Féminines|Fem)$/i);
  if (womenMatch) {
    base = womenMatch[1].trim();
    suffixAr = ' (سيدات)';
  } else {
    const youthMatch = base.match(/^(.*?)\s+(U17|U18|U19|U20|U21|U23)$/i);
    if (youthMatch) {
      base = youthMatch[1].trim();
      suffixAr = ` (تحت ${youthMatch[2].slice(1)})`;
    } else {
      const resMatch = base.match(/^(.*?)\s+(?:II|B|Res\.?)$/i);
      if (resMatch) {
        base = resMatch[1].trim();
        suffixAr = ' ب';
      }
    }
  }

  const normFull = normalizeLookupKey(base);
  if (NORMALIZED_AR_MAP[normFull]) {
    return `${NORMALIZED_AR_MAP[normFull]}${suffixAr}`;
  }

  const stripped = stripClubAffixes(normFull);
  if (stripped && (NORMALIZED_AR_MAP[stripped] || STRIPPED_AR_MAP[stripped])) {
    const found = NORMALIZED_AR_MAP[stripped] || STRIPPED_AR_MAP[stripped];
    return `${found}${suffixAr}`;
  }

  return null;
}

/**
 * Translates any team name (Arabic, French, or English) to clean Arabic.
 * Guarantees an Arabic result even for previously unseen clubs.
 */
export function translateTeamToArabic(teamName: string, frName?: string): string {
  const primary = decodeBasicEntities(teamName);
  const alt = decodeBasicEntities(frName || '');

  // If primary already is pure Arabic without Latin fallback
  if (primary && hasArabicLetters(primary) && !hasLatinLetters(primary)) {
    return primary;
  }

  const fromPrimary = lookupLatinToArabic(primary);
  if (fromPrimary) return fromPrimary;

  const fromAlt = alt ? lookupLatinToArabic(alt) : null;
  if (fromAlt) return fromAlt;

  const source = primary || alt;
  if (!source) return '';
  if (hasArabicLetters(source) && !hasLatinLetters(source)) return source;
  return transliterateLatinPhraseToArabic(source);
}

/**
 * Resolves the clean French/Latin display name when `lang === 'FR'`.
 */
export function translateTeamToFrench(teamName: string, frName?: string): string {
  const cleanFr = decodeBasicEntities(frName || '');
  if (cleanFr && hasLatinLetters(cleanFr)) return cleanFr;
  const cleanPrimary = decodeBasicEntities(teamName);
  if (cleanPrimary && hasLatinLetters(cleanPrimary)) return cleanPrimary;
  if (ARABIC_TO_FR_MAP[cleanPrimary]) return ARABIC_TO_FR_MAP[cleanPrimary];
  return cleanFr || cleanPrimary;
}

const COMPETITION_AR_DICTIONARY: Record<string, string> = {
  'UEFA Nations League': 'دوري الأمم الأوروبية',
  'Africa Cup of Nations - Qualification': 'تصفيات كأس أمم إفريقيا',
  'Africa Cup of Nations': 'كأس أمم إفريقيا',
  'World Cup - Qualification': 'تصفيات كأس العالم',
  'World Cup': 'كأس العالم',
  'Champions League': 'دوري أبطال أوروبا',
  'UEFA Champions League': 'دوري أبطال أوروبا',
  'Europa League': 'الدوري الأوروبي',
  'UEFA Europa League': 'الدوري الأوروبي',
  'Conference League': 'دوري المؤتمر الأوروبي',
  'UEFA Europa Conference League': 'دوري المؤتمر الأوروبي',
  'Premier League': 'الدوري الإنجليزي الممتاز',
  'Championship': 'دوري البطولة الإنجليزية',
  'FA Cup': 'كأس الاتحاد الإنجليزي',
  'EFL Cup': 'كأس الرابطة الإنجليزية',
  'La Liga': 'الدوري الإسباني',
  'LaLiga': 'الدوري الإسباني',
  'LaLiga Hypermotion': 'الدوري الإسباني الدرجة 2',
  'Segunda División': 'الدوري الإسباني الدرجة 2',
  'Segunda Division': 'الدوري الإسباني الدرجة 2',
  'Copa del Rey': 'كأس ملك إسبانيا',
  'Serie A': 'الدوري الإيطالي',
  'Serie B': 'الدوري الإيطالي الدرجة 2',
  'Coppa Italia': 'كأس إيطاليا',
  'Ligue 1': 'الدوري الفرنسي',
  'Ligue 2': 'الدوري الفرنسي الدرجة 2',
  'Coupe de France': 'كأس فرنسا',
  'Bundesliga': 'الدوري الألماني',
  '2. Bundesliga': 'الدوري الألماني الدرجة 2',
  'DFB Pokal': 'كأس ألمانيا',
  'Primeira Liga': 'الدوري البرتغالي',
  'Liga Portugal': 'الدوري البرتغالي',
  'Eredivisie': 'الدوري الهولندي',
  'Jupiler Pro League': 'الدوري البلجيكي',
  'Pro League': 'الدوري البلجيكي',
  'Super Lig': 'الدوري التركي',
  'Süper Lig': 'الدوري التركي',
  'Premiership': 'الدوري الإسكتلندي',
  'Ligue Professionnelle 1': 'الرابطة المحترفة الأولى التونسية',
  'Ligue 1 Pro': 'الرابطة المحترفة الأولى التونسية',
  'Football': 'مباراة كرة قدم',
};

const NORMALIZED_COMP_AR_MAP: Record<string, string> = {};
for (const [k, v] of Object.entries(COMPETITION_AR_DICTIONARY)) {
  NORMALIZED_COMP_AR_MAP[normalizeLookupKey(k)] = v;
}

export function translateCompetitionToArabic(competition?: string, competitionFr?: string): string {
  const cleanPrimary = decodeBasicEntities(competition || '');
  const cleanFr = decodeBasicEntities(competitionFr || '');

  if (cleanPrimary && hasArabicLetters(cleanPrimary) && !hasLatinLetters(cleanPrimary)) {
    return cleanPrimary;
  }

  const candidate = cleanFr || cleanPrimary;
  if (!candidate) return 'النتيجة الرسمية';

  // Preserve "(1ère MT)" / "(1ère mi-temps)" suffix
  const halfMatch = candidate.match(/^(.*?)\s*\((1ère MT|1ère mi-temps|1st Half)\)$/i);
  const base = halfMatch ? halfMatch[1].trim() : candidate;
  const suffix = halfMatch ? ' (الشوط 1)' : '';

  const normBase = normalizeLookupKey(base);
  if (NORMALIZED_COMP_AR_MAP[normBase]) {
    return `${NORMALIZED_COMP_AR_MAP[normBase]}${suffix}`;
  }

  // Try matching known league keyword inside compound string like "England : Premier League"
  for (const [normKey, arVal] of Object.entries(NORMALIZED_COMP_AR_MAP)) {
    if (normKey.length >= 6 && normBase.includes(normKey)) {
      return `${arVal}${suffix}`;
    }
  }

  if (cleanPrimary && hasArabicLetters(cleanPrimary)) return cleanPrimary;
  return candidate;
}

/**
 * Normalizes all team and competition names on a cached or newly synced WeeklyConcours
 * so stale localStorage/server JSON from earlier parser runs immediately shows crisp Arabic names.
 */
export function normalizeConcoursTranslations(concours: WeeklyConcours): WeeklyConcours {
  if (!concours || !Array.isArray(concours.matches)) return concours;
  return {
    ...concours,
    matches: concours.matches.map((m) => {
      const frHome = translateTeamToFrench(m.homeTeam, m.homeTeamFr);
      const frAway = translateTeamToFrench(m.awayTeam, m.awayTeamFr);
      const arHome = translateTeamToArabic(m.homeTeam, frHome);
      const arAway = translateTeamToArabic(m.awayTeam, frAway);
      const arComp = translateCompetitionToArabic(m.competition || '', m.competitionFr);
      return {
        ...m,
        homeTeam: arHome,
        homeTeamFr: frHome || m.homeTeamFr,
        awayTeam: arAway,
        awayTeamFr: frAway || m.awayTeamFr,
        competition: arComp,
      };
    }),
  };
}

export function normalizeGrilleTranslations(grille: PromosportGrille): PromosportGrille {
  if (!grille || !Array.isArray(grille.matches)) return grille;
  return {
    ...grille,
    matches: grille.matches.map((m) => {
      const frHome = translateTeamToFrench(m.homeTeam, m.homeTeamFr);
      const frAway = translateTeamToFrench(m.awayTeam, m.awayTeamFr);
      const arHome = translateTeamToArabic(m.homeTeam, frHome);
      const arAway = translateTeamToArabic(m.awayTeam, frAway);
      const arComp = translateCompetitionToArabic(m.competition || '', m.competitionFr);
      return {
        ...m,
        homeTeam: arHome,
        homeTeamFr: frHome || m.homeTeamFr,
        awayTeam: arAway,
        awayTeamFr: frAway || m.awayTeamFr,
        competition: arComp,
      };
    }),
  };
}
