/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ParticipantProfile } from '../types/promosport';
import { getStoredRemoteSyncOrigin } from './storageService';

const PARTICIPANT_PROFILE_KEY = 'promosport_participant_profile_v1';
const PARTICIPANT_BACKUP_KEY = 'promosport_participant_profile_backup_v1';
const PARTICIPANT_DEVICE_ID_KEY = 'promosport_participant_device_id_v1';
const PARTICIPANT_COOKIE_NAME = 'promosport_participant_owner_v1';
const PARTICIPANT_CACHE_NAME = 'promosport-participant-v1';
const PARTICIPANT_CACHE_URL = '/__promosport_participant.json';
const PARTICIPANT_IDB_NAME = 'promosport_participant_db';
const PARTICIPANT_IDB_STORE = 'profile';
const PARTICIPANT_IDB_KEY = 'owner';
const PARTICIPANT_REVERIFY_EPOCH_KEY = 'promosport_participant_reverify_epoch_v1';
const CURRENT_REVERIFY_EPOCH = '2026-11-19-reverify-1';
let pendingSessionClearPromise: Promise<void> | null = null;

function isValidProfile(value: unknown): value is ParticipantProfile {
  if (!value || typeof value !== 'object') return false;
  const p = value as Partial<ParticipantProfile>;
  return (
    typeof p.id === 'string' &&
    p.id.trim().length > 0 &&
    typeof p.baseName === 'string' &&
    p.baseName.trim().length > 0 &&
    typeof p.suffixDigits === 'string' &&
    /^\d{2}$/.test(p.suffixDigits) &&
    typeof p.fullName === 'string' &&
    p.fullName.trim().length > 0 &&
    typeof p.registeredAt === 'string'
  );
}

export function cleanParticipantInputName(raw: string): string {
  return String(raw || '')
    .replace(/[\r\n\t]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 40);
}

function generateCryptoTwoDigits(): string {
  try {
    if (typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function') {
      const buf = new Uint32Array(1);
      crypto.getRandomValues(buf);
      const num = 10 + (buf[0] % 90);
      return String(num);
    }
  } catch {
    // ignore crypto fallback errors
  }
  return String(Math.floor(10 + Math.random() * 90));
}

function getOrCreateDeviceId(): string {
  try {
    const existing = localStorage.getItem(PARTICIPANT_DEVICE_ID_KEY);
    if (existing && existing.trim().length >= 6) {
      return existing.trim();
    }
  } catch {
    // ignore storage errors
  }

  let randomPart = '';
  try {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
      randomPart = crypto.randomUUID();
    }
  } catch {
    // fallback below
  }
  if (!randomPart) {
    randomPart = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  }
  const deviceId = `ps-${randomPart}`;
  try {
    localStorage.setItem(PARTICIPANT_DEVICE_ID_KEY, deviceId);
  } catch {
    // ignore storage errors
  }
  return deviceId;
}

function readProfileCookie(): ParticipantProfile | null {
  try {
    if (typeof document === 'undefined' || !document.cookie) return null;
    const parts = document.cookie.split(';');
    for (const part of parts) {
      const trimmed = part.trim();
      if (!trimmed.startsWith(`${PARTICIPANT_COOKIE_NAME}=`)) continue;
      const encoded = trimmed.slice(PARTICIPANT_COOKIE_NAME.length + 1);
      const parsed = JSON.parse(decodeURIComponent(encoded));
      if (isValidProfile(parsed)) return parsed;
    }
  } catch {
    // ignore cookie errors
  }
  return null;
}

function writeProfileCookie(profile: ParticipantProfile): void {
  try {
    if (typeof document === 'undefined') return;
    const encoded = encodeURIComponent(JSON.stringify(profile));
    document.cookie = `${PARTICIPANT_COOKIE_NAME}=${encoded}; max-age=315360000; path=/; SameSite=Lax`;
  } catch {
    // ignore cookie write errors
  }
}

function writeToIndexedDB(profile: ParticipantProfile): Promise<void> {
  return new Promise((resolve) => {
    try {
      if (typeof indexedDB === 'undefined') {
        resolve();
        return;
      }
      const req = indexedDB.open(PARTICIPANT_IDB_NAME, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(PARTICIPANT_IDB_STORE)) {
          db.createObjectStore(PARTICIPANT_IDB_STORE);
        }
      };
      req.onsuccess = () => {
        try {
          const db = req.result;
          const tx = db.transaction(PARTICIPANT_IDB_STORE, 'readwrite');
          tx.objectStore(PARTICIPANT_IDB_STORE).put(profile, PARTICIPANT_IDB_KEY);
          tx.oncomplete = () => {
            db.close();
            resolve();
          };
          tx.onerror = () => {
            db.close();
            resolve();
          };
        } catch {
          resolve();
        }
      };
      req.onerror = () => resolve();
    } catch {
      resolve();
    }
  });
}

function readFromIndexedDB(): Promise<ParticipantProfile | null> {
  return new Promise((resolve) => {
    try {
      if (typeof indexedDB === 'undefined') {
        resolve(null);
        return;
      }
      const req = indexedDB.open(PARTICIPANT_IDB_NAME, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(PARTICIPANT_IDB_STORE)) {
          db.createObjectStore(PARTICIPANT_IDB_STORE);
        }
      };
      req.onsuccess = () => {
        try {
          const db = req.result;
          const tx = db.transaction(PARTICIPANT_IDB_STORE, 'readonly');
          const getReq = tx.objectStore(PARTICIPANT_IDB_STORE).get(PARTICIPANT_IDB_KEY);
          getReq.onsuccess = () => {
            const val = getReq.result;
            db.close();
            resolve(isValidProfile(val) ? val : null);
          };
          getReq.onerror = () => {
            db.close();
            resolve(null);
          };
        } catch {
          resolve(null);
        }
      };
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

function clearIndexedDB(): Promise<void> {
  return new Promise((resolve) => {
    try {
      if (typeof indexedDB === 'undefined') {
        resolve();
        return;
      }
      const req = indexedDB.open(PARTICIPANT_IDB_NAME, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(PARTICIPANT_IDB_STORE)) {
          db.createObjectStore(PARTICIPANT_IDB_STORE);
        }
      };
      req.onsuccess = () => {
        try {
          const db = req.result;
          const tx = db.transaction(PARTICIPANT_IDB_STORE, 'readwrite');
          tx.objectStore(PARTICIPANT_IDB_STORE).delete(PARTICIPANT_IDB_KEY);
          tx.oncomplete = () => {
            db.close();
            resolve();
          };
          tx.onerror = () => {
            db.close();
            resolve();
          };
        } catch {
          resolve();
        }
      };
      req.onerror = () => resolve();
    } catch {
      resolve();
    }
  });
}

function clearProfileCookie(): void {
  try {
    if (typeof document === 'undefined') return;
    document.cookie = `${PARTICIPANT_COOKIE_NAME}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; SameSite=Lax`;
  } catch {
    // ignore cookie delete errors
  }
}

/**
 * Clears only the local device session so the app returns to صفحة التسجيل للتثبت,
 * while preserving all registered participants in the server registry.
 */
export function clearActiveParticipantSession(): Promise<void> {
  try {
    localStorage.removeItem(PARTICIPANT_PROFILE_KEY);
    localStorage.removeItem(PARTICIPANT_BACKUP_KEY);
    localStorage.removeItem(PARTICIPANT_DEVICE_ID_KEY);
    localStorage.setItem(PARTICIPANT_REVERIFY_EPOCH_KEY, CURRENT_REVERIFY_EPOCH);
  } catch {
    // ignore storage errors
  }

  clearProfileCookie();

  const cacheClearPromise =
    typeof caches !== 'undefined'
      ? caches
          .open(PARTICIPANT_CACHE_NAME)
          .then((cache) => cache.delete(PARTICIPANT_CACHE_URL).then(() => undefined))
          .catch(() => undefined)
      : Promise.resolve();

  const task = Promise.all([clearIndexedDB(), cacheClearPromise]).then(() => undefined);
  pendingSessionClearPromise = task;
  return task;
}

function consumePendingReverifyReturnIfNeeded(): boolean {
  try {
    if (typeof window === 'undefined' || typeof localStorage === 'undefined') return false;
    const seenEpoch = localStorage.getItem(PARTICIPANT_REVERIFY_EPOCH_KEY);
    if (seenEpoch === CURRENT_REVERIFY_EPOCH) return false;
    void clearActiveParticipantSession();
    return true;
  } catch {
    return false;
  }
}

/**
 * Synchronously reads the permanently locked participant profile.
 * Returns null ONLY on the very first opening before registration.
 */
export function loadParticipantProfileSync(): ParticipantProfile | null {
  if (consumePendingReverifyReturnIfNeeded()) {
    return null;
  }
  try {
    const rawPrimary = localStorage.getItem(PARTICIPANT_PROFILE_KEY);
    if (rawPrimary) {
      const parsed = JSON.parse(rawPrimary);
      if (isValidProfile(parsed)) return parsed;
    }
  } catch {
    // fallback below
  }

  try {
    const rawBackup = localStorage.getItem(PARTICIPANT_BACKUP_KEY);
    if (rawBackup) {
      const parsed = JSON.parse(rawBackup);
      if (isValidProfile(parsed)) {
        try {
          localStorage.setItem(PARTICIPANT_PROFILE_KEY, JSON.stringify(parsed));
        } catch {
          // ignore
        }
        return parsed;
      }
    }
  } catch {
    // fallback below
  }

  const fromCookie = readProfileCookie();
  if (fromCookie) {
    try {
      const serialized = JSON.stringify(fromCookie);
      localStorage.setItem(PARTICIPANT_PROFILE_KEY, serialized);
      localStorage.setItem(PARTICIPANT_BACKUP_KEY, serialized);
    } catch {
      // ignore
    }
    return fromCookie;
  }

  return null;
}

/**
 * Persists the participant profile across localStorage, IndexedDB, CacheStorage, and Cookie.
 * Strictly write-once: once saved, name and 2 random digits can NEVER be replaced.
 */
export function persistParticipantProfile(profile: ParticipantProfile): ParticipantProfile {
  const existing = loadParticipantProfileSync();
  const lockedProfile: ParticipantProfile = existing
    ? {
        ...existing,
        syncedToServer: Boolean(existing.syncedToServer || profile.syncedToServer),
      }
    : profile;

  const serialized = JSON.stringify(lockedProfile);
  try {
    localStorage.setItem(PARTICIPANT_PROFILE_KEY, serialized);
    localStorage.setItem(PARTICIPANT_BACKUP_KEY, serialized);
    localStorage.setItem(PARTICIPANT_DEVICE_ID_KEY, lockedProfile.id);
    localStorage.setItem(PARTICIPANT_REVERIFY_EPOCH_KEY, CURRENT_REVERIFY_EPOCH);
  } catch {
    // ignore localStorage quota errors
  }

  writeProfileCookie(lockedProfile);
  void writeToIndexedDB(lockedProfile);

  try {
    if (typeof caches !== 'undefined') {
      void caches
        .open(PARTICIPANT_CACHE_NAME)
        .then((cache) =>
          cache.put(
            PARTICIPANT_CACHE_URL,
            new Response(serialized, { headers: { 'Content-Type': 'application/json' } })
          )
        )
        .catch(() => {});
    }
  } catch {
    // ignore cache errors
  }

  return lockedProfile;
}

/**
 * Recovers the participant profile from durable browser/Capacitor caches if localStorage was ever purged.
 */
export async function restoreParticipantProfileAsync(): Promise<ParticipantProfile | null> {
  if (pendingSessionClearPromise) {
    await pendingSessionClearPromise;
  }
  if (consumePendingReverifyReturnIfNeeded()) {
    if (pendingSessionClearPromise) {
      await pendingSessionClearPromise;
    }
    return null;
  }
  const syncFound = loadParticipantProfileSync();
  if (syncFound) return syncFound;

  try {
    if (typeof caches !== 'undefined') {
      const cache = await caches.open(PARTICIPANT_CACHE_NAME);
      const match = await cache.match(PARTICIPANT_CACHE_URL);
      if (match) {
        const parsed = await match.json();
        if (isValidProfile(parsed)) {
          return persistParticipantProfile(parsed);
        }
      }
    }
  } catch {
    // ignore cache read errors
  }

  const idbFound = await readFromIndexedDB();
  if (idbFound) {
    return persistParticipantProfile(idbFound);
  }

  // Last-resort recovery via existing deviceId on backend registry
  try {
    const deviceId = localStorage.getItem(PARTICIPANT_DEVICE_ID_KEY);
    if (deviceId) {
      const origins = buildCandidateApiOrigins();
      for (const base of origins) {
        try {
          const controller = new AbortController();
          const timer = window.setTimeout(() => controller.abort(), 1600);
          const res = await fetch(`${base}/api/participant/profile?deviceId=${encodeURIComponent(deviceId)}`, {
            cache: 'no-store',
            signal: controller.signal,
          });
          window.clearTimeout(timer);
          if (!res.ok) continue;
          const data = (await res.json()) as { ok?: boolean; profile?: unknown };
          if (data?.ok && isValidProfile(data.profile)) {
            return persistParticipantProfile({ ...data.profile, syncedToServer: true });
          }
        } catch {
          // try next origin
        }
      }
    }
  } catch {
    // ignore
  }

  return null;
}

function buildCandidateApiOrigins(): string[] {
  const origins: string[] = [];
  if (typeof window !== 'undefined' && window.location?.origin?.startsWith('http')) {
    origins.push('');
  }
  const remoteOrigin = getStoredRemoteSyncOrigin();
  if (remoteOrigin) {
    origins.push(remoteOrigin.replace(/\/+$/, ''));
  }
  if (origins.length === 0) {
    origins.push('');
  }
  return origins;
}

export interface RegisterParticipantResult {
  ok: boolean;
  profile?: ParticipantProfile;
  error?: string;
}

/**
 * Registers the app owner one time ONLY:
 * - Requires mandatory baseName
 * - Appends 2 unique random digits automatically
 * - Locks permanently so neither name nor digits can ever be replaced
 */
export async function registerParticipant(
  rawBaseName: string,
  lang: 'AR' | 'FR' = 'AR'
): Promise<RegisterParticipantResult> {
  const existing = loadParticipantProfileSync();
  if (existing) {
    return { ok: true, profile: existing };
  }

  const baseName = cleanParticipantInputName(rawBaseName);
  if (!baseName) {
    return {
      ok: false,
      error:
        lang === 'FR'
          ? 'Le nom du participant est obligatoire.'
          : 'كتابة اسم المشارك إجبارية قبل التسجيل.',
    };
  }

  const deviceId = getOrCreateDeviceId();
  const origins = buildCandidateApiOrigins();

  for (const base of origins) {
    try {
      const controller = new AbortController();
      const timeoutId = window.setTimeout(() => controller.abort(), 2800);
      const res = await fetch(`${base}/api/participant/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ baseName, deviceId }),
        signal: controller.signal,
      });
      window.clearTimeout(timeoutId);

      const contentType = res.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) continue;

      const data = (await res.json()) as {
        ok?: boolean;
        code?: string;
        error?: string;
        profile?: unknown;
      };

      if (res.status === 409 && data.code === 'NAME_EXHAUSTED') {
        return {
          ok: false,
          error:
            lang === 'FR'
              ? 'Ce nom est déjà utilisé avec toutes les combinaisons. Ajoutez un prénom ou une lettre.'
              : data.error || 'هذا الاسم مستعمل بجميع الأرقام المتاحة، يرجى إضافة اللقب لتمييز اسمك.',
        };
      }

      if (res.ok && data.ok && isValidProfile(data.profile)) {
        const locked = persistParticipantProfile({ ...data.profile, syncedToServer: true });
        return { ok: true, profile: locked };
      }
    } catch {
      // Try next origin or offline fallback below
    }
  }

  // Offline / Capacitor standalone fallback: generate 2 cryptographically random digits and lock immediately
  const suffixDigits = generateCryptoTwoDigits();
  const localProfile: ParticipantProfile = {
    id: deviceId,
    baseName,
    suffixDigits,
    fullName: `${baseName} ${suffixDigits}`,
    registeredAt: new Date().toISOString(),
    syncedToServer: false,
  };
  const locked = persistParticipantProfile(localProfile);
  return { ok: true, profile: locked };
}

/**
 * Quietly records an offline-created participant name in the server registry once online
 * without ever altering the owner's locked fullName or 2 random digits.
 */
export async function syncPendingParticipantToServer(profile: ParticipantProfile): Promise<void> {
  if (!profile || profile.syncedToServer) return;
  const origins = buildCandidateApiOrigins();
  for (const base of origins) {
    try {
      const controller = new AbortController();
      const timeoutId = window.setTimeout(() => controller.abort(), 2000);
      const res = await fetch(`${base}/api/participant/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          baseName: profile.baseName,
          deviceId: profile.id,
          preferredSuffixDigits: profile.suffixDigits,
        }),
        signal: controller.signal,
      });
      window.clearTimeout(timeoutId);
      if (res.ok) {
        persistParticipantProfile({ ...profile, syncedToServer: true });
        return;
      }
    } catch {
      // ignore transient network errors
    }
  }
}

function normalizeArabicDigitsClient(value: string): string {
  return String(value || '')
    .replace(/[\u0660-\u0669]/g, (ch) => String(ch.charCodeAt(0) - 0x0660))
    .replace(/[\u06F0-\u06F9]/g, (ch) => String(ch.charCodeAt(0) - 0x06f0));
}

/**
 * Strictly verifies an already-registered participant identity ("الاسم + الرقمين")
 * against the server's durable registered participants list.
 * NEVER grants access unless confirmed by the server registry.
 */
export async function verifyRegisteredParticipant(
  rawFullNameInput: string,
  lang: 'AR' | 'FR' = 'AR'
): Promise<RegisterParticipantResult> {
  const existing = loadParticipantProfileSync();
  if (existing) {
    return { ok: true, profile: existing };
  }

  const cleaned = normalizeArabicDigitsClient(rawFullNameInput)
    .replace(/[\r\n\t]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const notRegisteredMsg =
    lang === 'FR' ? 'Non enregistré, réessayez' : 'غير مسجل أعد المحاولة';

  if (!cleaned || !/\d{2}$/.test(cleaned)) {
    return { ok: false, error: notRegisteredMsg };
  }

  const deviceId = getOrCreateDeviceId();
  const origins = buildCandidateApiOrigins();

  for (const base of origins) {
    try {
      const controller = new AbortController();
      const timeoutId = window.setTimeout(() => controller.abort(), 3000);
      const res = await fetch(`${base}/api/participant/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fullNameInput: cleaned, deviceId }),
        signal: controller.signal,
      });
      window.clearTimeout(timeoutId);

      const contentType = res.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) continue;

      const data = (await res.json()) as {
        ok?: boolean;
        registered?: boolean;
        error?: string;
        profile?: unknown;
      };

      if (res.ok && data.ok && data.registered && isValidProfile(data.profile)) {
        const locked = persistParticipantProfile({ ...data.profile, syncedToServer: true });
        return { ok: true, profile: locked };
      }

      if (res.status === 404 || data.registered === false) {
        return { ok: false, error: notRegisteredMsg };
      }
    } catch {
      // Try next candidate origin; never bypass verification offline
    }
  }

  return {
    ok: false,
    error:
      lang === 'FR'
        ? 'Vérification impossible sans connexion, réessayez'
        : 'غير مسجل أعد المحاولة',
  };
}

