/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { WeeklyConcours, WeeklyConcoursMatch } from '../types/promosport';

/**
 * Safely extracts home and away numeric scores from either explicit fields
 * (`scoreHome`/`scoreAway`) or formatted strings (`"2 - 1"`, `"0 : 2"`).
 */
export function parseMatchScore(match: WeeklyConcoursMatch): { home: string; away: string } | null {
  if (match.isDelayed) {
    return null;
  }
  if (
    match.scoreHome !== undefined &&
    match.scoreAway !== undefined &&
    /^\d+$/.test(String(match.scoreHome).trim()) &&
    /^\d+$/.test(String(match.scoreAway).trim())
  ) {
    return { home: String(match.scoreHome).trim(), away: String(match.scoreAway).trim() };
  }
  if (match.score && match.score !== '- - -') {
    const parts = match.score.split(/[-:]/).map((s) => s.trim());
    if (parts.length === 2 && /^\d+$/.test(parts[0]) && /^\d+$/.test(parts[1])) {
      return { home: parts[0], away: parts[1] };
    }
  }
  return null;
}

/**
 * Computes official Promosport sign ('1' | 'X' | '2') from numeric scores.
 */
export function computeResultSign(homeScore: number, awayScore: number): '1' | 'X' | '2' {
  if (homeScore > awayScore) return '1';
  if (homeScore < awayScore) return '2';
  return 'X';
}

/**
 * Strict Zero-Assumption Match Evaluator:
 * NEVER fabricates 0 - 0, live minutes, or finished 'X' states purely from local device clock.
 * Only verified live/finished feeds from promosport-pronostic.com / live sports APIs are shown.
 * Delayed or postponed matches strictly suppress scores ('- - -').
 */
export function evaluateMatchRealTime(
  match: WeeklyConcoursMatch,
  _nowMs: number,
  _simulatedKickoffStartedAtMs: number | null = null
): WeeklyConcoursMatch {
  // 0. If delayed / postponed / suspended, suppress unverified scores strictly
  if (match.isDelayed) {
    return {
      ...match,
      status: 'scheduled',
      score: '- - -',
      scoreHome: undefined,
      scoreAway: undefined,
      liveMinute: undefined,
      result: null,
    };
  }

  const parsedScore = parseMatchScore(match);

  // 1. Confirmed FINISHED match with verified final score
  if (match.status === 'finished' && parsedScore) {
    const h = Number(parsedScore.home);
    const a = Number(parsedScore.away);
    return {
      ...match,
      status: 'finished',
      scoreHome: parsedScore.home,
      scoreAway: parsedScore.away,
      score: `${parsedScore.home} - ${parsedScore.away}`,
      result: match.result || computeResultSign(h, a),
      liveMinute: undefined,
    };
  }

  // 2. Confirmed LIVE match from authoritative live feed with verified live score
  if (match.status === 'live' && parsedScore) {
    return {
      ...match,
      status: 'live',
      scoreHome: parsedScore.home,
      scoreAway: parsedScore.away,
      score: `${parsedScore.home} - ${parsedScore.away}`,
      liveMinute: match.liveMinute || 'LIVE',
      result: null,
    };
  }

  // 3. Scheduled / waiting for verified kickoff confirmation (NO assumptions, NO fake 0 - 0)
  return {
    ...match,
    status: 'scheduled',
    score: '- - -',
    scoreHome: undefined,
    scoreAway: undefined,
    liveMinute: undefined,
    result: null,
  };
}

/**
 * Evaluates all matches of a WeeklyConcours strictly from verified site/feed states.
 */
export function evaluateConcoursRealTime(
  concours: WeeklyConcours,
  nowMs: number,
  simulatedKickoffStartedAtMs: number | null = null
): WeeklyConcours {
  return {
    ...concours,
    matches: concours.matches.map((m) =>
      evaluateMatchRealTime(m, nowMs, simulatedKickoffStartedAtMs)
    ),
  };
}

/**
 * Checks whether all matches in the concours have confirmed full-time results.
 */
export function isConcoursCompletelyFinished(
  concours: WeeklyConcours,
  nowMs: number
): boolean {
  const evaluated = evaluateConcoursRealTime(concours, nowMs, null);
  return (
    evaluated.matches.length > 0 &&
    evaluated.matches.every((m) => m.status === 'finished' && parseMatchScore(m) !== null)
  );
}
