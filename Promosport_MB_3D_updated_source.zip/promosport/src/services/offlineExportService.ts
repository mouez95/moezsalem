/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import JSZip from 'jszip';
import { AppSettings, NotificationSettings, UserBetSlip, WeeklyConcours } from '../types/promosport';
import { buildZipBootstrapPayload, loadSettings, loadUserSlips } from './storageService';

export interface ExportReadinessStatus {
  ready: boolean;
  hasGradleWrapper: boolean;
  hasWorkflow: boolean;
  hasInternetPermission: boolean;
  hasNotificationPermission: boolean;
  hasCapacitorAssetsPublic: boolean;
  distBuilt: boolean;
  iconCount: number;
  splashCount: number;
  slipsCount: number;
  packageId: string;
  appName: string;
  lastAutoSyncAt: string;
}

let inFlightWorkspaceSync: Promise<void> | null = null;

export async function syncAppChangesToWorkspace(params: {
  appSettings: AppSettings;
  notificationSettings?: NotificationSettings;
  userSlips?: UserBetSlip[];
  concours: WeeklyConcours;
  activeUrl?: string;
}): Promise<boolean> {
  if (typeof window === 'undefined' || (typeof navigator !== 'undefined' && !navigator.onLine)) {
    return false;
  }

  const notificationSettings = params.notificationSettings || loadSettings();
  const userSlips = params.userSlips ?? loadUserSlips();
  const activeUrl =
    params.activeUrl ||
    (window.location.origin.startsWith('http') ? window.location.origin : '');

  const runSync = async () => {
    try {
      const res = await fetch('/api/export/sync-state', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          appSettings: params.appSettings,
          notificationSettings,
          userSlips,
          activeConcours: params.concours,
          activeUrl,
        }),
      });
      return res.ok;
    } catch {
      return false;
    }
  };

  if (inFlightWorkspaceSync) {
    await inFlightWorkspaceSync;
  }
  let ok = false;
  inFlightWorkspaceSync = runSync().then((result) => {
    ok = result;
  }).finally(() => {
    inFlightWorkspaceSync = null;
  });
  await inFlightWorkspaceSync;
  return ok;
}

export async function fetchExportReadiness(): Promise<ExportReadinessStatus | null> {
  try {
    const res = await fetch('/api/export/readiness', { cache: 'no-store' });
    if (!res.ok) return null;
    return (await res.json()) as ExportReadinessStatus;
  } catch {
    return null;
  }
}

export function downloadBlobFile(filename: string, blob: Blob): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.setTimeout(() => URL.revokeObjectURL(url), 1500);
}

export function downloadTextFile(filename: string, content: string, mimeType = 'text/plain;charset=utf-8'): void {
  const blob = new Blob([content], { type: mimeType });
  downloadBlobFile(filename, blob);
}

export function buildPromptSpecificationText(
  settings: AppSettings,
  userSlips: UserBetSlip[],
  concours: WeeklyConcours,
  activeUrl: string
): string {
  const cleanUrl = activeUrl.replace(/\/+$/, '');
  const installUrl = cleanUrl.includes('?') ? `${cleanUrl}&install=1` : `${cleanUrl}/?install=1`;
  const pwaBuilderUrl = `https://www.pwabuilder.com/?url=${encodeURIComponent(cleanUrl)}`;

  return `[بروموسبور تونس - ${settings.appName || 'MB Football'} | Full Android APK & Zero-SDK Cloud Build Specification]
========================================================================
معرف الحزمة (Package ID): ${settings.packageId || 'com.promosport.tunisie.mb'}
رقم الهاتف المباشر: ${settings.phoneNumber || '51155580'}
رقم القصاصة المعتمدة: ${concours.number}
تسعيرة العمود: ${Number(settings.columnRate ?? 0.15).toFixed(3)} TND
معلوم القصاصة الأساسي: ${Number(settings.baseFee ?? 0.25).toFixed(3)} TND
الرابط المباشر الشغال الآن: ${cleanUrl}
رابط التثبيت المباشر: ${installUrl}
حالة PWA: Manifest + Service Worker + sw-notifications.js + Icons (192/512/Apple 180) مفعلة بالكامل
غلاف وموارد أندرويد (Capacitor): شاشة بداية مذهبة 3D عالية الدقة (drawable/splash.png + port/land) + أيقونات إقلاع بجميع المقاسات (mdpi..xxxhdpi) + AndroidManifest كامل الصلاحيات
المزايا المفعلة في الحزمة:
• تسجيل تلقائي فوري لأي تعديل أو إضافة في التطبيق أو القصاصات أو الإعدادات داخل ملف ZIP عند التنزيل
• مشروع Android Capacitor جاهز ومزامَن بالكامل (android/app/src/main/assets/public + gradlew + .github/workflows) لتحويله فوراً إلى APK بدون نقص
• التحديث الحي والمباشر لنتائج المباريات الـ 13 لحظة بلحظة وكل ثانية (/api/promosport/sync + ESPN Live Feed)
• أيقونة الهدف الحديث باللهب المشتعل والتزلزل مدة 7 ثوانٍ مع صوت قطرة الماء المزدوجة بصدى ناعم
• تعمير وحفظ وتعديل وفسخ القصاصات مع احتساب الأعمدة والأسعار بدقة
• تنبيهات الجهاز والاشعارات الفورية للقصاصات الجديدة والأهداف والنتائج
• توافق كامل وسريع مع أندرويد 6 فما فوق (API 23+) عبر الوايفاي أو إنترنت الهاتف (100vh/100dvh + Safe Area)

1. قاعدة بيئة البناء المعدّلة (في حال عدم توفر Android SDK و Gradle):
------------------------------------------------------------------------
⚠️ تنبيه مهم: بيئات المتصفح / Node.js / الاستوديو لا تحتوي محلياً على Android SDK و Gradle.
• لا تقم بتشغيل ./gradlew assembleDebug محلياً إذا كان ANDROID_HOME غير موجود.
• استبدل الأمر تلقائياً بهذه الحلول الشغالة 100% بدون Android SDK على جهازك:
  1) بناء وتشغيل التطبيق كاملاً (Web + Live Sync API + PWA):
     npm install && npm run build && npm start
  2) التشغيل الفوري للتطبيق المبني مع خادم التحديث الحي للنتائج (/api/promosport/sync):
     node start-ready-app.mjs
  3) سكريبت الفحص الذكي المدمج في الحزمة:
     node scripts/check-and-build-apk.mjs
  4) بناء ملف app-debug.apk سحابياً عبر GitHub Actions (مدمج داخل .github/workflows/build-android-apk.yml مع android-actions/setup-android@v3 + Java 17 + Gradle 8.9).
  5) تحويل الرابط الحي إلى APK فوري عبر PWABuilder (بدون أي أدوات محلية):
     ${pwaBuilderUrl}
  6) تثبيت Chrome WebAPK مباشرة أو تشغيل ملف Promosport_MB_3D_Offline_App_${concours.number}.html المرفق في الحزمة أوفلاين.

2. المعادلة الرسمية لاحتساب ثمن القصاصة (Promosport Official Tariff):
------------------------------------------------------------------------
الاحتمالات (الأعمدة): C = 2^D * 3^T
الثمن = (C * ${Number(settings.columnRate ?? 0.15).toFixed(3)}) + ${Number(settings.baseFee ?? 0.25).toFixed(3)} TND

3. سجل القصاصات المحفوظة (${userSlips.length}):
${JSON.stringify(userSlips, null, 2)}
`;
}

export function buildStandaloneOfflineHtml(
  settings: AppSettings,
  userSlips: UserBetSlip[],
  concours: WeeklyConcours,
  apiOrigin: string
): string {
  const safeAppName = (settings.appName || 'بروموسبور تونس - MB Football').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const safeCagnotte = (concours.cagnotteEstimate || 'تُحدد عند السحب').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const matchesJson = JSON.stringify(concours.matches || []).replace(/<\/script/gi, '<\\/script');
  const slipsJson = JSON.stringify(userSlips || []).replace(/<\/script/gi, '<\\/script');
  const settingsJson = JSON.stringify(settings).replace(/<\/script/gi, '<\\/script');
  const cleanOrigin = apiOrigin.replace(/\/+$/, '');
  const colRate = Number(settings.columnRate ?? 0.15);
  const baseFee = Number(settings.baseFee ?? 0.25);

  return `<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no,viewport-fit=cover" />
<meta name="theme-color" content="#020612" />
<meta name="mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<title>${safeAppName} — نسخة الهاتف المستقلة</title>
<style>
  *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
  html,body{margin:0;padding:0;min-height:100vh;min-height:100dvh;background:radial-gradient(circle at top,#0a1d42,#020612);color:#fff;font-family:system-ui,-apple-system,sans-serif;overscroll-behavior-y:contain;touch-action:manipulation}
  body{padding:max(10px,env(safe-area-inset-top)) 10px max(96px,env(safe-area-inset-bottom))}
  .header{max-width:780px;margin:0 auto 12px;padding:12px;border-radius:18px;background:linear-gradient(135deg,#091a38,#0d2552);border:2px solid #facc15;box-shadow:0 8px 24px rgba(0,0,0,.6)}
  .h-top{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px}
  .badge{background:#facc15;color:#000;font-weight:900;border-radius:10px;padding:4px 10px;font-size:11px;display:inline-flex;align-items:center;gap:4px}
  .btn-notif{background:rgba(16,185,129,.18);border:1px solid #34d399;color:#6ee7b7;border-radius:10px;padding:4px 10px;font-size:11px;font-weight:800;cursor:pointer}
  .tabs{display:flex;gap:8px;margin-top:10px}
  .tab{flex:1;padding:9px 6px;border-radius:10px;border:1px solid rgba(250,204,21,.4);background:rgba(255,255,255,.06);color:#fff;font-weight:800;font-size:12px;cursor:pointer}
  .tab.active{background:#facc15;color:#000}
  .wrap{max-width:780px;margin:0 auto;display:grid;gap:12px}
  .card{position:relative;background:linear-gradient(180deg,#1a7dff,#00349e);border-radius:18px;border:2px solid #cbd5e1;overflow:hidden;box-shadow:0 8px 22px rgba(0,0,0,.6);transition:border-color .3s}
  .card.goal-active{border-color:#fb923c;box-shadow:0 0 28px rgba(249,115,22,.85)}
  .crown{background:#111827;text-align:center;font-size:11px;font-weight:900;padding:5px 8px;color:#fef08a;display:flex;justify-content:center;align-items:center;gap:8px}
  .live-pill{background:#dc2626;color:#fff;padding:1px 7px;border-radius:6px;font-size:10px;animation:pulseLive 1s infinite}
  .ft-pill{background:#047857;color:#d1fae5;padding:1px 7px;border-radius:6px;font-size:10px}
  .goal-banner{background:linear-gradient(90deg,#dc2626,#f97316,#facc15);color:#fff;font-size:11px;font-weight:900;padding:3px 10px;text-align:center;animation:goalQuake 0.55s infinite linear}
  .wings{display:flex;align-items:center;justify-content:space-between;padding:10px 10px;gap:6px}
  .team{flex:1;font-weight:900;font-size:clamp(12px,3.2vw,14px);word-break:break-word}.left{text-align:left}.right{text-align:right}
  .dial{position:relative;background:#090d14;border:3px solid #e2e8f0;border-radius:999px;padding:6px 10px;display:flex;flex-direction:column;align-items:center;justify-content:center;min-width:96px}
  .dial.goal-quake{border-color:#fb923c;box-shadow:0 0 22px rgba(249,115,22,.95),0 0 38px rgba(239,68,68,.7);animation:goalQuake 0.5s infinite linear}
  .score-main{font-family:ui-monospace,monospace;font-weight:900;font-size:17px;color:#fff;letter-spacing:2px}
  .score-live{color:#86efac}
  .score-goal{color:#fde047}
  .pick-row{display:flex;gap:4px;margin-top:4px}
  .pick{width:28px;height:28px;border-radius:999px;border:1px solid #64748b;background:#0f172a;color:#fff;font-weight:900;cursor:pointer;font-size:12px}
  .pick.on{background:linear-gradient(180deg,#fde047,#f59e0b);color:#000;border-color:#fff}
  .pick:disabled{opacity:.45;cursor:not-allowed}
  .tray{background:rgba(250,204,21,.22);border-top:1px solid rgba(254,240,138,.6);padding:7px 12px;font-size:11px;display:flex;justify-content:space-between;align-items:center;gap:6px}
  .dock{position:fixed;bottom:0;inset-x:0;background:#040c1a;border-top:2px solid #facc15;padding:10px 14px max(10px,env(safe-area-inset-bottom));display:flex;justify-content:space-between;align-items:center;gap:10px;z-index:20;flex-wrap:wrap}
  .btn{background:linear-gradient(90deg,#10b981,#22c55e);color:#000;font-weight:900;border:none;border-radius:10px;padding:9px 14px;cursor:pointer;font-size:12px}
  .btn:disabled{opacity:.45;cursor:not-allowed}
  .btn-clear{background:#e11d48;color:#fff}
  .slip-item{background:#091730;border:1px solid rgba(250,204,21,.5);border-radius:14px;padding:12px;font-size:12px}
  .toast{max-width:780px;margin:0 auto 10px;padding:8px 12px;border-radius:10px;background:#78350f;border:1px solid #facc15;color:#fef08a;font-size:12px;font-weight:800;display:none}
  @keyframes pulseLive{0%,100%{opacity:1}50%{opacity:.55}}
  @keyframes goalQuake{0%,100%{transform:translate3d(0,0,0) rotate(0)}20%{transform:translate3d(-3px,2px,0) rotate(-3deg)}40%{transform:translate3d(3px,-2px,0) rotate(3deg)}60%{transform:translate3d(-3px,-1px,0) rotate(-2.5deg)}80%{transform:translate3d(3px,2px,0) rotate(2.5deg)}}
</style>
</head>
<body>
  <div class="header">
    <div class="h-top">
      <div>
        <div style="font-weight:900;font-size:15px;color:#fde047">${safeAppName} • نسخة أوفلاين + بث حي</div>
        <div style="font-size:11px;color:#cbd5e1;margin-top:3px">المسابقة #<span id="numOut">${concours.number}</span> • الجائزة: <span id="cagOut">${safeCagnotte}</span> • <span id="clockOut">--:--:--</span></div>
      </div>
      <div style="display:flex;gap:6px;align-items:center">
        <button class="btn-notif" id="notifBtn" onclick="reqNotif()">تفعيل الإشعارات</button>
        <span class="badge" id="syncBadge">أوفلاين جاهز ✓</span>
      </div>
    </div>
    <div class="tabs">
      <button class="tab active" onclick="switchView('fill',this)">تعمير القصاصة (13)</button>
      <button class="tab" onclick="switchView('slips',this)">القصاصات المسجلة (<span id="slipCount">0</span>)</button>
    </div>
  </div>
  <div id="toastMsg" class="toast"></div>
  <div id="appRoot" class="wrap"></div>
  <div class="dock" id="dockBar">
    <div style="font-size:12px;font-weight:800">
      المباريات: <span id="cntM">0</span>/13 • الأعمدة: <span id="cntC">1</span> •
      <span id="priceOut" style="color:#fde047;font-family:monospace">${(colRate + baseFee).toFixed(3)} TND</span>
    </div>
    <div style="display:flex;gap:6px">
      <button class="btn" id="saveBtn" onclick="saveSlip()">تسجيل القصاصة</button>
      <button class="btn btn-clear" onclick="clearSel()">مسح</button>
    </div>
  </div>
<script>
  var MATCHES = ${matchesJson};
  var API_ORIGIN = ${JSON.stringify(cleanOrigin)};
  var EXPORTED_APP_SETTINGS = ${settingsJson};
  var COL_RATE = ${colRate};
  var BASE_FEE = ${baseFee};
  var CONCOURS_NUM = ${Number(concours.number)};
  var KEY = 'promosport_user_slips_v1';
  var SETTINGS_KEY = 'promosport_app_settings_v1';
  try{ if(!localStorage.getItem(SETTINGS_KEY)){ localStorage.setItem(SETTINGS_KEY, JSON.stringify(EXPORTED_APP_SETTINGS)); } }catch(e){}
  var sel = {};
  var view = 'fill';
  var seededSlips = ${slipsJson};
  var localSlips = null;
  try{ localSlips = JSON.parse(localStorage.getItem(KEY) || 'null'); }catch(e){}
  var slips = (Array.isArray(localSlips) && localSlips.length) ? localSlips : seededSlips;
  try{ if(Array.isArray(slips) && slips.length && (!localSlips || !localSlips.length)){ localStorage.setItem(KEY, JSON.stringify(slips)); } }catch(e){}
  var goalFlashUntil = {};
  var prevScores = null;

  function showToast(msg){
    var t = document.getElementById('toastMsg');
    t.textContent = msg;
    t.style.display = 'block';
    setTimeout(function(){ t.style.display = 'none'; }, 3500);
  }
  function reqNotif(){
    if(!('Notification' in window)){ showToast('الإشعارات غير مدعومة في هذا المتصفح'); return; }
    Notification.requestPermission().then(function(p){
      document.getElementById('notifBtn').textContent = p === 'granted' ? 'الإشعارات مفعلة ✓' : 'تم رفض الإشعارات';
      if(p === 'granted') sendDeviceNotif('${safeAppName}', 'تم تفعيل تنبيهات الأهداف والقصاصات على جهازك بنجاح.');
    });
  }
  function sendDeviceNotif(title, body){
    if('Notification' in window && Notification.permission === 'granted'){
      try{ new Notification(title, { body: body, tag: 'promosport-live' }); }catch(e){}
    }
  }
  function playWaterDropletGoal(){
    try{
      var Ctx = window.AudioContext || window.webkitAudioContext;
      if(!Ctx) return;
      var ctx = new Ctx();
      if(ctx.state === 'suspended' && ctx.resume){ ctx.resume().catch(function(){}); }
      var now = ctx.currentTime;
      function drop(off, f1, f2, dur, pk){
        var st = now + off;
        var o = ctx.createOscillator(), flt = ctx.createBiquadFilter(), g = ctx.createGain();
        o.type = 'sine'; o.frequency.setValueAtTime(f1, st); o.frequency.exponentialRampToValueAtTime(f2, st + dur*0.72);
        flt.type = 'bandpass'; flt.frequency.setValueAtTime((f1+f2)*0.55, st); flt.Q.value = 3.2;
        g.gain.setValueAtTime(0.0001, st); g.gain.linearRampToValueAtTime(pk, st + 0.008); g.gain.exponentialRampToValueAtTime(0.0004, st + dur);
        o.connect(flt); flt.connect(g); g.connect(ctx.destination);
        o.start(st); o.stop(st + dur + 0.02);
      }
      drop(0.0, 520, 1540, 0.13, 0.34);
      drop(0.21, 690, 2120, 0.15, 0.38);
    }catch(e){}
  }
  function hasExplicitScore(m){
    return Boolean(m && !m.isDelayed && m.score && m.score !== '- - -' && (m.status === 'live' || m.status === 'finished') && m.scoreHome != null && m.scoreAway != null);
  }
  function evalMatches(){
    var now = Date.now();
    var nextSnapshot = {};
    var goalFired = false;
    MATCHES = MATCHES.map(function(m){
      var delayed = Boolean(m.isDelayed);
      var status = delayed ? 'scheduled' : (m.status || 'scheduled');
      var hasScore = !delayed && m.scoreHome != null && m.scoreAway != null && /^\\d+$/.test(String(m.scoreHome)) && /^\\d+$/.test(String(m.scoreAway));
      var sh = hasScore ? String(m.scoreHome) : undefined;
      var sa = hasScore ? String(m.scoreAway) : undefined;
      var scoreStr = hasScore && (status === 'live' || status === 'finished') ? (sh + ' - ' + sa) : '- - -';
      if(prevScores && prevScores[m.id] && !delayed && hasScore){
        var p = prevScores[m.id];
        if((status==='live' || (p.s==='live' && status==='finished')) && ((p.hs && (Number(sh)>p.h || Number(sa)>p.a)) || (!p.hs && (Number(sh)>0 || Number(sa)>0)))){
          goalFlashUntil[m.id] = now + 7000;
          goalFired = true;
          sendDeviceNotif('هدف مسجل الآن! ' + m.homeTeam + ' ' + sh + ' - ' + sa + ' ' + m.awayTeam, 'الدقيقة ' + (m.liveMinute || 'LIVE'));
        }
      }
      nextSnapshot[m.id] = { s: status, h: hasScore ? Number(sh) : 0, a: hasScore ? Number(sa) : 0, hs: hasScore };
      return Object.assign({}, m, { status: status, score: scoreStr, scoreHome: sh, scoreAway: sa });
    });
    prevScores = nextSnapshot;
    if(goalFired){ playWaterDropletGoal(); showToast('هدف حديث مسجل الآن!'); }
  }
  function syncLiveFeeds(){
    if(!navigator.onLine || !API_ORIGIN || API_ORIGIN.indexOf('http') !== 0) return;
    fetch(API_ORIGIN + '/api/promosport/sync?refresh=1', { cache: 'no-store' })
      .then(function(r){ return r.ok ? r.json() : null; })
      .then(function(d){
        if(d && d.activeConcours && Array.isArray(d.activeConcours.matches)){
          document.getElementById('syncBadge').textContent = 'متصل حي ✓';
          MATCHES = d.activeConcours.matches;
          CONCOURS_NUM = d.activeConcours.number || CONCOURS_NUM;
          document.getElementById('numOut').textContent = CONCOURS_NUM;
          document.getElementById('cagOut').textContent = d.activeConcours.cagnotteEstimate || '';
          evalMatches();
          render();
        }
      }).catch(function(){});
  }
  function switchView(v, el){
    view = v;
    document.querySelectorAll('.tab').forEach(function(b){ b.classList.remove('active'); });
    el.classList.add('active');
    document.getElementById('dockBar').style.display = v==='fill'?'flex':'none';
    render();
  }
  function togglePick(id, s){
    var locked = MATCHES.some(function(m){ return m.status==='live' || m.status==='finished'; });
    if(locked){ showToast('تم إغلاق التعمير لأن المباريات قد انطلقت'); return; }
    var cur = sel[id] || [];
    sel[id] = cur.indexOf(s)>=0 ? cur.filter(function(x){ return x!==s; }) : cur.concat([s]);
    render();
  }
  function clearSel(){ sel = {}; render(); }
  function deleteSlip(id){
    slips = slips.filter(function(x){ return String(x.id) !== String(id); });
    try{ localStorage.setItem(KEY, JSON.stringify(slips)); }catch(e){}
    showToast('تم فسخ القصاصة نهائياً ✓');
    render();
  }
  function calc(){
    var d=0,t=0,m=0;
    Object.keys(sel).forEach(function(k){ var arr=sel[k]; if(arr&&arr.length){ m++; if(arr.length===2)d++; if(arr.length===3)t++; }});
    var cols = Math.pow(2,d)*Math.pow(3,t);
    var price = (cols*COL_RATE + BASE_FEE).toFixed(3);
    document.getElementById('cntM').textContent = m;
    document.getElementById('cntC').textContent = cols;
    document.getElementById('priceOut').textContent = price + ' TND';
    return {m:m,cols:cols,price:price};
  }
  function saveSlip(){
    var locked = MATCHES.some(function(m){ return m.status==='live' || m.status==='finished'; });
    if(locked){ showToast('انطلقت المباريات — التعمير مقفل الآن'); return; }
    var c = calc();
    if(c.m<13){ showToast('أكمل تعمير الـ 13 مباراة أولاً ('+c.m+'/13)'); return; }
    slips.unshift({ id: 'slip-'+Date.now(), grilleNumber: CONCOURS_NUM, name: 'قصاصة مسجلة رقم '+(slips.length+1), totalCombinations: c.cols, totalCostDt: Number(c.price), selections: JSON.parse(JSON.stringify(sel)), createdAt: new Date().toLocaleString('fr-FR') });
    try{ localStorage.setItem(KEY, JSON.stringify(slips)); }catch(e){}
    sel = {};
    showToast('تم حفظ القصاصة بنجاح ✓');
    sendDeviceNotif('تم حفظ قصاصة جديدة', 'تم تسجيل القصاصة ('+c.cols+' عمود) بنجاح.');
    render();
  }
  function render(){
    var now = Date.now();
    document.getElementById('clockOut').textContent = new Date(now).toLocaleTimeString('fr-FR');
    document.getElementById('slipCount').textContent = slips.length;
    var locked = MATCHES.some(function(m){ return m.status==='live' || m.status==='finished'; });
    document.getElementById('saveBtn').disabled = locked;
    var root = document.getElementById('appRoot');
    if(view==='slips'){
      root.innerHTML = slips.length ? slips.map(function(s){
        var rows = MATCHES.map(function(m){
          var picks = (s.selections && (s.selections[m.id] || s.selections[String(m.id)])) || [];
          var isLive = !m.isDelayed && m.status === 'live';
          var isFt = !m.isDelayed && m.status === 'finished';
          var hasNumScore = !m.isDelayed && m.scoreHome != null && m.scoreAway != null;
          var scoreStr = (isLive || isFt) && hasNumScore ? (m.scoreHome + ' - ' + m.scoreAway) : '- - -';
          var badge = m.isDelayed ? '<span style="color:#fbbf24;font-size:10px;font-weight:900">مؤجلة</span>' : (isLive ? '<span class="live-pill">'+(m.liveMinute||'LIVE')+'</span>' : (isFt ? '<span class="ft-pill">FT '+(m.result||'')+'</span>' : ''));
          var ok = isFt && m.result && picks.indexOf(m.result) >= 0;
          var mark = isFt && picks.length ? (ok ? '<span style="color:#4ade80;font-weight:900">✓</span>' : '<span style="color:#f87171;font-weight:900">✗</span>') : '';
          return '<div style="display:flex;align-items:center;justify-content:space-between;gap:6px;padding:6px 8px;border-top:1px solid rgba(255,255,255,.08);font-size:11px">' +
            '<span style="color:#cbd5e1;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">#'+m.id+' '+m.homeTeam+' - '+m.awayTeam+'</span>' +
            '<span style="display:inline-flex;align-items:center;gap:4px;font-family:monospace;font-weight:900;color:'+(isLive?'#86efac':(isFt?'#fde047':'#94a3b8'))+'">'+badge+' '+scoreStr+'</span>' +
            '<span style="background:#facc15;color:#000;border-radius:6px;padding:1px 6px;font-weight:900;font-size:10px">'+(picks.join('/')||'--')+'</span>' +
            mark +
          '</div>';
        }).join('');
        return '<div class="slip-item"><div style="display:flex;justify-content:space-between;align-items:center"><strong style="color:#fde047">'+s.name+'</strong><button onclick="deleteSlip(\\''+s.id+'\\')" style="background:#dc2626;color:#fff;border:none;border-radius:8px;padding:4px 8px;font-size:11px;cursor:pointer">فسخ</button></div><div style="margin-top:4px">'+s.totalCombinations+' عمود • <span style="color:#34d399">'+Number(s.totalCostDt).toFixed(3)+' TND</span> • <span style="color:#94a3b8;font-size:11px">'+(s.createdAt||'')+'</span></div><div style="margin-top:8px;background:rgba(0,0,0,.35);border-radius:10px;overflow:hidden">'+rows+'</div></div>';
      }).join('') : '<div class="slip-item" style="text-align:center">لا توجد قصاصات مسجلة بعد</div>';
      return;
    }
    root.innerHTML = MATCHES.map(function(m){
      var chosen = sel[m.id] || [];
      var isLive = !m.isDelayed && m.status === 'live';
      var isFt = !m.isDelayed && m.status === 'finished';
      var hasGoal = (goalFlashUntil[m.id] || 0) > now;
      var hasNumScore = !m.isDelayed && m.scoreHome != null && m.scoreAway != null;
      var scoreText = (isLive || isFt) && hasNumScore ? (m.scoreHome + ' - ' + m.scoreAway) : '- - -';
      var statusBadge = m.isDelayed ? '<span style="background:#92400e;color:#fde68a;padding:1px 7px;border-radius:6px;font-size:10px">مؤجلة</span>' : (isLive ? '<span class="live-pill">LIVE '+(m.liveMinute||'')+'</span>' : (isFt ? '<span class="ft-pill">FT '+(m.result||'')+'</span>' : ''));
      var interactive = !locked && !isLive && !isFt && !m.isDelayed;
      var p1 = Number(m.prob1) > 0 ? Number(m.prob1) : 34;
      var pX = Number(m.probX) > 0 ? Number(m.probX) : 33;
      var p2 = Number(m.prob2) > 0 ? Number(m.prob2) : 33;
      var pTot = p1 + pX + p2 || 100;
      var w1 = ((p1 / pTot) * 100).toFixed(1);
      var wX = ((pX / pTot) * 100).toFixed(1);
      var w2 = Math.max(0, 100 - Number(w1) - Number(wX)).toFixed(1);
      var probBar = '<div dir="ltr" style="width:100%;height:7px;margin-top:4px;border-radius:999px;padding:1px;background:linear-gradient(90deg,#e2e8f0,#94a3b8,#e2e8f0);box-shadow:0 1px 4px rgba(0,0,0,0.85)"><div style="width:100%;height:100%;border-radius:999px;overflow:hidden;display:flex;background:#05070b"><div style="width:'+w1+'%;min-width:3px;background:linear-gradient(180deg,#fef08a,#facc15,#b45309)"></div><div style="width:'+wX+'%;min-width:3px;background:#040507;border-left:1px solid rgba(255,255,255,0.85);border-right:1px solid rgba(255,255,255,0.85)"></div><div style="width:'+w2+'%;min-width:3px;background:linear-gradient(180deg,#fef08a,#facc15,#b45309)"></div></div></div>';
      return '<div class="card '+(hasGoal?'goal-active':'')+'">' +
        (hasGoal ? '<div class="goal-banner">هدف حديث! GOAL!</div>' : '') +
        '<div class="crown"><span>MATCH #'+m.id+' • '+(m.competition||'Promosport')+'</span>'+statusBadge+'</div>' +
        '<div class="wings">' +
          '<div class="team left">'+m.homeTeam+'</div>' +
          '<div class="dial '+(hasGoal?'goal-quake':'')+'">' +
            '<div class="score-main '+(isLive?'score-live':'')+' '+(hasGoal?'score-goal':'')+'">'+scoreText+'</div>' +
            (interactive ? '<div class="pick-row">'+['1','X','2'].map(function(k){ return '<button class="pick '+(chosen.indexOf(k)>=0?'on':'')+'" onclick="togglePick('+m.id+',\\''+k+'\\')">'+k+'</button>'; }).join('')+'</div>'+probBar : '') +
          '</div>' +
          '<div class="team right">'+m.awayTeam+'</div>' +
        '</div>' +
        '<div class="tray"><span>#'+m.id+' • '+m.dayTime+' • '+m.date+'</span><span>في انتظار البداية</span></div>' +
      '</div>';
    }).join('');
    calc();
  }
  evalMatches();
  render();
  syncLiveFeeds();
  setInterval(function(){ evalMatches(); render(); }, 1000);
  setInterval(syncLiveFeeds, 5000);
</script>
</body>
</html>`;
}

function base64ToUint8Array(base64: string): Uint8Array {
  const binStr = window.atob(base64);
  const bytes = new Uint8Array(binStr.length);
  for (let i = 0; i < binStr.length; i += 1) {
    bytes[i] = binStr.charCodeAt(i);
  }
  return bytes;
}

export async function buildAndDownloadFullZipArchive(params: {
  settings: AppSettings;
  userSlips: UserBetSlip[];
  concours: WeeklyConcours;
  activeUrl: string;
}): Promise<{ fileCount: number; includesDist: boolean; includesFullAndroid: boolean }> {
  const { settings, userSlips, concours, activeUrl } = params;
  const notificationSettings = loadSettings();
  const promptSpec = buildPromptSpecificationText(settings, userSlips, concours, activeUrl);
  const offlineHtml = buildStandaloneOfflineHtml(settings, userSlips, concours, activeUrl);

  // 1. Primary path: server builds fresh dist/, syncs Capacitor android/ assets/public, icons & splash,
  // embeds recorded slips/settings, and streams the complete ZIP archive including src/, android/, dist/ & workflows.
  try {
    const serverRes = await fetch('/api/export/full-zip', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        appSettings: settings,
        notificationSettings,
        userSlips,
        activeConcours: concours,
        activeUrl,
        promptSpec,
        offlineHtml,
      }),
    });

    const contentType = serverRes.headers.get('content-type') || '';
    if (serverRes.ok && contentType.includes('application/zip')) {
      const zipBlob = await serverRes.blob();
      const headerCount = Number(serverRes.headers.get('X-Bundle-File-Count') || '0');
      downloadBlobFile(`Promosport_MB_3D_Full_Package_${concours.number}.zip`, zipBlob);
      return {
        fileCount: headerCount > 0 ? headerCount : 80,
        includesDist: true,
        includesFullAndroid: true,
      };
    }
  } catch {
    // Fallback to client-side JSZip assembly if offline or endpoint unavailable
  }

  // 2. Fallback path: client-side ZIP assembly + built dist/
  const zip = new JSZip();
  const bootstrapPayload = buildZipBootstrapPayload(settings, userSlips, concours, activeUrl);

  zip.file('APP_BOOTSTRAP.json', JSON.stringify(bootstrapPayload, null, 2));
  zip.file('APP_SETTINGS.json', JSON.stringify(settings, null, 2));
  zip.file('NOTIFICATION_SETTINGS.json', JSON.stringify(notificationSettings, null, 2));
  zip.file('PROMPT_SPECIFICATION.txt', promptSpec);
  zip.file('SAVED_USER_SLIPS.json', JSON.stringify(userSlips, null, 2));
  zip.file(`Promosport_MB_3D_Offline_App_${concours.number}.html`, offlineHtml);

  let includesDist = false;
  let bundledFiles = 6;

  try {
    const res = await fetch('/api/export/built-bundle?fresh=1', { cache: 'no-store' });
    if (res.ok) {
      const data = (await res.json()) as {
        files?: Array<{ path: string; base64: string }>;
        extras?: Array<{ path: string; base64: string }>;
      };

      if (Array.isArray(data.files) && data.files.length > 0) {
        includesDist = true;
        for (const f of data.files) {
          zip.file(`dist/${f.path}`, base64ToUint8Array(f.base64));
          bundledFiles += 1;
        }
        zip.file('dist/promosport-bootstrap.json', JSON.stringify(bootstrapPayload, null, 2));
      }

      if (Array.isArray(data.extras)) {
        for (const ex of data.extras) {
          zip.file(ex.path, base64ToUint8Array(ex.base64));
          bundledFiles += 1;
        }
      }
    }
  } catch {
    // Offline fallback still provides bootstrap, offline HTML, and Capacitor config
  }

  if (!includesDist) {
    zip.file(
      'capacitor.config.json',
      JSON.stringify(
        {
          appId: settings.packageId || 'com.promosport.tunisie.mb',
          appName: settings.appName || 'بروموسبور تونس - MB Football',
          webDir: 'dist',
          bundledWebRuntime: false,
          server: {
            androidScheme: 'https',
            allowNavigation: ['*'],
            cleartext: true,
          },
        },
        null,
        2
      )
    );
  }

  const zipBlob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE' });
  downloadBlobFile(`Promosport_MB_3D_Full_Package_${concours.number}.zip`, zipBlob);

  return { fileCount: bundledFiles, includesDist, includesFullAndroid: false };
}
