/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PromosportGrille, SiteLiveScanPayload, WeeklyConcours } from '../types/promosport';
import { enrichConcoursWithDirectLiveFeeds, mergeConcoursPreservingScores } from './liveFootballFeed';
import {
  applyRapidToLiveMatches,
  fetchPromosportPronosticFullScan,
  fetchRapidLiveMap,
  scanPromosportLiveCatalogHtml,
} from './promosportSiteParser';
import {
  getStoredRemoteSyncOrigin,
  loadCachedConcours,
  saveCachedConcours,
  loadCachedGrilles,
  saveCachedGrilles,
} from './storageService';
import {
  normalizeConcoursTranslations,
  normalizeGrilleTranslations,
} from './teamTranslationService';

/**
 * Official Promosport Concours International N°936 (du 17/11/2026 à 20:00)
 * Verified directly from https://www.promosport-pronostic.com/welcome/promo_result?grille=936&jeux=Promosport
 */
export const CONCOURS_936_GRILLE: PromosportGrille = {
  id: 'grille-936',
  number: 936,
  date: '17-11-2026 à 20:00',
  cagnotte: 64441,
  cagnotteFormatted: '64 441 DT',
  winnersCount: 1,
  winnersFormatted: '1 مرابيح',
  prizePerWinner: 64441,
  prizePerWinnerFormatted: '64 441 DT',
  isRollover: false,
  status: 'official',
  sourceUrl: 'https://www.promosport-pronostic.com/welcome/promo_result?grille=936&jeux=Promosport',
  matches: [
    { id: 1, homeTeam: 'ويلز', homeTeamFr: 'Wales', homeLogo: 'WAL', awayTeam: 'البرتغال', awayTeamFr: 'Portugal', awayLogo: 'PT', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '2 - 3', result: '2' },
    { id: 2, homeTeam: 'بولندا', homeTeamFr: 'Poland', homeLogo: 'PL', awayTeam: 'السويد', awayTeamFr: 'Sweden', awayLogo: 'SE', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '1 - 1', result: 'X' },
    { id: 3, homeTeam: 'الدنمارك', homeTeamFr: 'Denmark', homeLogo: 'DK', awayTeam: 'النرويج', awayTeamFr: 'Norway', awayLogo: 'NO', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '2 - 3', result: '2' },
    { id: 4, homeTeam: 'جمهورية أيرلندا', homeTeamFr: 'Rep. Of Ireland', homeLogo: 'IE', awayTeam: 'كوسوفو', awayTeamFr: 'Kosovo', awayLogo: 'XK', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '3 - 0', result: '1' },
    { id: 5, homeTeam: 'المجر', homeTeamFr: 'Hungary', homeLogo: 'HU', awayTeam: 'أيرلندا الشمالية', awayTeamFr: 'Northern Ireland', awayLogo: 'GB-NIR', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '1 - 1', result: 'X' },
    { id: 6, homeTeam: 'أوكرانيا', homeTeamFr: 'Ukraine', homeLogo: 'UA', awayTeam: 'جورجيا', awayTeamFr: 'Georgia', awayLogo: 'GE', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '1 - 0', result: '1' },
    { id: 7, homeTeam: 'البوسنة والهرسك', homeTeamFr: 'Bosnia & Herzegovina', homeLogo: 'BA', awayTeam: 'رومانيا', awayTeamFr: 'Romania', awayLogo: 'RO', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '2 - 1', result: '1' },
    { id: 8, homeTeam: 'الكونغو', homeTeamFr: 'Congo', homeLogo: 'CG', awayTeam: 'جزر القمر', awayTeamFr: 'Comoros', awayLogo: 'KM', competition: 'تصفيات كأس أمم إفريقيا', competitionFr: 'Africa Cup of Nations - Qualification', score: '0 - 1', result: '2' },
    { id: 9, homeTeam: 'موريتانيا', homeTeamFr: 'Mauritania', homeLogo: 'MR', awayTeam: 'بوركينا فاسو', awayTeamFr: 'Burkina Faso', awayLogo: 'BF', competition: 'تصفيات كأس أمم إفريقيا', competitionFr: 'Africa Cup of Nations - Qualification', score: '1 - 3', result: '2' },
    { id: 10, homeTeam: 'رواندا', homeTeamFr: 'Rwanda', homeLogo: 'RW', awayTeam: 'مالي', awayTeamFr: 'Mali', awayLogo: 'ML', competition: 'تصفيات كأس أمم إفريقيا', competitionFr: 'Africa Cup of Nations - Qualification', score: '0 - 2', result: '2' },
    { id: 11, homeTeam: 'بوتسوانا', homeTeamFr: 'Botswana', homeLogo: 'BW', awayTeam: 'أوغندا', awayTeamFr: 'Uganda', awayLogo: 'UG', competition: 'تصفيات كأس أمم إفريقيا', competitionFr: 'Africa Cup of Nations - Qualification', score: '1 - 1', result: 'X' },
    { id: 12, homeTeam: 'ليبيريا', homeTeamFr: 'Liberia', homeLogo: 'LR', awayTeam: 'الرأس الأخضر', awayTeamFr: 'Cape Verde Islands', awayLogo: 'CV', competition: 'تصفيات كأس أمم إفريقيا', competitionFr: 'Africa Cup of Nations - Qualification', score: '2 - 0', result: '1' },
    { id: 13, homeTeam: 'النيجر', homeTeamFr: 'Niger', homeLogo: 'NE', awayTeam: 'المغرب', awayTeamFr: 'Morocco', awayLogo: 'MA', competition: 'تصفيات كأس أمم إفريقيا', competitionFr: 'Africa Cup of Nations - Qualification', score: '0 - 1', result: '2' },
  ],
};

/**
 * Official Promosport Concours International N°935 (du 15/11/2026)
 * Verified directly from https://www.promosport-pronostic.com/welcome/promosport & promo_result?grille=935
 */
export const CONCOURS_935_GRILLE: PromosportGrille = {
  id: 'grille-935',
  number: 935,
  date: '15-11-2026 à 14:00',
  cagnotte: 68399,
  cagnotteFormatted: '68 399 DT',
  winnersCount: 2,
  winnersFormatted: '2 مرابيح',
  prizePerWinner: 34199.5,
  prizePerWinnerFormatted: '34 199,500 DT',
  isRollover: false,
  status: 'official',
  sourceUrl: 'https://www.promosport-pronostic.com/welcome/promo_result?grille=935&jeux=Promosport',
  matches: [
    { id: 1, homeTeam: 'إسبانيا', homeTeamFr: 'Spain', homeLogo: 'ES', awayTeam: 'إنجلترا', awayTeamFr: 'England', awayLogo: 'GB-ENG', competition: 'دوري الأمم الأوروبية (الشوط 1)', competitionFr: 'UEFA Nations League (1ère MT)', score: '0 - 1', result: '2' },
    { id: 2, homeTeam: 'إسبانيا', homeTeamFr: 'Spain', homeLogo: 'ES', awayTeam: 'إنجلترا', awayTeamFr: 'England', awayLogo: 'GB-ENG', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '2 - 3', result: '2' },
    { id: 3, homeTeam: 'بلجيكا', homeTeamFr: 'Belgium', homeLogo: 'BE', awayTeam: 'إيطاليا', awayTeamFr: 'Italy', awayLogo: 'IT', competition: 'دوري الأمم الأوروبية (الشوط 1)', competitionFr: 'UEFA Nations League (1ère MT)', score: '3 - 1', result: '1' },
    { id: 4, homeTeam: 'بلجيكا', homeTeamFr: 'Belgium', homeLogo: 'BE', awayTeam: 'إيطاليا', awayTeamFr: 'Italy', awayLogo: 'IT', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '4 - 1', result: '1' },
    { id: 5, homeTeam: 'فرنسا', homeTeamFr: 'France', homeLogo: 'FR', awayTeam: 'تركيا', awayTeamFr: 'Türkiye', awayLogo: 'TR', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '2 - 1', result: '1' },
    { id: 6, homeTeam: 'كرواتيا', homeTeamFr: 'Croatia', homeLogo: 'HR', awayTeam: 'التشيك', awayTeamFr: 'Czechia', awayLogo: 'CZ', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '2 - 1', result: '1' },
    { id: 7, homeTeam: 'بيلاروسيا', homeTeamFr: 'Belarus', homeLogo: 'BY', awayTeam: 'ألبانيا', awayTeamFr: 'Albania', awayLogo: 'AL', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '0 - 2', result: '2' },
    { id: 8, homeTeam: 'قبرص', homeTeamFr: 'Cyprus', homeLogo: 'CY', awayTeam: 'الجبل الأسود', awayTeamFr: 'Montenegro', awayLogo: 'ME', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '1 - 4', result: '2' },
    { id: 9, homeTeam: 'لاتفيا', homeTeamFr: 'Latvia', homeLogo: 'LV', awayTeam: 'أرمينيا', awayTeamFr: 'Armenia', awayLogo: 'AM', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '0 - 0', result: 'X' },
    { id: 10, homeTeam: 'غرناطة', homeTeamFr: 'Granada CF', homeLogo: 'GRA', awayTeam: 'لاس بالماس', awayTeamFr: 'Las Palmas', awayLogo: 'LPA', competition: 'الدوري الإسباني الدرجة 2', competitionFr: 'LaLiga Hypermotion', score: '1 - 0', result: '1' },
    { id: 11, homeTeam: 'إيبار', homeTeamFr: 'Eibar', homeLogo: 'EIB', awayTeam: 'قادش', awayTeamFr: 'Cadiz', awayLogo: 'CAD', competition: 'الدوري الإسباني الدرجة 2', competitionFr: 'LaLiga Hypermotion', score: '1 - 1', result: 'X' },
    { id: 12, homeTeam: 'إلدينسي', homeTeamFr: 'Eldense', homeLogo: 'ELD', awayTeam: 'ساباديل', awayTeamFr: 'Sabadell', awayLogo: 'SAB', competition: 'الدوري الإسباني الدرجة 2', competitionFr: 'LaLiga Hypermotion', score: '2 - 0', result: '1' },
    { id: 13, homeTeam: 'تينيريفي', homeTeamFr: 'Tenerife', homeLogo: 'TEN', awayTeam: 'سبتة', awayTeamFr: 'AD Ceuta FC', awayLogo: 'CEU', competition: 'الدوري الإسباني الدرجة 2', competitionFr: 'LaLiga Hypermotion', score: '2 - 0', result: '1' },
  ],
};

/**
 * Official Promosport Concours International N°934 (du 14/11/2026)
 * Verified directly from https://www.promosport-pronostic.com/welcome/promosport & promo_result?grille=934
 */
export const CONCOURS_934_GRILLE: PromosportGrille = {
  id: 'grille-934',
  number: 934,
  date: '14-11-2026 à 16:15',
  cagnotte: 53306,
  cagnotteFormatted: '53 306 DT',
  winnersCount: 1,
  winnersFormatted: '1 مرابيح',
  prizePerWinner: 53306,
  prizePerWinnerFormatted: '53 306 DT',
  isRollover: false,
  status: 'official',
  sourceUrl: 'https://www.promosport-pronostic.com/welcome/promo_result?grille=934&jeux=Promosport',
  matches: [
    { id: 1, homeTeam: 'البرتغال', homeTeamFr: 'Portugal', homeLogo: 'PT', awayTeam: 'الدنمارك', awayTeamFr: 'Denmark', awayLogo: 'DK', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '1 - 4', result: '2' },
    { id: 2, homeTeam: 'النرويج', homeTeamFr: 'Norway', homeLogo: 'NO', awayTeam: 'ويلز', awayTeamFr: 'Wales', awayLogo: 'WAL', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '3 - 1', result: '1' },
    { id: 3, homeTeam: 'أيرلندا الشمالية', homeTeamFr: 'Northern Ireland', homeLogo: 'GB-NIR', awayTeam: 'أوكرانيا', awayTeamFr: 'Ukraine', awayLogo: 'UA', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '1 - 0', result: '1' },
    { id: 4, homeTeam: 'النمسا', homeTeamFr: 'Austria', homeLogo: 'AT', awayTeam: 'جمهورية أيرلندا', awayTeamFr: 'Rep. Of Ireland', awayLogo: 'IE', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '1 - 0', result: '1' },
    { id: 5, homeTeam: 'رومانيا', homeTeamFr: 'Romania', homeLogo: 'RO', awayTeam: 'بولندا', awayTeamFr: 'Poland', awayLogo: 'PL', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '2 - 1', result: '1' },
    { id: 6, homeTeam: 'السويد', homeTeamFr: 'Sweden', homeLogo: 'SE', awayTeam: 'البوسنة والهرسك', awayTeamFr: 'Bosnia & Herzegovina', awayLogo: 'BA', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '3 - 2', result: '1' },
    { id: 7, homeTeam: 'جورجيا', homeTeamFr: 'Georgia', homeLogo: 'GE', awayTeam: 'المجر', awayTeamFr: 'Hungary', awayLogo: 'HU', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '0 - 2', result: '2' },
    { id: 8, homeTeam: 'أوغندا', homeTeamFr: 'Uganda', homeLogo: 'UG', awayTeam: 'بوتسوانا', awayTeamFr: 'Botswana', awayLogo: 'BW', competition: 'تصفيات كأس إفريقيا', competitionFr: 'Africa Cup of Nations - Qualification', score: '1 - 1', result: 'X' },
    { id: 9, homeTeam: 'الجزائر', homeTeamFr: 'Algeria', homeLogo: 'DZ', awayTeam: 'توغو', awayTeamFr: 'Togo', awayLogo: 'TG', competition: 'تصفيات كأس إفريقيا', competitionFr: 'Africa Cup of Nations - Qualification', score: '1 - 0', result: '1' },
    { id: 10, homeTeam: 'ريال أوفييدو', homeTeamFr: 'Oviedo', homeLogo: 'OVI', awayTeam: 'جيرونا', awayTeamFr: 'Girona', awayLogo: 'GIR', competition: 'الدوري الإسباني الدرجة 2', competitionFr: 'LaLiga Hypermotion', score: '1 - 2', result: '2' },
    { id: 11, homeTeam: 'مايوركا', homeTeamFr: 'Mallorca', homeLogo: 'MAL', awayTeam: 'قرطبة', awayTeamFr: 'Cordoba', awayLogo: 'COR', competition: 'الدوري الإسباني الدرجة 2', competitionFr: 'LaLiga Hypermotion', score: '3 - 3', result: 'X' },
    { id: 12, homeTeam: 'ريال سوسيداد ب', homeTeamFr: 'Real Sociedad II', homeLogo: 'RSOB', awayTeam: 'سبورتينغ خيخون', awayTeamFr: 'Sporting Gijon', awayLogo: 'GIJ', competition: 'الدوري الإسباني الدرجة 2', competitionFr: 'LaLiga Hypermotion', score: '2 - 2', result: 'X' },
    { id: 13, homeTeam: 'ألميريا', homeTeamFr: 'Almeria', homeLogo: 'ALM', awayTeam: 'أندورا', awayTeamFr: 'FC Andorra', awayLogo: 'AND', competition: 'الدوري الإسباني الدرجة 2', competitionFr: 'LaLiga Hypermotion', score: '2 - 1', result: '1' },
  ],
};

/**
 * Official Promosport Concours International N°933 (du 12/11/2026)
 */
export const CONCOURS_933_GRILLE: PromosportGrille = {
  id: 'grille-933',
  number: 933,
  date: '12-11-2026 à 17:00',
  cagnotte: 61958.934,
  cagnotteFormatted: '61 958,934 DT',
  winnersCount: 616,
  winnersFormatted: '616 مرابيح',
  prizePerWinner: 100.582,
  prizePerWinnerFormatted: '100,582 DT',
  isRollover: false,
  status: 'official',
  sourceUrl: 'https://www.promosport-pronostic.com/welcome/promo_result?grille=933&jeux=Promosport',
  matches: [
    { id: 1, homeTeam: 'إيطاليا', homeTeamFr: 'Italie', homeLogo: 'IT', awayTeam: 'فرنسا', awayTeamFr: 'France', awayLogo: 'FR', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '3 - 1', result: '1' },
    { id: 2, homeTeam: 'تركيا', homeTeamFr: 'Turquie', homeLogo: 'TR', awayTeam: 'بلجيكا', awayTeamFr: 'Belgique', awayLogo: 'BE', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '1 - 2', result: '2' },
    { id: 3, homeTeam: 'التشيك', homeTeamFr: 'Tcheque', homeLogo: 'CZ', awayTeam: 'إسبانيا', awayTeamFr: 'Espagne', awayLogo: 'ES', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '0 - 2', result: '2' },
    { id: 4, homeTeam: 'إنجلترا', homeTeamFr: 'Angleterre', homeLogo: 'GB-ENG', awayTeam: 'كرواتيا', awayTeamFr: 'Croatie', awayLogo: 'HR', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '2 - 1', result: '1' },
    { id: 5, homeTeam: 'ألبانيا', homeTeamFr: 'Albanie', homeLogo: 'AL', awayTeam: 'فنلندا', awayTeamFr: 'Finlande', awayLogo: 'FI', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '2 - 0', result: '1' },
    { id: 6, homeTeam: 'الجبل الأسود', homeTeamFr: 'Montenegro', homeLogo: 'ME', awayTeam: 'لاتفيا', awayTeamFr: 'Lettonie', awayLogo: 'LV', competition: 'دوري الأمم الأوروبية', competitionFr: 'UEFA Nations League', score: '2 - 1', result: '1' },
    { id: 7, homeTeam: 'أرمينيا', homeTeamFr: 'Armenie', homeLogo: 'AM', awayTeam: 'قبرص', awayTeamFr: 'Chypre', awayLogo: 'CY', competition: 'تصفيات أمم أوروبا', competitionFr: 'Éliminatoires Euro', score: '1 - 1', result: 'X' },
    { id: 8, homeTeam: 'غينيا الاستوائية', homeTeamFr: 'Guinee Equatoriale', homeLogo: 'GQ', awayTeam: 'زيمبابوي', awayTeamFr: 'Zimbabwe', awayLogo: 'ZW', competition: 'تصفيات كأس إفريقيا', competitionFr: 'Éliminatoires CAN', score: '0 - 0', result: 'X' },
    { id: 9, homeTeam: 'مدغشقر', homeTeamFr: 'Madagascar', homeLogo: 'MG', awayTeam: 'غينيا بيساو', awayTeamFr: 'Guinee Bissau', awayLogo: 'GW', competition: 'تصفيات كأس إفريقيا', competitionFr: 'Éliminatoires CAN', score: '1 - 1', result: 'X' },
    { id: 10, homeTeam: 'كوت ديفوار', homeTeamFr: 'Cote D ivoire', homeLogo: 'CI', awayTeam: 'غامبيا', awayTeamFr: 'Gambie', awayLogo: 'GM', competition: 'تصفيات كأس إفريقيا', competitionFr: 'Éliminatoires CAN', score: '2 - 1', result: '1' },
    { id: 11, homeTeam: 'الكونغو الديمقراطية', homeTeamFr: 'RD Congo', homeLogo: 'CD', awayTeam: 'سيراليون', awayTeamFr: 'Sierra Leone', awayLogo: 'SL', competition: 'تصفيات كأس إفريقيا', competitionFr: 'Éliminatoires CAN', score: '3 - 1', result: '1' },
    { id: 12, homeTeam: 'بنين', homeTeamFr: 'Benin', homeLogo: 'BJ', awayTeam: 'إفريقيا الوسطى', awayTeamFr: 'Afrique Centrale', awayLogo: 'CF', competition: 'تصفيات كأس إفريقيا', competitionFr: 'Éliminatoires CAN', score: '4 - 1', result: '1' },
    { id: 13, homeTeam: 'السنغال', homeTeamFr: 'Senegal', homeLogo: 'SN', awayTeam: 'السودان', awayTeamFr: 'Soudan', awayLogo: 'SD', competition: 'تصفيات كأس إفريقيا', competitionFr: 'Éliminatoires CAN', score: '4 - 1', result: '1' },
  ],
};

/**
 * Official Promosport international competition results matching
 * https://www.promosport-pronostic.com/welcome/promosport
 * Ordered descending: 935, 934, 933, 932, 931, 930
 */
export const INITIAL_GRILLES: PromosportGrille[] = [
  CONCOURS_936_GRILLE,
  CONCOURS_935_GRILLE,
  CONCOURS_934_GRILLE,
  CONCOURS_933_GRILLE,
  {
    id: 'grille-932',
    number: 932,
    date: '08-11-2026 à 15:00',
    cagnotte: 194030.169,
    cagnotteFormatted: '194 030,169 DT',
    winnersCount: 45,
    winnersFormatted: '45 مرابيح',
    prizePerWinner: 4311.781,
    prizePerWinnerFormatted: '4 311,781 DT',
    isRollover: false,
    status: 'official',
    sourceUrl: 'https://www.promosport-pronostic.com/welcome/promo_result?grille=932&jeux=Promosport',
    matches: [
      { id: 1, homeTeam: 'ليفربول', homeTeamFr: 'Liverpool', homeLogo: 'LIV', awayTeam: 'أستون فيلا', awayTeamFr: 'Aston Villa', awayLogo: 'AVL', competition: 'الدوري الإنجليزي', competitionFr: 'Premier League', score: '2 - 0', result: '1' },
      { id: 2, homeTeam: 'مانشستر سيتي', homeTeamFr: 'Manchester City', homeLogo: 'MCI', awayTeam: 'برايتون', awayTeamFr: 'Brighton', awayLogo: 'BHA', competition: 'الدوري الإنجليزي', competitionFr: 'Premier League', score: '1 - 2', result: '2' },
      { id: 3, homeTeam: 'ريال مدريد', homeTeamFr: 'Real Madrid', homeLogo: 'RMA', awayTeam: 'أوساسونا', awayTeamFr: 'Osasuna', awayLogo: 'OSA', competition: 'الدوري الإسباني', competitionFr: 'La Liga', score: '4 - 0', result: '1' },
      { id: 4, homeTeam: 'فياريال', homeTeamFr: 'Villarreal', homeLogo: 'VIL', awayTeam: 'ديبورتيفو ألافيس', awayTeamFr: 'Alavés', awayLogo: 'ALA', competition: 'الدوري الإسباني', competitionFr: 'La Liga', score: '3 - 0', result: '1' },
      { id: 5, homeTeam: 'يوفنتوس', homeTeamFr: 'Juventus', homeLogo: 'JUV', awayTeam: 'تورينو', awayTeamFr: 'Torino', awayLogo: 'TOR', competition: 'الدوري الإيطالي', competitionFr: 'Serie A', score: '2 - 0', result: '1' },
      { id: 6, homeTeam: 'ميلان', homeTeamFr: 'AC Milan', homeLogo: 'MIL', awayTeam: 'كالياري', awayTeamFr: 'Cagliari', awayLogo: 'CAG', competition: 'الدوري الإيطالي', competitionFr: 'Serie A', score: '3 - 3', result: 'X' },
      { id: 7, homeTeam: 'بايرن ميونخ', homeTeamFr: 'Bayern Munich', homeLogo: 'BAY', awayTeam: 'سانت باولي', awayTeamFr: 'St. Pauli', awayLogo: 'STP', competition: 'الدوري الألماني', competitionFr: 'Bundesliga', score: '1 - 0', result: '1' },
      { id: 8, homeTeam: 'بوروسيا دورتموند', homeTeamFr: 'B. Dortmund', homeLogo: 'BVB', awayTeam: 'ماينتس', awayTeamFr: 'Mainz 05', awayLogo: 'M05', competition: 'الدوري الألماني', competitionFr: 'Bundesliga', score: '1 - 3', result: '2' },
      { id: 9, homeTeam: 'باريس سان جيرمان', homeTeamFr: 'Paris SG', homeLogo: 'PSG', awayTeam: 'أنجيه', awayTeamFr: 'Angers', awayLogo: 'ANG', competition: 'الدوري الفرنسي', competitionFr: 'Ligue 1', score: '4 - 2', result: '1' },
      { id: 10, homeTeam: 'موناكو', homeTeamFr: 'AS Monaco', homeLogo: 'MON', awayTeam: 'ستراسبورغ', awayTeamFr: 'Strasbourg', awayLogo: 'STR', competition: 'الدوري الفرنسي', competitionFr: 'Ligue 1', score: '3 - 1', result: '1' },
      { id: 11, homeTeam: 'إنتر ميلان', homeTeamFr: 'Inter Milan', homeLogo: 'INT', awayTeam: 'نابولي', awayTeamFr: 'Napoli', awayLogo: 'NAP', competition: 'الدوري الإيطالي', competitionFr: 'Serie A', score: '2 - 1', result: '1' },
      { id: 12, homeTeam: 'تشيلسي', homeTeamFr: 'Chelsea', homeLogo: 'CHE', awayTeam: 'أرسنال', awayTeamFr: 'Arsenal', awayLogo: 'ARS', competition: 'الدوري الإنجليزي', competitionFr: 'Premier League', score: '1 - 1', result: 'X' },
      { id: 13, homeTeam: 'برشلونة', homeTeamFr: 'FC Barcelona', homeLogo: 'BAR', awayTeam: 'ريال سوسيداد', awayTeamFr: 'Real Sociedad', awayLogo: 'RSO', competition: 'الدوري الإسباني', competitionFr: 'La Liga', score: '3 - 0', result: '1' },
    ],
  },
  {
    id: 'grille-931',
    number: 931,
    date: '07-11-2026 à 15:00',
    cagnotte: 72152,
    cagnotteFormatted: '72 152 DT',
    winnersCount: 0,
    winnersFormatted: '0 مرابيح (ترحيل)',
    prizePerWinner: 0,
    prizePerWinnerFormatted: 'ترحيل الجائزة (0 DT)',
    isRollover: true,
    status: 'official',
    sourceUrl: 'https://www.promosport-pronostic.com/welcome/promo_result?grille=931&jeux=Promosport',
    matches: [
      { id: 1, homeTeam: 'إنتر ميلان', homeTeamFr: 'Inter Milan', homeLogo: 'INT', awayTeam: 'أرسنال', awayTeamFr: 'Arsenal', awayLogo: 'ARS', competition: 'دوري أبطال أوروبا', competitionFr: 'Champions League', score: '1 - 0', result: '1' },
      { id: 2, homeTeam: 'باريس سان جيرمان', homeTeamFr: 'Paris SG', homeLogo: 'PSG', awayTeam: 'أتلتيكو مدريد', awayTeamFr: 'Atlético Madrid', awayLogo: 'ATM', competition: 'دوري أبطال أوروبا', competitionFr: 'Champions League', score: '1 - 2', result: '2' },
      { id: 3, homeTeam: 'بايرن ميونخ', homeTeamFr: 'Bayern Munich', homeLogo: 'BAY', awayTeam: 'بنفيكا', awayTeamFr: 'Benfica', awayLogo: 'BEN', competition: 'دوري أبطال أوروبا', competitionFr: 'Champions League', score: '1 - 0', result: '1' },
      { id: 4, homeTeam: 'النجم الأحمر بلغراد', homeTeamFr: 'Crvena Zvezda', homeLogo: 'RSB', awayTeam: 'برشلونة', awayTeamFr: 'FC Barcelona', awayLogo: 'BAR', competition: 'دوري أبطال أوروبا', competitionFr: 'Champions League', score: '2 - 5', result: '2' },
      { id: 5, homeTeam: 'شتوتغارت', homeTeamFr: 'VfB Stuttgart', homeLogo: 'STU', awayTeam: 'أتالانتا', awayTeamFr: 'Atalanta', awayLogo: 'ATA', competition: 'دوري أبطال أوروبا', competitionFr: 'Champions League', score: '0 - 2', result: '2' },
      { id: 6, homeTeam: 'فينورد', homeTeamFr: 'Feyenoord', homeLogo: 'FEY', awayTeam: 'سالزبورغ', awayTeamFr: 'RB Salzburg', awayLogo: 'SAL', competition: 'دوري أبطال أوروبا', competitionFr: 'Champions League', score: '1 - 3', result: '2' },
      { id: 7, homeTeam: 'سبارتا براغ', homeTeamFr: 'Sparta Prague', homeLogo: 'SPA', awayTeam: 'ستاد بريست', awayTeamFr: 'Stade Brestois', awayLogo: 'BRE', competition: 'دوري أبطال أوروبا', competitionFr: 'Champions League', score: '1 - 2', result: '2' },
      { id: 8, homeTeam: 'لاتسيو', homeTeamFr: 'SS Lazio', homeLogo: 'LAZ', awayTeam: 'بورتو', awayTeamFr: 'FC Porto', awayLogo: 'POR_C', competition: 'الدوري الأوروبي', competitionFr: 'Europa League', score: '2 - 1', result: '1' },
      { id: 9, homeTeam: 'مانشستر يونايتد', homeTeamFr: 'Man United', homeLogo: 'MUN', awayTeam: 'باوك سالونيكا', awayTeamFr: 'PAOK', awayLogo: 'PAO', competition: 'الدوري الأوروبي', competitionFr: 'Europa League', score: '2 - 0', result: '1' },
      { id: 10, homeTeam: 'غلطة سراي', homeTeamFr: 'Galatasaray', homeLogo: 'GAL', awayTeam: 'توتنهام', awayTeamFr: 'Tottenham', awayLogo: 'TOT', competition: 'الدوري الأوروبي', competitionFr: 'Europa League', score: '3 - 2', result: '1' },
      { id: 11, homeTeam: 'أولمبياكوس', homeTeamFr: 'Olympiacos', homeLogo: 'OLY', awayTeam: 'رينجرز', awayTeamFr: 'Rangers', awayLogo: 'RAN', competition: 'الدوري الأوروبي', competitionFr: 'Europa League', score: '1 - 1', result: 'X' },
      { id: 12, homeTeam: 'أياكس', homeTeamFr: 'AFC Ajax', homeLogo: 'AJA', awayTeam: 'فيكتوريا بلزن', awayTeamFr: 'Viktoria Plzeň', awayLogo: 'PLZ', competition: 'الدوري الأوروبي', competitionFr: 'Europa League', score: '5 - 0', result: '1' },
      { id: 13, homeTeam: 'تشيلسي', homeTeamFr: 'Chelsea', homeLogo: 'CHE', awayTeam: 'نوح الأرميني', awayTeamFr: 'FC Noah', awayLogo: 'NOA', competition: 'دوري المؤتمر الأوروبي', competitionFr: 'Conference League', score: '8 - 0', result: '1' },
    ],
  },
  {
    id: 'grille-930',
    number: 930,
    date: '05-11-2026 à 18:45',
    cagnotte: 48179,
    cagnotteFormatted: '48 179 DT',
    winnersCount: 8,
    winnersFormatted: '8 مرابيح',
    prizePerWinner: 6022.375,
    prizePerWinnerFormatted: '6 022,375 DT',
    isRollover: false,
    status: 'official',
    sourceUrl: 'https://www.promosport-pronostic.com/welcome/promo_result?grille=930&jeux=Promosport',
    matches: [
      { id: 1, homeTeam: 'ريال مدريد', homeTeamFr: 'Real Madrid', homeLogo: 'RMA', awayTeam: 'ميلان', awayTeamFr: 'AC Milan', awayLogo: 'MIL', competition: 'دوري أبطال أوروبا', competitionFr: 'Champions League', score: '1 - 3', result: '2' },
      { id: 2, homeTeam: 'ليفربول', homeTeamFr: 'Liverpool', homeLogo: 'LIV', awayTeam: 'باير ليفركوزن', awayTeamFr: 'Bayer Leverkusen', awayLogo: 'LEV', competition: 'دوري أبطال أوروبا', competitionFr: 'Champions League', score: '4 - 0', result: '1' },
      { id: 3, homeTeam: 'سبورتينغ لشبونة', homeTeamFr: 'Sporting CP', homeLogo: 'SCP', awayTeam: 'مانشستر سيتي', awayTeamFr: 'Manchester City', awayLogo: 'MCI', competition: 'دوري أبطال أوروبا', competitionFr: 'Champions League', score: '4 - 1', result: '1' },
      { id: 4, homeTeam: 'ليل', homeTeamFr: 'Lille OSC', homeLogo: 'LIL', awayTeam: 'يوفنتوس', awayTeamFr: 'Juventus', awayLogo: 'JUV', competition: 'دوري أبطال أوروبا', competitionFr: 'Champions League', score: '1 - 1', result: 'X' },
      { id: 5, homeTeam: 'سلتيك', homeTeamFr: 'Celtic FC', homeLogo: 'CEL', awayTeam: 'لايبزيغ', awayTeamFr: 'RB Leipzig', awayLogo: 'RBL', competition: 'دوري أبطال أوروبا', competitionFr: 'Champions League', score: '3 - 1', result: '1' },
      { id: 6, homeTeam: 'بوروسيا دورتموند', homeTeamFr: 'B. Dortmund', homeLogo: 'BVB', awayTeam: 'شتورم غراتس', awayTeamFr: 'Sturm Graz', awayLogo: 'STG', competition: 'دوري أبطال أوروبا', competitionFr: 'Champions League', score: '1 - 0', result: '1' },
      { id: 7, homeTeam: 'بولونيا', homeTeamFr: 'Bologna', homeLogo: 'BOL', awayTeam: 'موناكو', awayTeamFr: 'AS Monaco', awayLogo: 'MON', competition: 'دوري أبطال أوروبا', competitionFr: 'Champions League', score: '0 - 1', result: '2' },
      { id: 8, homeTeam: 'بي إس في آيندهوفن', homeTeamFr: 'PSV Eindhoven', homeLogo: 'PSV', awayTeam: 'جيرونا', awayTeamFr: 'Girona FC', awayLogo: 'GIR', competition: 'دوري أبطال أوروبا', competitionFr: 'Champions League', score: '4 - 0', result: '1' },
      { id: 9, homeTeam: 'سلوفان براتيسلافا', homeTeamFr: 'Slovan Bratislava', homeLogo: 'SLO', awayTeam: 'دينامو زغرب', awayTeamFr: 'Dinamo Zagreb', awayLogo: 'DZG', competition: 'دوري أبطال أوروبا', competitionFr: 'Champions League', score: '1 - 4', result: '2' },
      { id: 10, homeTeam: 'أتلتيكو مدريد', homeTeamFr: 'Atlético Madrid', homeLogo: 'ATM', awayTeam: 'إشبيلية', awayTeamFr: 'Sevilla FC', awayLogo: 'SEV', competition: 'الدوري الإسباني', competitionFr: 'La Liga', score: '2 - 1', result: '1' },
      { id: 11, homeTeam: 'أرسنال', homeTeamFr: 'Arsenal', homeLogo: 'ARS', awayTeam: 'نيوكاسل يونايتد', awayTeamFr: 'Newcastle Utd', awayLogo: 'NEW', competition: 'الدوري الإنجليزي', competitionFr: 'Premier League', score: '2 - 0', result: '1' },
      { id: 12, homeTeam: 'روما', homeTeamFr: 'AS Roma', homeLogo: 'ROM', awayTeam: 'فيورنتينا', awayTeamFr: 'Fiorentina', awayLogo: 'FIO', competition: 'الدوري الإيطالي', competitionFr: 'Serie A', score: '2 - 2', result: 'X' },
      { id: 13, homeTeam: 'ليون', homeTeamFr: 'Olympique Lyon', homeLogo: 'LYO', awayTeam: 'مارسيليا', awayTeamFr: 'Marseille', awayLogo: 'OM', competition: 'الدوري الفرنسي', competitionFr: 'Ligue 1', score: '3 - 2', result: '1' },
    ],
  },
];

/**
 * Active Promosport Concours International N°936 (du 17/11/2026 à 20:00)
 * Exactly aligned with https://www.promosport-pronostic.com/welcome/promosport & promo_pronostic?jeux=Promosport&ng=936
 */
export const INTERNATIONAL_WEEKLY_CONCOURS_936: WeeklyConcours = {
  number: 936,
  category: 'international',
  title: 'Promosport : Concours N° 936',
  season: 'Saison 2026-2027',
  fullDateFormatted: 'mardi 17/11/2026 à 20:00',
  dateStr: '17-11-2026',
  closingTimeStr: '17/11/2026 à 20:00',
  cagnotteEstimate: 'تُحدد عند السحب',
  sourceUrl: 'https://www.promosport-pronostic.com/welcome/promo_pronostic?jeux=Promosport&ng=936',
  matches: [
    {
      id: 1,
      siteMatchId: '1528992',
      dayTime: '19:45:00',
      competition: 'دوري الأمم الأوروبية',
      competitionFr: 'UEFA Nations League',
      homeTeam: 'ويلز',
      homeTeamFr: 'Wales',
      homeLogo: 'WAL',
      awayTeam: 'البرتغال',
      awayTeamFr: 'Portugal',
      awayLogo: 'PT',
      date: '17-11-2026',
      time: '19:45:00',
      kickoffTimestamp: new Date('2026-11-17T20:45:00+01:00').getTime(),
      status: 'scheduled',
      score: '- - -',
      result: null,
      prob1: 11,
      probX: 17,
      prob2: 72,
    },
    {
      id: 2,
      siteMatchId: '1528998',
      dayTime: '19:45:00',
      competition: 'دوري الأمم الأوروبية',
      competitionFr: 'UEFA Nations League',
      homeTeam: 'بولندا',
      homeTeamFr: 'Poland',
      homeLogo: 'PL',
      awayTeam: 'السويد',
      awayTeamFr: 'Sweden',
      awayLogo: 'SE',
      date: '17-11-2026',
      time: '19:45:00',
      kickoffTimestamp: new Date('2026-11-17T20:45:00+01:00').getTime(),
      status: 'scheduled',
      score: '- - -',
      result: null,
      prob1: 40,
      probX: 24,
      prob2: 36,
    },
    {
      id: 3,
      siteMatchId: '1528993',
      dayTime: '19:45:00',
      competition: 'دوري الأمم الأوروبية',
      competitionFr: 'UEFA Nations League',
      homeTeam: 'الدنمارك',
      homeTeamFr: 'Denmark',
      homeLogo: 'DK',
      awayTeam: 'النرويج',
      awayTeamFr: 'Norway',
      awayLogo: 'NO',
      date: '17-11-2026',
      time: '19:45:00',
      kickoffTimestamp: new Date('2026-11-17T20:45:00+01:00').getTime(),
      status: 'scheduled',
      score: '- - -',
      result: null,
      prob1: 38,
      probX: 23,
      prob2: 39,
    },
    {
      id: 4,
      siteMatchId: '1528997',
      dayTime: '19:45:00',
      competition: 'دوري الأمم الأوروبية',
      competitionFr: 'UEFA Nations League',
      homeTeam: 'جمهورية أيرلندا',
      homeTeamFr: 'Rep. Of Ireland',
      homeLogo: 'IE',
      awayTeam: 'كوسوفو',
      awayTeamFr: 'Kosovo',
      awayLogo: 'XK',
      date: '17-11-2026',
      time: '19:45:00',
      kickoffTimestamp: new Date('2026-11-17T20:45:00+01:00').getTime(),
      status: 'scheduled',
      score: '- - -',
      result: null,
      prob1: 49,
      probX: 27,
      prob2: 24,
    },
    {
      id: 5,
      siteMatchId: '1528995',
      dayTime: '19:45:00',
      competition: 'دوري الأمم الأوروبية',
      competitionFr: 'UEFA Nations League',
      homeTeam: 'المجر',
      homeTeamFr: 'Hungary',
      homeLogo: 'HU',
      awayTeam: 'أيرلندا الشمالية',
      awayTeamFr: 'Northern Ireland',
      awayLogo: 'GB-NIR',
      date: '17-11-2026',
      time: '19:45:00',
      kickoffTimestamp: new Date('2026-11-17T20:45:00+01:00').getTime(),
      status: 'scheduled',
      score: '- - -',
      result: null,
      prob1: 50,
      probX: 27,
      prob2: 23,
    },
    {
      id: 6,
      siteMatchId: '1528994',
      dayTime: '19:45:00',
      competition: 'دوري الأمم الأوروبية',
      competitionFr: 'UEFA Nations League',
      homeTeam: 'أوكرانيا',
      homeTeamFr: 'Ukraine',
      homeLogo: 'UA',
      awayTeam: 'جورجيا',
      awayTeamFr: 'Georgia',
      awayLogo: 'GE',
      date: '17-11-2026',
      time: '19:45:00',
      kickoffTimestamp: new Date('2026-11-17T20:45:00+01:00').getTime(),
      status: 'scheduled',
      score: '- - -',
      result: null,
      prob1: 38,
      probX: 26,
      prob2: 36,
    },
    {
      id: 7,
      siteMatchId: '1528999',
      dayTime: '19:45:00',
      competition: 'دوري الأمم الأوروبية',
      competitionFr: 'UEFA Nations League',
      homeTeam: 'البوسنة والهرسك',
      homeTeamFr: 'Bosnia & Herzegovina',
      homeLogo: 'BA',
      awayTeam: 'رومانيا',
      awayTeamFr: 'Romania',
      awayLogo: 'RO',
      date: '17-11-2026',
      time: '19:45:00',
      kickoffTimestamp: new Date('2026-11-17T20:45:00+01:00').getTime(),
      status: 'scheduled',
      score: '- - -',
      result: null,
      prob1: 54,
      probX: 25,
      prob2: 21,
    },
    {
      id: 8,
      siteMatchId: '1545889',
      dayTime: '19:00:00',
      competition: 'تصفيات كأس أمم إفريقيا',
      competitionFr: 'Africa Cup of Nations - Qualification',
      homeTeam: 'الكونغو',
      homeTeamFr: 'Congo',
      homeLogo: 'CG',
      awayTeam: 'جزر القمر',
      awayTeamFr: 'Comoros',
      awayLogo: 'KM',
      date: '17-11-2026',
      time: '19:00:00',
      kickoffTimestamp: new Date('2026-11-17T20:00:00+01:00').getTime(),
      status: 'scheduled',
      score: '- - -',
      result: null,
      prob1: 25,
      probX: 50,
      prob2: 25,
    },
    {
      id: 9,
      siteMatchId: '1545899',
      dayTime: '19:00:00',
      competition: 'تصفيات كأس أمم إفريقيا',
      competitionFr: 'Africa Cup of Nations - Qualification',
      homeTeam: 'موريتانيا',
      homeTeamFr: 'Mauritania',
      homeLogo: 'MR',
      awayTeam: 'بوركينا فاسو',
      awayTeamFr: 'Burkina Faso',
      awayLogo: 'BF',
      date: '17-11-2026',
      time: '19:00:00',
      kickoffTimestamp: new Date('2026-11-17T20:00:00+01:00').getTime(),
      status: 'scheduled',
      score: '- - -',
      result: null,
      prob1: 25,
      probX: 50,
      prob2: 25,
    },
    {
      id: 10,
      siteMatchId: '1545902',
      dayTime: '19:00:00',
      competition: 'تصفيات كأس أمم إفريقيا',
      competitionFr: 'Africa Cup of Nations - Qualification',
      homeTeam: 'رواندا',
      homeTeamFr: 'Rwanda',
      homeLogo: 'RW',
      awayTeam: 'مالي',
      awayTeamFr: 'Mali',
      awayLogo: 'ML',
      date: '17-11-2026',
      time: '19:00:00',
      kickoffTimestamp: new Date('2026-11-17T20:00:00+01:00').getTime(),
      status: 'scheduled',
      score: '- - -',
      result: null,
      prob1: 25,
      probX: 50,
      prob2: 25,
    },
    {
      id: 11,
      siteMatchId: '1545886',
      dayTime: '19:00:00',
      competition: 'تصفيات كأس أمم إفريقيا',
      competitionFr: 'Africa Cup of Nations - Qualification',
      homeTeam: 'بوتسوانا',
      homeTeamFr: 'Botswana',
      homeLogo: 'BW',
      awayTeam: 'أوغندا',
      awayTeamFr: 'Uganda',
      awayLogo: 'UG',
      date: '17-11-2026',
      time: '19:00:00',
      kickoffTimestamp: new Date('2026-11-17T20:00:00+01:00').getTime(),
      status: 'scheduled',
      score: '- - -',
      result: null,
      prob1: 25,
      probX: 50,
      prob2: 25,
    },
    {
      id: 12,
      siteMatchId: '1545896',
      dayTime: '19:00:00',
      competition: 'تصفيات كأس أمم إفريقيا',
      competitionFr: 'Africa Cup of Nations - Qualification',
      homeTeam: 'ليبيريا',
      homeTeamFr: 'Liberia',
      homeLogo: 'LR',
      awayTeam: 'الرأس الأخضر',
      awayTeamFr: 'Cape Verde Islands',
      awayLogo: 'CV',
      date: '17-11-2026',
      time: '19:00:00',
      kickoffTimestamp: new Date('2026-11-17T20:00:00+01:00').getTime(),
      status: 'scheduled',
      score: '- - -',
      result: null,
      prob1: 25,
      probX: 50,
      prob2: 25,
    },
    {
      id: 13,
      siteMatchId: '1545901',
      dayTime: '20:00:00',
      competition: 'تصفيات كأس أمم إفريقيا',
      competitionFr: 'Africa Cup of Nations - Qualification',
      homeTeam: 'النيجر',
      homeTeamFr: 'Niger',
      homeLogo: 'NE',
      awayTeam: 'المغرب',
      awayTeamFr: 'Morocco',
      awayLogo: 'MA',
      date: '17-11-2026',
      time: '20:00:00',
      kickoffTimestamp: new Date('2026-11-17T21:00:00+01:00').getTime(),
      status: 'scheduled',
      score: '- - -',
      result: null,
      prob1: 25,
      probX: 50,
      prob2: 25,
    },
  ],
};

export const ALL_WEEKLY_CONCOURS: WeeklyConcours[] = [
  INTERNATIONAL_WEEKLY_CONCOURS_936,
];

// Active Concours displayed in خانة القصاصة (No 936, auto-upgraded live from promosport-pronostic.com)
export const INITIAL_WEEKLY_CONCOURS: WeeklyConcours = INTERNATIONAL_WEEKLY_CONCOURS_936;

/**
 * Strictly returns ONLY the immediate preceding grille (activeConcoursNumber - 1 first,
 * otherwise nearest lower archived grille) so Tirage ALWAYS locks onto the previous concours (e.g. 936 when 937 is active).
 */
export function getOrderedRecentTirageGrilles(
  allGrilles: PromosportGrille[],
  activeConcoursNumber: number
): PromosportGrille[] {
  const exactPrev = allGrilles.find((g) => g.number === activeConcoursNumber - 1);
  if (exactPrev) {
    return [exactPrev];
  }
  const byNumber = new Map<number, PromosportGrille>();
  for (const g of allGrilles) {
    if (g.number < activeConcoursNumber && !byNumber.has(g.number)) {
      byNumber.set(g.number, g);
    }
  }
  return Array.from(byNumber.values())
    .sort((a, b) => b.number - a.number)
    .slice(0, 1);
}

/**
 * Converts a superseded WeeklyConcours into a PromosportGrille entry for Tirage IMMEDIATELY on rollover.
 * Preserves "قيد التحديد الرسمي" whenever official winners/payouts are not yet published on the site,
 * and NEVER fabricates '0 - 0' / 'X' scores for unplayed/unverified matches.
 */
export function archiveConcoursToGrille(
  concours: WeeklyConcours,
  existingGrille?: PromosportGrille
): PromosportGrille {
  if (existingGrille && existingGrille.status === 'official') {
    return existingGrille;
  }

  return {
    id: `grille-${concours.number}`,
    number: concours.number,
    date: concours.closingTimeStr || concours.fullDateFormatted.replace(/^du\s+/i, ''),
    cagnotte: existingGrille?.cagnotte ?? 0,
    cagnotteFormatted: existingGrille?.cagnotteFormatted || 'قيد التحديد الرسمي',
    winnersCount: existingGrille?.winnersCount ?? 0,
    winnersFormatted: existingGrille?.winnersFormatted || 'قيد التحديد الرسمي',
    prizePerWinner: existingGrille?.prizePerWinner ?? 0,
    prizePerWinnerFormatted: existingGrille?.prizePerWinnerFormatted || 'قيد التحديد الرسمي',
    isRollover: existingGrille?.isRollover ?? false,
    status: 'pending',
    sourceUrl: `https://www.promosport-pronostic.com/welcome/promo_result?grille=${concours.number}&jeux=Promosport`,
    matches: concours.matches.map((m) => {
      const hasVerifiedFinalScore =
        !m.isDelayed &&
        m.status === 'finished' &&
        m.score &&
        m.score !== '- - -';
      return {
        id: m.id,
        homeTeam: m.homeTeam,
        homeTeamFr: m.homeTeamFr,
        homeLogo: m.homeLogo,
        awayTeam: m.awayTeam,
        awayTeamFr: m.awayTeamFr,
        awayLogo: m.awayLogo,
        competition: m.competition,
        competitionFr: m.competitionFr,
        score: hasVerifiedFinalScore ? m.score : '- - -',
        result: hasVerifiedFinalScore ? m.result : null,
      };
    }),
  };
}

export function mergeGrilleArchives(
  base: PromosportGrille[],
  extra: PromosportGrille[]
): PromosportGrille[] {
  const byNumber = new Map<number, PromosportGrille>();
  for (const g of base) {
    byNumber.set(g.number, g);
  }
  for (const g of extra) {
    const existing = byNumber.get(g.number);
    if (!existing) {
      byNumber.set(g.number, g);
      continue;
    }

    const payoutsChanged =
      g.cagnotte !== existing.cagnotte ||
      g.winnersCount !== existing.winnersCount ||
      g.prizePerWinner !== existing.prizePerWinner ||
      g.status !== existing.status;

    if (g.status === 'official') {
      if (existing.status !== 'official' || payoutsChanged) {
        const hasSettledMatches =
          existing.status !== 'official' &&
          g.matches.length >= existing.matches.length &&
          g.matches.some((m) => /^\d+\s*[-:]\s*\d+$/.test(String(m.score || '')));
        byNumber.set(g.number, {
          ...existing,
          cagnotte: g.cagnotte,
          cagnotteFormatted: g.cagnotteFormatted,
          winnersCount: g.winnersCount,
          winnersFormatted: g.winnersFormatted,
          prizePerWinner: g.prizePerWinner,
          prizePerWinnerFormatted: g.prizePerWinnerFormatted,
          isRollover: g.isRollover,
          status: 'official',
          matches: hasSettledMatches ? g.matches : existing.matches,
        });
      }
    } else if (existing.status !== 'official') {
      // Never run or overwrite matches with live scores in Tirage; only update financial cagnotte if newly published
      if (g.cagnotte > 0 && existing.cagnotte <= 0) {
        byNumber.set(g.number, {
          ...existing,
          cagnotte: g.cagnotte,
          cagnotteFormatted: g.cagnotteFormatted,
        });
      } else if (existing.matches.length === 0 && g.matches.length > 0) {
        byNumber.set(g.number, g);
      }
    }
  }
  return Array.from(byNumber.values()).sort((a, b) => b.number - a.number);
}

export interface PromosportSyncPayload {
  activeConcours: WeeklyConcours;
  grilles: PromosportGrille[];
  syncedAt: string;
  source: 'server-live' | 'server-cache' | 'local-fallback';
}

let inFlightSyncPromise: Promise<PromosportSyncPayload> | null = null;
let lastCompletedSyncPayload: PromosportSyncPayload | null = null;
let lastCompletedSyncMs = 0;

export function getSyncApiOrigins(): string[] {
  const originCandidates = [''];
  const remoteOrigin = typeof window !== 'undefined' ? getStoredRemoteSyncOrigin() : null;
  if (
    remoteOrigin &&
    typeof window !== 'undefined' &&
    remoteOrigin.replace(/\/$/, '') !== window.location.origin.replace(/\/$/, '')
  ) {
    originCandidates.push(remoteOrigin.replace(/\/$/, ''));
  }
  return originCandidates;
}

export function fetchPromosportSyncState(forceRefresh = false): Promise<PromosportSyncPayload> {
  if (inFlightSyncPromise) {
    return inFlightSyncPromise;
  }
  const now = Date.now();
  if (!forceRefresh && lastCompletedSyncPayload && now - lastCompletedSyncMs < 4000) {
    return Promise.resolve(lastCompletedSyncPayload);
  }

  inFlightSyncPromise = (async (): Promise<PromosportSyncPayload> => {
    const query = forceRefresh ? '?refresh=1' : '';
    const candidateEndpoints = getSyncApiOrigins().map((origin) => `${origin}/api/promosport/sync${query}`);

    for (const endpoint of candidateEndpoints) {
      try {
        const controller = new AbortController();
        const tid = setTimeout(() => controller.abort(), 5500);
        const response = await fetch(endpoint, {
          headers: { Accept: 'application/json' },
          cache: 'no-store',
          signal: controller.signal,
        });
        clearTimeout(tid);

        const contentType = response.headers.get('content-type') || '';
        if (response.ok && contentType.includes('application/json')) {
          const data = (await response.json()) as PromosportSyncPayload;
          if (data && data.activeConcours && Array.isArray(data.grilles) && data.grilles.length > 0) {
            let resolvedConcours = normalizeConcoursTranslations(data.activeConcours);
            // Only enrich client-side if server didn't just provide a fresh server-live payload
            if (data.source !== 'server-live') {
              const direct = await enrichConcoursWithDirectLiveFeeds(resolvedConcours);
              if (direct.matchedCount > 0) {
                resolvedConcours = normalizeConcoursTranslations(
                  mergeConcoursPreservingScores(resolvedConcours, direct.concours)
                );
              }
            }
            const normalizedGrilles = data.grilles.map(normalizeGrilleTranslations);
            if (typeof window !== 'undefined') {
              saveCachedConcours(resolvedConcours);
              saveCachedGrilles(normalizedGrilles);
            }
            const resultPayload: PromosportSyncPayload = {
              ...data,
              activeConcours: resolvedConcours,
              grilles: normalizedGrilles,
            };
            lastCompletedSyncPayload = resultPayload;
            lastCompletedSyncMs = Date.now();
            return resultPayload;
          }
        }
      } catch {
        // Continue to direct promosport-pronostic.com live scan
      }
    }

    // Standalone APK / Offline-first / Client direct scan of https://www.promosport-pronostic.com/welcome/promosport
    const seedConcours =
      (typeof window !== 'undefined' ? loadCachedConcours(INITIAL_WEEKLY_CONCOURS.number) : null) ||
      INITIAL_WEEKLY_CONCOURS;

    const cachedGrilles = typeof window !== 'undefined' ? loadCachedGrilles() : [];
    let baseConcours = seedConcours;
    let mergedGrilles: PromosportGrille[] = mergeGrilleArchives(INITIAL_GRILLES, cachedGrilles);
    let directSiteSuccess = false;

    try {
      const siteScan = await fetchPromosportPronosticFullScan();
      if (siteScan.activeConcours && siteScan.activeConcours.number >= baseConcours.number) {
        if (siteScan.activeConcours.number > baseConcours.number) {
          const prevAsGrille = archiveConcoursToGrille(baseConcours);
          mergedGrilles = mergeGrilleArchives(mergedGrilles, [prevAsGrille]);
          baseConcours = siteScan.activeConcours;
        } else {
          baseConcours = mergeConcoursPreservingScores(baseConcours, siteScan.activeConcours);
        }
        directSiteSuccess = true;
      }
      if (siteScan.grilles.length > 0) {
        mergedGrilles = mergeGrilleArchives(mergedGrilles, siteScan.grilles);
        directSiteSuccess = true;
      }
    } catch {
      // Fallback gracefully to direct live feed enrichment below
    }

    const directFeedResult = await enrichConcoursWithDirectLiveFeeds(baseConcours);
    const resolvedFallback = normalizeConcoursTranslations(
      mergeConcoursPreservingScores(baseConcours, directFeedResult.concours)
    );
    const normalizedMergedGrilles = mergedGrilles.map(normalizeGrilleTranslations);
    if (typeof window !== 'undefined') {
      saveCachedConcours(resolvedFallback);
      saveCachedGrilles(normalizedMergedGrilles);
    }

    const fallbackPayload: PromosportSyncPayload = {
      activeConcours: resolvedFallback,
      grilles: normalizedMergedGrilles,
      syncedAt: new Date().toISOString(),
      source: directSiteSuccess || directFeedResult.matchedCount > 0 ? 'server-live' : 'local-fallback',
    };
    lastCompletedSyncPayload = fallbackPayload;
    lastCompletedSyncMs = Date.now();
    return fallbackPayload;
  })().finally(() => {
    inFlightSyncPromise = null;
  });

  return inFlightSyncPromise;
}

export async function fetchLatestGrilles(): Promise<PromosportGrille[]> {
  const sync = await fetchPromosportSyncState(false);
  return sync.grilles;
}

export async function fetchPromosportLiveMatchesScan(forceScan = false): Promise<SiteLiveScanPayload | null> {
  const originCandidates = getSyncApiOrigins();
  const suffix = forceScan ? '?scan=1' : '';

  for (const origin of originCandidates) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), forceScan ? 8000 : 4500);
      const res = await fetch(`${origin}/api/promosport/live-matches${suffix}`, {
        cache: 'no-store',
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      const contentType = res.headers.get('content-type') || '';
      if (res.ok && contentType.includes('application/json')) {
        const data = (await res.json()) as SiteLiveScanPayload;
        if (data && Array.isArray(data.matches)) {
          return data;
        }
      }
    } catch {
      // Fallback to next origin or direct scan
    }
  }

  try {
    const [catalog, rapid] = await Promise.all([
      scanPromosportLiveCatalogHtml(),
      fetchRapidLiveMap(),
    ]);
    if (catalog.length > 0) {
      return applyRapidToLiveMatches(catalog, rapid);
    }
  } catch {
    // Ignore transient direct scan errors
  }

  return null;
}

