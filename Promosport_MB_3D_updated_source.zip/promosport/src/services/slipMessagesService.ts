/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ParticipantProfile,
  RegisteredDirectoryUser,
  SlipMessageRecord,
  UserBetSlip,
  WeeklyConcours,
} from '../types/promosport';
import { Capacitor } from '@capacitor/core';
import { getStoredRemoteSyncOrigin } from './storageService';

const SEEN_MESSAGE_IDS_PREFIX = 'promosport_seen_slip_msg_ids_v1_';
function buildCandidateApiOrigins(): string[] {
  const origins: string[] = [];
  const remoteOrigin = getStoredRemoteSyncOrigin()?.replace(/\/+$/, '');
  if (remoteOrigin && Capacitor.isNativePlatform()) {
    origins.push(remoteOrigin);
  }
  if (typeof window !== 'undefined' && window.location?.origin?.startsWith('http')) {
    origins.push('');
  }
  if (remoteOrigin && !origins.includes(remoteOrigin)) {
    origins.push(remoteOrigin);
  }
  if (origins.length === 0) {
    origins.push('');
  }
  return origins;
}

export async function fetchRegisteredUsersDirectory(
  query = '',
  excludeId?: string
): Promise<RegisteredDirectoryUser[]> {
  const origins = buildCandidateApiOrigins();
  const params = new URLSearchParams();
  if (query.trim()) params.set('q', query.trim());
  if (excludeId) params.set('excludeId', excludeId);

  for (const base of origins) {
    try {
      const controller = new AbortController();
      const timer = window.setTimeout(() => controller.abort(), 3000);
      const res = await fetch(`${base}/api/participant/directory?${params.toString()}`, {
        cache: 'no-store',
        signal: controller.signal,
      });
      window.clearTimeout(timer);
      if (!res.ok) continue;
      const contentType = res.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) continue;
      const data = (await res.json()) as { ok?: boolean; users?: RegisteredDirectoryUser[] };
      if (data.ok && Array.isArray(data.users)) {
        return data.users;
      }
    } catch {
      // try next origin
    }
  }
  return [];
}

export async function fetchParticipantMessages(
  participant: ParticipantProfile
): Promise<{
  ok: boolean;
  sent: SlipMessageRecord[];
  received: SlipMessageRecord[];
  error?: string;
}> {
  const origins = buildCandidateApiOrigins();
  const params = new URLSearchParams({
    participantId: participant.id,
    fullName: participant.fullName,
  });

  for (const base of origins) {
    try {
      const controller = new AbortController();
      const timer = window.setTimeout(() => controller.abort(), 3500);
      const res = await fetch(`${base}/api/messages/list?${params.toString()}`, {
        cache: 'no-store',
        signal: controller.signal,
      });
      window.clearTimeout(timer);
      if (!res.ok) continue;
      const contentType = res.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) continue;
      const data = (await res.json()) as {
        ok?: boolean;
        sent?: SlipMessageRecord[];
        received?: SlipMessageRecord[];
      };
      if (data.ok) {
        return {
          ok: true,
          sent: Array.isArray(data.sent) ? data.sent : [],
          received: Array.isArray(data.received) ? data.received : [],
        };
      }
    } catch {
      // try next origin
    }
  }
  return { ok: false, sent: [], received: [], error: 'تعذر الاتصال بالخادم لجلب سجل الرسائل.' };
}

export async function sendSlipToParticipant(params: {
  sender: ParticipantProfile;
  recipientFullNameInput: string;
  recipientId?: string;
  slip: UserBetSlip;
  slipNumber: number;
  slipNumberLabel: string;
  concoursSnapshot?: WeeklyConcours;
  lang?: 'AR' | 'FR';
}): Promise<{ ok: boolean; message?: SlipMessageRecord; error?: string }> {
  const {
    sender,
    recipientFullNameInput,
    recipientId,
    slip,
    slipNumber,
    slipNumberLabel,
    concoursSnapshot,
    lang = 'AR',
  } = params;

  const trimmedRecipient = recipientFullNameInput.replace(/\s+/g, ' ').trim();
  if (!trimmedRecipient && !recipientId) {
    return {
      ok: false,
      error:
        lang === 'FR'
          ? 'Veuillez saisir ou sélectionner le nom du destinataire avec les 2 chiffres.'
          : 'يرجى كتابة أو اختيار اسم المستخدم مع الرقمين من الخادم.',
    };
  }

  const origins = buildCandidateApiOrigins();
  for (const base of origins) {
    try {
      const controller = new AbortController();
      const timer = window.setTimeout(() => controller.abort(), 4000);
      const res = await fetch(`${base}/api/messages/send`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderId: sender.id,
          senderFullName: sender.fullName,
          recipientId,
          recipientFullNameInput: trimmedRecipient,
          slipNumber,
          slipNumberLabel,
          slip,
          concoursSnapshot,
        }),
        signal: controller.signal,
      });
      window.clearTimeout(timer);

      const contentType = res.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) continue;
      const data = (await res.json()) as {
        ok?: boolean;
        message?: SlipMessageRecord;
        error?: string;
      };

      if (res.ok && data.ok && data.message) {
        return { ok: true, message: data.message };
      }
      return {
        ok: false,
        error:
          data.error ||
          (lang === 'FR'
            ? 'Utilisateur introuvable ou envoi impossible.'
            : 'هذا المستخدم غير مسجل في الخادم — تحقق من الاسم والرقمين.'),
      };
    } catch {
      // try next origin
    }
  }

  return {
    ok: false,
    error:
      lang === 'FR'
        ? 'Connexion au serveur impossible pour envoyer la fiche.'
        : 'تعذر الاتصال بالخادم لإرسال القصاصة.',
  };
}

export async function markSlipMessageSaved(
  messageId: string,
  participantId: string
): Promise<boolean> {
  const origins = buildCandidateApiOrigins();
  for (const base of origins) {
    try {
      const res = await fetch(`${base}/api/messages/mark-saved`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messageId, participantId }),
      });
      if (res.ok) return true;
    } catch {
      // try next origin
    }
  }
  return false;
}

export async function deleteSlipMessage(
  messageId: string,
  participantId: string
): Promise<boolean> {
  const origins = buildCandidateApiOrigins();
  for (const base of origins) {
    try {
      const res = await fetch(`${base}/api/messages/delete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messageId, participantId }),
      });
      if (res.ok) return true;
    } catch {
      // try next origin
    }
  }
  return false;
}

export function subscribeParticipantMessageStream(
  participant: ParticipantProfile,
  onNewMessage: (msg: SlipMessageRecord) => void,
  onSyncNeeded: () => void
): () => void {
  if (typeof window === 'undefined' || typeof EventSource === 'undefined') {
    return () => {};
  }

  const origins = buildCandidateApiOrigins();
  const base = origins[0] || '';
  const params = new URLSearchParams({
    participantId: participant.id,
    fullName: participant.fullName,
  });

  let closed = false;
  let source: EventSource | null = null;
  let reconnectTimer: number | null = null;

  const connect = () => {
    if (closed) return;
    try {
      source = new EventSource(`${base}/api/messages/stream?${params.toString()}`);
      source.addEventListener('new-message', (ev) => {
        try {
          const parsed = JSON.parse((ev as MessageEvent).data) as SlipMessageRecord;
          if (parsed && parsed.id) {
            onNewMessage(parsed);
          }
        } catch {
          onSyncNeeded();
        }
      });
      source.addEventListener('message-updated', () => {
        onSyncNeeded();
      });
      source.onerror = () => {
        source?.close();
        source = null;
        if (!closed && reconnectTimer === null) {
          reconnectTimer = window.setTimeout(() => {
            reconnectTimer = null;
            connect();
          }, 5000);
        }
      };
    } catch {
      // fallback polling in App handles updates
    }
  };

  connect();

  return () => {
    closed = true;
    if (reconnectTimer !== null) {
      window.clearTimeout(reconnectTimer);
    }
    source?.close();
    source = null;
  };
}

export function loadSeenMessageIds(participantId: string): Set<string> {
  try {
    const raw = localStorage.getItem(`${SEEN_MESSAGE_IDS_PREFIX}${participantId}`);
    if (!raw) return new Set();
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? new Set(parsed.filter((x) => typeof x === 'string')) : new Set();
  } catch {
    return new Set();
  }
}

export function markMessageIdsSeen(participantId: string, ids: string[]): void {
  if (!participantId || ids.length === 0) return;
  try {
    const existing = loadSeenMessageIds(participantId);
    ids.forEach((id) => existing.add(id));
    const pruned = Array.from(existing).slice(-300);
    localStorage.setItem(`${SEEN_MESSAGE_IDS_PREFIX}${participantId}`, JSON.stringify(pruned));
  } catch {
    // ignore storage errors
  }
}
