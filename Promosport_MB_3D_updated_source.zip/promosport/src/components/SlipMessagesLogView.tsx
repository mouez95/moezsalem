/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo, useState } from 'react';
import {
  ArrowRight,
  BookmarkPlus,
  CheckCircle2,
  Clock,
  Eye,
  Inbox,
  Mail,
  Radio,
  Receipt,
  RefreshCw,
  Send,
  Trash2,
  UserCheck,
} from 'lucide-react';
import {
  PromosportGrille,
  SlipMessageRecord,
  WeeklyConcours,
} from '../types/promosport';
import { audioService } from '../services/audioService';
import { computeSlipSummaryStats } from '../services/slipStatsService';
import { SlipSummaryBadges } from './SlipSummaryBadges';

interface SlipMessagesLogViewProps {
  lang: 'AR' | 'FR';
  sentMessages: SlipMessageRecord[];
  receivedMessages: SlipMessageRecord[];
  serverError?: string | null;
  liveConcours: WeeklyConcours;
  grilles: PromosportGrille[];
  isRefreshing?: boolean;
  onRefresh: () => void;
  onBackToSlips: () => void;
  onOpenMessageSlip: (msg: SlipMessageRecord, direction: 'incoming' | 'sent') => void;
  onSaveToMySlips: (msg: SlipMessageRecord) => Promise<void> | void;
  onDeleteMessage: (messageId: string) => Promise<void> | void;
}

type MessagesFilter = 'all' | 'incoming' | 'sent';

export const SlipMessagesLogView: React.FC<SlipMessagesLogViewProps> = ({
  lang,
  sentMessages,
  receivedMessages,
  serverError = null,
  liveConcours,
  grilles,
  isRefreshing = false,
  onRefresh,
  onBackToSlips,
  onOpenMessageSlip,
  onSaveToMySlips,
  onDeleteMessage,
}) => {
  const [filter, setFilter] = useState<MessagesFilter>('all');
  const [busyMessageId, setBusyMessageId] = useState<string | null>(null);

  const resolveConcoursForMessage = (msg: SlipMessageRecord): WeeklyConcours => {
    const grilleNum = msg.slip.grilleNumber;
    if (grilleNum === liveConcours.number) {
      return liveConcours;
    }
    const archived = grilles.find((g) => g.number === grilleNum);
    if (archived) {
      return {
        ...(msg.concoursSnapshot || liveConcours),
        number: archived.number,
        title: `المسابقة الأسبوعية رقم ${archived.number}`,
        cagnotteEstimate: archived.cagnotteFormatted,
        matches: (msg.concoursSnapshot?.matches || liveConcours.matches).map((m, idx) => {
          const archMatch = archived.matches[idx] || archived.matches.find((am) => am.id === m.id);
          return archMatch
            ? {
                ...m,
                score: archMatch.score,
                result: archMatch.result,
                status: 'finished' as const,
              }
            : m;
        }),
      };
    }
    return msg.concoursSnapshot || liveConcours;
  };

  const combinedItems = useMemo(() => {
    const incoming = receivedMessages.map((msg) => ({
      direction: 'incoming' as const,
      msg,
      sortMs: Date.parse(msg.sentAtIso) || 0,
    }));
    const outgoing = sentMessages.map((msg) => ({
      direction: 'sent' as const,
      msg,
      sortMs: Date.parse(msg.sentAtIso) || 0,
    }));

    const merged =
      filter === 'incoming'
        ? incoming
        : filter === 'sent'
          ? outgoing
          : [...incoming, ...outgoing];

    return merged.sort((a, b) => b.sortMs - a.sortMs);
  }, [filter, receivedMessages, sentMessages]);

  const totalCount = receivedMessages.length + sentMessages.length;

  return (
    <div dir={lang === 'AR' ? 'rtl' : 'ltr'} className="space-y-3 px-2 sm:px-3 pb-4">
      {/* Top Bar of سجل الرسائل */}
      <div className="rounded-2xl bg-gradient-to-r from-[#081633] via-[#0d234d] to-[#081633] border border-sky-400/70 p-2.5 sm:p-3 flex flex-wrap items-center justify-between gap-2 shadow-lg">
        <div className="flex items-center gap-2 min-w-0">
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              onBackToSlips();
            }}
            className="min-h-[44px] px-3 py-2 rounded-xl bg-[#0e2246] hover:bg-[#15346a] border border-sky-400/80 text-cyan-200 hover:text-white font-black text-xs flex items-center gap-1.5 cursor-pointer active:scale-95 transition-all whitespace-nowrap shrink-0"
          >
            <ArrowRight className={`w-4 h-4 shrink-0 ${lang === 'FR' ? 'rotate-180' : ''}`} />
            <span>{lang === 'AR' ? 'القصاصات' : 'Fiches'}</span>
          </button>

          <div className="min-w-0">
            <h3 className="text-sm sm:text-base font-black text-yellow-300 flex items-center gap-1.5 truncate">
              <Mail className="w-4 h-4 text-sky-300 shrink-0" />
              <span>{lang === 'AR' ? 'سجل الرسائل' : 'Journal des messages'}</span>
            </h3>
            <p className="text-[11px] text-sky-100/80 font-semibold truncate">
              {lang === 'AR'
                ? 'القصاصات المرسلة والمستوردة متصلة مباشرة بالخادم'
                : 'Fiches envoyées et reçues synchronisées avec le serveur'}
            </p>
          </div>
        </div>

        <button
          type="button"
          disabled={isRefreshing}
          onClick={() => {
            audioService.playClick();
            onRefresh();
          }}
          className="min-h-[44px] px-3 py-2 rounded-xl bg-black/60 hover:bg-sky-900/60 border border-sky-400/75 text-sky-200 font-black text-xs flex items-center gap-1.5 cursor-pointer active:scale-95 transition-all disabled:opacity-50 whitespace-nowrap shrink-0"
        >
          <RefreshCw className={`w-3.5 h-3.5 shrink-0 ${isRefreshing ? 'animate-spin' : ''}`} />
          <span>{lang === 'AR' ? 'تحديث الخادم' : 'Actualiser'}</span>
        </button>
      </div>

      {serverError && (
        <div
          role="alert"
          className="rounded-xl border border-amber-400/70 bg-amber-950/70 px-3 py-2 text-xs font-bold text-amber-100"
        >
          <p>{lang === 'AR' ? 'تعذر الاتصال بخادم سجل الرسائل؛ أعد المحاولة عند توفر اتصال صالح.' : 'Serveur des messages inaccessible ; réessayez lorsque la connexion sera disponible.'}</p>
          <p className="mt-1 text-[11px] font-semibold text-amber-200/80">{serverError}</p>
        </div>
      )}

      {/* Filter Segmented Control: الكل | المستوردة | المرسلة */}
      <div className="grid grid-cols-3 gap-1.5 p-1 rounded-2xl bg-[#061129] border border-white/15">
        <button
          type="button"
          onClick={() => {
            audioService.playClick();
            setFilter('all');
          }}
          className={`min-h-[44px] px-2 py-2 rounded-xl font-black text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
            filter === 'all'
              ? 'bg-gradient-to-r from-yellow-300 to-amber-400 text-black shadow'
              : 'text-sky-100 hover:bg-white/10'
          }`}
        >
          <Mail className="w-3.5 h-3.5 shrink-0" />
          <span className="tabular-nums">
            {lang === 'AR' ? `الكل (${totalCount})` : `Tout (${totalCount})`}
          </span>
        </button>

        <button
          type="button"
          onClick={() => {
            audioService.playClick();
            setFilter('incoming');
          }}
          className={`min-h-[44px] px-2 py-2 rounded-xl font-black text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
            filter === 'incoming'
              ? 'bg-gradient-to-r from-emerald-400 to-cyan-400 text-black shadow'
              : 'text-emerald-200 hover:bg-white/10'
          }`}
        >
          <Inbox className="w-3.5 h-3.5 shrink-0" />
          <span className="tabular-nums">
            {lang === 'AR'
              ? `المستوردة (${receivedMessages.length})`
              : `Reçues (${receivedMessages.length})`}
          </span>
        </button>

        <button
          type="button"
          onClick={() => {
            audioService.playClick();
            setFilter('sent');
          }}
          className={`min-h-[44px] px-2 py-2 rounded-xl font-black text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
            filter === 'sent'
              ? 'bg-gradient-to-r from-sky-400 to-indigo-400 text-black shadow'
              : 'text-sky-200 hover:bg-white/10'
          }`}
        >
          <Send className="w-3.5 h-3.5 shrink-0" />
          <span className="tabular-nums">
            {lang === 'AR'
              ? `المرسلة (${sentMessages.length})`
              : `Envoyées (${sentMessages.length})`}
          </span>
        </button>
      </div>

      {/* Empty State vs List */}
      {combinedItems.length === 0 ? (
        <div className="p-8 rounded-2xl bg-[#071328] border border-white/15 text-center space-y-2.5">
          <div className="w-12 h-12 rounded-full bg-white/5 border border-white/20 mx-auto flex items-center justify-center text-sky-300">
            <Mail className="w-6 h-6" />
          </div>
          <p className="text-sm font-black text-white">
            {filter === 'incoming'
              ? lang === 'AR'
                ? 'لا توجد قصاصات مستوردة في سجل الرسائل بعد'
                : 'Aucune fiche reçue pour le moment'
              : filter === 'sent'
                ? lang === 'AR'
                  ? 'لا توجد قصاصات مرسلة في سجل الرسائل بعد'
                  : 'Aucune fiche envoyée pour le moment'
                : lang === 'AR'
                  ? 'سجل الرسائل فارغ حالياً'
                  : 'Le journal des messages est vide'}
          </p>
          <p className="text-xs text-slate-300 leading-relaxed">
            {lang === 'AR'
              ? 'اضغط على أيقونة "إرسال" بجانب ترقيم أي قصاصة مسجلة لإرسالها مباشرة إلى أي مشارك مسجل.'
              : 'Cliquez sur « Envoyer » à côté du numéro d’une fiche enregistrée pour l’expédier.'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {combinedItems.map(({ direction, msg }) => {
            const isIncoming = direction === 'incoming';
            const slipConcours = resolveConcoursForMessage(msg);
            const slipStats = computeSlipSummaryStats(
              msg.slip.selections,
              slipConcours,
              msg.slip.grilleNumber || liveConcours.number
            );
            const isBusy = busyMessageId === msg.id;

            return (
              <div
                key={`${direction}-${msg.id}`}
                className={`rounded-2xl border-2 overflow-hidden shadow-lg transition-colors ${
                  isIncoming
                    ? 'bg-[#07172d] border-emerald-400/75'
                    : 'bg-[#08152e] border-sky-400/75'
                }`}
              >
                {/* Clickable Card Body -> Opens Read-Only Live Tracking View */}
                <div
                  role="button"
                  tabIndex={0}
                  onClick={() => {
                    audioService.playClick();
                    onOpenMessageSlip(msg, direction);
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      audioService.playClick();
                      onOpenMessageSlip(msg, direction);
                    }
                  }}
                  className="p-3 sm:p-3.5 space-y-2.5 cursor-pointer hover:bg-white/[0.04] transition-colors"
                >
                  {/* Top Summary Line: Direction + Sender/Recipient + Slip # */}
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div className="space-y-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span
                          className={`inline-flex items-center gap-1 text-xs font-black ${
                            isIncoming ? 'text-emerald-300' : 'text-sky-300'
                          }`}
                        >
                          {isIncoming ? (
                            <Inbox className="w-3.5 h-3.5 shrink-0" />
                          ) : (
                            <Send className="w-3.5 h-3.5 shrink-0" />
                          )}
                          <span>
                            {isIncoming
                              ? lang === 'AR'
                                ? 'قصاصة مستوردة'
                                : 'Fiche reçue'
                              : lang === 'AR'
                                ? 'قصاصة مرسلة'
                                : 'Fiche envoyée'}
                          </span>
                        </span>

                        <span className="text-white/40" aria-hidden="true">·</span>

                        <span className="text-xs sm:text-sm font-black text-yellow-300">
                          {msg.slipNumberLabel || `#${msg.slipNumber}`}
                        </span>

                        <span className="text-white/40" aria-hidden="true">·</span>

                        <span className="text-xs font-mono font-black text-cyan-200 tabular-nums">
                          {lang === 'AR'
                            ? `المسابقة #${msg.slip.grilleNumber}`
                            : `Concours #${msg.slip.grilleNumber}`}
                        </span>
                      </div>

                      {/* Always Display Sender App Owner Name, Recipient, Date & Time */}
                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-200 font-bold">
                        <span className="inline-flex items-center gap-1 text-amber-200">
                          <UserCheck className="w-3.5 h-3.5 text-yellow-300 shrink-0" />
                          <span>
                            {lang === 'AR'
                              ? `المرسل: ${msg.senderFullName}`
                              : `Expéditeur : ${msg.senderFullName}`}
                          </span>
                        </span>
                        <span className="text-white/35" aria-hidden="true">·</span>
                        <span className="inline-flex items-center gap-1 text-sky-200">
                          <span>
                            {lang === 'AR'
                              ? `المستورد: ${msg.recipientFullName}`
                              : `Destinataire : ${msg.recipientFullName}`}
                          </span>
                        </span>
                        <span className="text-white/35" aria-hidden="true">·</span>
                        <span
                          dir="ltr"
                          className="inline-flex items-center gap-1 text-emerald-200 font-mono text-[11px] tabular-nums"
                        >
                          <Clock className="w-3 h-3 shrink-0" />
                          <span>{msg.sentAtDisplay}</span>
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 text-[11px] font-black text-amber-200 shrink-0">
                      <Radio className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                      <span>
                        {lang === 'AR' ? 'مباشر فقط · بدون تعديل' : 'Direct · Lecture seule'}
                      </span>
                    </div>
                  </div>

                  {/* Slip Price + Live Score Summary Badges */}
                  <div className="flex flex-col items-start gap-1.5 pt-2 border-t border-white/10">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-gray-200 font-bold">
                      <span className="inline-flex items-center gap-1 text-emerald-300 font-mono tabular-nums" dir="ltr">
                        <Receipt className="w-3.5 h-3.5 shrink-0" />
                        <span>{Number(msg.slip.totalCostDt || 0).toFixed(3)} TND</span>
                      </span>
                      <span className="text-white/35" aria-hidden="true">·</span>
                      <span className="text-cyan-300 font-mono tabular-nums">
                        {lang === 'AR'
                          ? `${msg.slip.totalCombinations} عمود`
                          : `${msg.slip.totalCombinations} col.`}
                      </span>
                      {msg.savedToSlipsByRecipient && isIncoming && (
                        <>
                          <span className="text-white/35" aria-hidden="true">·</span>
                          <span className="inline-flex items-center gap-1 text-emerald-300 font-black">
                            <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                            <span>
                              {lang === 'AR' ? 'محفوظة في قصاصاتي' : 'Enregistrée dans mes fiches'}
                            </span>
                          </span>
                        </>
                      )}
                    </div>

                    <SlipSummaryBadges stats={slipStats} lang={lang} compact />
                  </div>
                </div>

                {/* Action Row: فتح القصاصة (مباشر) + حفظ في قصاصاتي (للمستوردة) + فسخ */}
                <div className="px-3 py-2 bg-black/45 border-t border-white/10 flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      audioService.playClick();
                      onOpenMessageSlip(msg, direction);
                    }}
                    className="flex-1 min-h-[44px] px-3 py-2 rounded-xl bg-gradient-to-r from-sky-500/25 to-cyan-500/25 hover:from-sky-500 hover:to-cyan-500 border border-sky-400 text-sky-100 hover:text-black font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-all whitespace-nowrap"
                  >
                    <Eye className="w-4 h-4 shrink-0" />
                    <span>{lang === 'AR' ? 'فتح وتتبّع مباشر' : 'Ouvrir en direct'}</span>
                  </button>

                  {isIncoming && (
                    <button
                      type="button"
                      disabled={isBusy || Boolean(msg.savedToSlipsByRecipient)}
                      onClick={async () => {
                        audioService.playClick();
                        setBusyMessageId(msg.id);
                        try {
                          await onSaveToMySlips(msg);
                        } finally {
                          setBusyMessageId(null);
                        }
                      }}
                      className={`flex-1 min-h-[44px] px-3 py-2 rounded-xl font-black text-xs flex items-center justify-center gap-1.5 transition-all whitespace-nowrap ${
                        msg.savedToSlipsByRecipient
                          ? 'bg-emerald-950/75 border border-emerald-400/60 text-emerald-300 cursor-default'
                          : 'bg-gradient-to-r from-emerald-400 to-green-500 hover:brightness-105 border border-white text-black shadow cursor-pointer active:scale-95 disabled:opacity-60'
                      }`}
                    >
                      <BookmarkPlus className="w-4 h-4 shrink-0" />
                      <span>
                        {msg.savedToSlipsByRecipient
                          ? lang === 'AR'
                            ? 'تم الحفظ في قصاصاتي'
                            : 'Enregistrée'
                          : lang === 'AR'
                            ? 'حفظ في قصاصاتي'
                            : 'Enregistrer'}
                      </span>
                    </button>
                  )}

                  <button
                    type="button"
                    disabled={isBusy}
                    onClick={async () => {
                      audioService.playClick();
                      setBusyMessageId(msg.id);
                      try {
                        await onDeleteMessage(msg.id);
                      } finally {
                        setBusyMessageId(null);
                      }
                    }}
                    className="min-h-[44px] px-3.5 py-2 rounded-xl bg-red-600/30 hover:bg-red-600 border border-red-400/80 text-red-100 hover:text-white font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-all disabled:opacity-60 whitespace-nowrap"
                  >
                    <Trash2 className="w-3.5 h-3.5 shrink-0" />
                    <span>{lang === 'AR' ? 'فسخ' : 'Supprimer'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
