/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

interface TeamCrestProps {
  teamName: string;
  logoCode: string;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const TEAM_NAME_CODE_MAP: Record<string, string> = {
  'ليفربول': 'LIV', 'liverpool': 'LIV',
  'أستون فيلا': 'AVL', 'aston villa': 'AVL',
  'مانشستر سيتي': 'MCI', 'manchester city': 'MCI',
  'برايتون': 'BHA', 'brighton': 'BHA',
  'ريال مدريد': 'RMA', 'real madrid': 'RMA',
  'أوساسونا': 'OSA', 'osasuna': 'OSA',
  'فياريال': 'VIL', 'villarreal': 'VIL',
  'ديبورتيفو ألافيس': 'ALA', 'alavés': 'ALA', 'alaves': 'ALA',
  'يوفنتوس': 'JUV', 'juventus': 'JUV',
  'تورينو': 'TOR', 'torino': 'TOR',
  'ميلان': 'MIL', 'ac milan': 'MIL',
  'كالياري': 'CAG', 'cagliari': 'CAG',
  'بايرن ميونخ': 'BAY', 'bayern munich': 'BAY', 'bayern münchen': 'BAY',
  'سانت باولي': 'STP', 'st. pauli': 'STP',
  'بوروسيا دورتموند': 'BVB', 'b. dortmund': 'BVB', 'dortmund': 'BVB',
  'ماينتس': 'M05', 'mainz 05': 'M05',
  'باريس سان جيرمان': 'PSG', 'paris sg': 'PSG',
  'أنجيه': 'ANG', 'angers': 'ANG',
  'موناكو': 'MON', 'as monaco': 'MON',
  'ستراسبورغ': 'STR', 'strasbourg': 'STR',
  'إنتر ميلان': 'INT', 'inter milan': 'INT',
  'نابولي': 'NAP', 'napoli': 'NAP',
  'تشيلسي': 'CHE', 'chelsea': 'CHE',
  'أرسنال': 'ARS', 'arsenal': 'ARS',
  'برشلونة': 'BAR', 'fc barcelona': 'BAR', 'barcelona': 'BAR',
  'ريال سوسيداد': 'RSO', 'real sociedad': 'RSO',
  'أتلتيكو مدريد': 'ATM', 'atlético madrid': 'ATM', 'atletico madrid': 'ATM',
  'بنفيكا': 'BEN', 'benfica': 'BEN',
  'النجم الأحمر بلغراد': 'RSB', 'crvena zvezda': 'RSB',
  'شتوتغارت': 'STU', 'vfb stuttgart': 'STU',
  'أتالانتا': 'ATA', 'atalanta': 'ATA',
  'فينورد': 'FEY', 'feyenoord': 'FEY',
  'سالزبورغ': 'SAL', 'rb salzburg': 'SAL',
  'سبارتا براغ': 'SPA', 'sparta prague': 'SPA',
  'ستاد بريست': 'BRE', 'stade brestois': 'BRE',
  'لاتسيو': 'LAZ', 'ss lazio': 'LAZ',
  'بورتو': 'POR_C', 'fc porto': 'POR_C',
  'مانشستر يونايتد': 'MUN', 'man united': 'MUN', 'manchester united': 'MUN',
  'باوك سالونيكا': 'PAO', 'paok': 'PAO',
  'غلطة سراي': 'GAL', 'galatasaray': 'GAL',
  'توتنهام': 'TOT', 'tottenham': 'TOT',
  'أولمبياكوس': 'OLY', 'olympiacos': 'OLY',
  'رينجرز': 'RAN', 'rangers': 'RAN',
  'أياكس': 'AJA', 'afc ajax': 'AJA', 'ajax': 'AJA',
  'فيكتوريا بلزن': 'PLZ', 'viktoria plzeň': 'PLZ', 'viktoria plzen': 'PLZ',
  'نوح الأرميني': 'NOA', 'fc noah': 'NOA',
  'باير ليفركوزن': 'LEV', 'bayer leverkusen': 'LEV',
  'سبورتينغ لشبونة': 'SCP', 'sporting cp': 'SCP',
  'ليل': 'LIL', 'lille osc': 'LIL',
  'سلتيك': 'CEL', 'celtic fc': 'CEL',
  'لايبزيغ': 'RBL', 'rb leipzig': 'RBL',
  'شتورم غراتس': 'STG', 'sturm graz': 'STG',
  'بولونيا': 'BOL', 'bologna': 'BOL',
  'بي إس في آيندهوفن': 'PSV', 'psv eindhoven': 'PSV',
  'جيرونا': 'GIR', 'girona fc': 'GIR',
  'سلوفان براتيسلافا': 'SLO', 'slovan bratislava': 'SLO',
  'دينامو زغرب': 'DZG', 'dinamo zagreb': 'DZG',
  'إشبيلية': 'SEV', 'sevilla fc': 'SEV',
  'نيوكاسل يونايتد': 'NEW', 'newcastle utd': 'NEW',
  'روما': 'ROM', 'as roma': 'ROM',
  'فيورنتينا': 'FIO', 'fiorentina': 'FIO',
  'ليون': 'LYO', 'olympique lyon': 'LYO',
  'مارسيليا': 'OM', 'marseille': 'OM',
  // --- Concours 934 National Teams & Clubs ---
  'البرتغال': 'POR', 'portugal': 'POR',
  'الدنمارك': 'DK', 'danemark': 'DK', 'denmark': 'DK',
  'النرويج': 'NO', 'norvege': 'NO', 'norway': 'NO',
  'ويلز': 'GB-WLS', 'pays de galles': 'GB-WLS', 'wales': 'GB-WLS',
  'أيرلندا الشمالية': 'GB-NIR', 'irlande du nord': 'GB-NIR', 'northern ireland': 'GB-NIR',
  'أوكرانيا': 'UA', 'ukraine': 'UA',
  'النمسا': 'AT', 'autriche': 'AT', 'austria': 'AT',
  'أيرلندا': 'IE', 'irlande': 'IE', 'ireland': 'IE',
  'رومانيا': 'RO', 'roumanie': 'RO', 'romania': 'RO',
  'بولندا': 'POL', 'pologne': 'POL', 'poland': 'POL',
  'السويد': 'SE', 'suede': 'SE', 'sweden': 'SE',
  'البوسنة والهرسك': 'BA', 'bosnie herzegovine': 'BA', 'bosnia': 'BA',
  'جورجيا': 'GEO', 'georgie': 'GEO', 'georgia': 'GEO',
  'المجر': 'HU', 'hongrie': 'HU', 'hungary': 'HU',
  'أوغندا': 'UG', 'ouganda': 'UG', 'uganda': 'UG',
  'بوتسوانا': 'BW', 'botswana': 'BW',
  'الجزائر': 'DZ', 'algerie': 'DZ', 'algeria': 'DZ',
  'توغو': 'TG', 'togo': 'TG',
  // --- Spanish Segunda & National/World Additions (Concours 936 / promosport-pronostic.com) ---
  'ريال أوفييدو': 'OVI', 'real oviedo': 'OVI', 'oviedo': 'OVI',
  'girona': 'GIR',
  'مايوركا': 'MAL', 'mallorca': 'MAL', 'rcd mallorca': 'MAL',
  'قرطبة': 'COR', 'cordoba': 'COR', 'córdoba': 'COR',
  'ريال سوسيداد ب': 'RSOB', 'real sociedad b': 'RSOB', 'real sociedad ii': 'RSOB',
  'سبورتينغ خيخون': 'GIJ', 'sporting gijon': 'GIJ', 'sporting gijón': 'GIJ',
  'ألميريا': 'ALM', 'almeria': 'ALM', 'ud almeria': 'ALM',
  'أندورا': 'AND', 'fc andorra': 'AND',
  'غرناطة': 'GRA', 'granada cf': 'GRA', 'granada': 'GRA',
  'لاس بالماس': 'LPA', 'las palmas': 'LPA', 'ud las palmas': 'LPA',
  'إيبار': 'EIB', 'eibar': 'EIB', 'sd eibar': 'EIB',
  'قادش': 'CAD', 'cadiz': 'CAD', 'cádiz': 'CAD',
  'إلدينسي': 'ELD', 'eldense': 'ELD', 'cd eldense': 'ELD',
  'ساباديل': 'SAB', 'sabadell': 'SAB', 'ce sabadell': 'SAB',
  'تينيريفي': 'TEN', 'tenerife': 'TEN', 'cd tenerife': 'TEN',
  'سبتة': 'CEU', 'ad ceuta fc': 'CEU', 'ceuta': 'CEU',
  // --- Concours 936 Nations (Arabic & French/English) ---
  'جمهورية أيرلندا': 'IE', 'rep. of ireland': 'IE', 'republic of ireland': 'IE',
  'كوسوفو': 'XK', 'kosovo': 'XK',
  'الكونغو': 'CG', 'congo': 'CG',
  'جزر القمر': 'KM', 'comoros': 'KM', 'comores': 'KM',
  'موريتانيا': 'MR', 'mauritania': 'MR', 'mauritanie': 'MR',
  'بوركينا فاسو': 'BF', 'burkina faso': 'BF',
  'رواندا': 'RW', 'rwanda': 'RW',
  'مالي': 'ML', 'mali': 'ML',
  'ليبيريا': 'LR', 'liberia': 'LR',
  'الرأس الأخضر': 'CV', 'cape verde islands': 'CV', 'cape verde': 'CV', 'cap-vert': 'CV',
  'النيجر': 'NE', 'niger': 'NE',
  'المغرب': 'MA', 'morocco': 'MA', 'maroc': 'MA',
  'إسبانيا': 'ES', 'spain': 'ES', 'espagne': 'ES',
  'إنجلترا': 'GB-ENG', 'england': 'GB-ENG', 'angleterre': 'GB-ENG',
  'بلجيكا': 'BE', 'belgium': 'BE', 'belgique': 'BE',
  'إيطاليا': 'IT', 'italy': 'IT', 'italie': 'IT',
  'فرنسا': 'FR', 'france': 'FR',
  'تركيا': 'TR', 'turkey': 'TR', 'turquie': 'TR', 'türkiye': 'TR',
  'كرواتيا': 'HR', 'croatia': 'HR', 'croatie': 'HR',
  'التشيك': 'CZ', 'czechia': 'CZ', 'czech republic': 'CZ', 'tcheque': 'CZ',
  'بيلاروسيا': 'BY', 'belarus': 'BY', 'bielorussie': 'BY',
  'ألبانيا': 'AL', 'albania': 'AL', 'albanie': 'AL',
  'قبرص': 'CY', 'cyprus': 'CY', 'chypre': 'CY',
  'الجبل الأسود': 'ME', 'montenegro': 'ME',
  'لاتفيا': 'LV', 'latvia': 'LV', 'lettonie': 'LV',
  'أرمينيا': 'AM', 'armenia': 'AM', 'armenie': 'AM',
  'البوسنة': 'BA', 'bosnia & herzegovina': 'BA', 'bosnia and herzegovina': 'BA',
  'تونس': 'TN', 'tunisia': 'TN', 'tunisie': 'TN',
  'مصر': 'EG', 'egypt': 'EG', 'egypte': 'EG',
  'السعودية': 'SA', 'saudi arabia': 'SA', 'arabie saoudite': 'SA',
  'قطر': 'QA', 'qatar': 'QA',
  'ألمانيا': 'DE', 'germany': 'DE', 'allemagne': 'DE',
  'هولندا': 'NL', 'netherlands': 'NL', 'pays-bas': 'NL',
  'سويسرا': 'CH', 'switzerland': 'CH', 'suisse': 'CH',
  'اليونان': 'GR', 'greece': 'GR', 'grece': 'GR',
  'اسكتلندا': 'GB-SCT', 'scotland': 'GB-SCT', 'ecosse': 'GB-SCT',
};

const SHIELD_PALETTES: Array<[string, string, string]> = [
  ['#0f4c81', '#ffffff', '#facc15'],
  ['#b91c1c', '#ffffff', '#fde047'],
  ['#15803d', '#ffffff', '#facc15'],
  ['#1d4ed8', '#e0f2fe', '#ffffff'],
  ['#991b1b', '#facc15', '#ffffff'],
  ['#0e7490', '#ffffff', '#38bdf8'],
  ['#4338ca', '#facc15', '#ffffff'],
  ['#065f46', '#fde047', '#ffffff'],
];

const getDeterministicPalette = (name: string): [string, string, string] => {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = (hash * 31 + name.charCodeAt(i)) | 0;
  }
  return SHIELD_PALETTES[Math.abs(hash) % SHIELD_PALETTES.length];
};

const buildMonogram = (name: string, code: string): string => {
  const cleanCode = (code || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  if (cleanCode && cleanCode !== 'CLUB' && cleanCode.length <= 4) {
    return cleanCode.slice(0, 3);
  }
  const latin = name.replace(/[^A-Za-z0-9\s]/g, '').trim();
  if (latin.length >= 2) {
    const words = latin.split(/\s+/).filter(Boolean);
    if (words.length >= 2) {
      return `${words[0][0]}${words[1][0]}${words[2]?.[0] || ''}`.toUpperCase();
    }
    return latin.slice(0, 3).toUpperCase();
  }
  return name.trim().slice(0, 2);
};

export const TeamCrest: React.FC<TeamCrestProps> = ({
  teamName,
  logoCode,
  size = 'md',
  className = ''
}) => {
  // Crisp high-resolution dimensions without hazy CSS blur/drop-shadow
  const dim = size === 'sm'
    ? 'w-7 h-5 text-xs'
    : size === 'lg'
    ? 'w-11 h-8 text-sm'
    : 'w-9 h-7 text-xs';

  const normalizedNameKey = teamName.trim().toLowerCase();
  const resolvedCode =
    TEAM_NAME_CODE_MAP[normalizedNameKey] ||
    (logoCode ? logoCode.toUpperCase() : '');

  // National flags and club emblems SVGs
  const renderCrest = () => {
    switch (resolvedCode) {
      // --- International Teams from Screenshot ---
      case 'IT': // Italie
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="10" height="20" fill="#009246" />
            <rect x="10" width="10" height="20" fill="#ffffff" />
            <rect x="20" width="10" height="20" fill="#ce2b37" />
          </svg>
        );

      case 'FR': // France
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="10" height="20" fill="#002395" />
            <rect x="10" width="10" height="20" fill="#ffffff" />
            <rect x="20" width="10" height="20" fill="#ed2939" />
          </svg>
        );

      case 'TR': // Turquie
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="20" fill="#e30a17" />
            <circle cx="11" cy="10" r="5" fill="#ffffff" />
            <circle cx="12.5" cy="10" r="4" fill="#e30a17" />
            <polygon points="16,8.5 17.5,10 16,11.5 18,10.5 18,9.5" fill="#ffffff" />
          </svg>
        );

      case 'BE': // Belgique
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="10" height="20" fill="#000000" />
            <rect x="10" width="10" height="20" fill="#ffd90c" />
            <rect x="20" width="10" height="20" fill="#ef3340" />
          </svg>
        );

      case 'CZ': // Tcheque
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="10" fill="#ffffff" />
            <rect y="10" width="30" height="10" fill="#d7141a" />
            <polygon points="0,0 15,10 0,20" fill="#11457e" />
          </svg>
        );

      case 'ES': // Espagne
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="5" fill="#aa151b" />
            <rect y="5" width="30" height="10" fill="#f1bf00" />
            <rect y="15" width="30" height="5" fill="#aa151b" />
            <rect x="7" y="8" width="3" height="4" fill="#aa151b" rx="1" />
          </svg>
        );

      case 'GB-ENG': // Angleterre
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="20" fill="#ffffff" />
            <rect x="13" width="4" height="20" fill="#ce1124" />
            <rect y="8" width="30" height="4" fill="#ce1124" />
          </svg>
        );

      case 'HR': // Croatie
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="6.6" fill="#ff0000" />
            <rect y="6.6" width="30" height="6.6" fill="#ffffff" />
            <rect y="13.2" width="30" height="6.8" fill="#171796" />
            {/* Checkerboard shield badge */}
            <rect x="12" y="5.5" width="6" height="8" fill="#ffffff" stroke="#000" strokeWidth="0.5" />
            <rect x="12" y="5.5" width="3" height="4" fill="#ff0000" />
            <rect x="15" y="9.5" width="3" height="4" fill="#ff0000" />
          </svg>
        );

      case 'AL': // Albanie
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="20" fill="#e41e20" />
            {/* Double headed eagle emblem */}
            <circle cx="15" cy="10" r="4.5" fill="#000000" />
          </svg>
        );

      case 'FI': // Finlande
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="20" fill="#ffffff" />
            <rect x="8" width="4.5" height="20" fill="#003580" />
            <rect y="7.5" width="30" height="5" fill="#003580" />
          </svg>
        );

      case 'ME': // Montenegro
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded shadow-sm border border-yellow-400">
            <rect width="30" height="20" fill="#c40308" />
            <rect x="1" y="1" width="28" height="18" fill="none" stroke="#d4af37" strokeWidth="1" />
            <circle cx="15" cy="10" r="3.5" fill="#d4af37" />
          </svg>
        );

      case 'LV': // Lettonie
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="8" fill="#9e3039" />
            <rect y="8" width="30" height="4" fill="#ffffff" />
            <rect y="12" width="30" height="8" fill="#9e3039" />
          </svg>
        );

      case 'AM': // Armenie
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="6.6" fill="#d90012" />
            <rect y="6.6" width="30" height="6.6" fill="#0033a0" />
            <rect y="13.2" width="30" height="6.8" fill="#f2a800" />
          </svg>
        );

      case 'CY': // Chypre
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded shadow-sm bg-white">
            <rect width="30" height="20" fill="#ffffff" />
            <ellipse cx="15" cy="9" rx="7" ry="4" fill="#d57800" />
            <path d="M 10 16 Q 15 13 20 16" stroke="#4e7037" strokeWidth="1.5" fill="none" />
          </svg>
        );

      case 'GQ': // Guinee Equatoriale
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="6.6" fill="#3e9a00" />
            <rect y="6.6" width="30" height="6.6" fill="#ffffff" />
            <rect y="13.2" width="30" height="6.8" fill="#e32118" />
            <polygon points="0,0 8,10 0,20" fill="#0073ce" />
          </svg>
        );

      case 'ZW': // Zimbabwe
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="3" fill="#319208" />
            <rect y="3" width="30" height="3" fill="#ffd200" />
            <rect y="6" width="30" height="3" fill="#de2010" />
            <rect y="9" width="30" height="3" fill="#000000" />
            <rect y="12" width="30" height="3" fill="#de2010" />
            <rect y="15" width="30" height="3" fill="#ffd200" />
            <rect y="18" width="30" height="2" fill="#319208" />
            <polygon points="0,0 9,10 0,20" fill="#ffffff" />
          </svg>
        );

      case 'MG': // Madagascar
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="10" height="20" fill="#ffffff" />
            <rect x="10" width="20" height="10" fill="#fc3d32" />
            <rect x="10" y="10" width="20" height="10" fill="#007e3a" />
          </svg>
        );

      case 'GW': // Guinee Bissau
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="10" height="20" fill="#ce1126" />
            <rect x="10" width="20" height="10" fill="#fcd116" />
            <rect x="10" y="10" width="20" height="10" fill="#009e49" />
            <circle cx="5" cy="10" r="2.5" fill="#000000" />
          </svg>
        );

      case 'CI': // Cote D ivoire
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="10" height="20" fill="#f77f00" />
            <rect x="10" width="10" height="20" fill="#ffffff" />
            <rect x="20" width="10" height="20" fill="#009a44" />
          </svg>
        );

      case 'GM': // Gambie
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="6" fill="#ce1126" />
            <rect y="6" width="30" height="2" fill="#ffffff" />
            <rect y="8" width="30" height="4" fill="#0c1c8c" />
            <rect y="12" width="30" height="2" fill="#ffffff" />
            <rect y="14" width="30" height="6" fill="#3a7728" />
          </svg>
        );

      case 'CD': // RD Congo
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="20" fill="#007fff" />
            <polygon points="0,17 25,0 30,0 5,20 0,20" fill="#ce1021" />
            <polygon points="0,15 23,0 25,0 0,17" fill="#f7d618" />
            <polygon points="30,3 5,20 7,20 30,5" fill="#f7d618" />
            <polygon points="4,2 5,5 2,3 6,3 3,5" fill="#f7d618" />
          </svg>
        );

      case 'SL': // Sierra Leone
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="6.6" fill="#1eb53a" />
            <rect y="6.6" width="30" height="6.6" fill="#ffffff" />
            <rect y="13.2" width="30" height="6.8" fill="#0072c6" />
          </svg>
        );

      case 'BJ': // Benin
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="12" height="20" fill="#008751" />
            <rect x="12" width="18" height="10" fill="#fcd116" />
            <rect x="12" y="10" width="18" height="10" fill="#e8112d" />
          </svg>
        );

      case 'CF': // Afrique Centrale
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="5" fill="#003082" />
            <rect y="5" width="30" height="5" fill="#ffffff" />
            <rect y="10" width="30" height="5" fill="#289728" />
            <rect y="15" width="30" height="5" fill="#ffce00" />
            <rect x="12.5" width="5" height="20" fill="#d21034" />
          </svg>
        );

      case 'SN': // Senegal
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="10" height="20" fill="#00853f" />
            <rect x="10" width="10" height="20" fill="#fdef42" />
            <rect x="20" width="10" height="20" fill="#e31b23" />
            <polygon points="15,7 16,10 19,10 16.5,12 17.5,15 15,13 12.5,15 13.5,12 11,10 14,10" fill="#00853f" />
          </svg>
        );

      case 'SD': // Soudan
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="6.6" fill="#d21034" />
            <rect y="6.6" width="30" height="6.6" fill="#ffffff" />
            <rect y="13.2" width="30" height="6.8" fill="#000000" />
            <polygon points="0,0 10,10 0,20" fill="#007229" />
          </svg>
        );

      // --- Tunisian National Clubs (المسابقة الوطنية) ---
      case 'EST': // Espérance Sportive de Tunis
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 3 L 25 3 L 25 18 Q 25 28 15 30 Q 5 28 5 18 Z" fill="#dc2626" stroke="#fbbf24" strokeWidth="1.5" />
            <rect x="10" y="3" width="5" height="20" fill="#fbbf24" />
            <rect x="20" y="3" width="5" height="15" fill="#fbbf24" />
          </svg>
        );

      case 'CA': // Club Africain
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#ffffff" stroke="#dc2626" strokeWidth="2" />
            <circle cx="15" cy="15" r="10" fill="#dc2626" />
            <circle cx="16" cy="15" r="5" fill="#ffffff" />
            <circle cx="17.5" cy="15" r="4.2" fill="#dc2626" />
            <polygon points="13.5,13.5 14.5,15 13,16 15,15.5" fill="#ffffff" />
          </svg>
        );

      case 'ESS': // Étoile Sportive du Sahel
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#dc2626" stroke="#ffffff" strokeWidth="1.5" />
            <polygon points="15,4 18,12 26,12 19,17 22,25 15,20 8,25 11,17 4,12 12,12" fill="#ffffff" />
          </svg>
        );

      case 'CSS': // Club Sportif Sfaxien
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 3 L 25 3 L 25 18 Q 25 28 15 30 Q 5 28 5 18 Z" fill="#000000" stroke="#ffffff" strokeWidth="1.5" />
            <rect x="9" y="3" width="4" height="22" fill="#ffffff" />
            <rect x="17" y="3" width="4" height="22" fill="#ffffff" />
          </svg>
        );

      case 'ST': // Stade Tunisien
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 3 L 25 3 L 25 18 Q 25 28 15 30 Q 5 28 5 18 Z" fill="#16a34a" stroke="#dc2626" strokeWidth="2" />
            <rect x="10" y="3" width="5" height="22" fill="#dc2626" />
            <rect x="20" y="3" width="5" height="15" fill="#dc2626" />
          </svg>
        );

      case 'USMO': // Union Sportive Monastirienne
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#1d4ed8" stroke="#ffffff" strokeWidth="2" />
            <text x="15" y="19" fill="#ffffff" fontSize="10" fontWeight="900" textAnchor="middle">USM</text>
          </svg>
        );

      // --- European Clubs from Screenshot ---
      case 'ATM': // Atletico Madrid
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 25 18 Q 25 28 15 30 Q 5 28 5 18 Z" fill="#ffffff" stroke="#2563eb" strokeWidth="1.5" />
            <rect x="8" y="5" width="3" height="20" fill="#dc2626" />
            <rect x="14" y="5" width="3" height="23" fill="#dc2626" />
            <rect x="20" y="5" width="3" height="20" fill="#dc2626" />
            <rect x="5" y="5" width="10" height="9" fill="#1e3a8a" />
          </svg>
        );

      case 'BAY': // Bayern München
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#dc2626" stroke="#2563eb" strokeWidth="2" />
            <circle cx="15" cy="15" r="10" fill="#ffffff" />
            <circle cx="15" cy="15" r="7" fill="#2563eb" />
            <polygon points="12,12 15,10 18,12 15,14" fill="#ffffff" />
            <polygon points="12,16 15,14 18,16 15,18" fill="#ffffff" />
          </svg>
        );

      case 'MUN': // Manchester United
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#dc2626" stroke="#fbbf24" strokeWidth="2" />
            <rect x="5" y="10" width="20" height="10" fill="#fbbf24" rx="2" />
            <circle cx="15" cy="15" r="4" fill="#dc2626" />
          </svg>
        );

      case 'ROM': // AS Roma
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 6 5 L 24 5 L 24 16 Q 24 27 15 29 Q 6 27 6 16 Z" fill="#991b1b" stroke="#f59e0b" strokeWidth="1.5" />
            <rect x="6" y="5" width="18" height="10" fill="#f59e0b" />
            <circle cx="15" cy="10" r="3.5" fill="#991b1b" />
          </svg>
        );

      case 'VIL': // Villarreal
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 25 18 Q 25 28 15 30 Q 5 28 5 18 Z" fill="#facc15" stroke="#1d4ed8" strokeWidth="1.5" />
            <polygon points="10,8 15,18 20,8" fill="#1d4ed8" />
          </svg>
        );

      case 'PSG': // Paris Saint-Germain
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#1e3a8a" stroke="#ffffff" strokeWidth="1.5" />
            <circle cx="15" cy="15" r="11" fill="#ffffff" />
            <polygon points="15,6 12,20 18,20" fill="#dc2626" />
            <ellipse cx="15" cy="16" rx="4" ry="1.5" fill="#ffffff" />
          </svg>
        );

      case 'BAR': // Barcelona
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 6 L 25 6 L 25 18 Q 25 28 15 30 Q 5 28 5 18 Z" fill="#facc15" stroke="#1e3a8a" strokeWidth="1.5" />
            <rect x="5" y="15" width="4" height="12" fill="#991b1b" />
            <rect x="11" y="15" width="4" height="14" fill="#1e3a8a" />
            <rect x="17" y="15" width="4" height="12" fill="#991b1b" />
            <rect x="5" y="6" width="10" height="8" fill="#ffffff" />
            <rect x="9" y="6" width="2" height="8" fill="#dc2626" />
            <rect x="5" y="9" width="10" height="2" fill="#dc2626" />
          </svg>
        );

      case 'AVL': // Aston Villa
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 6 5 L 24 5 L 24 17 Q 24 27 15 29 Q 6 27 6 17 Z" fill="#38bdf8" stroke="#7f1d1d" strokeWidth="2" />
            <polygon points="13,11 17,14 15,19 12,16" fill="#facc15" />
          </svg>
        );

      case 'GAL': // Galatasaray
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#ea580c" stroke="#dc2626" strokeWidth="2" />
            <circle cx="15" cy="15" r="10" fill="#dc2626" />
            <text x="15" y="19" fill="#facc15" fontSize="12" fontWeight="900" textAnchor="middle">GS</text>
          </svg>
        );

      case 'STU': // VfB Stuttgart
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 6 5 L 24 5 L 24 17 Q 24 27 15 29 Q 6 27 6 17 Z" fill="#ffffff" stroke="#dc2626" strokeWidth="2" />
            <rect x="6" y="13" width="18" height="4" fill="#dc2626" />
            <text x="15" y="11" fill="#000000" fontSize="8" fontWeight="bold" textAnchor="middle">VfB</text>
          </svg>
        );

      // --- World & Club World Cup Teams from Latest Screenshot ---
      case 'CHE': // Chelsea
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#034694" stroke="#ffffff" strokeWidth="1.5" />
            <circle cx="15" cy="15" r="10" fill="#ffffff" />
            <circle cx="15" cy="15" r="8" fill="#034694" />
            <path d="M 12 18 Q 15 10 18 12 Q 15 15 13 18 Z" fill="#ffffff" />
          </svg>
        );

      case 'LAFC': // Los Angeles FC
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 25 18 Q 25 28 15 30 Q 5 28 5 18 Z" fill="#000000" stroke="#c59b27" strokeWidth="2" />
            <text x="15" y="19" fill="#c59b27" fontSize="11" fontWeight="900" textAnchor="middle">LA</text>
          </svg>
        );

      case 'FLU': // Fluminense
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 25 18 Q 25 28 15 30 Q 5 28 5 18 Z" fill="#7f1d1d" stroke="#ffffff" strokeWidth="1.5" />
            <polygon points="15,5 25,18 15,30 5,18" fill="#15803d" />
            <text x="15" y="18" fill="#ffffff" fontSize="8" fontWeight="bold" textAnchor="middle">FFC</text>
          </svg>
        );

      case 'BVB': // Borussia Dortmund
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#fde047" stroke="#000000" strokeWidth="2.5" />
            <text x="15" y="17" fill="#000000" fontSize="9" fontWeight="900" textAnchor="middle">BVB</text>
            <text x="15" y="23" fill="#000000" fontSize="7" fontWeight="bold" textAnchor="middle">09</text>
          </svg>
        );

      case 'BOCA': // Boca Juniors
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 25 18 Q 25 28 15 30 Q 5 28 5 18 Z" fill="#1e3a8a" stroke="#facc15" strokeWidth="2" />
            <rect x="5" y="11" width="20" height="8" fill="#facc15" />
            <text x="15" y="17" fill="#1e3a8a" fontSize="8" fontWeight="900" textAnchor="middle">CABJ</text>
          </svg>
        );

      case 'BEN': // Benfica
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#ffffff" stroke="#dc2626" strokeWidth="1.5" />
            <path d="M 5 15 L 25 15 L 20 25 L 10 25 Z" fill="#dc2626" />
            <circle cx="15" cy="10" r="4" fill="#facc15" />
          </svg>
        );

      case 'POL': // Pologne / Poland flag
      case 'PL':
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded shadow-sm border border-white/25">
            <rect width="30" height="10" fill="#ffffff" />
            <rect y="10" width="30" height="10" fill="#dc143c" />
          </svg>
        );

      case 'GEO': // Georgie / Georgia flag
      case 'GE':
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded shadow-sm border border-white/25">
            <rect width="30" height="20" fill="#ffffff" />
            <rect x="13" width="4" height="20" fill="#ff0000" />
            <rect y="8" width="30" height="4" fill="#ff0000" />
            <path d="M6.5 3.5h1.5v1.5h1.5v1.5h-1.5v1.5h-1.5v-1.5h-1.5v-1.5h1.5z M22 3.5h1.5v1.5h1.5v1.5h-1.5v1.5h-1.5v-1.5h-1.5v-1.5h1.5z M6.5 12h1.5v1.5h1.5v1.5h-1.5v1.5h-1.5v-1.5h-1.5v-1.5h1.5z M22 12h1.5v1.5h1.5v1.5h-1.5v1.5h-1.5v-1.5h-1.5v-1.5h1.5z" fill="#ff0000" />
          </svg>
        );

      case 'POR': // Portugal flag
      case 'PT':
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="12" height="20" fill="#006600" />
            <rect x="12" width="18" height="20" fill="#ff0000" />
            <circle cx="12" cy="10" r="4" fill="#ffcc00" />
            <rect x="10.5" y="8" width="3" height="4" rx="1" fill="#ffffff" stroke="#003399" strokeWidth="0.7" />
          </svg>
        );

      case 'DK': // Danemark
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="20" fill="#c60c30" />
            <rect x="9" width="3.5" height="20" fill="#ffffff" />
            <rect y="8.25" width="30" height="3.5" fill="#ffffff" />
          </svg>
        );

      case 'NO': // Norvege
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="20" fill="#ba0c2f" />
            <rect x="8" width="5" height="20" fill="#ffffff" />
            <rect y="7.5" width="30" height="5" fill="#ffffff" />
            <rect x="9.25" width="2.5" height="20" fill="#00205b" />
            <rect y="8.75" width="30" height="2.5" fill="#00205b" />
          </svg>
        );

      case 'WAL': // Wales
      case 'GB-WLS': // Pays de Galles
        return (
          <svg viewBox="0 0 30 20" shapeRendering="geometricPrecision" className="w-full h-full rounded-[3px]">
            <rect width="30" height="10" fill="#ffffff" />
            <rect y="10" width="30" height="10" fill="#00ab39" />
            <path d="M9 13.5 C11 7.5, 16.5 5.5, 21 8 C19.5 10.2, 21.5 11.2, 22.5 13.5 L18 14.2 L15 12 L10.8 14.2 Z" fill="#d30731" />
          </svg>
        );

      case 'GB-NIR': // Irlande du Nord
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded shadow-sm border border-white/25">
            <rect width="30" height="20" fill="#ffffff" />
            <rect x="13" width="4" height="20" fill="#ce1124" />
            <rect y="8" width="30" height="4" fill="#ce1124" />
            <circle cx="15" cy="10" r="3" fill="#ffffff" stroke="#fbbf24" strokeWidth="1" />
            <circle cx="15" cy="10" r="1.4" fill="#ce1124" />
          </svg>
        );

      case 'UA': // Ukraine
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="10" fill="#0057b7" />
            <rect y="10" width="30" height="10" fill="#ffd700" />
          </svg>
        );

      case 'AT': // Autriche
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="6.66" fill="#ed2939" />
            <rect y="6.66" width="30" height="6.68" fill="#ffffff" />
            <rect y="13.34" width="30" height="6.66" fill="#ed2939" />
          </svg>
        );

      case 'IE': // Irlande
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="10" height="20" fill="#169b62" />
            <rect x="10" width="10" height="20" fill="#ffffff" />
            <rect x="20" width="10" height="20" fill="#ff883e" />
          </svg>
        );

      case 'RO': // Roumanie
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="10" height="20" fill="#002b7f" />
            <rect x="10" width="10" height="20" fill="#fcd116" />
            <rect x="20" width="10" height="20" fill="#ce1126" />
          </svg>
        );

      case 'SE': // Suede
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="20" fill="#006aa7" />
            <rect x="9" width="3.5" height="20" fill="#fecc02" />
            <rect y="8.25" width="30" height="3.5" fill="#fecc02" />
          </svg>
        );

      case 'BA': // Bosnie herzegovine
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="20" fill="#002395" />
            <polygon points="8,0 24,0 24,20" fill="#fecb00" />
            <circle cx="8" cy="4" r="1" fill="#ffffff" />
            <circle cx="11" cy="8" r="1" fill="#ffffff" />
            <circle cx="14" cy="12" r="1" fill="#ffffff" />
            <circle cx="17" cy="16" r="1" fill="#ffffff" />
          </svg>
        );

      case 'HU': // Hongrie
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="6.66" fill="#cd2a3e" />
            <rect y="6.66" width="30" height="6.68" fill="#ffffff" />
            <rect y="13.34" width="30" height="6.66" fill="#436f4d" />
          </svg>
        );

      case 'UG': // Ouganda
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="3.33" fill="#000000" />
            <rect y="3.33" width="30" height="3.33" fill="#fcdc04" />
            <rect y="6.66" width="30" height="3.34" fill="#d90000" />
            <rect y="10" width="30" height="3.33" fill="#000000" />
            <rect y="13.33" width="30" height="3.33" fill="#fcdc04" />
            <rect y="16.66" width="30" height="3.34" fill="#d90000" />
            <circle cx="15" cy="10" r="3.4" fill="#ffffff" />
            <circle cx="15" cy="10" r="1.5" fill="#d90000" />
          </svg>
        );

      case 'BW': // Botswana
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="20" fill="#6da9d2" />
            <rect y="7" width="30" height="6" fill="#ffffff" />
            <rect y="8" width="30" height="4" fill="#000000" />
          </svg>
        );

      case 'DZ': // Algerie
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded shadow-sm border border-white/25">
            <rect width="15" height="20" fill="#006233" />
            <rect x="15" width="15" height="20" fill="#ffffff" />
            <circle cx="15" cy="10" r="4" fill="#d21034" />
            <circle cx="16.2" cy="10" r="3.2" fill="#ffffff" />
            <polygon points="16.5,8.7 17,9.7 18,9.7 17.2,10.3 17.5,11.3 16.5,10.7 15.5,11.3 15.8,10.3 15,9.7 16,9.7" fill="#d21034" />
          </svg>
        );

      case 'TG': // Togo
        return (
          <svg viewBox="0 0 30 20" className="w-full h-full rounded-[3px]">
            <rect width="30" height="4" fill="#006a4e" />
            <rect y="4" width="30" height="4" fill="#ffce00" />
            <rect y="8" width="30" height="4" fill="#006a4e" />
            <rect y="12" width="30" height="4" fill="#ffce00" />
            <rect y="16" width="30" height="4" fill="#006a4e" />
            <rect width="12" height="12" fill="#d21034" />
            <polygon points="6,3 7,5.5 9.5,5.5 7.5,7 8.2,9.5 6,8 3.8,9.5 4.5,7 2.5,5.5 5,5.5" fill="#ffffff" />
          </svg>
        );

      // --- International & European Clubs (Tirage 932 / 931 / 930) ---
      case 'LIV': // Liverpool FC
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 6 4 L 24 4 L 24 17 Q 24 27 15 29 Q 6 27 6 17 Z" fill="#c8102e" stroke="#f6eb61" strokeWidth="1.5" />
            <rect x="8" y="6" width="14" height="4" fill="#00b2a9" rx="1" />
            <path d="M 15 11 C 18 13 18 19 15 24 C 12 19 12 13 15 11 Z" fill="#f6eb61" />
            <text x="15" y="20" fill="#ffffff" fontSize="6" fontWeight="900" textAnchor="middle">LFC</text>
          </svg>
        );

      case 'MCI': // Manchester City
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#6cabdd" stroke="#ffffff" strokeWidth="1.8" />
            <circle cx="15" cy="15" r="10.5" fill="#1c2c5b" stroke="#ffc659" strokeWidth="1" />
            <path d="M 10 15 L 15 10 L 20 15 L 15 21 Z" fill="#6cabdd" />
            <text x="15" y="17" fill="#ffffff" fontSize="6" fontWeight="900" textAnchor="middle">MC</text>
          </svg>
        );

      case 'BHA': // Brighton & Hove Albion
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#0057b8" stroke="#ffffff" strokeWidth="1.8" />
            <circle cx="15" cy="15" r="10" fill="#ffffff" />
            <path d="M 8 15 Q 15 10 22 15 Q 15 14 8 15 Z" fill="#0057b8" />
            <text x="15" y="21" fill="#0057b8" fontSize="6" fontWeight="900" textAnchor="middle">BHA</text>
          </svg>
        );

      case 'RMA': // Real Madrid
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 10 3 L 20 3 L 18 7 L 12 7 Z" fill="#febe10" />
            <circle cx="15" cy="17" r="11" fill="#ffffff" stroke="#febe10" strokeWidth="2" />
            <path d="M 7 10 L 23 24" stroke="#00529f" strokeWidth="3.5" />
            <text x="15" y="19" fill="#00529f" fontSize="7" fontWeight="900" textAnchor="middle">RM</text>
          </svg>
        );

      case 'OSA': // CA Osasuna
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 6 5 L 24 5 L 24 18 Q 24 28 15 29 Q 6 28 6 18 Z" fill="#d91a21" stroke="#0a2540" strokeWidth="2" />
            <rect x="6" y="5" width="18" height="8" fill="#0a2540" />
            <circle cx="15" cy="18" r="4" fill="#fbbf24" />
          </svg>
        );

      case 'ALA': // Deportivo Alavés
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 22 21 L 15 29 L 8 21 Z" fill="#0053a0" stroke="#ffffff" strokeWidth="1.5" />
            <rect x="12" y="5" width="6" height="22" fill="#ffffff" />
            <text x="15" y="16" fill="#0053a0" fontSize="6.5" fontWeight="900" textAnchor="middle">DA</text>
          </svg>
        );

      case 'JUV': // Juventus
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <rect x="4" y="4" width="22" height="22" rx="4" fill="#ffffff" stroke="#000000" strokeWidth="1.5" />
            <rect x="8" y="4" width="4" height="22" fill="#000000" />
            <rect x="18" y="4" width="4" height="22" fill="#000000" />
            <rect x="4" y="11" width="22" height="8" fill="#000000" />
            <text x="15" y="17.5" fill="#ffffff" fontSize="7" fontWeight="900" textAnchor="middle">JUV</text>
          </svg>
        );

      case 'TOR': // Torino FC
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 4 L 25 4 L 24 19 Q 21 27 15 29 Q 9 27 6 19 Z" fill="#8b1e2b" stroke="#ffffff" strokeWidth="1.5" />
            <text x="15" y="18" fill="#ffffff" fontSize="7.5" fontWeight="900" textAnchor="middle">TOR</text>
          </svg>
        );

      case 'MIL': // AC Milan
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <ellipse cx="15" cy="15" rx="10" ry="13.5" fill="#ffffff" stroke="#fb090b" strokeWidth="2" />
            <rect x="7" y="4" width="8" height="22" fill="#000000" />
            <rect x="10" y="4" width="2.5" height="22" fill="#fb090b" />
            <rect x="15" y="13.5" width="8" height="3" fill="#fb090b" />
            <rect x="17.5" y="4" width="3" height="22" fill="#fb090b" />
          </svg>
        );

      case 'CAG': // Cagliari
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 23 19 Q 20 27 15 29 Q 10 27 7 19 Z" fill="#002350" stroke="#ffffff" strokeWidth="1.5" />
            <path d="M 15 5 L 25 5 L 23 19 Q 20 27 15 29 Z" fill="#b31b2c" />
            <text x="15" y="17" fill="#ffffff" fontSize="6.5" fontWeight="900" textAnchor="middle">CAG</text>
          </svg>
        );

      case 'STP': // FC St. Pauli
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#624637" stroke="#ffffff" strokeWidth="1.8" />
            <circle cx="15" cy="15" r="9" fill="#ffffff" />
            <text x="15" y="17.5" fill="#624637" fontSize="6.5" fontWeight="900" textAnchor="middle">FCSP</text>
          </svg>
        );

      case 'M05': // Mainz 05
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#c3141e" stroke="#ffffff" strokeWidth="1.8" />
            <text x="15" y="18.5" fill="#ffffff" fontSize="9.5" fontWeight="900" textAnchor="middle">05</text>
          </svg>
        );

      case 'ANG': // Angers SCO
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 6 4 L 24 4 L 24 18 Q 24 27 15 29 Q 6 27 6 18 Z" fill="#111111" stroke="#d4af37" strokeWidth="1.6" />
            <rect x="11" y="4" width="3" height="23" fill="#ffffff" />
            <rect x="16" y="4" width="3" height="23" fill="#ffffff" />
            <text x="15" y="18" fill="#d4af37" fontSize="6.5" fontWeight="900" textAnchor="middle">SCO</text>
          </svg>
        );

      case 'MON': // AS Monaco
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 6 5 L 24 5 L 24 18 Q 24 27 15 29 Q 6 27 6 18 Z" fill="#ffffff" stroke="#d4af37" strokeWidth="1.8" />
            <path d="M 6 5 L 24 5 L 6 22 Z" fill="#e51b22" />
            <text x="16" y="21" fill="#e51b22" fontSize="6" fontWeight="900" textAnchor="middle">ASM</text>
          </svg>
        );

      case 'STR': // RC Strasbourg
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#009ee0" stroke="#ffffff" strokeWidth="1.8" />
            <path d="M 7 15 L 15 7 L 23 15 L 15 23 Z" fill="#ffffff" />
            <text x="15" y="17.5" fill="#009ee0" fontSize="6" fontWeight="900" textAnchor="middle">RCS</text>
          </svg>
        );

      case 'INT': // Inter Milan
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#000000" stroke="#0068a8" strokeWidth="2.5" />
            <circle cx="15" cy="15" r="10.5" fill="#0068a8" stroke="#ffffff" strokeWidth="1" />
            <text x="15" y="18.5" fill="#ffffff" fontSize="8.5" fontWeight="900" textAnchor="middle">IM</text>
          </svg>
        );

      case 'NAP': // SSC Napoli
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#003c82" stroke="#ffffff" strokeWidth="1.8" />
            <circle cx="15" cy="15" r="11" fill="#12a0d7" />
            <text x="15" y="19.5" fill="#ffffff" fontSize="11" fontWeight="900" textAnchor="middle">N</text>
          </svg>
        );

      case 'ARS': // Arsenal
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 24 18 Q 21 27 15 29 Q 9 27 6 18 Z" fill="#ef0107" stroke="#db9b0d" strokeWidth="1.8" />
            <rect x="8" y="15" width="14" height="3.5" fill="#ffffff" rx="1" />
            <circle cx="10" cy="19" r="2.2" fill="#db9b0d" />
            <text x="15" y="12.5" fill="#ffffff" fontSize="6" fontWeight="900" textAnchor="middle">ARS</text>
          </svg>
        );

      case 'RSO': // Real Sociedad
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="13.5" fill="#0067b1" stroke="#ffffff" strokeWidth="1.8" />
            <rect x="9" y="4" width="4" height="22" fill="#ffffff" />
            <rect x="17" y="4" width="4" height="22" fill="#ffffff" />
            <circle cx="15" cy="15" r="4" fill="#fbbf24" />
          </svg>
        );

      case 'RSB': // Red Star Belgrade (Crvena Zvezda)
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 24 18 Q 21 27 15 29 Q 9 27 6 18 Z" fill="#d91a21" stroke="#ffffff" strokeWidth="1.5" />
            <rect x="11" y="5" width="4" height="22" fill="#ffffff" />
            <polygon points="15,9 16.5,13 20.5,13 17.2,15.5 18.5,19.5 15,17 11.5,19.5 12.8,15.5 9.5,13 13.5,13" fill="#ffffff" />
          </svg>
        );

      case 'ATA': // Atalanta BC
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <ellipse cx="15" cy="15" rx="11" ry="13.5" fill="#1e71b8" stroke="#ffffff" strokeWidth="1.8" />
            <rect x="15" y="3" width="9" height="24" fill="#000000" />
            <circle cx="15" cy="15" r="5" fill="#ffffff" />
            <text x="15" y="17.5" fill="#1e71b8" fontSize="6" fontWeight="900" textAnchor="middle">ATA</text>
          </svg>
        );

      case 'FEY': // Feyenoord
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#ffffff" stroke="#d4af37" strokeWidth="1.8" />
            <path d="M 1 15 A 14 14 0 0 1 15 1 L 15 29 A 14 14 0 0 1 1 15 Z" fill="#dc1f26" />
            <circle cx="15" cy="15" r="5.5" fill="#000000" stroke="#ffffff" strokeWidth="1" />
            <text x="15" y="17.5" fill="#ffffff" fontSize="7" fontWeight="900" textAnchor="middle">F</text>
          </svg>
        );

      case 'SAL': // RB Salzburg
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 24 18 Q 21 27 15 29 Q 9 27 6 18 Z" fill="#ffffff" stroke="#db0a40" strokeWidth="2" />
            <circle cx="15" cy="14" r="5" fill="#fbbf24" />
            <rect x="7" y="12" width="16" height="4" fill="#db0a40" />
          </svg>
        );

      case 'SPA': // Sparta Prague
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 24 18 Q 21 27 15 29 Q 9 27 6 18 Z" fill="#9c1c23" stroke="#facc15" strokeWidth="1.8" />
            <text x="15" y="19" fill="#ffffff" fontSize="11" fontWeight="900" textAnchor="middle">S</text>
          </svg>
        );

      case 'BRE': // Stade Brestois
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 24 18 Q 21 27 15 29 Q 9 27 6 18 Z" fill="#d91a21" stroke="#ffffff" strokeWidth="1.8" />
            <text x="15" y="17.5" fill="#ffffff" fontSize="6.5" fontWeight="900" textAnchor="middle">SB29</text>
          </svg>
        );

      case 'LAZ': // SS Lazio
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 24 18 Q 21 27 15 29 Q 9 27 6 18 Z" fill="#87d8f7" stroke="#ffffff" strokeWidth="1.8" />
            <path d="M 6 11 L 15 7 L 24 11 L 15 14 Z" fill="#d4af37" />
            <text x="15" y="21" fill="#003366" fontSize="6" fontWeight="900" textAnchor="middle">LAZ</text>
          </svg>
        );

      case 'POR_C': // FC Porto
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 6 5 L 24 5 L 24 18 Q 24 27 15 29 Q 6 27 6 18 Z" fill="#00428c" stroke="#ffffff" strokeWidth="1.8" />
            <rect x="11" y="5" width="3" height="23" fill="#ffffff" />
            <rect x="16" y="5" width="3" height="23" fill="#ffffff" />
            <text x="15" y="18" fill="#fbbf24" fontSize="6.5" fontWeight="900" textAnchor="middle">FCP</text>
          </svg>
        );

      case 'PAO': // PAOK Thessaloniki
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#111111" stroke="#ffffff" strokeWidth="1.8" />
            <rect x="12" y="3" width="6" height="24" fill="#ffffff" />
            <circle cx="15" cy="15" r="6" fill="#111111" stroke="#d4af37" strokeWidth="1" />
            <text x="15" y="17" fill="#ffffff" fontSize="5.5" fontWeight="900" textAnchor="middle">PAOK</text>
          </svg>
        );

      case 'TOT': // Tottenham Hotspur
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#ffffff" stroke="#132257" strokeWidth="2.2" />
            <circle cx="15" cy="20" r="4" fill="#132257" />
            <text x="15" y="13" fill="#132257" fontSize="7" fontWeight="900" textAnchor="middle">THFC</text>
          </svg>
        );

      case 'OLY': // Olympiacos
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#dd1c24" stroke="#ffffff" strokeWidth="2" />
            <rect x="10" y="3" width="3" height="24" fill="#ffffff" />
            <rect x="17" y="3" width="3" height="24" fill="#ffffff" />
            <circle cx="15" cy="15" r="5" fill="#dd1c24" stroke="#facc15" strokeWidth="1" />
          </svg>
        );

      case 'RAN': // Rangers FC
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#1b458f" stroke="#ffffff" strokeWidth="1.8" />
            <text x="15" y="18" fill="#ffffff" fontSize="7.5" fontWeight="900" textAnchor="middle">RFC</text>
          </svg>
        );

      case 'AJA': // AFC Ajax
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#ffffff" stroke="#d2122e" strokeWidth="2.5" />
            <rect x="11" y="4" width="8" height="22" fill="#d2122e" />
            <text x="15" y="18" fill="#ffffff" fontSize="6.5" fontWeight="900" textAnchor="middle">AJA</text>
          </svg>
        );

      case 'PLZ': // Viktoria Plzeň
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#003d8f" stroke="#d71920" strokeWidth="2.5" />
            <text x="15" y="18" fill="#ffffff" fontSize="7" fontWeight="900" textAnchor="middle">PLZ</text>
          </svg>
        );

      case 'NOA': // FC Noah
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#111827" stroke="#f59e0b" strokeWidth="2" />
            <text x="15" y="18" fill="#fbbf24" fontSize="7" fontWeight="900" textAnchor="middle">NOAH</text>
          </svg>
        );

      case 'LEV': // Bayer Leverkusen
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#e32221" stroke="#000000" strokeWidth="2" />
            <rect x="4" y="11" width="22" height="8" fill="#000000" />
            <text x="15" y="17.5" fill="#ffffff" fontSize="6.5" fontWeight="900" textAnchor="middle">B04</text>
          </svg>
        );

      case 'SCP': // Sporting CP
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 6 4 L 24 4 L 24 18 Q 24 27 15 29 Q 6 27 6 18 Z" fill="#008057" stroke="#ffffff" strokeWidth="1.8" />
            <rect x="6" y="12" width="18" height="3.5" fill="#ffffff" />
            <rect x="6" y="19" width="18" height="3.5" fill="#ffffff" />
            <text x="15" y="10.5" fill="#fbbf24" fontSize="6.5" fontWeight="900" textAnchor="middle">SCP</text>
          </svg>
        );

      case 'LIL': // Lille OSC
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 21 23 L 15 29 L 9 23 Z" fill="#e01e13" stroke="#1e2a4a" strokeWidth="2" />
            <text x="15" y="17.5" fill="#ffffff" fontSize="6.5" fontWeight="900" textAnchor="middle">LOSC</text>
          </svg>
        );

      case 'CEL': // Celtic FC
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#018749" stroke="#ffffff" strokeWidth="2" />
            <circle cx="15" cy="15" r="9" fill="#ffffff" />
            <circle cx="15" cy="15" r="5" fill="#018749" />
          </svg>
        );

      case 'RBL': // RB Leipzig
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#ffffff" stroke="#dd0741" strokeWidth="2" />
            <circle cx="15" cy="15" r="5" fill="#fbbf24" />
            <text x="15" y="18" fill="#dd0741" fontSize="6.5" fontWeight="900" textAnchor="middle">RBL</text>
          </svg>
        );

      case 'STG': // Sturm Graz
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#111111" stroke="#ffffff" strokeWidth="2" />
            <rect x="4" y="12" width="22" height="6" fill="#ffffff" />
            <text x="15" y="17" fill="#111111" fontSize="6" fontWeight="900" textAnchor="middle">STG</text>
          </svg>
        );

      case 'BOL': // Bologna FC
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <ellipse cx="15" cy="15" rx="10.5" ry="13.5" fill="#1a2f48" stroke="#ffffff" strokeWidth="1.6" />
            <rect x="8" y="4" width="4" height="22" fill="#a21c26" />
            <rect x="18" y="4" width="4" height="22" fill="#a21c26" />
            <text x="15" y="17.5" fill="#ffffff" fontSize="6.5" fontWeight="900" textAnchor="middle">BFC</text>
          </svg>
        );

      case 'PSV': // PSV Eindhoven
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 23 19 Q 20 27 15 29 Q 10 27 7 19 Z" fill="#ed1c24" stroke="#ffffff" strokeWidth="1.8" />
            <rect x="5" y="12" width="20" height="4" fill="#ffffff" />
            <text x="15" y="10" fill="#ffffff" fontSize="6.5" fontWeight="900" textAnchor="middle">PSV</text>
          </svg>
        );

      case 'GIR': // Girona FC
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#cd2534" stroke="#ffffff" strokeWidth="2" />
            <rect x="9" y="4" width="4" height="22" fill="#ffffff" />
            <rect x="17" y="4" width="4" height="22" fill="#ffffff" />
            <circle cx="15" cy="15" r="4.5" fill="#fbbf24" />
          </svg>
        );

      case 'SLO': // Slovan Bratislava
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#0088ce" stroke="#ffffff" strokeWidth="2" />
            <text x="15" y="18" fill="#ffffff" fontSize="6.5" fontWeight="900" textAnchor="middle">ŠKS</text>
          </svg>
        );

      case 'DZG': // Dinamo Zagreb
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#004a99" stroke="#ffffff" strokeWidth="2" />
            <path d="M 7 15 L 15 7 L 23 15 L 15 23 Z" fill="#dc2626" />
            <text x="15" y="18" fill="#ffffff" fontSize="8" fontWeight="900" textAnchor="middle">d</text>
          </svg>
        );

      case 'SEV': // Sevilla FC
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 23 19 Q 20 27 15 29 Q 10 27 7 19 Z" fill="#ffffff" stroke="#d4001c" strokeWidth="2" />
            <rect x="11" y="5" width="3" height="22" fill="#d4001c" />
            <rect x="16" y="5" width="3" height="22" fill="#d4001c" />
            <text x="15" y="17" fill="#000000" fontSize="6.5" fontWeight="900" textAnchor="middle">SFC</text>
          </svg>
        );

      case 'NEW': // Newcastle United
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 24 18 Q 21 27 15 29 Q 9 27 6 18 Z" fill="#111111" stroke="#d4af37" strokeWidth="1.8" />
            <rect x="10" y="5" width="4" height="22" fill="#ffffff" />
            <rect x="16" y="5" width="4" height="22" fill="#ffffff" />
            <text x="15" y="18" fill="#d4af37" fontSize="6" fontWeight="900" textAnchor="middle">NUFC</text>
          </svg>
        );

      case 'FIO': // ACF Fiorentina
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 15 3 L 26 15 L 15 27 L 4 15 Z" fill="#5e2d91" stroke="#ffffff" strokeWidth="1.8" />
            <path d="M 15 8 L 19 15 L 15 22 L 11 15 Z" fill="#e11d48" />
          </svg>
        );

      case 'LYO': // Olympique Lyonnais
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 23 19 Q 20 27 15 29 Q 10 27 7 19 Z" fill="#ffffff" stroke="#da291c" strokeWidth="2" />
            <rect x="12" y="5" width="6" height="22" fill="#1b3f8b" />
            <text x="15" y="17.5" fill="#fbbf24" fontSize="7" fontWeight="900" textAnchor="middle">OL</text>
          </svg>
        );

      case 'OM': // Olympique de Marseille
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="14" fill="#ffffff" stroke="#009de0" strokeWidth="2" />
            <text x="15" y="19" fill="#009de0" fontSize="10" fontWeight="900" textAnchor="middle">OM</text>
          </svg>
        );

      // --- Spanish Clubs in Concours 934 ---
      case 'OVI': // Real Oviedo
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 6 5 L 24 5 L 23 19 Q 20 27 15 29 Q 10 27 7 19 Z" fill="#004c99" stroke="#fbbf24" strokeWidth="1.8" />
            <path d="M 15 9 L 15 21 M 10 14 L 20 14" stroke="#fbbf24" strokeWidth="2.5" strokeLinecap="round" />
            <rect x="11" y="3" width="8" height="2.5" rx="1" fill="#fbbf24" />
          </svg>
        );

      case 'MAL': // RCD Mallorca
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <ellipse cx="15" cy="16" rx="10" ry="12" fill="#e20613" stroke="#111111" strokeWidth="2" />
            <rect x="10" y="9" width="10" height="14" fill="#111111" rx="2" />
            <rect x="10" y="2" width="10" height="3.5" rx="1" fill="#fbbf24" />
            <text x="15" y="18" fill="#fbbf24" fontSize="6.5" fontWeight="900" textAnchor="middle">RCD</text>
          </svg>
        );

      case 'COR': // Cordoba CF
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 23 19 Q 20 27 15 29 Q 10 27 7 19 Z" fill="#ffffff" stroke="#008a43" strokeWidth="2" />
            <rect x="9" y="5" width="4" height="21" fill="#008a43" />
            <rect x="17" y="5" width="4" height="21" fill="#008a43" />
            <circle cx="15" cy="15" r="4" fill="#fbbf24" />
          </svg>
        );

      case 'RSOB': // Real Sociedad B
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <circle cx="15" cy="15" r="13.5" fill="#0067b1" stroke="#ffffff" strokeWidth="1.8" />
            <rect x="9" y="4" width="4" height="22" fill="#ffffff" />
            <rect x="17" y="4" width="4" height="22" fill="#ffffff" />
            <circle cx="15" cy="15" r="5" fill="#fbbf24" />
            <text x="15" y="17.5" fill="#003366" fontSize="7" fontWeight="900" textAnchor="middle">B</text>
          </svg>
        );

      case 'GIJ': // Sporting Gijon
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 6 6 L 24 6 L 22 20 Q 19 27 15 29 Q 11 27 8 20 Z" fill="#ffffff" stroke="#d4001c" strokeWidth="1.8" />
            <rect x="9" y="6" width="3" height="20" fill="#d4001c" />
            <rect x="14" y="6" width="3" height="21" fill="#d4001c" />
            <rect x="19" y="6" width="3" height="20" fill="#d4001c" />
            <rect x="10" y="2" width="10" height="3.5" rx="1" fill="#fbbf24" />
          </svg>
        );

      case 'ALM': // UD Almeria
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 15 28 Z" fill="#ed1c24" stroke="#ffffff" strokeWidth="1.8" />
            <rect x="12" y="6" width="6" height="12" fill="#ffffff" />
            <text x="15" y="14" fill="#ed1c24" fontSize="6" fontWeight="900" textAnchor="middle">UDA</text>
          </svg>
        );

      case 'AND': // FC Andorra
        return (
          <svg viewBox="0 0 30 30" className="w-full h-full">
            <path d="M 6 5 L 24 5 L 23 19 Q 20 27 15 29 Q 10 27 7 19 Z" fill="#1e3a8a" stroke="#fbbf24" strokeWidth="1.8" />
            <rect x="11" y="5" width="8" height="22" fill="#fbbf24" />
            <rect x="18" y="5" width="5" height="20" fill="#dc2626" />
            <text x="15" y="17.5" fill="#111827" fontSize="6" fontWeight="900" textAnchor="middle">FCA</text>
          </svg>
        );

      // --- Concours 936 National Teams & Major World/European/Spanish Crests ---
      case 'XK': // Kosovo
        return (
          <svg viewBox="0 0 30 20" shapeRendering="geometricPrecision" className="w-full h-full rounded-[3px]">
            <rect width="30" height="20" fill="#244aa5" />
            <circle cx="10" cy="4.2" r="0.85" fill="#ffffff" />
            <circle cx="12.5" cy="3.7" r="0.85" fill="#ffffff" />
            <circle cx="15" cy="3.5" r="0.85" fill="#ffffff" />
            <circle cx="17.5" cy="3.7" r="0.85" fill="#ffffff" />
            <circle cx="20" cy="4.2" r="0.85" fill="#ffffff" />
            <polygon points="15,6.5 19.5,11 16,16.5 11.5,13.5 11.5,9.5" fill="#d0a650" />
          </svg>
        );

      case 'CG': // Congo
        return (
          <svg viewBox="0 0 30 20" shapeRendering="geometricPrecision" className="w-full h-full rounded-[3px]">
            <rect width="30" height="20" fill="#009543" />
            <polygon points="20,0 30,0 10,20 0,20" fill="#fbde4a" />
            <polygon points="30,0 30,20 10,20" fill="#dc241f" />
          </svg>
        );

      case 'KM': // Comoros
        return (
          <svg viewBox="0 0 30 20" shapeRendering="geometricPrecision" className="w-full h-full rounded-[3px]">
            <rect width="30" height="5" fill="#ffc61e" />
            <rect y="5" width="30" height="5" fill="#ffffff" />
            <rect y="10" width="30" height="5" fill="#ce1126" />
            <rect y="15" width="30" height="5" fill="#3a75c4" />
            <polygon points="0,0 13,10 0,20" fill="#3d8e33" />
            <circle cx="4.8" cy="10" r="3" fill="#ffffff" />
            <circle cx="5.8" cy="10" r="2.6" fill="#3d8e33" />
          </svg>
        );

      case 'MR': // Mauritania
        return (
          <svg viewBox="0 0 30 20" shapeRendering="geometricPrecision" className="w-full h-full rounded-[3px]">
            <rect width="30" height="3.2" fill="#d01c1f" />
            <rect y="3.2" width="30" height="13.6" fill="#00a95c" />
            <rect y="16.8" width="30" height="3.2" fill="#d01c1f" />
            <circle cx="15" cy="10.2" r="4.2" fill="#ffd700" />
            <circle cx="15" cy="8.7" r="3.7" fill="#00a95c" />
            <polygon points="15,6.2 15.7,8 17.5,8 16,9 16.5,10.6 15,9.6 13.5,10.6 14,9 12.5,8 14.3,8" fill="#ffd700" />
          </svg>
        );

      case 'BF': // Burkina Faso
        return (
          <svg viewBox="0 0 30 20" shapeRendering="geometricPrecision" className="w-full h-full rounded-[3px]">
            <rect width="30" height="10" fill="#ef2b2d" />
            <rect y="10" width="30" height="10" fill="#009e49" />
            <polygon points="15,6.2 16,9 19,9 16.6,10.7 17.5,13.5 15,11.8 12.5,13.5 13.4,10.7 11,9 14,9" fill="#fcd116" />
          </svg>
        );

      case 'RW': // Rwanda
        return (
          <svg viewBox="0 0 30 20" shapeRendering="geometricPrecision" className="w-full h-full rounded-[3px]">
            <rect width="30" height="10" fill="#00a1de" />
            <rect y="10" width="30" height="5" fill="#fad201" />
            <rect y="15" width="30" height="5" fill="#20603d" />
            <circle cx="23.5" cy="5" r="2.6" fill="#e5be01" />
          </svg>
        );

      case 'ML': // Mali
        return (
          <svg viewBox="0 0 30 20" shapeRendering="geometricPrecision" className="w-full h-full rounded-[3px]">
            <rect width="10" height="20" fill="#14b53a" />
            <rect x="10" width="10" height="20" fill="#fcd116" />
            <rect x="20" width="10" height="20" fill="#ce1126" />
          </svg>
        );

      case 'LR': // Liberia
        return (
          <svg viewBox="0 0 30 20" shapeRendering="geometricPrecision" className="w-full h-full rounded-[3px]">
            <rect width="30" height="20" fill="#ffffff" />
            <rect y="0" width="30" height="2.8" fill="#bf0a30" />
            <rect y="5.6" width="30" height="2.8" fill="#bf0a30" />
            <rect y="11.2" width="30" height="2.8" fill="#bf0a30" />
            <rect y="16.8" width="30" height="3.2" fill="#bf0a30" />
            <rect width="11" height="11" fill="#002868" />
            <polygon points="5.5,2.7 6.3,4.9 8.6,4.9 6.7,6.2 7.4,8.4 5.5,7.1 3.6,8.4 4.3,6.2 2.4,4.9 4.7,4.9" fill="#ffffff" />
          </svg>
        );

      case 'CV': // Cape Verde
        return (
          <svg viewBox="0 0 30 20" shapeRendering="geometricPrecision" className="w-full h-full rounded-[3px]">
            <rect width="30" height="20" fill="#003893" />
            <rect y="10.5" width="30" height="4.2" fill="#ffffff" />
            <rect y="11.9" width="30" height="1.5" fill="#cf2027" />
            <circle cx="11" cy="12.6" r="4.5" fill="none" stroke="#f7d116" strokeWidth="1.2" strokeDasharray="1.1 1.4" />
          </svg>
        );

      case 'NE': // Niger
        return (
          <svg viewBox="0 0 30 20" shapeRendering="geometricPrecision" className="w-full h-full rounded-[3px]">
            <rect width="30" height="6.66" fill="#e05206" />
            <rect y="6.66" width="30" height="6.68" fill="#ffffff" />
            <rect y="13.34" width="30" height="6.66" fill="#0db02b" />
            <circle cx="15" cy="10" r="2.7" fill="#e05206" />
          </svg>
        );

      case 'MA': // Morocco (المغرب)
        return (
          <svg viewBox="0 0 30 20" shapeRendering="geometricPrecision" className="w-full h-full rounded-[3px]">
            <rect width="30" height="20" fill="#c1272d" />
            <polygon
              points="15,5 16.4,9.2 20.8,9.2 17.2,11.7 18.6,15.8 15,13.3 11.4,15.8 12.8,11.7 9.2,9.2 13.6,9.2"
              fill="none"
              stroke="#006233"
              strokeWidth="1.35"
            />
          </svg>
        );

      case 'BY': // Belarus
        return (
          <svg viewBox="0 0 30 20" shapeRendering="geometricPrecision" className="w-full h-full rounded-[3px]">
            <rect width="30" height="13.4" fill="#c8313e" />
            <rect y="13.4" width="30" height="6.6" fill="#4aa657" />
            <rect width="4.5" height="20" fill="#ffffff" />
            <rect x="1.2" y="2" width="2" height="16" fill="#c8313e" />
          </svg>
        );

      case 'TN': // Tunisia
        return (
          <svg viewBox="0 0 30 20" shapeRendering="geometricPrecision" className="w-full h-full rounded-[3px]">
            <rect width="30" height="20" fill="#e70013" />
            <circle cx="15" cy="10" r="5.5" fill="#ffffff" />
            <circle cx="15.8" cy="10" r="3.9" fill="#e70013" />
            <circle cx="16.8" cy="10" r="3.1" fill="#ffffff" />
            <polygon points="17.2,8.1 17.8,9.5 19.2,9.5 18.1,10.3 18.5,11.7 17.2,10.9 15.9,11.7 16.3,10.3 15.2,9.5 16.6,9.5" fill="#e70013" />
          </svg>
        );

      case 'EG': // Egypt
        return (
          <svg viewBox="0 0 30 20" shapeRendering="geometricPrecision" className="w-full h-full rounded-[3px]">
            <rect width="30" height="6.66" fill="#ce1126" />
            <rect y="6.66" width="30" height="6.68" fill="#ffffff" />
            <rect y="13.34" width="30" height="6.66" fill="#000000" />
            <circle cx="15" cy="10" r="2.2" fill="#c09300" />
          </svg>
        );

      case 'DE': // Germany
        return (
          <svg viewBox="0 0 30 20" shapeRendering="geometricPrecision" className="w-full h-full rounded-[3px]">
            <rect width="30" height="6.66" fill="#000000" />
            <rect y="6.66" width="30" height="6.68" fill="#dd0000" />
            <rect y="13.34" width="30" height="6.66" fill="#ffce00" />
          </svg>
        );

      case 'NL': // Netherlands
        return (
          <svg viewBox="0 0 30 20" shapeRendering="geometricPrecision" className="w-full h-full rounded-[3px]">
            <rect width="30" height="6.66" fill="#ae1c28" />
            <rect y="6.66" width="30" height="6.68" fill="#ffffff" />
            <rect y="13.34" width="30" height="6.66" fill="#21468b" />
          </svg>
        );

      case 'CH': // Switzerland
        return (
          <svg viewBox="0 0 30 20" shapeRendering="geometricPrecision" className="w-full h-full rounded-[3px]">
            <rect width="30" height="20" fill="#ff0000" />
            <rect x="13" y="4" width="4" height="12" fill="#ffffff" />
            <rect x="9" y="8" width="12" height="4" fill="#ffffff" />
          </svg>
        );

      case 'GR': // Greece
        return (
          <svg viewBox="0 0 30 20" shapeRendering="geometricPrecision" className="w-full h-full rounded-[3px]">
            <rect width="30" height="20" fill="#0d5eaf" />
            <rect y="2.2" width="30" height="2.2" fill="#ffffff" />
            <rect y="6.6" width="30" height="2.2" fill="#ffffff" />
            <rect y="11" width="30" height="2.2" fill="#ffffff" />
            <rect y="15.4" width="30" height="2.2" fill="#ffffff" />
            <rect width="11" height="11" fill="#0d5eaf" />
            <rect x="4.5" width="2" height="11" fill="#ffffff" />
            <rect y="4.5" width="11" height="2" fill="#ffffff" />
          </svg>
        );

      case 'GB-SCT': // Scotland
        return (
          <svg viewBox="0 0 30 20" shapeRendering="geometricPrecision" className="w-full h-full rounded-[3px]">
            <rect width="30" height="20" fill="#005eb8" />
            <line x1="0" y1="0" x2="30" y2="20" stroke="#ffffff" strokeWidth="3.2" />
            <line x1="30" y1="0" x2="0" y2="20" stroke="#ffffff" strokeWidth="3.2" />
          </svg>
        );

      case 'GRA': // Granada CF
        return (
          <svg viewBox="0 0 30 30" shapeRendering="geometricPrecision" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 24 18 Q 21 27 15 29 Q 9 27 6 18 Z" fill="#ffffff" stroke="#d91a21" strokeWidth="2" />
            <rect x="6" y="10" width="18" height="4" fill="#d91a21" />
            <rect x="6" y="18" width="18" height="4" fill="#d91a21" />
            <text x="15" y="17" fill="#111827" fontSize="6.5" fontWeight="900" textAnchor="middle">GCF</text>
          </svg>
        );

      case 'LPA': // UD Las Palmas
        return (
          <svg viewBox="0 0 30 30" shapeRendering="geometricPrecision" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 24 18 Q 21 27 15 29 Q 9 27 6 18 Z" fill="#facc15" stroke="#0057b8" strokeWidth="2" />
            <rect x="6" y="17" width="18" height="10" fill="#0057b8" />
            <text x="15" y="14" fill="#0057b8" fontSize="6.5" fontWeight="900" textAnchor="middle">UDLP</text>
          </svg>
        );

      case 'EIB': // SD Eibar
        return (
          <svg viewBox="0 0 30 30" shapeRendering="geometricPrecision" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 24 18 Q 21 27 15 29 Q 9 27 6 18 Z" fill="#004c99" stroke="#facc15" strokeWidth="1.8" />
            <rect x="11" y="5" width="8" height="22" fill="#b91c1c" />
            <text x="15" y="18" fill="#ffffff" fontSize="6.5" fontWeight="900" textAnchor="middle">SDE</text>
          </svg>
        );

      case 'CAD': // Cadiz CF
        return (
          <svg viewBox="0 0 30 30" shapeRendering="geometricPrecision" className="w-full h-full">
            <path d="M 5 5 L 25 5 L 24 18 Q 21 27 15 29 Q 9 27 6 18 Z" fill="#facc15" stroke="#003d8f" strokeWidth="2" />
            <rect x="6" y="5" width="18" height="6" fill="#003d8f" />
            <text x="15" y="20" fill="#003d8f" fontSize="6.5" fontWeight="900" textAnchor="middle">CCF</text>
          </svg>
        );

      case 'ELD': // Eldense
      case 'SAB': // Sabadell
      case 'TEN': // Tenerife
      case 'CEU': // Ceuta
      default: {
        const [primary, secondary, accent] = getDeterministicPalette(teamName || resolvedCode || 'CLUB');
        const label = buildMonogram(teamName, resolvedCode);
        return (
          <svg viewBox="0 0 30 30" shapeRendering="geometricPrecision" className="w-full h-full">
            <path
              d="M 5 4 L 25 4 L 24 17 Q 21 27 15 29 Q 9 27 6 17 Z"
              fill={primary}
              stroke={accent}
              strokeWidth="2"
            />
            <path d="M 15 5 L 24 5 L 23 17 Q 20 26 15 28 Z" fill={secondary} opacity="0.22" />
            <rect x="6" y="10.5" width="18" height="9" rx="2" fill="#030918" stroke={accent} strokeWidth="0.9" />
            <text
              x="15"
              y="17"
              fill="#ffffff"
              fontSize={label.length >= 3 ? '6.5' : '7.5'}
              fontWeight="900"
              textAnchor="middle"
            >
              {label}
            </text>
          </svg>
        );
      }
    }
  };

  return (
    <div
      className={`inline-flex items-center justify-center shrink-0 ${dim} ${className}`}
      style={{ transform: 'translateZ(0)', backfaceVisibility: 'hidden' }}
    >
      {renderCrest()}
    </div>
  );
};
