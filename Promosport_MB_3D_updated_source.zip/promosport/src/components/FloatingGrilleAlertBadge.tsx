/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { BellRing, Sparkles } from 'lucide-react';
import { audioService } from '../services/audioService';
import { NotificationTargetTab } from '../types/promosport';

export interface FloatingGrilleAlertData {
  id: string;
  concoursNumber: number;
  title: string;
  cagnotte: string;
  targetTab?: NotificationTargetTab;
  createdAtMs: number;
}

interface FloatingGrilleAlertBadgeProps {
  alert: FloatingGrilleAlertData | null;
  lang?: 'AR' | 'FR';
  onOpenGrille: () => void;
  onExpire: () => void;
}

const ALERT_DURATION_MS = 10000;
const ENTER_DURATION_MS = 540;
const EXIT_START_MS = 9480;

const SMOKE_PUFFS = [
  { x: '-22px', delay: '0ms', size: 22 },
  { x: '18px', delay: '55ms', size: 26 },
  { x: '-10px', delay: '110ms', size: 30 },
  { x: '26px', delay: '160ms', size: 20 },
  { x: '-28px', delay: '210ms', size: 24 },
  { x: '8px', delay: '260ms', size: 28 },
];

export const FloatingGrilleAlertBadge: React.FC<FloatingGrilleAlertBadgeProps> = ({
  alert,
  lang = 'AR',
  onOpenGrille,
  onExpire,
}) => {
  const [remainingMs, setRemainingMs] = useState<number>(ALERT_DURATION_MS);
  const [phase, setPhase] = useState<'entering' | 'resting' | 'leaving'>('entering');
  const [showSmoke, setShowSmoke] = useState<boolean>(true);
  const onExpireRef = useRef(onExpire);
  onExpireRef.current = onExpire;

  useEffect(() => {
    if (!alert) return;

    setRemainingMs(ALERT_DURATION_MS);
    setPhase('entering');
    setShowSmoke(true);
    const startMs = Date.now();

    const enterTimer = window.setTimeout(() => {
      setPhase('resting');
    }, ENTER_DURATION_MS);

    const smokeTimer = window.setTimeout(() => {
      setShowSmoke(false);
    }, 950);

    const leaveTimer = window.setTimeout(() => {
      setPhase('leaving');
    }, EXIT_START_MS);

    const intervalId = window.setInterval(() => {
      const elapsed = Date.now() - startMs;
      const left = Math.max(0, ALERT_DURATION_MS - elapsed);
      setRemainingMs(left);
      if (left <= 0) {
        window.clearInterval(intervalId);
      }
    }, 100);

    const expireTimer = window.setTimeout(() => {
      onExpireRef.current();
    }, ALERT_DURATION_MS);

    return () => {
      window.clearTimeout(enterTimer);
      window.clearTimeout(smokeTimer);
      window.clearTimeout(leaveTimer);
      window.clearInterval(intervalId);
      window.clearTimeout(expireTimer);
    };
  }, [alert?.id]);

  if (!alert) return null;

  const progress = Math.max(0, Math.min(1, remainingMs / ALERT_DURATION_MS));
  const secondsLeft = Math.max(1, Math.ceil(remainingMs / 1000));
  const ringRadius = 24;
  const ringCircumference = 2 * Math.PI * ringRadius;
  const strokeDashoffset = ringCircumference * (1 - progress);

  const motionClass =
    phase === 'entering'
      ? 'notif-drop-enter'
      : phase === 'leaving'
        ? 'notif-rise-exit'
        : 'notif-center-resting';

  return (
    <div
      key={alert.id}
      className={`fixed top-1/2 left-1/2 z-[85] pointer-events-auto max-w-[92vw] ${motionClass}`}
      role="status"
      aria-live="polite"
    >
      {/* Dispersing lightweight smoke trail rising behind the dropping icon */}
      {showSmoke && (
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -top-10 left-1/2 -translate-x-1/2 flex items-center justify-center"
        >
          {SMOKE_PUFFS.map((puff, idx) => (
            <span
              key={idx}
              className="notif-smoke-puff absolute rounded-full bg-gradient-to-t from-amber-200/45 via-slate-100/35 to-transparent"
              style={
                {
                  width: `${puff.size}px`,
                  height: `${puff.size}px`,
                  animationDelay: puff.delay,
                  '--smoke-x': puff.x,
                  filter: 'blur(4px)',
                } as React.CSSProperties
              }
            />
          ))}
        </div>
      )}

      {/* Outer radiant golden glow surrounding the centered notification icon */}
      <div
        aria-hidden="true"
        className="notif-golden-aura pointer-events-none absolute -inset-4 rounded-3xl bg-radial from-yellow-400/35 via-amber-500/15 to-transparent blur-md"
      />

      <button
        type="button"
        dir={lang === 'AR' ? 'rtl' : 'ltr'}
        onClick={() => {
          audioService.playClick();
          onOpenGrille();
        }}
        title={lang === 'AR' ? 'انقر لفتح القصاصة الجديدة مباشرة' : 'Cliquer pour ouvrir'}
        className="group relative flex items-center gap-3.5 pr-3 pl-5 py-2.5 rounded-2xl bg-[#07152e]/95 border-2 border-yellow-400/95 shadow-[0_0_38px_rgba(250,204,21,0.72),0_12px_32px_rgba(0,0,0,0.88)] md:backdrop-blur-md hover:scale-[1.03] active:scale-95 transition-transform duration-200 cursor-pointer"
      >
        {/* Circular Alert Medallion with 10-Second 360° Revolving Golden Beam */}
        <div className="relative flex items-center justify-center w-14 h-14 shrink-0">
          <div className="absolute -inset-3 pointer-events-none flex items-center justify-center animate-spin-beam-fast">
            <div
              className="w-full h-full rounded-full opacity-95"
              style={{
                background:
                  'conic-gradient(from 0deg, transparent 0deg, transparent 45deg, rgba(254, 240, 138, 0.95) 75deg, rgba(250, 204, 21, 1) 90deg, rgba(249, 115, 22, 0.85) 105deg, transparent 140deg, transparent 225deg, rgba(254, 240, 138, 0.75) 260deg, rgba(250, 204, 21, 0.95) 270deg, transparent 310deg, transparent 360deg)',
                filter: 'blur(2.5px)',
              }}
            />
            <span className="absolute top-0 w-2.5 h-6 rounded-full bg-yellow-100 blur-[1.5px] shadow-[0_0_14px_#fef08a]" />
            <span className="absolute bottom-0 w-2 h-5 rounded-full bg-amber-400 blur-[1.5px] shadow-[0_0_12px_#f59e0b]" />
          </div>

          <svg
            viewBox="0 0 56 56"
            className="absolute inset-0 w-14 h-14 -rotate-90 pointer-events-none"
          >
            <circle
              cx="28"
              cy="28"
              r={ringRadius}
              fill="rgba(10, 20, 44, 0.95)"
              stroke="rgba(250, 204, 21, 0.25)"
              strokeWidth="3.5"
            />
            <circle
              cx="28"
              cy="28"
              r={ringRadius}
              fill="none"
              stroke="#facc15"
              strokeWidth="3.5"
              strokeLinecap="round"
              strokeDasharray={ringCircumference}
              strokeDashoffset={strokeDashoffset}
            />
          </svg>

          <div className="relative z-10 flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-br from-red-600 via-amber-500 to-yellow-400 text-black shadow-[0_0_16px_rgba(250,204,21,0.9)]">
            <BellRing className="w-5 h-5 text-black animate-bounce" />
          </div>
        </div>

        <div className={`${lang === 'AR' ? 'text-right' : 'text-left'} min-w-0`}>
          <div className="flex items-center gap-1.5 text-yellow-300 font-black text-xs sm:text-sm leading-tight">
            <Sparkles className="w-3.5 h-3.5 text-yellow-300 shrink-0 animate-pulse" />
            <span className="truncate">{alert.title}</span>
          </div>
          <div className="flex items-center gap-2 mt-1 text-[11px] font-bold text-gray-200">
            <span className="text-emerald-300 font-mono tabular-nums" dir="ltr">
              #{alert.concoursNumber}
            </span>
            <span className="text-white/40">•</span>
            <span className="text-amber-200 font-mono truncate" dir="ltr">
              {alert.cagnotte}
            </span>
            <span className="text-yellow-400/90 font-mono tabular-nums shrink-0" dir="ltr">
              ({secondsLeft}s)
            </span>
          </div>
        </div>
      </button>
    </div>
  );
};
