/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useLayoutEffect, useMemo, useRef, useCallback } from 'react';
import {
  Radar,
  Radio,
  Star,
  Tv,
  RefreshCw,
  Trophy,
  Globe2,
  Filter,
  Clock,
  Bell,
  Trash2,
  Power,
  Zap,
  Flame,
  Settings,
  X,
  ChevronUp,
  ChevronDown,
  CheckCircle2,
  ZoomIn,
  ZoomOut,
  RotateCcw,
} from 'lucide-react';
import {
  SiteLiveMatch,
  SiteLiveLeagueSummary,
  LiveNotificationItem,
} from '../types/promosport';
import { fetchPromosportLiveMatchesScan } from '../services/promosportData';
import { formatUtcPlusOneClock, useUtcClock } from '../services/timeUtils';
import {
  translateCompetitionToArabic,
  translateTeamToArabic,
  translateTeamToFrench,
} from '../services/teamTranslationService';
import {
  loadLiveFavoriteMatchIds,
  saveLiveFavoriteMatchIds,
  loadLiveFavoriteLeagues,
  saveLiveFavoriteLeagues,
  loadLiveWatchMatchIds,
  saveLiveWatchMatchIds,
  loadLiveAlwaysOn,
  saveLiveAlwaysOn,
  loadLiveScanEnabled,
  saveLiveScanEnabled,
  loadRetainedFinishedLiveMatches,
  mergeAndSaveRetainedFinishedLiveMatches,
} from '../services/storageService';
import { audioService } from '../services/audioService';
import { PinterestScoreboardCard } from './PinterestScoreboardCard';

interface LiveMatchesScanViewProps {
  lang: 'AR' | 'FR';
  getTeamName?: (teamName: string, frName?: string) => string;
  onLiveCountChange?: (liveCount: number) => void;
  liveNotifications?: LiveNotificationItem[];
  unreadNotificationsCount?: number;
  onClearNotifications?: () => void;
  onMarkNotificationsRead?: () => void;
  onOpenNotification?: (item: LiveNotificationItem) => void;
  onAppendLiveNotification?: (
    item: Omit<LiveNotificationItem, 'timestamp' | 'createdAtMs'>,
    options?: { silent?: boolean }
  ) => void;
  onOpenNotificationSettings?: () => void;
  onScanEnabledChange?: (enabled: boolean) => void;
}

type LiveFilterTab = 'all' | 'live' | 'watch' | 'favorites';

const INVALID_STATUS_CODES = new Set(['PST', 'PPD', 'CANC', 'SUSP', 'ABD', 'AWD', 'INT', 'WO', 'DELAYED']);

const MIN_LIVE_ZOOM = 0.3;
const MAX_LIVE_ZOOM = 1.6;
const LIVE_ZOOM_STEP = 0.1;
const LIVE_ZOOM_STORAGE_KEY = 'promosport_live_zoom_v1';
const LIVE_TIMEDATE_BAR_STORAGE_KEY = 'promosport_live_timedate_bar_v1';

const loadInitialLiveTimeDateBarVisible = (): boolean => {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return true;
    const raw = window.localStorage.getItem(LIVE_TIMEDATE_BAR_STORAGE_KEY);
    return raw === null ? true : raw === '1';
  } catch {
    return true;
  }
};

const clampLiveZoom = (val: number): number => {
  const clamped = Math.min(MAX_LIVE_ZOOM, Math.max(MIN_LIVE_ZOOM, val));
  return Math.round(clamped * 100) / 100;
};

const loadInitialLiveZoom = (): number => {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return 1;
    const raw = window.localStorage.getItem(LIVE_ZOOM_STORAGE_KEY);
    if (!raw) return 1;
    const parsed = Number(raw);
    return Number.isFinite(parsed) ? clampLiveZoom(parsed) : 1;
  } catch {
    return 1;
  }
};

function isMatchValidForDisplay(m: SiteLiveMatch): boolean {
  if (m.isDelayed) return false;
  const st = String(m.statusCode || '').trim().toUpperCase();
  if (INVALID_STATUS_CODES.has(st)) return false;
  if (!m.homeTeam || !m.awayTeam) return false;
  if (m.status === 'live' || m.status === 'finished') {
    return (
      m.hasVerifiedScore &&
      m.scoreHome !== undefined &&
      m.scoreAway !== undefined &&
      /^\d+$/.test(String(m.scoreHome)) &&
      /^\d+$/.test(String(m.scoreAway))
    );
  }
  return true;
}

function advanceMinuteTick(minuteText: string | undefined, steps: number): string | undefined {
  if (!minuteText || steps <= 0) return minuteText;
  const trimmed = minuteText.trim();
  if (/^(HT|FT|PAUSE|MT)$/i.test(trimmed)) return trimmed;
  const numMatch = trimmed.match(/^(\d{1,3})/);
  if (!numMatch) return trimmed;
  const baseMin = Number(numMatch[1]);
  if (!Number.isFinite(baseMin)) return trimmed;
  const isFirstHalf = /1H/i.test(trimmed) || baseMin <= 45;
  const cap = isFirstHalf ? 45 : 90;
  const nextMin = Math.min(cap, baseMin + steps);
  const suffix = trimmed.replace(/^\d{1,3}'?/, '').trim();
  return suffix ? `${nextMin}' ${suffix}` : `${nextMin}'`;
}

function buildLeagueSummariesFromMatches(
  allMatches: SiteLiveMatch[],
  baseLeagues: SiteLiveLeagueSummary[]
): SiteLiveLeagueSummary[] {
  const byKey = new Map<string, SiteLiveLeagueSummary>();
  for (const l of baseLeagues) {
    byKey.set(l.leagueKey, { ...l });
  }
  const counts = new Map<string, { total: number; live: number }>();
  for (const m of allMatches) {
    const cur = counts.get(m.leagueKey) || { total: 0, live: 0 };
    cur.total += 1;
    if (m.status === 'live') cur.live += 1;
    counts.set(m.leagueKey, cur);

    if (!byKey.has(m.leagueKey)) {
      byKey.set(m.leagueKey, {
        leagueKey: m.leagueKey,
        countryName: m.countryName,
        countryAr: m.countryName,
        leagueName: m.leagueName,
        countryFlagUrl: m.countryFlagUrl,
        leagueLogoUrl: m.leagueLogoUrl,
        rank: m.leagueOrderRank,
        totalCount: 0,
        liveCount: 0,
      });
    }
  }
  return Array.from(byKey.values()).map((meta) => {
    const c = counts.get(meta.leagueKey);
    return c ? { ...meta, totalCount: c.total, liveCount: c.live } : meta;
  });
}

export const LiveMatchesScanView: React.FC<LiveMatchesScanViewProps> = ({
  lang,
  getTeamName,
  onLiveCountChange,
  liveNotifications = [],
  unreadNotificationsCount = 0,
  onClearNotifications,
  onMarkNotificationsRead,
  onOpenNotification,
  onAppendLiveNotification,
  onOpenNotificationSettings,
  onScanEnabledChange,
}) => {
  const [scanEnabled, setScanEnabled] = useState<boolean>(() => loadLiveScanEnabled());
  const [matches, setMatches] = useState<SiteLiveMatch[]>(() => loadRetainedFinishedLiveMatches());
  const [baseLeagues, setBaseLeagues] = useState<SiteLiveLeagueSummary[]>([]);
  const leagues = useMemo(
    () => buildLeagueSummariesFromMatches(matches, baseLeagues),
    [matches, baseLeagues]
  );
  const [scannedAt, setScannedAt] = useState<string>('');
  const { timePlusOne } = useUtcClock(1000);
  const [isScanning, setIsScanning] = useState<boolean>(() => loadLiveScanEnabled());
  const [scanError, setScanError] = useState<string | null>(null);
  const [isNotificationsPanelOpen, setIsNotificationsPanelOpen] = useState<boolean>(false);

  const [alwaysLiveActive, setAlwaysLiveActive] = useState<boolean>(() => loadLiveAlwaysOn());
  const [filterTab, setFilterTab] = useState<LiveFilterTab>('all');
  const [selectedLeagueKey, setSelectedLeagueKey] = useState<string>('ALL');

  const [favoriteMatchIds, setFavoriteMatchIds] = useState<string[]>(() => loadLiveFavoriteMatchIds());
  const [favoriteLeagues, setFavoriteLeagues] = useState<string[]>(() => loadLiveFavoriteLeagues());
  const [watchMatchIds, setWatchMatchIds] = useState<string[]>(() => loadLiveWatchMatchIds());

  const [goalFlashMap, setGoalFlashMap] = useState<Record<string, number>>({});
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});
  const [minuteStepsSincePoll, setMinuteStepsSincePoll] = useState<number>(0);

  // Floating glass scanner bar + Zoom bar visibility (auto-hides on up/down scroll, toggles via small icon)
  const [isScannerBarOpen, setIsScannerBarOpen] = useState<boolean>(true);
  const [scannerSpacerHeight, setScannerSpacerHeight] = useState<number>(224);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const scannerHeaderRef = useRef<HTMLDivElement>(null);
  const isScannerBarOpenRef = useRef<boolean>(isScannerBarOpen);
  isScannerBarOpenRef.current = isScannerBarOpen;
  const suppressScrollHideUntilRef = useRef<number>(Date.now() + 500);
  const lastScrollTopRef = useRef<number>(0);
  const touchStartYRef = useRef<number | null>(null);

  // Live + non-live matches Zoom state (30% - 160%, zero finger pinch zoom)
  const [zoom, setZoom] = useState<number>(loadInitialLiveZoom);
  const [isZoomBarOpen, setIsZoomBarOpen] = useState<boolean>(false);
  const [isTimeDateBarVisible, setIsTimeDateBarVisible] = useState<boolean>(
    loadInitialLiveTimeDateBarVisible
  );
  const [anchorCardIndex, setAnchorCardIndex] = useState<number | null>(null);
  const [hasToggledTimeDateBar, setHasToggledTimeDateBar] = useState<boolean>(false);
  const zoomViewportRef = useRef<HTMLDivElement>(null);
  const scaledWrapperRef = useRef<HTMLDivElement>(null);
  const matchesContentRef = useRef<HTMLDivElement>(null);
  const pendingScrollAnchorRef = useRef<{
    el: HTMLElement;
    prevTop: number;
  } | null>(null);
  const activeAnchorRafRef = useRef<number | null>(null);

  const cancelActiveScrollAnchor = useCallback(() => {
    if (activeAnchorRafRef.current !== null) {
      window.cancelAnimationFrame(activeAnchorRafRef.current);
      activeAnchorRafRef.current = null;
    }
  }, []);

  useEffect(() => cancelActiveScrollAnchor, [cancelActiveScrollAnchor]);

  const handleToggleTimeDateBar = useCallback(
    (anchorEl?: HTMLElement | null, clickedIndex?: number) => {
      audioService.playClick();
      cancelActiveScrollAnchor();
      if (anchorEl && scrollContainerRef.current) {
        pendingScrollAnchorRef.current = {
          el: anchorEl,
          prevTop: anchorEl.getBoundingClientRect().top,
        };
      } else {
        pendingScrollAnchorRef.current = null;
      }
      setAnchorCardIndex(typeof clickedIndex === 'number' ? clickedIndex : null);
      setHasToggledTimeDateBar(true);
      setIsTimeDateBarVisible((prev) => {
        const next = !prev;
        try {
          if (typeof window !== 'undefined' && window.localStorage) {
            window.localStorage.setItem(LIVE_TIMEDATE_BAR_STORAGE_KEY, next ? '1' : '0');
          }
        } catch {
          // ignore storage errors
        }
        return next;
      });
    },
    [cancelActiveScrollAnchor]
  );
  const [zoomTextInput, setZoomTextInput] = useState<string>(() =>
    String(Math.round(loadInitialLiveZoom() * 100))
  );
  const [viewportWidth, setViewportWidth] = useState<number>(0);
  const [unscaledHeight, setUnscaledHeight] = useState<number>(0);
  const numericInputRef = useRef<HTMLInputElement>(null);
  const zoomRef = useRef<number>(zoom);
  zoomRef.current = zoom;
  const isZoomBarOpenRef = useRef<boolean>(isZoomBarOpen);
  isZoomBarOpenRef.current = isZoomBarOpen;

  // Desktop mouse drag-to-scroll refs
  const isMouseDownRef = useRef<boolean>(false);
  const startYRef = useRef<number>(0);
  const startXRef = useRef<number>(0);
  const scrollTopRef = useRef<number>(0);
  const scrollLeftRef = useRef<number>(0);

  const freshMatchesRef = useRef<SiteLiveMatch[]>([]);

  const prevScoreMapRef = useRef<Record<string, { h: number; a: number; hasScore: boolean; status: string }> | null>(
    null
  );
  const mountedRef = useRef<boolean>(true);
  const langRef = useRef<'AR' | 'FR'>(lang);
  langRef.current = lang;
  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
    };
  }, []);

  const performScan = useCallback(async (forceScan: boolean, silent = false) => {
    if (!loadLiveScanEnabled()) {
      if (mountedRef.current) setIsScanning(false);
      return;
    }
    if (!silent) {
      setIsScanning(true);
    }
    try {
      const payload = await fetchPromosportLiveMatchesScan(forceScan);
      if (!mountedRef.current) return;

      if (payload && Array.isArray(payload.matches)) {
        const cleanMatches = payload.matches.filter(isMatchValidForDisplay);
        freshMatchesRef.current = cleanMatches;

        const retainedFinished = mergeAndSaveRetainedFinishedLiveMatches(cleanMatches);
        const freshIds = new Set(cleanMatches.map((m) => m.siteMatchId));
        const extraFinished = retainedFinished.filter((m) => !freshIds.has(m.siteMatchId));
        const mergedMatches = [...cleanMatches, ...extraFinished];

        setMatches(mergedMatches);
        setBaseLeagues(payload.leagues || []);
        setScannedAt(payload.scannedAt || new Date().toISOString());
        setMinuteStepsSincePoll(0);
        setScanError(null);
      } else if (!silent) {
        setScanError(
          langRef.current === 'AR'
            ? 'تعذر الاتصال بنطاق promosport-pronostic.com حالياً — جارٍ إعادة المحاولة.'
            : 'Connexion impossible à promosport-pronostic.com — nouvelle tentative.'
        );
      }
    } catch {
      if (mountedRef.current && !silent) {
        setScanError(
          langRef.current === 'AR'
            ? 'تعذر مسح النطاق المباشر — تحقق من الاتصال.'
            : 'Impossible de scanner le flux en direct — vérifiez votre connexion.'
        );
      }
    } finally {
      if (mountedRef.current) {
        setIsScanning(false);
      }
    }
  }, []);

  // Initial domain scan on mount (respects scanEnabled toggle)
  useEffect(() => {
    if (scanEnabled) {
      void performScan(true, false);
    } else {
      setIsScanning(false);
    }
  }, [scanEnabled, performScan]);

  // Periodically expire finished matches once 24h has elapsed (even if scan is paused)
  useEffect(() => {
    const pruneExpired = () => {
      const activeFinished = loadRetainedFinishedLiveMatches(Date.now());
      const activeFinishedIds = new Set(activeFinished.map((m) => m.siteMatchId));
      const freshIds = new Set(freshMatchesRef.current.map((m) => m.siteMatchId));
      const extraFinished = activeFinished.filter((m) => !freshIds.has(m.siteMatchId));

      setMatches((prev) => {
        const filtered = prev.filter((m) => {
          if (m.status !== 'finished') return true;
          if (freshIds.has(m.siteMatchId)) return true;
          return activeFinishedIds.has(m.siteMatchId);
        });
        const existingIds = new Set(filtered.map((m) => m.siteMatchId));
        const additions = extraFinished.filter((m) => !existingIds.has(m.siteMatchId));
        return [...filtered, ...additions];
      });
    };

    const timerId = window.setInterval(pruneExpired, 60000);
    return () => window.clearInterval(timerId);
  }, []);

  // Always-live continuous moment-by-moment polling (every 3 seconds when both scanEnabled & alwaysLiveActive)
  useEffect(() => {
    if (!scanEnabled || !alwaysLiveActive) return;
    const pollId = window.setInterval(() => {
      void performScan(false, true);
    }, 3000);
    return () => window.clearInterval(pollId);
  }, [scanEnabled, alwaysLiveActive, performScan]);

  // Smooth minute ticker between server updates while scanEnabled & Always-Live are ON
  useEffect(() => {
    if (!scanEnabled || !alwaysLiveActive) return;
    const tickId = window.setInterval(() => {
      setMinuteStepsSincePoll((s) => (s < 3 ? s + 1 : s));
    }, 20000);
    return () => window.clearInterval(tickId);
  }, [scanEnabled, alwaysLiveActive]);

  // Detect verified goals, kickoffs & finished results and log them into Live Notifications
  useEffect(() => {
    const nextMap: Record<string, { h: number; a: number; hasScore: boolean; status: string }> = {};
    const newlyScoredIds: string[] = [];

    for (const m of matches) {
      const hasScore =
        m.hasVerifiedScore &&
        m.scoreHome !== undefined &&
        m.scoreAway !== undefined &&
        /^\d+$/.test(String(m.scoreHome)) &&
        /^\d+$/.test(String(m.scoreAway));
      const h = hasScore ? Number(m.scoreHome) : 0;
      const a = hasScore ? Number(m.scoreAway) : 0;
      nextMap[m.siteMatchId] = { h, a, hasScore, status: m.status };

      const prev = prevScoreMapRef.current?.[m.siteMatchId];
      const isAr = langRef.current === 'AR';
      const hTeam = isAr
        ? translateTeamToArabic(m.homeTeam, m.homeTeamFr)
        : translateTeamToFrench(m.homeTeam, m.homeTeamFr);
      const aTeam = isAr
        ? translateTeamToArabic(m.awayTeam, m.awayTeamFr)
        : translateTeamToFrench(m.awayTeam, m.awayTeamFr);
      const leagueLabel = isAr
        ? translateCompetitionToArabic(m.leagueName || 'المباريات المباشرة', m.leagueName)
        : m.leagueName || 'Direct';

      if (
        prev &&
        hasScore &&
        (m.status === 'live' || (prev.status === 'live' && m.status === 'finished')) &&
        ((prev.hasScore && (h > prev.h || a > prev.a)) || (!prev.hasScore && (h > 0 || a > 0)))
      ) {
        newlyScoredIds.push(m.siteMatchId);
        onAppendLiveNotification?.({
          id: `live-goal-${m.siteMatchId}-${h}-${a}`,
          kind: 'goal',
          title: isAr
            ? `هدف مباشر! ${hTeam} ${h} - ${a} ${aTeam}`
            : `BUT EN DIRECT ! ${hTeam} ${h} - ${a} ${aTeam}`,
          message: isAr
            ? `${leagueLabel} • الدقيقة ${m.liveMinute || "1'"}`
            : `${leagueLabel} • Minute ${m.liveMinute || "1'"}`,
          scoreLabel: `${h} - ${a}`,
          leagueLabel: m.leagueName,
        });
      } else if (prev && prev.status === 'scheduled' && m.status === 'live' && hasScore) {
        onAppendLiveNotification?.({
          id: `live-kickoff-${m.siteMatchId}`,
          kind: 'kickoff',
          title: isAr
            ? `انطلاق المباراة: ${hTeam} ضد ${aTeam}`
            : `Coup d’envoi : ${hTeam} - ${aTeam}`,
          message: isAr
            ? `${leagueLabel} • بدأت الآن (${h} - ${a})`
            : `${leagueLabel} • En cours (${h} - ${a})`,
          scoreLabel: `${h} - ${a}`,
          leagueLabel: m.leagueName,
        });
      } else if (prev && prev.status === 'live' && m.status === 'finished' && hasScore) {
        onAppendLiveNotification?.({
          id: `live-ft-${m.siteMatchId}`,
          kind: 'result',
          title: isAr
            ? `نهاية المباراة: ${hTeam} ${h} - ${a} ${aTeam}`
            : `Score final : ${hTeam} ${h} - ${a} ${aTeam}`,
          message: isAr
            ? `${leagueLabel} • النتيجة النهائية`
            : `${leagueLabel} • Match terminé`,
          scoreLabel: `FT ${h} - ${a}`,
          leagueLabel: m.leagueName,
        });
      }
    }

    prevScoreMapRef.current = nextMap;

    if (newlyScoredIds.length > 0) {
      audioService.playGoalAlert();
      const stamp = Date.now();
      setGoalFlashMap((prev) => {
        const updated = { ...prev };
        newlyScoredIds.forEach((id) => {
          updated[id] = stamp;
        });
        return updated;
      });
      newlyScoredIds.forEach((id) => {
        window.setTimeout(() => {
          setGoalFlashMap((prev) => {
            if (prev[id] !== stamp) return prev;
            const copy = { ...prev };
            delete copy[id];
            return copy;
          });
        }, 7000);
      });
    }
  }, [matches, onAppendLiveNotification]);

  const favMatchSet = useMemo(() => new Set(favoriteMatchIds), [favoriteMatchIds]);
  const favLeagueSet = useMemo(() => new Set(favoriteLeagues), [favoriteLeagues]);
  const watchSet = useMemo(() => new Set(watchMatchIds), [watchMatchIds]);

  const liveMatchesCount = useMemo(
    () => matches.filter((m) => m.status === 'live').length,
    [matches]
  );

  useEffect(() => {
    onLiveCountChange?.(liveMatchesCount);
  }, [liveMatchesCount, onLiveCountChange]);

  const toggleFavoriteMatch = (siteMatchId: string) => {
    audioService.playClick();
    setFavoriteMatchIds((prev) => {
      const exists = prev.includes(siteMatchId);
      const next = exists ? prev.filter((id) => id !== siteMatchId) : [...prev, siteMatchId];
      saveLiveFavoriteMatchIds(next);
      return next;
    });
  };

  const toggleFavoriteLeague = (leagueKey: string) => {
    audioService.playClick();
    setFavoriteLeagues((prev) => {
      const exists = prev.includes(leagueKey);
      const next = exists ? prev.filter((k) => k !== leagueKey) : [...prev, leagueKey];
      saveLiveFavoriteLeagues(next);
      return next;
    });
  };

  const toggleWatchLiveMatch = (siteMatchId: string) => {
    audioService.playClick();
    setWatchMatchIds((prev) => {
      const exists = prev.includes(siteMatchId);
      const next = exists ? prev.filter((id) => id !== siteMatchId) : [...prev, siteMatchId];
      saveLiveWatchMatchIds(next);
      return next;
    });
  };

  const toggleScanEnabled = () => {
    audioService.playClick();
    const next = !scanEnabled;
    setScanEnabled(next);
    saveLiveScanEnabled(next);
    onScanEnabledChange?.(next);
    if (!next) {
      setIsScanning(false);
    } else {
      void performScan(true, false);
    }
  };

  const toggleAlwaysLive = () => {
    audioService.playClick();
    const next = !alwaysLiveActive;
    setAlwaysLiveActive(next);
    saveLiveAlwaysOn(next);
    if (next && scanEnabled) {
      void performScan(true, true);
    }
  };

  // Matches filtered by tab and league selector
  const filteredMatches = useMemo(() => {
    return matches.filter((m) => {
      if (filterTab === 'live' && m.status !== 'live') return false;
      if (filterTab === 'watch' && !watchSet.has(m.siteMatchId)) return false;
      if (
        filterTab === 'favorites' &&
        !favMatchSet.has(m.siteMatchId) &&
        !favLeagueSet.has(m.leagueKey)
      ) {
        return false;
      }
      if (selectedLeagueKey !== 'ALL' && m.leagueKey !== selectedLeagueKey) return false;

      return true;
    });
  }, [matches, filterTab, watchSet, favMatchSet, favLeagueSet, selectedLeagueKey]);

  // Pinned watched matches at top (when user selected matches via "مشاهدة مباشرة")
  const pinnedWatchedMatches = useMemo(() => {
    if (filterTab === 'favorites') return [];
    return matches.filter((m) => {
      if (!watchSet.has(m.siteMatchId)) return false;
      if (filterTab === 'live' && m.status !== 'live') return false;
      if (selectedLeagueKey !== 'ALL' && m.leagueKey !== selectedLeagueKey) return false;
      return true;
    });
  }, [matches, watchSet, filterTab, selectedLeagueKey]);

  // League metadata lookup
  const leagueMetaMap = useMemo(() => {
    const map = new Map<string, SiteLiveLeagueSummary>();
    for (const l of leagues) {
      map.set(l.leagueKey, l);
    }
    return map;
  }, [leagues]);

  // Group filtered matches by league and order leagues cleanly (`ترتيب الدوريات`)
  const orderedLeagueGroups = useMemo(() => {
    const groupsMap = new Map<
      string,
      {
        leagueKey: string;
        meta: SiteLiveLeagueSummary;
        matches: SiteLiveMatch[];
        liveInGroup: number;
      }
    >();

    for (const m of filteredMatches) {
      let group = groupsMap.get(m.leagueKey);
      if (!group) {
        const meta: SiteLiveLeagueSummary = leagueMetaMap.get(m.leagueKey) || {
          leagueKey: m.leagueKey,
          countryName: m.countryName,
          countryAr: m.countryName,
          leagueName: m.leagueName,
          countryFlagUrl: m.countryFlagUrl,
          leagueLogoUrl: m.leagueLogoUrl,
          rank: m.leagueOrderRank,
          totalCount: 0,
          liveCount: 0,
        };
        group = {
          leagueKey: m.leagueKey,
          meta,
          matches: [],
          liveInGroup: 0,
        };
        groupsMap.set(m.leagueKey, group);
      }
      group.matches.push(m);
      if (m.status === 'live') {
        group.liveInGroup += 1;
      }
    }

    const groups = Array.from(groupsMap.values());

    // Sort matches chronologically inside each league
    for (const g of groups) {
      g.matches.sort((a, b) => {
        if (a.kickoffTimestamp && b.kickoffTimestamp && a.kickoffTimestamp !== b.kickoffTimestamp) {
          return a.kickoffTimestamp - b.kickoffTimestamp;
        }
        return (a.dayTime || '').localeCompare(b.dayTime || '');
      });
    }

    // Sort leagues by favorite status then importance rank
    groups.sort((a, b) => {
      const aFav = favLeagueSet.has(a.leagueKey) ? 0 : 1;
      const bFav = favLeagueSet.has(b.leagueKey) ? 0 : 1;
      if (aFav !== bFav) return aFav - bFav;

      if (a.meta.rank !== b.meta.rank) return a.meta.rank - b.meta.rank;
      return a.meta.leagueKey.localeCompare(b.meta.leagueKey);
    });

    return groups;
  }, [filteredMatches, leagueMetaMap, favLeagueSet]);

  // Ordered league options for dropdown selector
  const orderedDropdownLeagues = useMemo(() => {
    return [...leagues].sort((a, b) => {
      const aFav = favLeagueSet.has(a.leagueKey) ? 0 : 1;
      const bFav = favLeagueSet.has(b.leagueKey) ? 0 : 1;
      if (aFav !== bFav) return aFav - bFav;
      if (a.rank !== b.rank) return a.rank - b.rank;
      return a.leagueKey.localeCompare(b.leagueKey);
    });
  }, [leagues, favLeagueSet]);

  const enrichMinuteForDisplay = (m: SiteLiveMatch): SiteLiveMatch => {
    if (m.status !== 'live' || minuteStepsSincePoll === 0) return m;
    return {
      ...m,
      liveMinute: advanceMinuteTick(m.liveMinute, minuteStepsSincePoll),
    };
  };

  const finishedMatchesCount = useMemo(
    () => matches.filter((m) => m.status === 'finished' && m.hasVerifiedScore).length,
    [matches]
  );

  // Measure open floating overlay stack height cleanly (excluding expandable notifications drawer) so cards start below it without shifting on close
  useEffect(() => {
    if (!isScannerBarOpen || isNotificationsPanelOpen) return;
    const el = scannerHeaderRef.current;
    if (!el) return;
    const measure = () => {
      const h = el.offsetHeight;
      if (h > 80) {
        setScannerSpacerHeight(h + 12);
      }
    };
    measure();
    if (typeof ResizeObserver !== 'undefined') {
      const ro = new ResizeObserver(measure);
      ro.observe(el);
      return () => ro.disconnect();
    }
    window.addEventListener('resize', measure);
    return () => window.removeEventListener('resize', measure);
  }, [isScannerBarOpen, isZoomBarOpen, isNotificationsPanelOpen, scanEnabled]);

  const hideScannerBarOnScroll = useCallback(() => {
    if (Date.now() < suppressScrollHideUntilRef.current) return;
    suppressScrollHideUntilRef.current = Date.now() + 300;
    if (isScannerBarOpenRef.current) {
      setIsScannerBarOpen(false);
      setIsNotificationsPanelOpen(false);
    }
    if (isZoomBarOpenRef.current) {
      setIsZoomBarOpen(false);
    }
  }, []);

  const openScannerBarManually = useCallback(() => {
    audioService.playClick();
    suppressScrollHideUntilRef.current = Date.now() + 480;
    setIsScannerBarOpen(true);
  }, []);

  const closeScannerBarManually = useCallback(() => {
    audioService.playClick();
    suppressScrollHideUntilRef.current = Date.now() + 480;
    setIsScannerBarOpen(false);
    setIsNotificationsPanelOpen(false);
  }, []);

  const openZoomBarManually = useCallback(() => {
    audioService.playClick();
    suppressScrollHideUntilRef.current = Date.now() + 480;
    setIsZoomBarOpen(true);
  }, []);

  const closeZoomBarManually = useCallback(() => {
    audioService.playClick();
    suppressScrollHideUntilRef.current = Date.now() + 480;
    setIsZoomBarOpen(false);
  }, []);

  const updateZoom = useCallback((next: number | ((prev: number) => number)) => {
    suppressScrollHideUntilRef.current = Date.now() + 480;
    const resolved = typeof next === 'function' ? next(zoomRef.current) : next;
    const clamped = clampLiveZoom(resolved);
    zoomRef.current = clamped;
    setZoom(clamped);
    setZoomTextInput(String(Math.round(clamped * 100)));
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem(LIVE_ZOOM_STORAGE_KEY, String(clamped));
      }
    } catch {
      // ignore storage errors
    }
  }, []);

  const handleApplyNumericZoom = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    audioService.playClick();
    const cleaned = zoomTextInput.replace(/[^\d]/g, '');
    const parsed = Number(cleaned);
    if (cleaned.length > 0 && Number.isFinite(parsed) && parsed > 0) {
      const clampedPct = Math.min(160, Math.max(30, Math.round(parsed)));
      updateZoom(clampedPct / 100);
      setZoomTextInput(String(clampedPct));
    } else {
      setZoomTextInput(String(Math.round(zoom * 100)));
    }
    numericInputRef.current?.blur();
  };

  // Measure unscaled live & non-live match list dimensions for smooth edge-to-edge scaling
  const measureLiveMatchesBox = useCallback(() => {
    if (zoomViewportRef.current) {
      const nextWidth = zoomViewportRef.current.clientWidth;
      if (nextWidth > 0) {
        setViewportWidth((prev) => (prev !== nextWidth ? nextWidth : prev));
      }
    }
    if (matchesContentRef.current) {
      const nextHeight = matchesContentRef.current.offsetHeight;
      if (nextHeight > 0) {
        setUnscaledHeight((prev) => (prev !== nextHeight ? nextHeight : prev));
      }
    }
  }, []);

  useEffect(() => {
    const rafId = window.requestAnimationFrame(measureLiveMatchesBox);
    window.addEventListener('resize', measureLiveMatchesBox);

    let observer: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      observer = new ResizeObserver(() => {
        measureLiveMatchesBox();
      });
      if (zoomViewportRef.current) observer.observe(zoomViewportRef.current);
      if (matchesContentRef.current) observer.observe(matchesContentRef.current);
    }

    return () => {
      window.cancelAnimationFrame(rafId);
      window.removeEventListener('resize', measureLiveMatchesBox);
      observer?.disconnect();
    };
  }, [
    measureLiveMatchesBox,
    zoom,
    matches.length,
    orderedLeagueGroups.length,
    pinnedWatchedMatches.length,
    filterTab,
    scanError,
    isScanning,
    scanEnabled,
    isTimeDateBarVisible,
  ]);

  // Keep clicked match pixel-locked in its exact screen position throughout gradual sequential toggle
  useLayoutEffect(() => {
    const pending = pendingScrollAnchorRef.current;
    pendingScrollAnchorRef.current = null;
    const container = scrollContainerRef.current;
    if (!pending || !container || !pending.el.isConnected) return;

    const syncAnchorFrame = () => {
      const c = scrollContainerRef.current;
      if (!c || !pending.el.isConnected) return;
      const currentZoom = zoomRef.current;
      if (Math.abs(currentZoom - 1) >= 0.01 && scaledWrapperRef.current && matchesContentRef.current) {
        const nextUnscaledH = matchesContentRef.current.offsetHeight;
        if (nextUnscaledH > 0) {
          scaledWrapperRef.current.style.height = `${Math.ceil(nextUnscaledH * currentZoom)}px`;
        }
      }

      const afterTop = pending.el.getBoundingClientRect().top;
      const deltaY = afterTop - pending.prevTop;
      if (Math.abs(deltaY) > 0.25) {
        suppressScrollHideUntilRef.current = Date.now() + 300;
        c.scrollTop = Math.max(0, c.scrollTop + deltaY);
        lastScrollTopRef.current = c.scrollTop;
      }
    };

    syncAnchorFrame();
    const endTime = performance.now() + 1500;
    const tick = () => {
      syncAnchorFrame();
      if (performance.now() < endTime) {
        activeAnchorRafRef.current = window.requestAnimationFrame(tick);
      } else {
        activeAnchorRafRef.current = null;
        measureLiveMatchesBox();
      }
    };
    activeAnchorRafRef.current = window.requestAnimationFrame(tick);
  }, [isTimeDateBarVisible, measureLiveMatchesBox]);

  // Desktop Ctrl+Wheel / trackpad pinch zoom on the matches area (finger pinch stays OFF)
  useEffect(() => {
    const el = zoomViewportRef.current;
    if (!el) return;

    const handleWheel = (e: WheelEvent) => {
      if (!e.ctrlKey && !e.metaKey) return;
      e.preventDefault();
      const delta = -e.deltaY * 0.0025;
      if (Math.abs(delta) > 0.001) {
        updateZoom((prev) => prev + delta);
      }
    };

    el.addEventListener('wheel', handleWheel, { passive: false });
    return () => {
      el.removeEventListener('wheel', handleWheel);
    };
  }, [updateZoom]);

  // Reset horizontal scroll when zooming back to <= 100%
  useEffect(() => {
    if (zoom <= 1.001 && zoomViewportRef.current && zoomViewportRef.current.scrollLeft !== 0) {
      zoomViewportRef.current.scrollLeft = 0;
    }
  }, [zoom]);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!scrollContainerRef.current) return;
    if ((e.target as HTMLElement | null)?.closest('button, input, a, select, textarea')) return;
    isMouseDownRef.current = true;
    startYRef.current = e.pageY - scrollContainerRef.current.offsetTop;
    scrollTopRef.current = scrollContainerRef.current.scrollTop;
    if (zoomViewportRef.current) {
      startXRef.current = e.pageX - zoomViewportRef.current.offsetLeft;
      scrollLeftRef.current = zoomViewportRef.current.scrollLeft;
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isMouseDownRef.current || !scrollContainerRef.current) return;
    const y = e.pageY - scrollContainerRef.current.offsetTop;
    const deltaY = y - startYRef.current;
    const x = zoomViewportRef.current ? e.pageX - zoomViewportRef.current.offsetLeft : 0;
    const deltaX = zoomViewportRef.current ? x - startXRef.current : 0;
    if (Math.abs(deltaY) <= 4 && Math.abs(deltaX) <= 4) return;
    e.preventDefault();
    cancelActiveScrollAnchor();
    if (Math.abs(deltaY) > 10) {
      hideScannerBarOnScroll();
    }
    scrollContainerRef.current.scrollTop = scrollTopRef.current - deltaY * 1.3;

    if (zoomRef.current > 1.001 && zoomViewportRef.current) {
      zoomViewportRef.current.scrollLeft = scrollLeftRef.current - deltaX * 1.2;
    }
  };

  const handleMouseUp = () => {
    isMouseDownRef.current = false;
  };

  const handleContainerScroll = () => {
    if (!scrollContainerRef.current) return;
    const nextTop = scrollContainerRef.current.scrollTop;
    const delta = Math.abs(nextTop - lastScrollTopRef.current);
    lastScrollTopRef.current = nextTop;
    if (delta > 6) {
      hideScannerBarOnScroll();
    }
  };

  const isDefaultZoom = Math.abs(zoom - 1) < 0.01;
  const zoomPercent = Math.round(zoom * 100);
  const trackProgressPct = Math.min(100, Math.max(0, ((zoomPercent - 30) / (160 - 30)) * 100));
  const scaledHeight = unscaledHeight > 0 ? Math.ceil(unscaledHeight * zoom) : 0;
  const unscaledEdgeToEdgeWidth =
    !isDefaultZoom && viewportWidth > 0
      ? Math.floor((viewportWidth / zoom) * 100) / 100
      : viewportWidth > 0
      ? viewportWidth
      : 0;

  const formattedScanClock = useMemo(() => {
    if (!scannedAt) return '--:--:-- +1';
    const d = new Date(scannedAt);
    if (Number.isNaN(d.getTime())) return '--:--:-- +1';
    return `${formatUtcPlusOneClock(d)} +1`;
  }, [scannedAt]);

  let liveCardSequenceCursor = 0;
  const getTimeDateTransitionDelayMs = (cardIdx: number) => {
    const refIdx = anchorCardIndex !== null ? anchorCardIndex : 0;
    return Math.min(Math.abs(cardIdx - refIdx), 12) * 75;
  };

  return (
    <div className="relative w-full h-full flex-1 flex flex-col overflow-hidden" dir={lang === 'AR' ? 'rtl' : 'ltr'}>
      {/* SMALL TOP-LEFT MANUAL REOPEN ICON FOR ZOOM BAR WHEN BOTH BARS ARE COLLAPSED */}
      {!isScannerBarOpen && !isZoomBarOpen && (
        <button
          type="button"
          data-no-flash="true"
          onClick={openZoomBarManually}
          title={lang === 'AR' ? 'فتح شريط زوم المقابلات المباشرة وغير المباشرة' : 'Ouvrir le zoom'}
          aria-label={lang === 'AR' ? 'فتح أيقونة الزوم' : 'Ouvrir le zoom'}
          className="absolute top-1.5 left-1.5 z-40 min-h-[34px] px-2.5 py-1 rounded-full bg-gradient-to-r from-[#07152f]/75 via-[#0c234b]/65 to-[#07152f]/75 hover:from-cyan-500/35 hover:to-sky-500/35 backdrop-blur-md border border-cyan-300/80 text-cyan-100 shadow-[0_4px_16px_rgba(0,0,0,0.65)] flex items-center gap-1 active:scale-95 transition-all cursor-pointer"
        >
          <ZoomIn className="w-3.5 h-3.5 text-yellow-300 shrink-0" />
          <span className="text-[10.5px] font-black whitespace-nowrap drop-shadow-[0_1px_3px_rgba(0,0,0,0.98)]">
            Zoom
          </span>
          <span className="font-mono tabular-nums text-[10.5px] font-black text-yellow-300" dir="ltr">
            {zoomPercent}%
          </span>
        </button>
      )}

      {/* TOP FLOATING OVERLAY STACK: GLASS SCANNER BAR + EDGE-TO-EDGE ZOOM BAR */}
      <div
        ref={scannerHeaderRef}
        onTouchMove={(e) => e.stopPropagation()}
        onWheel={(e) => e.stopPropagation()}
        className="absolute top-0 inset-x-0 z-30 pointer-events-none flex flex-col"
      >
        {/* SMALL MANUAL REOPEN ICON WHEN GLASS SCANNER BAR IS HIDDEN */}
        {!isScannerBarOpen && (
          <div className="pt-1.5 pb-1 flex items-center justify-center px-2">
            <button
              type="button"
              data-no-flash="true"
              onClick={openScannerBarManually}
              title={lang === 'AR' ? 'فتح شريط المسح المباشر يدوياً' : 'Ouvrir le scanner en direct'}
              aria-label={lang === 'AR' ? 'فتح شريط المسح المباشر يدوياً' : 'Ouvrir le scanner en direct'}
              className="pointer-events-auto relative min-h-[34px] px-3 py-1 rounded-full bg-gradient-to-r from-[#07152f]/70 via-[#0c234b]/60 to-[#07152f]/70 hover:from-sky-500/35 hover:to-emerald-500/35 backdrop-blur-md border border-sky-300/80 text-white shadow-[0_4px_18px_rgba(0,0,0,0.65)] flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
            >
              <Radar
                className={`w-3.5 h-3.5 text-emerald-300 shrink-0 ${
                  scanEnabled && (isScanning || alwaysLiveActive) ? 'animate-spin' : ''
                }`}
                style={{
                  animationDuration: scanEnabled && alwaysLiveActive && !isScanning ? '5s' : undefined,
                }}
              />
              <span className="text-[11px] font-black whitespace-nowrap drop-shadow-[0_1px_3px_rgba(0,0,0,0.95)]">
                {lang === 'AR' ? 'شريط المسح' : 'Scanner'}
              </span>
              <span className="px-1.5 py-0.2 rounded-full bg-emerald-500/25 border border-emerald-300/70 text-[9.5px] font-mono font-black text-emerald-200 tabular-nums">
                {liveMatchesCount}
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-sky-200 shrink-0" />
              {unreadNotificationsCount > 0 && (
                <>
                  <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-red-600 border border-black animate-ping" />
                  <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-red-600 border border-black" />
                </>
              )}
            </button>
          </div>
        )}

        {/* 1. FLOATING FROSTED GLASS LIVE DOMAIN SCANNER BAR */}
        {isScannerBarOpen && (
          <div className="px-1.5 sm:px-3 pt-1.5 pb-1">
            <div className="pointer-events-auto relative rounded-3xl backdrop-blur-md bg-gradient-to-br from-[#07152f]/58 via-[#0b224a]/46 to-[#061126]/58 border-2 border-sky-400/75 p-2.5 sm:p-3.5 shadow-[inset_0_0_22px_rgba(56,189,248,0.22),0_8px_28px_rgba(0,0,0,0.48)] space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-400 to-cyan-500 text-black flex items-center justify-center shadow-[0_0_16px_rgba(16,185,129,0.75)] border border-white/80 shrink-0">
              <Radar
                className={`w-5 h-5 ${scanEnabled && (isScanning || alwaysLiveActive) ? 'animate-spin' : ''}`}
                style={{
                  animationDuration: scanEnabled && alwaysLiveActive && !isScanning ? '5s' : undefined,
                }}
              />
            </div>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-1.5">
                <h2 className="text-sm sm:text-base font-black text-white drop-shadow-[0_1px_4px_rgba(0,0,0,0.95)]">
                  {lang === 'AR' ? 'المباشر — مسح النطاق الحي' : 'Direct — Scan en direct'}
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/25 border border-emerald-400 text-emerald-200 font-black text-[10px] tabular-nums whitespace-nowrap">
                  {liveMatchesCount} {lang === 'AR' ? 'مباشر الآن' : 'en direct'}
                </span>
                <span
                  title={
                    lang === 'AR'
                      ? 'نتائج المباريات المنتهية مفعلة وتظهر دوماً في كل المباريات لمدة 24 ساعة'
                      : 'Les matchs terminés restent affichés 24h'
                  }
                  className="px-2 py-0.5 rounded-full bg-sky-500/20 border border-sky-300/75 text-sky-100 font-black text-[10px] tabular-nums inline-flex items-center gap-1 whitespace-nowrap"
                >
                  <CheckCircle2 className="w-3 h-3 text-yellow-300 shrink-0" />
                  <span>{finishedMatchesCount} {lang === 'AR' ? 'منتهية (مفعلة)' : 'terminés (actifs)'}</span>
                </span>
                <span
                  dir="ltr"
                  title={lang === 'AR' ? 'ساعة التوقيت +1' : 'Heure +1'}
                  className="px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-300/70 font-mono font-black text-[10px] tabular-nums inline-flex items-center gap-1 whitespace-nowrap text-amber-200"
                >
                  <Clock className="w-3 h-3 text-amber-300 shrink-0" />
                  <span>{timePlusOne} +1</span>
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-cyan-200/90 font-mono truncate" dir="ltr">
                promosport-pronostic.com/welcome/promosport •{' '}
                {scanEnabled
                  ? `${lang === 'AR' ? 'آخر مسح' : 'Dernier scan'} ${formattedScanClock}`
                  : lang === 'AR' ? 'نطاق المسح متوقف' : 'Scan arrêté'}
              </p>
            </div>
          </div>

          {/* Scan Enable/Stop Toggle + Always-Live Toggle + Scan Now + Live Notifications Bell + Small Manual Close Icon */}
          <div className="flex flex-wrap items-center gap-1.5">
            {/* 1. Domain Scan Enable / Stop Choice */}
            <button
              type="button"
              onClick={toggleScanEnabled}
              title={
                scanEnabled
                  ? lang === 'AR' ? 'توقيف مسح النطاق scan' : 'Arrêter le scan'
                  : lang === 'AR' ? 'تفعيل مسح النطاق scan' : 'Activer le scan'
              }
              className={`min-h-[38px] px-3 py-1.5 rounded-xl border font-black text-[11px] flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 whitespace-nowrap ${
                scanEnabled
                  ? 'bg-cyan-400 text-black border-white shadow-[0_0_14px_rgba(34,211,238,0.85)]'
                  : 'bg-red-950/75 text-red-200 border-red-400/70 hover:bg-red-900/80'
              }`}
            >
              <Power className="w-3.5 h-3.5 shrink-0" />
              <span>
                {scanEnabled
                  ? lang === 'AR' ? 'نطاق المسح: مفعل' : 'Scan : Activé'
                  : lang === 'AR' ? 'نطاق المسح: متوقف' : 'Scan : Arrêté'}
              </span>
            </button>

            {/* 2. Permanent Always-Live Toggle */}
            <button
              type="button"
              onClick={toggleAlwaysLive}
              className={`min-h-[38px] px-3 py-1.5 rounded-xl border font-black text-[11px] flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 whitespace-nowrap ${
                scanEnabled && alwaysLiveActive
                  ? 'bg-emerald-500 text-black border-white shadow-[0_0_14px_rgba(16,185,129,0.85)]'
                  : 'bg-black/60 text-gray-300 border-white/25 hover:border-emerald-400/70'
              }`}
            >
              <Radio className={`w-3.5 h-3.5 ${scanEnabled && alwaysLiveActive ? 'animate-pulse' : ''}`} />
              <span>
                {alwaysLiveActive
                  ? lang === 'AR' ? 'المباشر دوماً: مفعل' : 'Direct continu : ON'
                  : lang === 'AR' ? 'المباشر دوماً: متوقف' : 'Direct continu : OFF'}
              </span>
            </button>

            {/* 3. Scan Now Button */}
            <button
              type="button"
              onClick={() => {
                audioService.playClick();
                if (!scanEnabled) {
                  setScanEnabled(true);
                  saveLiveScanEnabled(true);
                  onScanEnabledChange?.(true);
                }
                void performScan(true, false);
              }}
              disabled={isScanning}
              className="min-h-[38px] px-3 py-1.5 rounded-xl bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-500 hover:brightness-105 text-black border border-yellow-100 font-black text-[11px] flex items-center gap-1.5 shadow-[0_0_14px_rgba(250,204,21,0.65)] transition-all cursor-pointer active:scale-95 disabled:opacity-70 whitespace-nowrap"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
              <span>
                {isScanning
                  ? lang === 'AR' ? 'جارٍ المسح...' : 'Scan...'
                  : lang === 'AR' ? 'مسح نطاق Scan' : 'Scanner'}
              </span>
            </button>

            {/* 4. Notifications Icon Strictly Inside المباشر */}
            <button
              type="button"
              onClick={() => {
                audioService.playClick();
                const next = !isNotificationsPanelOpen;
                setIsNotificationsPanelOpen(next);
                if (next) {
                  onMarkNotificationsRead?.();
                }
              }}
              title={lang === 'AR' ? 'سجل الإشعارات والتنبيهات المباشرة' : 'Journal des alertes en direct'}
              aria-label={lang === 'AR' ? 'سجل الإشعارات والتنبيهات' : 'Alertes en direct'}
              className={`relative min-w-[40px] min-h-[38px] px-2.5 py-1.5 rounded-xl border-2 font-black text-[11px] flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 whitespace-nowrap ${
                isNotificationsPanelOpen
                  ? 'bg-gradient-to-r from-yellow-300 to-amber-400 text-black border-white shadow-[0_0_16px_rgba(250,204,21,0.9)]'
                  : 'bg-gradient-to-br from-yellow-500/20 via-amber-900/40 to-slate-900 border-yellow-400/85 text-yellow-200 hover:border-yellow-200 shadow-[0_0_12px_rgba(250,204,21,0.4)]'
              }`}
            >
              <Bell className="w-4 h-4 shrink-0" />
              <span className="tabular-nums font-mono text-[10.5px]">
                {liveNotifications.length}
              </span>
              {unreadNotificationsCount > 0 && (
                <>
                  <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-red-600 border border-black animate-ping" />
                  <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-red-600 border border-black" />
                </>
              )}
            </button>

            {/* 5. Zoom Toggle Icon Inside Glass Scanner Bar */}
            <button
              type="button"
              data-no-flash="true"
              onClick={() => {
                if (isZoomBarOpen) {
                  closeZoomBarManually();
                } else {
                  openZoomBarManually();
                }
              }}
              title={
                isZoomBarOpen
                  ? lang === 'AR' ? 'إغلاق شريط الزوم' : 'Masquer le zoom'
                  : lang === 'AR' ? 'زوم للمقابلات المباشرة والغير المباشرة (30% - 160%)' : 'Zoom des matchs (30% - 160%)'
              }
              aria-label={lang === 'AR' ? 'أيقونة الزوم' : 'Zoom'}
              className={`min-h-[38px] px-2.5 py-1.5 rounded-xl border font-black text-[11px] flex items-center gap-1 transition-all cursor-pointer active:scale-95 whitespace-nowrap ${
                isZoomBarOpen
                  ? 'bg-gradient-to-r from-cyan-300 to-sky-400 text-black border-white shadow-[0_0_14px_rgba(34,211,238,0.85)]'
                  : 'bg-black/60 text-cyan-200 border-cyan-400/60 hover:border-cyan-300'
              }`}
            >
              <ZoomIn className="w-3.5 h-3.5 shrink-0" />
              <span>Zoom</span>
              <span className="font-mono tabular-nums text-[10.5px]" dir="ltr">
                {zoomPercent}%
              </span>
            </button>

            {/* 6. Small Manual Close Icon for Glass Scanner Bar */}
            <button
              type="button"
              data-no-flash="true"
              onClick={closeScannerBarManually}
              title={lang === 'AR' ? 'إغلاق شريط المسح يدوياً' : 'Réduire la barre'}
              aria-label={lang === 'AR' ? 'إغلاق شريط المسح يدوياً' : 'Réduire la barre'}
              className="min-w-[36px] min-h-[38px] p-1.5 rounded-xl bg-black/55 hover:bg-white/15 border border-white/35 text-sky-100 hover:text-white flex items-center justify-center active:scale-95 transition-all cursor-pointer shrink-0"
            >
              <ChevronUp className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* EXPANDABLE LIVE NOTIFICATIONS PANEL */}
        {isNotificationsPanelOpen && (
          <div className="rounded-2xl bg-[#040c1f]/95 border-2 border-yellow-400/75 p-3 shadow-[0_0_24px_rgba(250,204,21,0.28)] space-y-2.5 animate-fade-in">
            <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-white/10">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-yellow-300 shrink-0" />
                <span className="text-xs sm:text-sm font-black text-yellow-200">
                  {lang === 'AR'
                    ? `تنبيهات خانة المباشر وحدها (${liveNotifications.length})`
                    : `Alertes Direct uniquement (${liveNotifications.length})`}
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                {onOpenNotificationSettings && (
                  <button
                    type="button"
                    onClick={() => {
                      audioService.playClick();
                      onOpenNotificationSettings();
                    }}
                    title={lang === 'AR' ? 'إعدادات أصوات الإشعارات' : 'Paramètres des alertes'}
                    className="px-2.5 py-1 rounded-xl bg-sky-500/20 hover:bg-sky-500/35 border border-sky-400/60 text-sky-200 text-[10.5px] font-black flex items-center gap-1 cursor-pointer transition-all"
                  >
                    <Settings className="w-3.5 h-3.5" />
                    <span>{lang === 'AR' ? 'إعدادات التنبيه' : 'Paramètres'}</span>
                  </button>
                )}

                {liveNotifications.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      audioService.playClick();
                      onClearNotifications?.();
                    }}
                    title={lang === 'AR' ? 'فسخ جميع الإشعارات الحالية مع استقبال أي إشعار جديد' : 'Effacer toutes les alertes'}
                    className="px-2.5 py-1 rounded-xl bg-red-600/30 hover:bg-red-600 border border-red-400/75 text-red-100 text-[10.5px] font-black flex items-center gap-1 cursor-pointer active:scale-95 transition-all"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{lang === 'AR' ? 'فسخ الكل' : 'Tout effacer'}</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => {
                    audioService.playClick();
                    setIsNotificationsPanelOpen(false);
                  }}
                  aria-label={lang === 'AR' ? 'إغلاق قائمة الإشعارات' : 'Fermer'}
                  className="p-1 rounded-lg bg-white/10 hover:bg-white/20 text-gray-200 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {liveNotifications.length === 0 ? (
              <div className="py-4 text-center text-xs text-slate-300 font-bold">
                {lang === 'AR'
                  ? 'لا توجد إشعارات حالياً — ستظهر هنا كل الإشعارات والتنبيهات الجديدة فور ورودها.'
                  : 'Aucune alerte — les nouveaux buts et notifications apparaîtront ici dès réception.'}
              </div>
            ) : (
              <div className="space-y-1.5 max-h-60 overflow-y-auto [&::-webkit-scrollbar]:hidden">
                {liveNotifications.map((item) => {
                  const isGoal = item.kind === 'goal';
                  const isGrille = item.kind === 'grille' || item.kind === 'winners';
                  return (
                    <div
                      key={item.id}
                      role="button"
                      tabIndex={0}
                      onClick={() => onOpenNotification?.(item)}
                      onKeyDown={(event) => {
                        if (event.key === 'Enter' || event.key === ' ') {
                          event.preventDefault();
                          onOpenNotification?.(item);
                        }
                      }}
                      className={`flex items-center justify-between gap-2 px-2.5 py-2 rounded-xl border cursor-pointer hover:ring-2 hover:ring-yellow-300/60 transition-all ${
                        isGoal
                          ? 'bg-amber-500/15 border-amber-400/55'
                          : isGrille
                            ? 'bg-cyan-500/12 border-cyan-400/45'
                            : 'bg-slate-900/80 border-slate-700/75'
                      }`}
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <span
                          className={`shrink-0 w-6 h-6 rounded-lg flex items-center justify-center ${
                            isGoal
                              ? 'bg-amber-400 text-black'
                              : isGrille
                                ? 'bg-cyan-400 text-black'
                                : 'bg-emerald-500 text-black'
                          }`}
                        >
                          {isGoal ? (
                            <Zap className="w-3.5 h-3.5" />
                          ) : isGrille ? (
                            <Trophy className="w-3.5 h-3.5" />
                          ) : (
                            <Flame className="w-3.5 h-3.5" />
                          )}
                        </span>
                        <div className="min-w-0">
                          <div className="text-[11px] font-black text-white truncate">
                            {item.title}
                          </div>
                          <div className="text-[9.5px] text-slate-300 truncate">
                            {item.message}
                          </div>
                        </div>
                      </div>
                      <div className="shrink-0 flex flex-col items-end gap-0.5">
                        {item.scoreLabel && (
                          <span
                            dir="ltr"
                            className="px-1.5 py-0.5 rounded bg-black/70 border border-yellow-300/60 text-[10px] font-mono font-black text-yellow-200 tabular-nums"
                          >
                            {item.scoreLabel}
                          </span>
                        )}
                        <span
                          dir="ltr"
                          className="text-[9px] font-mono text-amber-200/85 tabular-nums"
                        >
                          {item.timestamp}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {!scanEnabled && (
          <div className="rounded-xl bg-amber-950/55 border border-amber-400/60 px-3 py-2 flex flex-wrap items-center justify-between gap-2 text-[11px]">
            <span className="font-bold text-amber-100">
              {lang === 'AR'
                ? 'نطاق المسح متوقف حالياً — المباريات المنتهية خلال آخر 24 ساعة تبقى محفوظة بالنتيجة والتاريخ.'
                : 'Le scan est arrêté — les matchs terminés des dernières 24h restent conservés.'}
            </span>
            <button
              type="button"
              onClick={toggleScanEnabled}
              className="px-2.5 py-1 rounded-lg bg-cyan-400 text-black font-black text-[10.5px] cursor-pointer active:scale-95"
            >
              {lang === 'AR' ? 'تفعيل المسح الآن' : 'Activer le scan'}
            </button>
          </div>
        )}

        {/* 4 Filter Mode Tabs Side-by-Side in One Single Row */}
        <div className="grid grid-cols-4 gap-1 sm:gap-1.5">
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              setFilterTab('all');
            }}
            className={`min-h-[42px] sm:min-h-[38px] px-1 sm:px-2.5 py-1 rounded-xl border text-[9.5px] sm:text-[11px] font-black flex flex-col sm:flex-row items-center justify-center gap-0.5 sm:gap-1.5 transition-all cursor-pointer whitespace-nowrap overflow-hidden ${
              filterTab === 'all'
                ? 'bg-sky-500 text-black border-white shadow-[0_0_14px_rgba(56,189,248,0.75)]'
                : 'bg-black/50 text-sky-100 border-sky-400/40 hover:border-sky-300'
            }`}
          >
            <Globe2 className="w-3.5 h-3.5 shrink-0" />
            <span className="tabular-nums truncate max-w-full">
              {lang === 'AR' ? 'كل المباريات' : 'Tous'} ({matches.length})
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              setFilterTab('live');
            }}
            className={`min-h-[42px] sm:min-h-[38px] px-1 sm:px-2.5 py-1 rounded-xl border text-[9.5px] sm:text-[11px] font-black flex flex-col sm:flex-row items-center justify-center gap-0.5 sm:gap-1.5 transition-all cursor-pointer whitespace-nowrap overflow-hidden ${
              filterTab === 'live'
                ? 'bg-emerald-500 text-black border-white shadow-[0_0_14px_rgba(16,185,129,0.75)]'
                : 'bg-black/50 text-emerald-200 border-emerald-400/40 hover:border-emerald-300'
            }`}
          >
            <Radio className="w-3.5 h-3.5 shrink-0" />
            <span className="tabular-nums truncate max-w-full">
              {lang === 'AR' ? 'المباشر' : 'Direct'} ({liveMatchesCount})
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              setFilterTab('watch');
            }}
            className={`min-h-[42px] sm:min-h-[38px] px-1 sm:px-2.5 py-1 rounded-xl border text-[9.5px] sm:text-[11px] font-black flex flex-col sm:flex-row items-center justify-center gap-0.5 sm:gap-1.5 transition-all cursor-pointer whitespace-nowrap overflow-hidden ${
              filterTab === 'watch'
                ? 'bg-cyan-400 text-black border-white shadow-[0_0_14px_rgba(34,211,238,0.75)]'
                : 'bg-black/50 text-cyan-200 border-cyan-400/40 hover:border-cyan-300'
            }`}
          >
            <Tv className="w-3.5 h-3.5 shrink-0" />
            <span className="tabular-nums truncate max-w-full">
              {lang === 'AR' ? 'المشاهدة' : 'Suivis'} ({watchMatchIds.length})
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              setFilterTab('favorites');
            }}
            className={`min-h-[42px] sm:min-h-[38px] px-1 sm:px-2.5 py-1 rounded-xl border text-[9.5px] sm:text-[11px] font-black flex flex-col sm:flex-row items-center justify-center gap-0.5 sm:gap-1.5 transition-all cursor-pointer whitespace-nowrap overflow-hidden ${
              filterTab === 'favorites'
                ? 'bg-gradient-to-r from-yellow-300 to-amber-500 text-black border-white shadow-[0_0_14px_rgba(250,204,21,0.85)]'
                : 'bg-black/50 text-yellow-200 border-yellow-400/40 hover:border-yellow-300'
            }`}
          >
            <Star className={`w-3.5 h-3.5 shrink-0 ${filterTab === 'favorites' ? 'fill-black' : ''}`} />
            <span className="tabular-nums truncate max-w-full">
              {lang === 'AR' ? 'التفضيلات' : 'Favoris'} ({favoriteMatchIds.length + favoriteLeagues.length})
            </span>
          </button>
        </div>

        {/* Compact League Filter Selector */}
        <div className="relative">
          <Filter
            className={`w-3.5 h-3.5 text-yellow-300 absolute ${
              lang === 'AR' ? 'right-3' : 'left-3'
            } top-1/2 -translate-y-1/2 pointer-events-none`}
          />
          <select
            value={selectedLeagueKey}
            onChange={(e) => {
              audioService.playClick();
              setSelectedLeagueKey(e.target.value);
            }}
            className={`w-full min-h-[36px] ${
              lang === 'AR' ? 'pr-8 pl-3' : 'pl-8 pr-3'
            } py-1 rounded-xl bg-black/70 border border-sky-400/45 focus:border-yellow-400 text-xs font-bold text-white outline-none cursor-pointer`}
          >
            <option value="ALL">
              {lang === 'AR' ? `كل الدوريات (${leagues.length})` : `Toutes les ligues (${leagues.length})`}
            </option>
            {orderedDropdownLeagues.map((l) => (
              <option key={l.leagueKey} value={l.leagueKey}>
                {favLeagueSet.has(l.leagueKey) ? '★ ' : ''}
                {lang === 'AR' ? l.countryAr : l.countryName} :{' '}
                {lang === 'AR' ? translateCompetitionToArabic(l.leagueName, l.leagueName) : l.leagueName} (
                {l.liveCount > 0 ? `${l.liveCount} ${lang === 'AR' ? 'مباشر' : 'direct'} / ` : ''}
                {l.totalCount})
              </option>
            ))}
          </select>
        </div>
            </div>
          </div>
        )}

        {/* 1B. COMPACT EDGE-TO-EDGE FROSTED ZOOM BAR (30% - 160%, يطبق على المباشر والغير مباشر) */}
        {isZoomBarOpen && (
          <div
            data-no-flash="true"
            className="pointer-events-auto w-full px-1.5 sm:px-3 pt-0.5 pb-1"
          >
            <form
              onSubmit={handleApplyNumericZoom}
              dir="ltr"
              className="w-full flex items-center gap-1 py-1 px-1 rounded-2xl backdrop-blur-md bg-[#040c1f]/75 border border-cyan-400/75 shadow-[0_6px_22px_rgba(0,0,0,0.55)]"
            >
              <button
                type="button"
                data-no-flash="true"
                disabled={zoom <= MIN_LIVE_ZOOM}
                onClick={() => {
                  audioService.playClick();
                  updateZoom((prev) => prev - LIVE_ZOOM_STEP);
                }}
                title={lang === 'AR' ? 'تصغير المقابلات حتى 30%' : 'Dézoomer (30%)'}
                aria-label="تصغير المقابلات"
                className="min-w-[36px] h-[34px] px-1.5 bg-[#07152f]/80 hover:bg-[#0b224a] border border-sky-400/75 text-sky-100 hover:text-white flex items-center justify-center active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shrink-0 rounded-xl"
              >
                <ZoomOut className="w-4 h-4" />
              </button>

              <div className="relative flex-1 min-w-[28px] h-[34px] flex items-center px-1.5 pointer-events-none select-none">
                <div className="relative w-full h-2 rounded-full bg-black/60 border border-sky-400/50 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-cyan-400 via-yellow-400 to-amber-500 transition-all duration-150"
                    style={{ width: `${trackProgressPct}%` }}
                  />
                </div>
                <div
                  className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-3.5 h-3.5 rounded-full bg-gradient-to-b from-yellow-300 to-amber-500 border-2 border-white shadow-[0_0_8px_rgba(250,204,21,0.85)] transition-all duration-150"
                  style={{ left: `calc(${trackProgressPct}% * 0.88 + 6%)` }}
                />
              </div>

              <div className="flex items-center gap-1 shrink-0">
                <div className="relative flex items-center">
                  <input
                    ref={numericInputRef}
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    maxLength={3}
                    value={zoomTextInput}
                    onChange={(e) => setZoomTextInput(e.target.value.replace(/[^\d]/g, '').slice(0, 3))}
                    onMouseDown={(e) => e.stopPropagation()}
                    onClick={(e) => e.stopPropagation()}
                    aria-label="نسبة الزوم بالأرقام من 30 إلى 160"
                    placeholder="30-160"
                    style={{ userSelect: 'text', WebkitUserSelect: 'text' }}
                    className="w-[52px] h-[32px] pr-4 pl-1 rounded-lg bg-black/70 border border-sky-400/80 focus:border-yellow-400 text-center font-mono tabular-nums text-xs font-black text-yellow-300 outline-none select-text"
                  />
                  <span className="absolute right-1 text-[10px] font-black text-gray-300 pointer-events-none">
                    %
                  </span>
                </div>

                <button
                  type="submit"
                  data-no-flash="true"
                  className="min-h-[32px] px-2.5 rounded-lg bg-gradient-to-r from-yellow-400 to-amber-500 hover:brightness-105 text-black font-black text-[11px] shadow active:scale-95 transition-all cursor-pointer whitespace-nowrap"
                >
                  {lang === 'AR' ? 'تنفيذ' : 'OK'}
                </button>

                {!isDefaultZoom && (
                  <button
                    type="button"
                    data-no-flash="true"
                    onClick={() => {
                      audioService.playClick();
                      updateZoom(1);
                    }}
                    title={lang === 'AR' ? 'إعادة الضبط 100%' : 'Reset 100%'}
                    aria-label="إعادة الضبط 100%"
                    className="min-w-[28px] h-[32px] rounded-lg bg-black/65 hover:bg-amber-500/35 border border-yellow-400/70 text-yellow-300 flex items-center justify-center active:scale-95 transition-all cursor-pointer shrink-0"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                )}

                <button
                  type="button"
                  data-no-flash="true"
                  onClick={closeZoomBarManually}
                  title={lang === 'AR' ? 'إخفاء شريط الزوم' : 'Masquer'}
                  aria-label="إخفاء شريط الزوم"
                  className="min-w-[28px] h-[32px] rounded-lg bg-black/55 hover:bg-white/15 border border-white/30 text-white flex items-center justify-center active:scale-95 transition-all cursor-pointer shrink-0"
                >
                  <ChevronUp className="w-3.5 h-3.5" />
                </button>
              </div>

              <button
                type="button"
                data-no-flash="true"
                disabled={zoom >= MAX_LIVE_ZOOM}
                onClick={() => {
                  audioService.playClick();
                  updateZoom((prev) => prev + LIVE_ZOOM_STEP);
                }}
                title={lang === 'AR' ? 'تكبير المقابلات' : 'Zoomer'}
                aria-label="تكبير المقابلات"
                className="min-w-[36px] h-[34px] px-1.5 bg-[#07152f]/80 hover:bg-[#0b224a] border border-sky-400/75 text-sky-100 hover:text-white flex items-center justify-center active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shrink-0 rounded-xl"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
            </form>
          </div>
        )}
      </div>

      {/* SCROLLABLE MATCHES AREA (يمر تحت شريط المسح الزجاجي ويخفيه تلقائياً، ويدعم الزوم للمقابلات المباشرة وغير المباشرة) */}
      <div
        ref={scrollContainerRef}
        onScroll={handleContainerScroll}
        onWheel={(e) => {
          if (!e.ctrlKey && !e.metaKey) {
            cancelActiveScrollAnchor();
            if (Math.abs(e.deltaY) > 10) {
              hideScannerBarOnScroll();
            }
          }
        }}
        onTouchStart={(e) => {
          cancelActiveScrollAnchor();
          if (e.touches.length === 1) {
            touchStartYRef.current = e.touches[0].clientY;
          } else {
            touchStartYRef.current = null;
          }
        }}
        onTouchMove={(e) => {
          if (e.touches.length === 1 && touchStartYRef.current !== null) {
            if (Math.abs(e.touches[0].clientY - touchStartYRef.current) > 12) {
              hideScannerBarOnScroll();
            }
          }
        }}
        onTouchEnd={() => {
          touchStartYRef.current = null;
        }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className="flex-1 overflow-y-auto overflow-x-hidden overscroll-contain px-2 sm:px-4 pb-[92px] cursor-grab active:cursor-grabbing [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]"
        style={{
          paddingTop: `${scannerSpacerHeight}px`,
          WebkitOverflowScrolling: 'touch',
        }}
      >
        <div
          ref={zoomViewportRef}
          dir="ltr"
          className="w-full overflow-x-hidden [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]"
          style={{
            touchAction: 'pan-y',
            WebkitOverflowScrolling: 'touch',
          }}
        >
          <div
            ref={scaledWrapperRef}
            style={{
              position: 'relative',
              width: '100%',
              height: !isDefaultZoom && scaledHeight > 0 ? `${scaledHeight}px` : 'auto',
            }}
          >
            <div
              ref={matchesContentRef}
              dir={lang === 'AR' ? 'rtl' : 'ltr'}
              className="space-y-3"
              style={
                isDefaultZoom
                  ? {
                      position: 'relative',
                      width: '100%',
                    }
                  : {
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      width: unscaledEdgeToEdgeWidth > 0 ? `${unscaledEdgeToEdgeWidth}px` : '100%',
                      transform: `scale(${zoom})`,
                      transformOrigin: 'top left',
                      willChange: 'transform',
                    }
              }
            >

      {/* 2. PINNED LIVE WATCH LIST */}
      {filterTab !== 'watch' && pinnedWatchedMatches.length > 0 && (
        <div className="space-y-3 rounded-3xl bg-gradient-to-b from-emerald-950/60 via-[#071832]/85 to-[#050e20]/90 border-2 border-emerald-400/75 p-2.5 sm:p-3.5 shadow-[0_0_24px_rgba(16,185,129,0.28)]">
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-2">
              <span className="w-7 h-7 rounded-xl bg-emerald-500 text-black flex items-center justify-center shadow">
                <Tv className="w-4 h-4" />
              </span>
              <div>
                <h3 className="text-xs sm:text-sm font-black text-emerald-200">
                  {lang === 'AR'
                    ? `المشاهدة المباشرة المختارة (${pinnedWatchedMatches.length})`
                    : `Matchs suivis en direct (${pinnedWatchedMatches.length})`}
                </h3>
                <p className="text-[10px] text-emerald-100/80">
                  {lang === 'AR'
                    ? 'تحديث فوري لحظة بلحظة للنتائج والدقائق المختارة'
                    : 'Mise à jour instantanée des scores et minutes suivis'}
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {pinnedWatchedMatches.map((rawMatch) => {
              const m = enrichMinuteForDisplay(rawMatch);
              const cardIdx = liveCardSequenceCursor++;
              return (
                <PinterestScoreboardCard
                  key={`pinned-${m.siteMatchId}`}
                  match={m}
                  lang={lang}
                  mode="live"
                  getTeamName={getTeamName}
                  justScoredGoal={Boolean(goalFlashMap[m.siteMatchId])}
                  isFavorite={favMatchSet.has(m.siteMatchId)}
                  onToggleFavorite={() => toggleFavoriteMatch(m.siteMatchId)}
                  isWatchingLive={true}
                  onToggleWatchLive={() => toggleWatchLiveMatch(m.siteMatchId)}
                  showTimeDateBar={isTimeDateBarVisible}
                  onToggleTimeDateBar={handleToggleTimeDateBar}
                  cardIndex={cardIdx}
                  timeDateTransitionDelayMs={getTimeDateTransitionDelayMs(cardIdx)}
                  animateTimeDateBar={hasToggledTimeDateBar}
                />
              );
            })}
          </div>
        </div>
      )}

      {/* 3. ERROR / INITIAL SCANNING / EMPTY STATES */}
      {scanError && matches.length === 0 ? (
        <div className="rounded-2xl bg-red-950/60 border border-red-400/70 p-5 text-center space-y-3">
          <p className="text-xs sm:text-sm font-bold text-red-200">{scanError}</p>
          <button
            type="button"
            onClick={() => void performScan(true, false)}
            className="min-h-[40px] px-4 py-2 rounded-xl bg-yellow-400 text-black font-black text-xs inline-flex items-center gap-2 cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
            <span>{lang === 'AR' ? 'إعادة المسح الآن' : 'Réessayer'}</span>
          </button>
        </div>
      ) : isScanning && matches.length === 0 ? (
        <div className="rounded-3xl bg-[#07152d]/90 border border-sky-400/50 p-8 text-center space-y-3">
          <RefreshCw className="w-8 h-8 text-cyan-300 animate-spin mx-auto" />
          <p className="text-sm font-black text-cyan-100">
            {lang === 'AR'
              ? 'جارٍ مسح النطاق المباشر واستخراج جميع الدوريات والمقابلات الصحيحة...'
              : 'Scan du flux en direct et extraction des ligues et matchs...'}
          </p>
          <p className="text-[11px] text-sky-300 font-mono" dir="ltr">
            https://www.promosport-pronostic.com/welcome/promosport
          </p>
        </div>
      ) : !scanEnabled && matches.length === 0 ? (
        <div className="rounded-3xl bg-[#07152d]/85 border border-amber-400/55 p-6 text-center space-y-2.5">
          <Power className="w-8 h-8 text-amber-300 mx-auto opacity-85" />
          <p className="text-sm font-black text-amber-100">
            {lang === 'AR'
              ? 'نطاق المسح Scan متوقف حالياً ولا توجد مباريات منتهية خلال آخر 24 ساعة'
              : 'Le scan en direct est arrêté et aucun match récent n’est enregistré.'}
          </p>
          <button
            type="button"
            onClick={toggleScanEnabled}
            className="min-h-[38px] px-4 py-1.5 rounded-xl bg-cyan-400 text-black font-black text-xs cursor-pointer active:scale-95"
          >
            {lang === 'AR' ? 'تفعيل نطاق المسح الآن' : 'Activer le scan maintenant'}
          </button>
        </div>
      ) : orderedLeagueGroups.length === 0 ? (
        <div className="rounded-3xl bg-[#07152d]/85 border border-sky-400/40 p-6 text-center space-y-2.5">
          <Trophy className="w-8 h-8 text-yellow-300 mx-auto opacity-80" />
          <p className="text-sm font-black text-gray-200">
            {lang === 'AR' ? 'لا توجد مقابلات مطابقة للتصفية الحالية' : 'Aucun match ne correspond à ce filtre'}
          </p>
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              setFilterTab('all');
              setSelectedLeagueKey('ALL');
            }}
            className="min-h-[38px] px-4 py-1.5 rounded-xl bg-sky-500 text-black font-black text-xs cursor-pointer"
          >
            {lang === 'AR' ? 'إظهار جميع المباريات' : 'Afficher tous les matchs'}
          </button>
        </div>
      ) : (
        /* 4. GROUPED ORDERED LEAGUES WITH EXACT GRILLE-STYLE MATCH CARDS */
        <div className="space-y-5">
          {orderedLeagueGroups.map((group) => {
            const { meta, matches: groupMatches, liveInGroup } = group;
            const isLeagueFav = favLeagueSet.has(meta.leagueKey);
            const flagImgKey = `flag:${meta.leagueKey}`;
            const logoImgKey = `logo:${meta.leagueKey}`;

            return (
              <section key={meta.leagueKey} className="space-y-3">
                {/* League Header Banner */}
                <div
                  className={`rounded-2xl px-3 py-2 border flex items-center justify-between gap-2 shadow-md ${
                    isLeagueFav
                      ? 'bg-gradient-to-r from-amber-950/85 via-[#18294e] to-amber-950/85 border-yellow-400/85 shadow-[0_0_16px_rgba(250,204,21,0.28)]'
                      : liveInGroup > 0
                      ? 'bg-gradient-to-r from-emerald-950/80 via-[#0a2346] to-[#081936] border-emerald-400/70'
                      : 'bg-gradient-to-r from-[#081732] via-[#0c234b] to-[#081732] border-sky-400/50'
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    {meta.countryFlagUrl && !failedImages[flagImgKey] ? (
                      <img
                        src={meta.countryFlagUrl}
                        alt={meta.countryName}
                        referrerPolicy="no-referrer"
                        loading="lazy"
                        onError={() => setFailedImages((p) => ({ ...p, [flagImgKey]: true }))}
                        className="w-6 h-4 object-cover rounded-sm border border-white/60 shrink-0"
                      />
                    ) : (
                      <Globe2 className="w-4 h-4 text-sky-300 shrink-0" />
                    )}

                    {meta.leagueLogoUrl && !failedImages[logoImgKey] && (
                      <img
                        src={meta.leagueLogoUrl}
                        alt={meta.leagueName}
                        referrerPolicy="no-referrer"
                        loading="lazy"
                        onError={() => setFailedImages((p) => ({ ...p, [logoImgKey]: true }))}
                        className="w-5 h-5 object-contain rounded-full bg-white/95 p-0.5 shrink-0"
                      />
                    )}

                    <div className="min-w-0">
                      <div className="text-xs sm:text-sm font-black text-white truncate">
                        {lang === 'AR' ? meta.countryAr : meta.countryName} —{' '}
                        <span className="text-yellow-200">
                          {lang === 'AR'
                            ? translateCompetitionToArabic(meta.leagueName, meta.leagueName)
                            : meta.leagueName}
                        </span>
                      </div>
                      <div className="text-[10px] text-sky-200/85 font-bold flex items-center gap-2 tabular-nums">
                        <span>
                          {groupMatches.length} {lang === 'AR' ? 'مقابلة' : groupMatches.length > 1 ? 'matchs' : 'match'}
                        </span>
                        {liveInGroup > 0 && (
                          <span className="text-emerald-300 font-black">
                            • {liveInGroup} {lang === 'AR' ? 'مباشر الآن' : 'en direct'}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Favorite League Toggle */}
                  <button
                    type="button"
                    onClick={() => toggleFavoriteLeague(meta.leagueKey)}
                    title={
                      isLeagueFav
                        ? lang === 'AR' ? 'إزالة الدوري من التفضيلات' : 'Retirer la ligue des favoris'
                        : lang === 'AR' ? 'تفضيل الدوري وتثبيته في الأعلى' : 'Épingler cette ligue en haut'
                    }
                    className={`min-h-[36px] px-2.5 py-1 rounded-xl border font-black text-[10.5px] flex items-center gap-1 transition-all cursor-pointer active:scale-95 shrink-0 whitespace-nowrap ${
                      isLeagueFav
                        ? 'bg-gradient-to-b from-yellow-300 to-amber-500 text-black border-white shadow-[0_0_12px_rgba(250,204,21,0.85)]'
                        : 'bg-black/55 hover:bg-amber-950/75 text-yellow-200 border-yellow-300/60'
                    }`}
                  >
                    <Star className={`w-3.5 h-3.5 shrink-0 ${isLeagueFav ? 'fill-black text-black' : ''}`} />
                    <span>
                      {isLeagueFav
                        ? lang === 'AR' ? 'دوري مفضل' : 'Ligue favorite'
                        : lang === 'AR' ? 'تفضيل الدوري' : 'Favori'}
                    </span>
                  </button>
                </div>

                {/* Match Cards Using Exact Grille Card Geometry & Colors (Scaled 50%) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {groupMatches.map((rawMatch) => {
                    const m = enrichMinuteForDisplay(rawMatch);
                    const cardIdx = liveCardSequenceCursor++;
                    return (
                      <PinterestScoreboardCard
                        key={m.siteMatchId}
                        match={m}
                        lang={lang}
                        mode="live"
                        getTeamName={getTeamName}
                        justScoredGoal={Boolean(goalFlashMap[m.siteMatchId])}
                        isFavorite={favMatchSet.has(m.siteMatchId)}
                        onToggleFavorite={() => toggleFavoriteMatch(m.siteMatchId)}
                        isWatchingLive={watchSet.has(m.siteMatchId)}
                        onToggleWatchLive={() => toggleWatchLiveMatch(m.siteMatchId)}
                        showTimeDateBar={isTimeDateBarVisible}
                        onToggleTimeDateBar={handleToggleTimeDateBar}
                        cardIndex={cardIdx}
                        timeDateTransitionDelayMs={getTimeDateTransitionDelayMs(cardIdx)}
                        animateTimeDateBar={hasToggledTimeDateBar}
                      />
                    );
                  })}
                </div>
              </section>
            );
          })}
        </div>
      )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
