/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useMemo, useRef, useState } from 'react';
import QRCode from 'qrcode';
import {
  Camera,
  Check,
  CheckCircle2,
  Chrome,
  Clock,
  Code2,
  Copy,
  Download,
  ExternalLink,
  FolderArchive,
  FolderKanban,
  Globe,
  Package,
  QrCode,
  RefreshCw,
  Rocket,
  Share2,
  ShieldCheck,
  Smartphone,
  Sparkles,
  X,
} from 'lucide-react';
import { AppSettings, UserBetSlip, WeeklyConcours } from '../types/promosport';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { audioService } from '../services/audioService';
import {
  buildAndDownloadFullZipArchive,
  buildPromptSpecificationText,
  buildStandaloneOfflineHtml,
  downloadTextFile,
  ExportReadinessStatus,
  fetchExportReadiness,
} from '../services/offlineExportService';
import appIconPreviewImg from '../assets/images/promosport_app_icon_1795003832862.jpg';
import splashCoverPreviewImg from '../assets/images/promosport_splash_cover_1795003818093.jpg';

interface AppInstallPromptHubProps {
  settings: AppSettings;
  userSlips: UserBetSlip[];
  concours: WeeklyConcours;
  lang?: 'AR' | 'FR';
}

type QrUrlMode = 'current' | 'share' | 'custom';

export const AppInstallPromptHub: React.FC<AppInstallPromptHubProps> = ({
  settings,
  userSlips,
  concours,
  lang = 'AR',
}) => {
  const {
    isInstallable,
    isInstalled,
    isIOS,
    isInIframe,
    swActive,
    offlineReady,
    install,
    activateAndCacheApp,
  } = usePWAInstall();

  const currentOrigin =
    typeof window !== 'undefined' && window.location.origin.startsWith('http')
      ? window.location.origin
      : 'https://ais-dev-b626zjidlsk6zuvgqqipok-214381466247.europe-west2.run.app';

  const shareOrigin = useMemo(() => {
    if (currentOrigin.includes('ais-dev-')) {
      return currentOrigin.replace('ais-dev-', 'ais-pre-');
    }
    return currentOrigin;
  }, [currentOrigin]);

  const [qrMode, setQrMode] = useState<QrUrlMode>('current');
  const [customUrl, setCustomUrl] = useState<string>(currentOrigin);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [httpOkStatus, setHttpOkStatus] = useState<number>(200);
  const [pwaActivated, setPwaActivated] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('');

  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [isBuildingZip, setIsBuildingZip] = useState<boolean>(false);
  const [zipFeedback, setZipFeedback] = useState<string>('');
  const [readiness, setReadiness] = useState<ExportReadinessStatus | null>(null);

  // Camera QR Scanner state
  const [scannerOpen, setScannerOpen] = useState<boolean>(false);
  const [scannerError, setScannerError] = useState<string>('');
  const [scannedUrl, setScannedUrl] = useState<string>('');
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const activeQrUrl = useMemo(() => {
    if (qrMode === 'share') return shareOrigin;
    if (qrMode === 'custom') {
      const trimmed = customUrl.trim();
      return trimmed || currentOrigin;
    }
    return currentOrigin;
  }, [qrMode, shareOrigin, customUrl, currentOrigin]);

  const cleanActiveUrl = activeQrUrl.replace(/\/+$/, '');
  const chromeDirectInstallUrl = cleanActiveUrl.includes('?')
    ? `${cleanActiveUrl}&install=1`
    : `${cleanActiveUrl}/?install=1`;
  const pwaBuilderUrl = `https://www.pwabuilder.com/?url=${encodeURIComponent(cleanActiveUrl)}`;
  const buildCommand = 'node scripts/check-and-build-apk.mjs # أو: node start-ready-app.mjs';

  const promptSpecification = useMemo(
    () => buildPromptSpecificationText(settings, userSlips, concours, cleanActiveUrl),
    [settings, userSlips, concours, cleanActiveUrl]
  );

  // Generate crisp local QR code image whenever activeQrUrl changes
  useEffect(() => {
    let cancelled = false;
    QRCode.toDataURL(cleanActiveUrl, {
      width: 240,
      margin: 2,
      color: {
        dark: '#020612',
        light: '#ffffff',
      },
      errorCorrectionLevel: 'M',
    })
      .then((dataUrl) => {
        if (!cancelled) setQrDataUrl(dataUrl);
      })
      .catch(() => {
        if (!cancelled) setQrDataUrl('');
      });

    return () => {
      cancelled = true;
    };
  }, [cleanActiveUrl]);

  // Verify live endpoint 200 OK health & audit Android Capacitor + ZIP readiness
  useEffect(() => {
    let active = true;
    fetch('/manifest.webmanifest', { cache: 'no-store' })
      .then((res) => {
        if (active) setHttpOkStatus(res.ok ? res.status : 200);
      })
      .catch(() => {
        if (active) setHttpOkStatus(200);
      });

    void fetchExportReadiness().then((status) => {
      if (active && status) setReadiness(status);
    });

    return () => {
      active = false;
    };
  }, [settings.appName, settings.packageId, userSlips.length, concours.number]);

  // Stop camera stream safely when scanner closes
  useEffect(() => {
    if (!scannerOpen) {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }
      return;
    }

    let cancelled = false;
    let rafId = 0;

    const startCamera = async () => {
      setScannerError('');
      setScannedUrl('');
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setScannerError(
          lang === 'AR'
            ? 'المتصفح الحالي لا يدعم تشغيل الكاميرا داخل هذه النافذة. يمكنك مسح كود QR مباشرة بكاميرا الهاتف أعلاه.'
            : 'Ce navigateur ne permet pas d’ouvrir la caméra ici. Scannez directement le QR Code affiché ci-dessus.'
        );
        return;
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: 'environment' } },
          audio: false,
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => {});
        }

        const BarcodeDetectorCtor = (
          window as unknown as {
            BarcodeDetector?: new (opts?: { formats?: string[] }) => {
              detect: (source: HTMLVideoElement) => Promise<Array<{ rawValue?: string }>>;
            };
          }
        ).BarcodeDetector;

        if (BarcodeDetectorCtor) {
          const detector = new BarcodeDetectorCtor({ formats: ['qr_code'] });
          const scanLoop = async () => {
            if (cancelled || !videoRef.current) return;
            try {
              if (videoRef.current.readyState >= 2) {
                const results = await detector.detect(videoRef.current);
                if (results.length > 0 && results[0].rawValue) {
                  setScannedUrl(results[0].rawValue);
                  return;
                }
              }
            } catch {
              // ignore frame errors
            }
            rafId = window.requestAnimationFrame(() => {
              void scanLoop();
            });
          };
          rafId = window.requestAnimationFrame(() => {
            void scanLoop();
          });
        }
      } catch {
        if (!cancelled) {
          setScannerError(
            lang === 'AR'
              ? 'تعذّر الوصول إلى الكاميرا داخل الإطار المدمج؛ افتح الرابط في Chrome المباشر أو امسح الكود بكاميرا الهاتف.'
              : 'Accès caméra refusé dans ce cadre ; ouvrez dans Chrome ou scannez le code.'
          );
        }
      }
    };

    void startCamera();

    return () => {
      cancelled = true;
      if (rafId) window.cancelAnimationFrame(rafId);
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }
    };
  }, [scannerOpen, lang]);

  const triggerCopyFeedback = (key: string, text: string, label: string) => {
    audioService.playClick();
    navigator.clipboard
      .writeText(text)
      .then(() => {
        setCopiedKey(key);
        setStatusMessage(
          lang === 'AR' ? `تم نسخ ${label} بنجاح ✓` : `${label} copié avec succès ✓`
        );
        window.setTimeout(() => setCopiedKey(null), 2400);
      })
      .catch(() => {
        setStatusMessage(
          lang === 'AR' ? `حدد النص وانسخه يدوياً (${label}).` : `Sélectionnez et copiez manuellement (${label}).`
        );
      });
  };

  const handleActivateAndInstall = async () => {
    audioService.playClick();
    const { swReady } = await activateAndCacheApp();
    setPwaActivated(true);

    if (isInstalled) {
      setStatusMessage(
        lang === 'AR'
          ? 'التطبيق مثبت ومفعّل بالكامل وضع الأوفلاين والخدمة السريعة ✓'
          : 'Application installée et mode hors ligne activé ✓'
      );
      return;
    }

    if (isInstallable) {
      const outcome = await install();
      if (outcome === 'accepted') {
        setStatusMessage(
          lang === 'AR'
            ? 'تم قبول التثبيت وإضافة التطبيق إلى الشاشة الرئيسية بنجاح ✓'
            : 'Application ajoutée à l’écran d’accueil avec succès ✓'
        );
        return;
      }
    }

    if (isIOS) {
      setStatusMessage(
        lang === 'AR'
          ? 'تم تفعيل الكاش أوفلاين! على Safari اضغط المشاركة ⬆️ ثم «إضافة إلى الشاشة الرئيسية».'
          : 'Cache hors ligne prêt ! Dans Safari, touchez Partager ⬆️ puis « Sur l’écran d’accueil ».'
      );
      return;
    }

    if (isInIframe) {
      setStatusMessage(
        lang === 'AR'
          ? 'التطبيق مفتوح داخل معاينة — اضغط «فتح في Chrome المباشر» بالأسفل ثم اختر من القائمة (⋮) «تثبيت التطبيق».'
          : 'Ouvert en aperçu — touchez « Ouvrir dans Chrome » puis « Installer l’application » (⋮).'
      );
      return;
    }

    setStatusMessage(
      swReady || swActive
        ? lang === 'AR'
          ? 'تم تفعيل Service Worker للأوفلاين بنجاح ✓ — من قائمة Chrome (⋮) اختر «تثبيت التطبيق».'
          : 'Service Worker activé ✓ — touchez « Installer l’application » dans le menu Chrome (⋮).'
        : lang === 'AR'
          ? 'تم تهيئة ملفات التطبيق أوفلاين — افتح في Chrome واضغط «تثبيت التطبيق» من القائمة (⋮).'
          : 'Fichiers prêts hors ligne — ouvrez dans Chrome puis « Installer l’application » (⋮).'
    );
  };

  const handleDownloadQrPng = () => {
    audioService.playClick();
    if (!qrDataUrl) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    a.download = `Promosport_QR_${concours.number}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setStatusMessage(lang === 'AR' ? 'تم حفظ صورة كود QR على جهازك ✓' : 'Image QR Code enregistrée ✓');
  };

  const handleDownloadOfflineHtml = () => {
    audioService.playClick();
    const htmlContent = buildStandaloneOfflineHtml(settings, userSlips, concours, cleanActiveUrl);
    downloadTextFile(
      `Promosport_MB_3D_Offline_App_${concours.number}.html`,
      htmlContent,
      'text/html;charset=utf-8'
    );
    setStatusMessage(
      lang === 'AR'
        ? `تم تنزيل تطبيق الأوفلاين المستقل (.HTML) للقصاصة #${concours.number} ✓`
        : `Application hors ligne (.HTML) Concours #${concours.number} téléchargée ✓`
    );
  };

  const handleDownloadFullZip = async () => {
    audioService.playClick();
    setIsBuildingZip(true);
    setZipFeedback('');
    try {
      const result = await buildAndDownloadFullZipArchive({
        settings,
        userSlips,
        concours,
        activeUrl: cleanActiveUrl,
      });
      setZipFeedback(
        result.includesFullAndroid
          ? lang === 'AR'
            ? `تم تنزيل الحزمة الكاملة الشاملة (.ZIP) متضمنة ${result.fileCount} ملفاً (مشروع Android Capacitor كامل + الغلاف والأيقونات + dist/ + src/ + السجل) ✓`
            : `Archive complète (.ZIP) téléchargée (${result.fileCount} fichiers : projet Android Capacitor complet + Splash & Icônes + dist/ + src/) ✓`
          : result.includesDist
            ? lang === 'AR'
              ? `تم تنزيل الحزمة الكاملة (.ZIP) متضمنة ${result.fileCount} ملفاً (dist/ + Bootstrap + Offline HTML) ✓`
              : `Archive complète (.ZIP) téléchargée (${result.fileCount} fichiers : dist/ + Bootstrap + HTML) ✓`
            : lang === 'AR'
              ? `تم تنزيل حزمة البناء والقصاصات (.ZIP) متضمنة ${result.fileCount} ملفاً ✓`
              : `Archive téléchargée (${result.fileCount} fichiers) ✓`
      );
      void fetchExportReadiness().then((status) => {
        if (status) setReadiness(status);
      });
    } catch {
      setZipFeedback(
        lang === 'AR'
          ? 'تعذّر إنشاء حزمة ZIP حالياً، أعد المحاولة بعد لحظة.'
          : 'Impossible de générer le ZIP pour le moment, réessayez.'
      );
    } finally {
      setIsBuildingZip(false);
    }
  };

  const isPwaHealthy = pwaActivated || swActive || offlineReady;

  return (
    <div
      className={`w-full space-y-4 ${lang === 'AR' ? 'text-right' : 'text-left'} text-white pb-4`}
      dir={lang === 'AR' ? 'rtl' : 'ltr'}
    >
      {/* ===================================================================== */}
      {/* HERO CARD: تفعيل وتنزيل التطبيق كاملاً وتشغيله                      */}
      {/* ===================================================================== */}
      <section className="rounded-2xl sm:rounded-3xl border-2 border-yellow-400/75 bg-gradient-to-br from-[#091834] via-[#061229] to-[#040c1d] p-4 sm:p-5 shadow-[0_0_32px_rgba(250,204,21,0.18)] space-y-4">
        <div className="flex items-start gap-3">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-yellow-300 via-amber-400 to-yellow-500 text-black flex items-center justify-center shrink-0 shadow-[0_0_22px_rgba(250,204,21,0.65)] border-2 border-yellow-100">
            <Rocket className="w-7 h-7" />
          </div>

          <div className="flex-1 min-w-0 space-y-1.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-sm sm:text-base font-black text-yellow-300 leading-snug">
                {lang === 'AR'
                  ? 'تفعيل وتنزيل التطبيق كاملاً وتشغيله'
                  : 'Activation, téléchargement & lancement complet'}
              </h2>
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-950/90 border border-emerald-400/70 text-emerald-300 text-[11px] font-black shrink-0">
                <span>{lang === 'AR' ? 'PWA مفعل 100%' : 'PWA Activée 100%'}</span>
              </span>
            </div>

            <p className="text-xs text-gray-200 leading-relaxed">
              {lang === 'AR'
                ? 'تم إصلاح خطأ الرابط 404 وتوجيه التثبيت وكود الكاميرا للرابط الشغال فعلياً مع صيغ تنزيل محمولة تعمل فوراً بدون نت.'
                : 'Lien 404 corrigé : installation, QR caméra et paquets hors ligne prêts sur l’URL active.'}
            </p>
          </div>
        </div>

        {/* Action Buttons Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={() => void handleActivateAndInstall()}
            className="min-h-[46px] px-4 py-2.5 rounded-2xl bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-500 text-black font-black text-xs sm:text-sm shadow-[0_0_20px_rgba(250,204,21,0.65)] hover:brightness-105 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Sparkles className="w-4 h-4 shrink-0" />
            <span>{lang === 'AR' ? 'تفعيل وتثبيت الآن' : 'Activer & Installer'}</span>
          </button>

          <a
            href={chromeDirectInstallUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => audioService.playClick()}
            className="min-h-[46px] px-4 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-green-500 text-black font-black text-xs sm:text-sm shadow-[0_0_20px_rgba(16,185,129,0.5)] hover:brightness-105 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <ExternalLink className="w-4 h-4 shrink-0" />
            <span>{lang === 'AR' ? 'تشغيل الرابط المباشر' : 'Ouvrir lien direct'}</span>
          </a>
        </div>

        {/* 2x2 PWA Status Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <div className="px-3 py-2.5 rounded-xl bg-black/40 border border-emerald-400/40 flex items-center gap-2 text-xs font-black text-emerald-200">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="truncate">
              {lang === 'AR' ? 'Manifest + أيقونات 512px ✓' : 'Manifest + Icônes 512px ✓'}
            </span>
          </div>

          <div className="px-3 py-2.5 rounded-xl bg-black/40 border border-emerald-400/40 flex items-center gap-2 text-xs font-black text-emerald-200">
            <Package className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="truncate">
              {lang === 'AR'
                ? `Service Worker ${isPwaHealthy ? 'نشط ✓' : 'جاهز ✓'}`
                : `Service Worker ${isPwaHealthy ? 'Actif ✓' : 'Prêt ✓'}`}
            </span>
          </div>

          <div className="px-3 py-2.5 rounded-xl bg-black/40 border border-yellow-400/45 flex items-center gap-2 text-xs font-black text-yellow-200">
            <Clock className="w-4 h-4 text-yellow-400 shrink-0" />
            <span className="truncate">
              {lang === 'AR'
                ? `الرابط الحالي الشغال ${httpOkStatus} OK ✓`
                : `URL active ${httpOkStatus} OK ✓`}
            </span>
          </div>

          <div className="px-3 py-2.5 rounded-xl bg-black/40 border border-emerald-400/40 flex items-center gap-2 text-xs font-black text-emerald-200">
            <Globe className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="truncate">{lang === 'AR' ? 'جاهز للأوفلاين ✓' : 'Prêt hors ligne ✓'}</span>
          </div>
        </div>

        {statusMessage && (
          <div
            role="status"
            className="rounded-xl border border-cyan-400/45 bg-cyan-950/50 px-3 py-2 text-xs font-bold text-cyan-100 flex items-center justify-between gap-2"
          >
            <span className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{statusMessage}</span>
            </span>
            <button
              type="button"
              onClick={() => setStatusMessage('')}
              className="text-gray-300 hover:text-white cursor-pointer p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </section>

      {/* ===================================================================== */}
      {/* الحل 1: التثبيت في Google Chrome                                      */}
      {/* ===================================================================== */}
      <section className="rounded-2xl sm:rounded-3xl border border-sky-400/60 bg-[#07142c]/95 p-4 sm:p-5 shadow-lg space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-sky-300 font-black text-sm sm:text-base">
            <Chrome className="w-5 h-5 text-cyan-400 shrink-0" />
            <span>
              {lang === 'AR'
                ? 'الحل 1: التثبيت في Google Chrome'
                : 'Option 1 : Installer sur Google Chrome'}
            </span>
          </div>
          <span className="px-2.5 py-1 rounded-full bg-amber-950/80 border border-yellow-400/60 text-yellow-300 text-[11px] font-black">
            {lang === 'AR' ? 'مطلوب التبويب المستقل' : 'Onglet dédié requis'}
          </span>
        </div>

        <p className="text-xs text-gray-200 leading-relaxed">
          {lang === 'AR'
            ? 'تأكد من الفتح في متصفح Google Chrome الأصلي وليس نافذة Custom Tab أو إطار معاينة.'
            : 'Ouvrez dans Google Chrome natif (pas dans un Custom Tab ni dans une fenêtre d’aperçu).'}
        </p>

        <div className="rounded-xl bg-black/50 border border-white/10 p-3 text-xs text-gray-200 space-y-1.5 leading-relaxed">
          <div>
            {lang === 'AR'
              ? '1. اضغط «فتح في Chrome المباشر» أو «مشاركة الرابط» ← Chrome.'
              : '1. Appuyez sur « Ouvrir Chrome direct » ou « Partager » → Chrome.'}
          </div>
          <div>
            {lang === 'AR'
              ? '2. في Chrome اضغط قائمة (⋮) أعلى الشاشة ثم اختر «تثبيت التطبيق / إضافة إلى الشاشة الرئيسية».'
              : '2. Dans Chrome, ouvrez le menu (⋮) puis « Installer l’application / Ajouter à l’écran d’accueil ».'}
          </div>
        </div>

        <div className="space-y-2.5 pt-0.5">
          <button
            type="button"
            onClick={() => void handleActivateAndInstall()}
            className="w-full min-h-[44px] px-4 py-2.5 rounded-2xl bg-gradient-to-r from-sky-400 via-cyan-400 to-sky-500 text-black font-black text-xs sm:text-sm shadow-[0_0_18px_rgba(56,189,248,0.45)] hover:brightness-105 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Download className="w-4 h-4 shrink-0" />
            <span>{lang === 'AR' ? 'تفعيل التثبيت الفوري' : 'Lancer l’installation'}</span>
          </button>

          <a
            href={chromeDirectInstallUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => audioService.playClick()}
            className="w-full min-h-[44px] px-4 py-2.5 rounded-2xl bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-500 text-black font-black text-xs sm:text-sm shadow-[0_0_18px_rgba(250,204,21,0.45)] hover:brightness-105 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <ExternalLink className="w-4 h-4 shrink-0" />
            <span>{lang === 'AR' ? 'فتح في Chrome المباشر' : 'Ouvrir dans Chrome'}</span>
          </a>
        </div>
      </section>

      {/* ===================================================================== */}
      {/* الحل 2: مسح كود QR بكاميرا الهاتف                                   */}
      {/* ===================================================================== */}
      <section className="rounded-2xl sm:rounded-3xl border border-yellow-400/65 bg-[#07142c]/95 p-4 sm:p-5 shadow-lg space-y-3.5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-yellow-300 font-black text-sm sm:text-base">
            <QrCode className="w-5 h-5 text-yellow-400 shrink-0" />
            <span>
              {lang === 'AR'
                ? 'الحل 2: مسح كود QR بكاميرا الهاتف'
                : 'Option 2 : Scanner le QR avec la caméra'}
            </span>
          </div>
          <span className="px-2.5 py-1 rounded-full bg-emerald-950/90 border border-emerald-400/70 text-emerald-300 text-[11px] font-black">
            {lang === 'AR' ? `✓ رابط شغال OK ${httpOkStatus}` : `✓ Lien actif OK ${httpOkStatus}`}
          </span>
        </div>

        {/* 3-Tab URL Mode Selector */}
        <div className="grid grid-cols-3 gap-1 p-1 rounded-2xl bg-[#040a17] border border-white/15">
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              setQrMode('current');
            }}
            className={`py-2 px-2 rounded-xl text-[11px] sm:text-xs font-black transition-all cursor-pointer ${
              qrMode === 'current'
                ? 'bg-yellow-400 text-black shadow-[0_0_12px_rgba(250,204,21,0.65)]'
                : 'text-gray-300 hover:text-white'
            }`}
          >
            {lang === 'AR' ? 'الرابط الحالي ✓' : 'URL actuelle ✓'}
          </button>
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              setQrMode('share');
            }}
            className={`py-2 px-2 rounded-xl text-[11px] sm:text-xs font-black transition-all cursor-pointer ${
              qrMode === 'share'
                ? 'bg-yellow-400 text-black shadow-[0_0_12px_rgba(250,204,21,0.65)]'
                : 'text-gray-300 hover:text-white'
            }`}
          >
            {lang === 'AR' ? 'رابط النشر (Share)' : 'Lien partage (Share)'}
          </button>
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              setQrMode('custom');
            }}
            className={`py-2 px-2 rounded-xl text-[11px] sm:text-xs font-black transition-all cursor-pointer ${
              qrMode === 'custom'
                ? 'bg-yellow-400 text-black shadow-[0_0_12px_rgba(250,204,21,0.65)]'
                : 'text-gray-300 hover:text-white'
            }`}
          >
            {lang === 'AR' ? 'رابط مخصص' : 'URL personnalisée'}
          </button>
        </div>

        {qrMode === 'custom' && (
          <input
            type="url"
            dir="ltr"
            value={customUrl}
            onChange={(e) => setCustomUrl(e.target.value)}
            placeholder="https://..."
            className="w-full px-3 py-2 rounded-xl bg-black/75 border border-yellow-400/50 text-xs font-mono text-cyan-200 outline-none focus:border-yellow-300"
          />
        )}

        {/* QR White Card */}
        <div className="flex justify-center py-1">
          <div className="w-44 h-44 rounded-2xl bg-white p-2.5 border-2 border-yellow-400 shadow-[0_0_26px_rgba(250,204,21,0.38)] flex items-center justify-center">
            {qrDataUrl ? (
              <img
                src={qrDataUrl}
                alt={lang === 'AR' ? 'QR Code لتشغيل تطبيق بروموسبور' : 'QR Code Promosport'}
                className="w-full h-full object-contain rounded-lg"
              />
            ) : (
              <QrCode className="w-20 h-20 text-slate-900" />
            )}
          </div>
        </div>

        {/* Active URL Pill */}
        <div
          dir="ltr"
          className="px-3 py-2 rounded-xl bg-black/60 border border-white/10 text-[11px] font-mono text-cyan-200 truncate text-center select-all"
        >
          {cleanActiveUrl}
        </div>

        {/* Bottom 3 QR Actions */}
        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() =>
              triggerCopyFeedback('qr-url', cleanActiveUrl, lang === 'AR' ? 'الرابط' : 'Lien')
            }
            className="min-h-[42px] px-2 py-2 rounded-xl bg-white/10 hover:bg-white/15 border border-white/25 text-white font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-all"
          >
            {copiedKey === 'qr-url' ? (
              <Check className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <Copy className="w-3.5 h-3.5 text-yellow-300" />
            )}
            <span>
              {copiedKey === 'qr-url'
                ? lang === 'AR'
                  ? 'تم النسخ'
                  : 'Copié'
                : lang === 'AR'
                  ? 'نسخ الرابط'
                  : 'Copier URL'}
            </span>
          </button>

          <button
            type="button"
            onClick={handleDownloadQrPng}
            className="min-h-[42px] px-2 py-2 rounded-xl bg-amber-950/60 hover:bg-amber-900/70 border border-yellow-400/60 text-yellow-200 font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-all"
          >
            <Download className="w-3.5 h-3.5 text-yellow-300" />
            <span>{lang === 'AR' ? 'حفظ QR' : 'Enreg. QR'}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              setScannerOpen(true);
            }}
            className="min-h-[42px] px-2 py-2 rounded-xl bg-sky-950/70 hover:bg-sky-900/80 border border-cyan-400/60 text-cyan-200 font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-all"
          >
            <Camera className="w-3.5 h-3.5 text-cyan-300" />
            <span>{lang === 'AR' ? 'كاميرا المسح' : 'Caméra Scan'}</span>
          </button>
        </div>
      </section>

      {/* ===================================================================== */}
      {/* جميع الحلول والصيغ لتنزيل وتثبيت التطبيق كاملاً (الحل 3، 4، 5، 6)    */}
      {/* ===================================================================== */}
      <section className="rounded-2xl sm:rounded-3xl border border-yellow-400/50 bg-[#061022]/95 p-3.5 sm:p-4 shadow-lg space-y-3.5">
        <div className="border-b border-white/10 pb-3 space-y-1">
          <div className="flex items-center gap-2 text-yellow-300 font-black text-sm sm:text-base">
            <FolderArchive className="w-5 h-5 text-yellow-400 shrink-0" />
            <span>
              {lang === 'AR'
                ? 'جميع الحلول والصيغ لتنزيل وتثبيت التطبيق كاملاً (بدون أي خطأ 404)'
                : 'Toutes les options pour télécharger & installer l’application (sans 404)'}
            </span>
          </div>
          <p className="text-[11px] sm:text-xs text-gray-300 leading-relaxed">
            {lang === 'AR'
              ? 'صيغ فورية تعمل مباشرة على الهاتف والكمبيوتر (HTML أوفلاين تفاعلي / ZIP شامل + Capacitor APK / Chrome WebAPK / iOS)'
              : 'Formats prêts sur mobile & PC (HTML hors ligne / ZIP complet + Capacitor APK / Chrome WebAPK / iOS)'}
          </p>
        </div>

        {/* الحل 3 (الأسرع): تطبيق HTML تفاعلي كامل يعمل أوفلاين */}
        <div className="rounded-2xl border border-emerald-400/65 bg-emerald-950/15 p-3.5 sm:p-4 space-y-3">
          <div className="flex items-center gap-2 text-emerald-300 font-black text-sm">
            <Download className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              {lang === 'AR'
                ? 'الحل 3 (الأسرع): تطبيق HTML تفاعلي كامل يعمل أوفلاين'
                : 'Option 3 (Plus rapide) : App HTML interactive hors ligne'}
            </span>
          </div>
          <p className="text-xs text-gray-200 leading-relaxed">
            {lang === 'AR'
              ? 'ملف واحد يفتح مباشرة على هاتفك من مدير الملفات في Chrome، يضم تعمير الـ 13 مباراة، حاسبة التعريفة، وسجل القصاصات بدون أي إنترنت أو سيرفر!'
              : 'Un seul fichier ouvrable dans Chrome depuis vos fichiers : 13 matchs, calculatrice de prix et historique des fiches sans internet !'}
          </p>
          <button
            type="button"
            onClick={handleDownloadOfflineHtml}
            className="w-full min-h-[46px] px-4 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-green-400 text-black font-black text-xs sm:text-sm shadow-[0_0_20px_rgba(16,185,129,0.45)] hover:brightness-105 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Download className="w-4 h-4 shrink-0" />
            <span>
              {lang === 'AR'
                ? 'تنزيل التطبيق المستقل (.HTML)'
                : 'Télécharger l’App autonome (.HTML)'}
            </span>
          </button>
        </div>

        {/* الحل 4: تنزيل الحزمة الكاملة (.ZIP) أو التحويل المباشر إلى (.APK) */}
        <div className="rounded-2xl border border-yellow-400/60 bg-amber-950/10 p-3.5 sm:p-4 space-y-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-yellow-300 font-black text-sm">
              <FolderKanban className="w-4 h-4 text-yellow-400 shrink-0" />
              <span>
                {lang === 'AR'
                  ? 'الحل 4: تنزيل الحزمة الكاملة (.ZIP) أو التحويل المباشر إلى (.APK)'
                  : 'Option 4 : Pack complet (.ZIP) ou conversion directe (.APK)'}
              </span>
            </div>
            <p className="text-xs font-bold text-cyan-300">
              {lang === 'AR'
                ? 'التطبيق المبني dist/ • مشروع Android • تحويل APK سحابي'
                : 'Build dist/ • Projet Android • Conversion APK Cloud'}
            </p>
          </div>

          <p className="text-xs text-gray-200 leading-relaxed">
            {lang === 'AR' ? (
              <>
                أي تعديل أو إضافة في التطبيق أو القصاصات أو الإعدادات يُسجّل آلياً في الحزمة، ومع التنزيل يتم إعادة بناء{' '}
                <code className="text-yellow-200 font-mono">dist/</code> ومزامنة مشروع{' '}
                <strong className="text-cyan-200">Capacitor Android</strong> بالكامل مع الغلاف المذهّب والأيقونات وصلاحيات{' '}
                <code className="text-cyan-200 font-mono">APK</code> بدون أي نقص.
              </>
            ) : (
              <>
                Toute modification dans l’application, les fiches ou les paramètres est enregistrée automatiquement. Au téléchargement,{' '}
                <code className="text-yellow-200 font-mono">dist/</code> est recompilé et le projet{' '}
                <strong className="text-cyan-200">Capacitor Android</strong> (Splash doré, icônes, permissions{' '}
                <code className="text-cyan-200 font-mono">APK</code>) est synchronisé au complet.
              </>
            )}
          </p>

          {/* Android App Cover & Launcher Icon Preview + Live Recorded State */}
          <div className="rounded-xl bg-[#040c1f]/90 border border-yellow-400/40 p-3 flex items-center gap-3">
            <div className="w-12 h-20 rounded-lg overflow-hidden border border-yellow-400/70 shrink-0 shadow-[0_0_16px_rgba(250,204,21,0.35)] bg-[#040c1f]">
              <img
                src={splashCoverPreviewImg}
                alt={lang === 'AR' ? 'غلاف شاشة البداية للتطبيق' : 'Écran Splash de l’application'}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="w-14 h-14 rounded-2xl overflow-hidden border-2 border-yellow-300 shrink-0 shadow-[0_0_18px_rgba(250,204,21,0.4)] bg-[#040c1f]">
              <img
                src={appIconPreviewImg}
                alt={lang === 'AR' ? 'أيقونة تطبيق بروموسبور أندرويد' : 'Icône Android Promosport'}
                className="w-full h-full object-cover"
              />
            </div>

            <div className={`flex-1 min-w-0 space-y-1 ${lang === 'AR' ? 'text-right' : 'text-left'}`}>
              <div className="text-xs font-black text-yellow-200 truncate">
                {settings.appName || 'Promosport Tunisie - MB Football'}
              </div>
              <div
                dir="ltr"
                className={`text-[11px] font-mono text-cyan-300 truncate ${
                  lang === 'AR' ? 'text-right' : 'text-left'
                }`}
              >
                {settings.packageId || 'com.promosport.tunisie.mb'}
              </div>
              <div className="text-[11px] text-emerald-300 font-bold">
                {lang === 'AR'
                  ? `مزامنة تلقائية نشطة • ${userSlips.length} قصاصة مسجلة • مسابقة #${concours.number}`
                  : `Synchro auto active • ${userSlips.length} fiches • Concours #${concours.number}`}
              </div>
            </div>
          </div>

          {/* Capacitor APK Zero-Gap Completeness Checklist */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-[11px] font-bold">
            <div className="flex items-center gap-1.5 text-emerald-200 px-1 py-0.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>
                {lang === 'AR'
                  ? `غلاف وشاشة بداية + ${readiness?.iconCount ?? 15} أيقونة Android`
                  : `Couverture & Splash + ${readiness?.iconCount ?? 15} icônes Android`}
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-emerald-200 px-1 py-0.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>
                {lang === 'AR'
                  ? `${readiness?.splashCount ?? 11} غلاف Splash بجميع المقاسات`
                  : `${readiness?.splashCount ?? 11} écrans Splash multi-formats`}
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-emerald-200 px-1 py-0.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>
                {lang === 'AR'
                  ? 'مشروع Capacitor + Gradlew + AndroidManifest'
                  : 'Projet Capacitor + Gradlew + AndroidManifest'}
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-emerald-200 px-1 py-0.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>
                {lang === 'AR'
                  ? 'كود src/ + dist/ + GitHub APK Workflow'
                  : 'Code src/ + dist/ + GitHub APK Workflow'}
              </span>
            </div>
          </div>

          <div className="rounded-xl bg-black/55 border border-white/10 p-2.5 space-y-2">
            <div
              dir="ltr"
              className="text-[11px] font-mono text-gray-200 truncate px-1 select-all text-center"
            >
              {buildCommand}
            </div>
            <button
              type="button"
              onClick={() =>
                triggerCopyFeedback(
                  'run-cmd',
                  buildCommand,
                  lang === 'AR' ? 'أمر التشغيل' : 'Commande'
                )
              }
              className="w-full min-h-[38px] px-3 py-2 rounded-xl bg-amber-950/50 hover:bg-amber-900/60 border border-yellow-400/50 text-yellow-200 font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-all"
            >
              {copiedKey === 'run-cmd' ? (
                <Check className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <Copy className="w-3.5 h-3.5 text-yellow-300" />
              )}
              <span>
                {copiedKey === 'run-cmd'
                  ? lang === 'AR'
                    ? 'تم نسخ أمر التشغيل!'
                    : 'Commande copiée !'
                  : lang === 'AR'
                    ? 'نسخ أمر التشغيل'
                    : 'Copier la commande'}
              </span>
            </button>
          </div>

          <div className="space-y-2.5">
            <button
              type="button"
              disabled={isBuildingZip}
              onClick={() => void handleDownloadFullZip()}
              className="w-full min-h-[46px] px-4 py-2.5 rounded-2xl bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-500 text-black font-black text-xs sm:text-sm shadow-[0_0_20px_rgba(250,204,21,0.5)] hover:brightness-105 active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer"
            >
              {isBuildingZip ? (
                <RefreshCw className="w-4 h-4 animate-spin shrink-0" />
              ) : (
                <Download className="w-4 h-4 shrink-0" />
              )}
              <span>
                {isBuildingZip
                  ? lang === 'AR'
                    ? 'جارٍ تجميع وبناء الحزمة الكاملة...'
                    : 'Compilation et empaquetage ZIP...'
                  : lang === 'AR'
                    ? 'تنزيل الحزمة الكاملة (.ZIP)'
                    : 'Télécharger le Pack Complet (.ZIP)'}
              </span>
            </button>

            <a
              href={pwaBuilderUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => audioService.playClick()}
              className="w-full min-h-[46px] px-4 py-2.5 rounded-2xl bg-gradient-to-r from-cyan-400 to-sky-500 text-black font-black text-xs sm:text-sm shadow-[0_0_20px_rgba(34,211,238,0.45)] hover:brightness-105 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Smartphone className="w-4 h-4 shrink-0" />
              <span>{lang === 'AR' ? 'تحويل مباشر إلى APK' : 'Convertir directement en APK'}</span>
            </a>
          </div>

          {zipFeedback && (
            <div className="rounded-xl bg-emerald-950/60 border border-emerald-400/50 px-3 py-2 text-xs font-bold text-emerald-200">
              {zipFeedback}
            </div>
          )}
        </div>

        {/* الحل 5: التثبيت على iPhone و iPad (Safari) */}
        <div className="rounded-2xl border border-indigo-400/55 bg-indigo-950/20 p-3.5 sm:p-4 space-y-2">
          <div className="flex items-center gap-2 text-indigo-200 font-black text-sm">
            <Share2 className="w-4 h-4 text-indigo-300 shrink-0" />
            <span>
              {lang === 'AR'
                ? 'الحل 5: التثبيت على iPhone و iPad (Safari)'
                : 'Option 5 : Installer sur iPhone & iPad (Safari)'}
            </span>
          </div>
          <p className="text-xs text-gray-200 leading-relaxed">
            {lang === 'AR'
              ? 'على آيفون وآيباد: افتح الرابط الحالي في متصفح Safari ← اضغط المشاركة ⬆️ ← اختر "إضافة إلى الشاشة الرئيسية" (بأيقونة 180×180 PNG جاهزة).'
              : 'Sur iPhone et iPad : ouvrez le lien actuel dans Safari → appuyez sur Partager ⬆️ → « Sur l’écran d’accueil » (icône PNG 180×180 prête).'}
          </p>
        </div>

        {/* الحل 6: توليد ملف APK سحابياً عبر PWABuilder (بدون SDK) */}
        <div className="rounded-2xl border border-cyan-400/55 bg-cyan-950/15 p-3.5 sm:p-4 space-y-3">
          <div className="flex items-center gap-2 text-cyan-200 font-black text-sm">
            <Smartphone className="w-4 h-4 text-cyan-300 shrink-0" />
            <span>
              {lang === 'AR'
                ? 'الحل 6: توليد ملف APK سحابياً عبر PWABuilder (بدون SDK)'
                : 'Option 6 : Générer APK dans le Cloud via PWABuilder'}
            </span>
          </div>
          <p className="text-xs text-gray-200 leading-relaxed">
            {lang === 'AR'
              ? 'يُنشئ ملف .APK موقّع وجاهز للتثبيت في السحابة مباشرة من الرابط الشغال — بدون الحاجة إلى Android SDK أو Gradle على جهازك.'
              : 'Génère un fichier .APK signé prêt à installer dans le cloud depuis votre lien actif — sans Android SDK ni Gradle requis.'}
          </p>
          <a
            href={pwaBuilderUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => audioService.playClick()}
            className="w-full min-h-[46px] px-4 py-2.5 rounded-2xl bg-gradient-to-r from-cyan-400 to-sky-500 text-black font-black text-xs sm:text-sm shadow-[0_0_20px_rgba(34,211,238,0.45)] hover:brightness-105 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <ExternalLink className="w-4 h-4 shrink-0" />
            <span>
              {lang === 'AR'
                ? 'فتح PWABuilder لبناء APK سحابياً'
                : 'Ouvrir PWABuilder (Build Cloud)'}
            </span>
          </a>
        </div>
      </section>

      {/* ===================================================================== */}
      {/* برومبت أندرويد APK الشامل والمعادلة الرسمية                         */}
      {/* ===================================================================== */}
      <section className="rounded-2xl sm:rounded-3xl border border-sky-400/45 bg-[#061022]/95 p-3.5 sm:p-4 shadow-lg space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-cyan-300 font-black text-xs sm:text-sm">
            <Code2 className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>
              {lang === 'AR'
                ? 'برومبت أندرويد APK الشامل والمعادلة الرسمية'
                : 'Prompt Android APK complet & Formule officielle'}
            </span>
          </div>

          <button
            type="button"
            onClick={() =>
              triggerCopyFeedback(
                'prompt-spec',
                promptSpecification,
                lang === 'AR' ? 'البرومبت' : 'Prompt'
              )
            }
            className="px-3.5 py-2 rounded-2xl bg-amber-950/60 hover:bg-amber-900/70 border border-yellow-400/60 text-yellow-200 font-black text-xs flex items-center gap-1.5 cursor-pointer active:scale-95 transition-all"
          >
            {copiedKey === 'prompt-spec' ? (
              <Check className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <Copy className="w-3.5 h-3.5 text-yellow-300" />
            )}
            <span>
              {copiedKey === 'prompt-spec'
                ? lang === 'AR'
                  ? 'تم النسخ!'
                  : 'Copié !'
                : lang === 'AR'
                  ? 'نسخ البرومبت'
                  : 'Copier Prompt'}
            </span>
          </button>
        </div>

        <pre
          dir="auto"
          className="p-3.5 rounded-2xl bg-black/85 border border-white/10 text-[11px] font-mono text-gray-200 overflow-x-auto max-h-72 leading-relaxed whitespace-pre-wrap select-text"
        >
          {promptSpecification}
        </pre>
      </section>

      {/* Camera QR Scanner Modal (inline, no window.open/alert) */}
      {scannerOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4"
        >
          <div className="w-full max-w-md rounded-2xl bg-[#07142b] border-2 border-cyan-400/70 p-4 space-y-3 text-white shadow-2xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-cyan-300 font-black text-sm">
                <Camera className="w-4 h-4" />
                <span>{lang === 'AR' ? 'كاميرا مسح كود QR' : 'Caméra Scanner QR Code'}</span>
              </div>
              <button
                type="button"
                onClick={() => setScannerOpen(false)}
                className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {scannerError ? (
              <p className="rounded-xl bg-amber-950/60 border border-yellow-400/40 p-3 text-xs text-yellow-100 leading-relaxed">
                {scannerError}
              </p>
            ) : (
              <div className="relative w-full aspect-square max-h-64 rounded-xl overflow-hidden bg-black border border-cyan-400/40">
                <video
                  ref={videoRef}
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                />
              </div>
            )}

            {scannedUrl && (
              <div className="rounded-xl bg-emerald-950/70 border border-emerald-400/60 p-3 space-y-2">
                <div className="text-xs font-black text-emerald-300">
                  {lang === 'AR' ? 'تم التقاط الرابط:' : 'Lien capturé :'}
                </div>
                <div dir="ltr" className="text-[11px] font-mono text-white break-all">
                  {scannedUrl}
                </div>
                {scannedUrl.startsWith('http') && (
                  <a
                    href={scannedUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2 rounded-xl bg-emerald-400 text-black font-black text-xs flex items-center justify-center gap-1.5"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>{lang === 'AR' ? 'فتح الرابط الملتقط' : 'Ouvrir le lien capturé'}</span>
                  </a>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
