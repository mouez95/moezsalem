/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { Bell, Trash2, Zap, Trophy, Flame, UserPlus, UserCheck, CheckCircle2, AlertCircle, KeyRound, Unlock, Mail } from 'lucide-react';
import { audioService } from '../services/audioService';
import { LiveNotificationItem, ParticipantProfile } from '../types/promosport';
import { MbLogo } from './MbLogo';
import { LanguageToggleButton } from './LanguageToggleButton';

interface PromosportIntroStageProps {
  active: boolean;
  isClosing?: boolean;
  mode?: 'home' | 'register';
  participantProfile?: ParticipantProfile | null;
  onRegisterParticipant?: (
    baseName: string
  ) => Promise<{ ok: boolean; profile?: ParticipantProfile; error?: string }>;
  onVerifyRegisteredParticipant?: (
    fullNameInput: string
  ) => Promise<{ ok: boolean; profile?: ParticipantProfile; error?: string }>;
  onReturnToRegistration?: () => Promise<void> | void;
  onEnterGrille: () => void;
  lang?: 'AR' | 'FR';
  onChangeLang?: (lang: 'AR' | 'FR') => void;
  liveNotifications?: LiveNotificationItem[];
  onClearNotifications?: () => void;
  onOpenNotification?: (item: LiveNotificationItem) => void;
}

interface SoftwareProbe {
  isSoftware: boolean;
  rendererName: string;
}

function detectSoftwareWebGL(gl: WebGLRenderingContext | WebGL2RenderingContext): SoftwareProbe {
  try {
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    if (ext) {
      const rendererName = String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) || '');
      const isSoftware = /SwiftShader|llvmpipe|Software Rasterizer|Microsoft Basic Render/i.test(rendererName);
      return { isSoftware, rendererName };
    }
  } catch {
    // ignore probe errors
  }
  return { isSoftware: false, rendererName: 'hardware' };
}

/**
 * Generates exact seamless spherical truncated-icosahedron (12 pentagons + 20 hexagons)
 * albedo, bump, and roughness CanvasTextures for the 3D football with zero pole distortion.
 */
function createSoccerBallTextures(): {
  map: THREE.CanvasTexture;
  bumpMap: THREE.CanvasTexture;
  roughnessMap: THREE.CanvasTexture;
} {
  const width = 768;
  const height = 384;

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = width;
  albedoCanvas.height = height;
  const aCtx = albedoCanvas.getContext('2d')!;

  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = width;
  bumpCanvas.height = height;
  const bCtx = bumpCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = width;
  roughCanvas.height = height;
  const rCtx = roughCanvas.getContext('2d')!;

  const aImg = aCtx.createImageData(width, height);
  const bImg = bCtx.createImageData(width, height);
  const rImg = rCtx.createImageData(width, height);

  const phi = (1 + Math.sqrt(5)) / 2;

  const normalizeVec = (x: number, y: number, z: number): [number, number, number] => {
    const len = Math.hypot(x, y, z) || 1;
    return [x / len, y / len, z / len];
  };

  // 12 Pentagon centers (icosahedron vertices)
  const pentCenters: Array<[number, number, number]> = [
    normalizeVec(0, 1, phi),
    normalizeVec(0, -1, phi),
    normalizeVec(0, 1, -phi),
    normalizeVec(0, -1, -phi),
    normalizeVec(1, phi, 0),
    normalizeVec(-1, phi, 0),
    normalizeVec(1, -phi, 0),
    normalizeVec(-1, -phi, 0),
    normalizeVec(phi, 0, 1),
    normalizeVec(-phi, 0, 1),
    normalizeVec(phi, 0, -1),
    normalizeVec(-phi, 0, -1),
  ];

  // 20 Hexagon centers (dodecahedron vertices)
  const invPhi = 1 / phi;
  const hexCenters: Array<[number, number, number]> = [
    normalizeVec(1, 1, 1),
    normalizeVec(1, 1, -1),
    normalizeVec(1, -1, 1),
    normalizeVec(1, -1, -1),
    normalizeVec(-1, 1, 1),
    normalizeVec(-1, 1, -1),
    normalizeVec(-1, -1, 1),
    normalizeVec(-1, -1, -1),
    normalizeVec(0, phi, invPhi),
    normalizeVec(0, phi, -invPhi),
    normalizeVec(0, -phi, invPhi),
    normalizeVec(0, -phi, -invPhi),
    normalizeVec(invPhi, 0, phi),
    normalizeVec(-invPhi, 0, phi),
    normalizeVec(invPhi, 0, -phi),
    normalizeVec(-invPhi, 0, -phi),
    normalizeVec(phi, invPhi, 0),
    normalizeVec(phi, -invPhi, 0),
    normalizeVec(-phi, invPhi, 0),
    normalizeVec(-phi, -invPhi, 0),
  ];

  const invPentScale = 1 / 0.68819;
  const invHexScale = 1 / 0.86603;

  for (let py = 0; py < height; py++) {
    const v = (py + 0.5) / height;
    const phiA = v * Math.PI;
    const sinPhi = Math.sin(phiA);
    const cosPhi = Math.cos(phiA);

    for (let px = 0; px < width; px++) {
      const u = (px + 0.5) / width;
      const theta = u * Math.PI * 2;
      const vx = sinPhi * Math.cos(theta);
      const vy = cosPhi;
      const vz = sinPhi * Math.sin(theta);

      let best1 = Infinity;
      let best2 = Infinity;
      let isPent = false;

      for (let i = 0; i < 12; i++) {
        const c = pentCenters[i];
        const dot = Math.max(-1, Math.min(1, vx * c[0] + vy * c[1] + vz * c[2]));
        const sDist = Math.acos(dot) * invPentScale;
        if (sDist < best1) {
          best2 = best1;
          best1 = sDist;
          isPent = true;
        } else if (sDist < best2) {
          best2 = sDist;
        }
      }

      for (let i = 0; i < 20; i++) {
        const c = hexCenters[i];
        const dot = Math.max(-1, Math.min(1, vx * c[0] + vy * c[1] + vz * c[2]));
        const sDist = Math.acos(dot) * invHexScale;
        if (sDist < best1) {
          best2 = best1;
          best1 = sDist;
          isPent = false;
        } else if (sDist < best2) {
          best2 = sDist;
        }
      }

      const seamDelta = best2 - best1;
      const grain = Math.sin(vx * 115.0 + vy * 89.0) * Math.cos(vz * 110.0) * 6.0;

      const seamMask = Math.max(0, Math.min(1, (0.022 - seamDelta) / 0.022));
      const bevelMask = Math.max(0, Math.min(1, (0.055 - seamDelta) / 0.055));

      let r: number;
      let g: number;
      let b: number;
      let roughVal: number;

      if (isPent) {
        r = 18 + grain * 0.6;
        g = 22 + grain * 0.6;
        b = 31 + grain * 0.7;
        roughVal = 92;
      } else {
        r = 242 + grain * 0.7;
        g = 244 + grain * 0.7;
        b = 249 + grain * 0.7;
        roughVal = 82;
      }

      const bumpVal = 200 - bevelMask * 65 - seamMask * 125 + grain * 1.4;

      if (seamMask > 0.01) {
        const stitchPulse = 0.5 + 0.5 * Math.sin((theta + phiA) * 95.0);
        r = r * (1 - seamMask * 0.82) + stitchPulse * seamMask * 55;
        g = g * (1 - seamMask * 0.85) + stitchPulse * seamMask * 40;
        b = b * (1 - seamMask * 0.88) + stitchPulse * seamMask * 25;
        roughVal = Math.min(240, roughVal + seamMask * 110);
      }

      const idx = (py * width + px) * 4;
      aImg.data[idx] = Math.max(0, Math.min(255, r));
      aImg.data[idx + 1] = Math.max(0, Math.min(255, g));
      aImg.data[idx + 2] = Math.max(0, Math.min(255, b));
      aImg.data[idx + 3] = 255;

      const bv = Math.max(0, Math.min(255, bumpVal));
      bImg.data[idx] = bv;
      bImg.data[idx + 1] = bv;
      bImg.data[idx + 2] = bv;
      bImg.data[idx + 3] = 255;

      const rv = Math.max(0, Math.min(255, roughVal));
      rImg.data[idx] = rv;
      rImg.data[idx + 1] = rv;
      rImg.data[idx + 2] = rv;
      rImg.data[idx + 3] = 255;
    }
  }

  aCtx.putImageData(aImg, 0, 0);
  bCtx.putImageData(bImg, 0, 0);
  rCtx.putImageData(rImg, 0, 0);

  const map = new THREE.CanvasTexture(albedoCanvas);
  map.colorSpace = THREE.SRGBColorSpace;
  map.anisotropy = 4;

  const bumpMap = new THREE.CanvasTexture(bumpCanvas);
  const roughnessMap = new THREE.CanvasTexture(roughCanvas);

  return { map, bumpMap, roughnessMap };
}

export const PromosportIntroStage: React.FC<PromosportIntroStageProps> = ({
  active,
  isClosing = false,
  mode = 'home',
  participantProfile = null,
  onRegisterParticipant,
  onVerifyRegisteredParticipant,
  onReturnToRegistration,
  onEnterGrille,
  lang = 'AR',
  onChangeLang,
  liveNotifications = [],
  onClearNotifications,
  onOpenNotification,
}) => {
  const stageRef = useRef<HTMLDivElement>(null);
  const ribbonRef = useRef<HTMLDivElement>(null);
  const verifyInputRef = useRef<HTMLInputElement>(null);
  const [webglLost, setWebglLost] = useState(false);
  const [mbRevealed, setMbRevealed] = useState(false);
  const [participantInput, setParticipantInput] = useState('');
  const [registrationError, setRegistrationError] = useState<string | null>(null);
  const [isRegistering, setIsRegistering] = useState(false);
  const [isRegisteredLookupOpen, setIsRegisteredLookupOpen] = useState(false);
  const [verifyInput, setVerifyInput] = useState('');
  const [verifyError, setVerifyError] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [showReturnToRegisterConfirm, setShowReturnToRegisterConfirm] = useState(false);

  const isRegisterMode = mode === 'register';

  useEffect(() => {
    if (isRegisterMode) {
      setShowReturnToRegisterConfirm(false);
      setRegistrationError(null);
      setVerifyError(null);
      setIsRegistering(false);
      setIsVerifying(false);
    }
  }, [isRegisterMode]);

  const focusVerifyInput = () => {
    window.setTimeout(() => {
      verifyInputRef.current?.focus();
    }, 30);
  };

  const handleSelectNewRegistration = () => {
    audioService.playClick();
    setIsRegisteredLookupOpen(false);
    setVerifyError(null);
  };

  const handleOpenRegisteredLookup = () => {
    audioService.playClick();
    setIsRegisteredLookupOpen(true);
    setRegistrationError(null);
    setVerifyError(null);
    focusVerifyInput();
  };

  const handleRegistrationSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isRegisterMode || isRegistering || !onRegisterParticipant) return;
    audioService.playClick();
    const cleaned = participantInput.replace(/\s+/g, ' ').trim();
    if (!cleaned) {
      setRegistrationError(
        lang === 'FR'
          ? 'Veuillez saisir le nom du participant (obligatoire).'
          : 'يرجى كتابة اسم المشارك (إجباري).'
      );
      return;
    }
    setRegistrationError(null);
    setIsRegistering(true);
    try {
      const res = await onRegisterParticipant(cleaned);
      if (!res.ok) {
        setRegistrationError(
          res.error ||
            (lang === 'FR'
              ? 'Impossible de finaliser l’inscription, réessayez.'
              : 'تعذر إتمام التسجيل، يرجى المحاولة مجدداً.')
        );
      } else {
        audioService.playChime();
      }
    } finally {
      setIsRegistering(false);
    }
  };

  const handleVerifySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isRegisterMode || isVerifying || !onVerifyRegisteredParticipant) return;
    audioService.playClick();
    const cleaned = verifyInput.replace(/\s+/g, ' ').trim();
    if (!cleaned) {
      setVerifyError(lang === 'FR' ? 'Non inscrit, réessayez.' : 'غير مسجل أعد المحاولة');
      focusVerifyInput();
      return;
    }
    setVerifyError(null);
    setIsVerifying(true);
    try {
      const res = await onVerifyRegisteredParticipant(cleaned);
      if (!res.ok) {
        setVerifyError(
          res.error || (lang === 'FR' ? 'Non inscrit, réessayez.' : 'غير مسجل أعد المحاولة')
        );
        focusVerifyInput();
      } else {
        audioService.playChime();
      }
    } finally {
      setIsVerifying(false);
    }
  };

  // Reveal the radiant spinning gilded MB emblem from above right as the fiery ball lands
  useEffect(() => {
    if (!active) return;
    setMbRevealed(false);
    const tMb = window.setTimeout(() => setMbRevealed(true), 760);
    return () => {
      window.clearTimeout(tMb);
    };
  }, [active]);

  useEffect(() => {
    if (!active) return;
    const container = stageRef.current;
    if (!container) return;

    let width = container.clientWidth || window.innerWidth;
    let height = container.clientHeight || window.innerHeight;

    let renderer: THREE.WebGLRenderer | null = null;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: true,
        alpha: true,
        powerPreference: 'high-performance',
      });
    } catch {
      setWebglLost(true);
      return;
    }

    const gl = renderer.getContext();
    const { isSoftware } = detectSoftwareWebGL(gl);
    if (isSoftware) {
      renderer.setPixelRatio(1);
    } else {
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    }

    renderer.setSize(width, height);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.18;
    renderer.setClearColor(0x000000, 0);

    renderer.domElement.style.position = 'absolute';
    renderer.domElement.style.inset = '0';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.style.display = 'block';
    container.appendChild(renderer.domElement);

    const handleContextLost = (e: Event) => {
      e.preventDefault();
      setWebglLost(true);
    };
    const handleContextRestored = () => {
      setWebglLost(false);
    };
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);
    renderer.domElement.addEventListener('webglcontextrestored', handleContextRestored);

    const scene = new THREE.Scene();

    // Studio IBL for rich leather + gold metallic reflections
    const pmrem = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    const envTarget = pmrem.fromScene(roomEnv, 0.04);
    scene.environment = envTarget.texture;
    roomEnv.dispose();
    pmrem.dispose();

    const camera = new THREE.PerspectiveCamera(42, width / Math.max(1, height), 0.1, 100);
    camera.position.set(0, 0, 10);

    // Three-point + live fire lighting
    const ambientLight = new THREE.AmbientLight(0x93c5fd, 0.45);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xfff4e0, 1.45);
    keyLight.position.set(3.5, 4.5, 7.5);
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x38bdf8, 1.35);
    rimLight.position.set(-4.5, 2.5, -3.5);
    scene.add(rimLight);

    const fireLight = new THREE.PointLight(0xff7718, 6.4, 18, 1.6);
    fireLight.position.set(0, 0.4, 1.2);
    scene.add(fireLight);

    // Exact alignment helper mapping DOM ribbon coordinates directly into Three.js world space
    const computeLayout = (w: number, h: number) => {
      const aspect = w / Math.max(1, h);
      const visH = 2 * Math.tan(THREE.MathUtils.degToRad(42 / 2)) * 10;
      const visW = visH * aspect;
      const heroScale = THREE.MathUtils.clamp(visW / 5.4, 0.72, 1.15);

      const cRect = container.getBoundingClientRect();
      const rRect = ribbonRef.current?.getBoundingClientRect();

      let worldRibbonY = -0.35;
      let worldRibbonRightX = Math.min(visW * 0.28, 1.65 * heroScale);

      if (rRect && cRect.width > 0 && cRect.height > 0) {
        const ribbonCenterY = rRect.top + rRect.height * 0.48 - cRect.top;
        const ndcY = 1 - 2 * (ribbonCenterY / cRect.height);
        worldRibbonY = ndcY * (visH * 0.5);

        const ribbonRightX = rRect.right - rRect.width * 0.06 - cRect.left;
        const ndcRightX = 2 * (ribbonRightX / cRect.width) - 1;
        worldRibbonRightX = ndcRightX * (visW * 0.5);
      }

      const startX = -Math.max(visW * 0.58, 2.6);
      const startY = worldRibbonY + 0.02;
      // Lands cleanly on the right flank right behind & slightly cresting above the PROMOSPORT ribbon
      const targetX = Math.min(worldRibbonRightX, visW * 0.41);
      const targetY = worldRibbonY + 0.42 * heroScale;

      return { visW, visH, heroScale, targetX, targetY, startX, startY, worldRibbonY };
    };
    let layout = computeLayout(width, height);

    // =========================================================================
    // 1. SCI-FI ARENA STARFIELD & ENERGY HORIZON DUST
    // =========================================================================
    const dustCount = isSoftware ? 75 : 130;
    const dustPositions = new Float32Array(dustCount * 3);
    const dustColors = new Float32Array(dustCount * 3);
    const dustSizes = new Float32Array(dustCount);

    for (let i = 0; i < dustCount; i++) {
      dustPositions[i * 3] = (Math.random() - 0.5) * 14;
      dustPositions[i * 3 + 1] = (Math.random() - 0.5) * 9;
      dustPositions[i * 3 + 2] = -1.5 - Math.random() * 5.5;
      dustSizes[i] = 1.4 + Math.random() * 2.8;
      if (i % 3 === 0) {
        dustColors[i * 3] = 1.0;
        dustColors[i * 3 + 1] = 0.78;
        dustColors[i * 3 + 2] = 0.35;
      } else {
        dustColors[i * 3] = 0.35;
        dustColors[i * 3 + 1] = 0.78;
        dustColors[i * 3 + 2] = 1.0;
      }
    }

    const dustGeo = new THREE.BufferGeometry();
    dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPositions, 3));
    dustGeo.setAttribute('color', new THREE.BufferAttribute(dustColors, 3));
    dustGeo.setAttribute('aSize', new THREE.BufferAttribute(dustSizes, 1));

    const dustUniforms = { uTime: { value: 0 } };
    const dustMat = new THREE.ShaderMaterial({
      uniforms: dustUniforms,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      vertexShader: `
        attribute vec3 color;
        attribute float aSize;
        varying vec3 vColor;
        varying float vAlpha;
        uniform float uTime;
        void main() {
          vColor = color;
          vec3 p = position;
          p.y += sin(uTime * 0.6 + position.x * 1.4) * 0.08;
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_Position = projectionMatrix * mv;
          gl_PointSize = aSize * (18.0 / max(1.0, -mv.z));
          vAlpha = 0.35 + 0.35 * sin(uTime * 2.2 + position.x * 3.1 + position.y * 2.3);
        }
      `,
      fragmentShader: `
        varying vec3 vColor;
        varying float vAlpha;
        void main() {
          float d = length(gl_PointCoord - vec2(0.5));
          float core = smoothstep(0.5, 0.04, d);
          gl_FragColor = vec4(vColor, core * vAlpha * 0.7);
        }
      `,
    });
    const dustPoints = new THREE.Points(dustGeo, dustMat);
    scene.add(dustPoints);

    // =========================================================================
    // 2. COMPOSITE 3D FOOTBALL GROUP (Stitched Pentagons/Hexagons + Corona)
    // =========================================================================
    const ballGroup = new THREE.Group();
    ballGroup.position.set(layout.startX, layout.startY, -0.32);
    scene.add(ballGroup);

    const ballTextures = createSoccerBallTextures();
    const ballGeo = new THREE.SphereGeometry(0.62, 48, 36);
    const ballMat = new THREE.MeshPhysicalMaterial({
      map: ballTextures.map,
      bumpMap: ballTextures.bumpMap,
      bumpScale: 0.024,
      roughnessMap: ballTextures.roughnessMap,
      roughness: 0.42,
      metalness: 0.1,
      clearcoat: 0.46,
      clearcoatRoughness: 0.22,
      envMapIntensity: 1.25,
    });
    const ballMesh = new THREE.Mesh(ballGeo, ballMat);
    ballGroup.add(ballMesh);

    const coronaGeo = new THREE.SphereGeometry(0.7, 36, 28);
    const coronaUniforms = {
      uTime: { value: 0 },
      uIntensity: { value: 0 },
    };
    const coronaMat = new THREE.ShaderMaterial({
      uniforms: coronaUniforms,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      side: THREE.FrontSide,
      vertexShader: `
        varying vec3 vNormal;
        varying vec3 vViewPos;
        varying vec3 vLocalPos;
        void main() {
          vLocalPos = position;
          vNormal = normalize(normalMatrix * normal);
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          vViewPos = -mv.xyz;
          gl_Position = projectionMatrix * mv;
        }
      `,
      fragmentShader: `
        uniform float uTime;
        uniform float uIntensity;
        varying vec3 vNormal;
        varying vec3 vViewPos;
        varying vec3 vLocalPos;

        float hash(vec2 p) {
          return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
        }
        float noise(vec2 p) {
          vec2 i = floor(p);
          vec2 f = fract(p);
          vec2 u = f * f * (3.0 - 2.0 * f);
          return mix(
            mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
            mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x),
            u.y
          );
        }

        void main() {
          vec3 N = normalize(vNormal);
          vec3 V = normalize(vViewPos);
          float fresnel = pow(1.0 - max(0.0, dot(N, V)), 2.35);
          float flick = noise(vec2(vLocalPos.x * 4.5 + uTime * 2.2, vLocalPos.y * 5.0 - uTime * 4.8));
          vec3 hotCol = mix(vec3(1.0, 0.28, 0.03), vec3(1.0, 0.86, 0.25), flick * 0.8 + fresnel * 0.35);
          float alpha = fresnel * (0.45 + 0.55 * flick) * uIntensity;
          gl_FragColor = vec4(hotCol * alpha * 1.45, alpha);
        }
      `,
    });
    const coronaMesh = new THREE.Mesh(coronaGeo, coronaMat);
    ballGroup.add(coronaMesh);

    // =========================================================================
    // 3. REAL-TIME 3D VOLUMETRIC-FEEL GLSL FLAME PLUME (Behind Ball & Ribbon)
    // =========================================================================
    const flameUniforms = {
      uTime: { value: 0 },
      uIgnition: { value: 0 },
      uMotionBlur: { value: 1 },
    };

    const flameGeo = new THREE.PlaneGeometry(3.4, 3.6, 1, 1);
    const flameMat = new THREE.ShaderMaterial({
      uniforms: flameUniforms,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
      vertexShader: `
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform float uTime;
        uniform float uIgnition;
        uniform float uMotionBlur;
        varying vec2 vUv;

        float hash(vec2 p) {
          return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
        }

        float noise(vec2 p) {
          vec2 i = floor(p);
          vec2 f = fract(p);
          vec2 u = f * f * (3.0 - 2.0 * f);
          return mix(
            mix(hash(i + vec2(0.0, 0.0)), hash(i + vec2(1.0, 0.0)), u.x),
            mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x),
            u.y
          );
        }

        float fbm(vec2 p) {
          float sum = 0.0;
          float amp = 0.52;
          mat2 rot = mat2(0.8, 0.6, -0.6, 0.8);
          for (int i = 0; i < 5; i++) {
            sum += amp * noise(p);
            p = rot * p * 2.06 + vec2(1.4, -2.7);
            amp *= 0.5;
          }
          return sum;
        }

        void main() {
          vec2 p = (vUv - vec2(0.5, 0.34)) * vec2(2.6, 2.95);

          float tilt = uMotionBlur * 0.64;
          vec2 warpedP = p;
          warpedP.x += max(0.0, p.y + 0.35) * tilt * 0.72;

          float flow1 = fbm(vec2(warpedP.x * 2.35, warpedP.y * 1.55 - uTime * 3.9));
          float flow2 = fbm(vec2(warpedP.x * 4.4 + flow1 * 1.35, warpedP.y * 2.6 - uTime * 6.5));
          float turb = mix(flow1, flow2, 0.55);

          float heightNorm = clamp((warpedP.y + 0.58) / 2.25, 0.0, 1.0);
          float widthProfile = mix(0.68, 0.14, pow(heightNorm, 1.25));
          widthProfile += uMotionBlur * 0.18 * (1.0 - heightNorm);

          float sway = (turb - 0.5) * (0.45 + heightNorm * 0.65);
          float radial = abs(warpedP.x + sway) / max(0.08, widthProfile);

          float baseHeat = exp(-dot(p - vec2(0.0, -0.04), p - vec2(0.0, -0.04)) * 3.1);
          float tongueShape = smoothstep(1.18, 0.08, radial) * (1.0 - smoothstep(0.32, 1.0, heightNorm));
          tongueShape *= smoothstep(-0.62, -0.15, p.y);

          float cometX = clamp(-p.x / 1.5, 0.0, 1.0);
          float cometWake = exp(-abs(p.y + (turb - 0.5) * 0.25) * 5.0) * (1.0 - cometX) * step(p.x, 0.15) * uMotionBlur;

          float density = (tongueShape * (0.55 + 0.85 * turb) + baseHeat * 0.74 + cometWake * (0.58 + 0.6 * flow2)) * uIgnition;

          vec3 colCrimson = vec3(0.95, 0.15, 0.02);
          vec3 colOrange = vec3(1.0, 0.46, 0.04);
          vec3 colGold = vec3(1.0, 0.85, 0.24);
          vec3 colCore = vec3(1.0, 0.98, 0.86);

          vec3 fireColor = mix(colCrimson, colOrange, smoothstep(0.12, 0.42, density));
          fireColor = mix(fireColor, colGold, smoothstep(0.42, 0.82, density));
          fireColor = mix(fireColor, colCore, smoothstep(0.82, 1.35, density));

          float alpha = clamp(density * 1.18, 0.0, 1.0);
          float edgeFade = smoothstep(0.0, 0.12, vUv.x) * smoothstep(1.0, 0.88, vUv.x) *
                           smoothstep(0.0, 0.12, vUv.y) * smoothstep(1.0, 0.85, vUv.y);

          gl_FragColor = vec4(fireColor * (0.95 + density * 0.45), alpha * edgeFade);
        }
      `,
    });
    const flameMesh = new THREE.Mesh(flameGeo, flameMat);
    flameMesh.position.set(layout.startX, layout.startY + 0.48, -0.56);
    scene.add(flameMesh);

    const flameBackMesh = new THREE.Mesh(flameGeo, flameMat);
    flameBackMesh.position.set(layout.startX - 0.12, layout.startY + 0.36, -0.78);
    flameBackMesh.scale.set(1.15, 1.08, 1);
    flameBackMesh.rotation.z = 0.08;
    scene.add(flameBackMesh);

    // =========================================================================
    // 4. REAL-TIME 3D RISING & TRAILING FIRE EMBERS (THREE.Points)
    // =========================================================================
    const emberCount = isSoftware ? 65 : 115;
    const emberPositions = new Float32Array(emberCount * 3);
    const emberSizes = new Float32Array(emberCount);
    const emberLives = new Float32Array(emberCount);

    interface EmberParticle {
      x: number;
      y: number;
      z: number;
      vx: number;
      vy: number;
      life: number;
      maxLife: number;
      size: number;
    }

    const embers: EmberParticle[] = Array.from({ length: emberCount }, (_, i) => ({
      x: layout.startX,
      y: layout.startY,
      z: -0.45,
      vx: (Math.random() - 0.5) * 0.6,
      vy: 0.9 + Math.random() * 1.8,
      life: (i / emberCount) * 1.1,
      maxLife: 0.7 + Math.random() * 0.85,
      size: 2.2 + Math.random() * 4.2,
    }));

    const emberGeo = new THREE.BufferGeometry();
    emberGeo.setAttribute('position', new THREE.BufferAttribute(emberPositions, 3));
    emberGeo.setAttribute('aSize', new THREE.BufferAttribute(emberSizes, 1));
    emberGeo.setAttribute('aLife', new THREE.BufferAttribute(emberLives, 1));

    const emberMat = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      vertexShader: `
        attribute float aSize;
        attribute float aLife;
        varying float vLife;
        void main() {
          vLife = aLife;
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          gl_Position = projectionMatrix * mv;
          gl_PointSize = aSize * (16.0 / max(1.0, -mv.z)) * (0.4 + 0.6 * (1.0 - aLife));
        }
      `,
      fragmentShader: `
        varying float vLife;
        void main() {
          float d = length(gl_PointCoord - vec2(0.5));
          float glow = smoothstep(0.5, 0.02, d);
          vec3 col = mix(vec3(1.0, 0.92, 0.45), vec3(1.0, 0.28, 0.03), vLife);
          float alpha = glow * (1.0 - vLife) * 0.95;
          gl_FragColor = vec4(col * 1.35, alpha);
        }
      `,
    });
    const emberPoints = new THREE.Points(emberGeo, emberMat);
    emberPoints.frustumCulled = false;
    scene.add(emberPoints);

    // =========================================================================
    // ANIMATION LOOP (Fast Left->Right Entrance + Eternal Burning & Spinning)
    // =========================================================================
    const startMs = performance.now();
    let prevMs = startMs;
    let rafId = 0;
    let disposed = false;

    const handleResize = () => {
      if (disposed || !renderer || !container) return;
      width = container.clientWidth || window.innerWidth;
      height = container.clientHeight || window.innerHeight;
      camera.aspect = width / Math.max(1, height);
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
      renderer.setPixelRatio(isSoftware ? 1 : Math.min(window.devicePixelRatio || 1, 2));
      layout = computeLayout(width, height);
    };
    window.addEventListener('resize', handleResize);

    const ribbonObserver =
      typeof ResizeObserver !== 'undefined' && ribbonRef.current
        ? new ResizeObserver(() => {
            if (!disposed) layout = computeLayout(width, height);
          })
        : null;
    if (ribbonObserver && ribbonRef.current) {
      ribbonObserver.observe(ribbonRef.current);
    }

    // Re-sample layout after initial React paint so DOM rects are guaranteed settled
    const rafAlign = requestAnimationFrame(() => {
      if (!disposed) layout = computeLayout(width, height);
    });

    const FLIGHT_START = 0.08;
    const FLIGHT_DURATION = 0.98;

    const tick = () => {
      if (disposed || !renderer) return;
      const now = performance.now();
      const elapsed = (now - startMs) / 1000;
      const dt = Math.min(0.05, (now - prevMs) / 1000);
      prevMs = now;

      const ignition = THREE.MathUtils.smoothstep(elapsed, 0.0, 0.28);

      const rawFlightT = THREE.MathUtils.clamp((elapsed - FLIGHT_START) / FLIGHT_DURATION, 0, 1);
      const easedT = 1 - Math.pow(1 - rawFlightT, 3.2);
      const velocityWeight = rawFlightT < 1 ? Math.pow(1 - rawFlightT, 1.45) : 0;

      const curX = THREE.MathUtils.lerp(layout.startX, layout.targetX, easedT);
      const arcLift = Math.sin(rawFlightT * Math.PI) * 0.12 * layout.heroScale;
      const idleFloat = rawFlightT >= 1 ? Math.sin((elapsed - 1.1) * 2.4) * 0.022 * layout.heroScale : 0;
      const curY = THREE.MathUtils.lerp(layout.startY, layout.targetY, easedT) + arcLift + idleFloat;

      ballGroup.position.set(curX, curY, -0.32);
      ballGroup.scale.setScalar(layout.heroScale);

      // Continuous axial spin on itself (faster while flying, sleek steady spin once parked)
      const rollSpeed = 2.6 + velocityWeight * 6.8;
      ballMesh.rotation.z -= rollSpeed * dt;
      ballMesh.rotation.y += (1.85 + velocityWeight * 3.1) * dt;
      ballMesh.rotation.x = Math.sin(elapsed * 1.4) * 0.22;

      dustUniforms.uTime.value = elapsed;
      coronaUniforms.uTime.value = elapsed;
      coronaUniforms.uIntensity.value = ignition * (0.95 + 0.15 * Math.sin(elapsed * 9.0));

      flameUniforms.uTime.value = elapsed;
      flameUniforms.uIgnition.value = ignition;
      flameUniforms.uMotionBlur.value = velocityWeight;

      flameMesh.position.set(
        curX - velocityWeight * 0.42 * layout.heroScale,
        curY + (0.48 - velocityWeight * 0.26) * layout.heroScale,
        -0.56
      );
      flameMesh.scale.setScalar(layout.heroScale);

      flameBackMesh.position.set(
        curX - (0.1 + velocityWeight * 0.55) * layout.heroScale,
        curY + (0.38 - velocityWeight * 0.22) * layout.heroScale,
        -0.78
      );
      flameBackMesh.scale.set(1.14 * layout.heroScale, 1.08 * layout.heroScale, 1);

      fireLight.position.set(curX + 0.15, curY + 0.35, 1.05);
      fireLight.intensity = ignition * (5.2 + Math.sin(elapsed * 16.0) * 0.85 + Math.cos(elapsed * 23.0) * 0.55);

      camera.position.x = Math.sin(elapsed * 0.45) * 0.06;
      camera.position.y = Math.cos(elapsed * 0.38) * 0.04;
      camera.lookAt(0, 0, 0);

      const posArr = emberGeo.attributes.position.array as Float32Array;
      const sizeArr = emberGeo.attributes.aSize.array as Float32Array;
      const lifeArr = emberGeo.attributes.aLife.array as Float32Array;

      for (let i = 0; i < emberCount; i++) {
        const em = embers[i];
        em.life += dt;
        if (em.life >= em.maxLife) {
          em.life = 0;
          em.maxLife = 0.65 + Math.random() * 0.85;
          const angle = Math.random() * Math.PI * 2;
          const spawnR = (0.25 + Math.random() * 0.42) * layout.heroScale;
          em.x = curX + Math.cos(angle) * spawnR;
          em.y = curY + Math.sin(angle) * spawnR * 0.7;
          em.z = -0.45 + (Math.random() - 0.5) * 0.45;
          em.vx = -velocityWeight * (2.2 + Math.random() * 2.4) + (Math.random() - 0.5) * 0.85;
          em.vy = 0.95 + Math.random() * 1.95;
        } else {
          em.x += (em.vx + Math.sin(elapsed * 6.0 + i) * 0.35) * dt;
          em.y += em.vy * dt;
          em.vy += 0.45 * dt;
        }

        posArr[i * 3] = em.x;
        posArr[i * 3 + 1] = em.y;
        posArr[i * 3 + 2] = em.z;
        sizeArr[i] = em.size * layout.heroScale * ignition;
        lifeArr[i] = em.life / em.maxLife;
      }
      emberGeo.attributes.position.needsUpdate = true;
      emberGeo.attributes.aSize.needsUpdate = true;
      emberGeo.attributes.aLife.needsUpdate = true;

      renderer.render(scene, camera);
      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);

    return () => {
      disposed = true;
      cancelAnimationFrame(rafAlign);
      cancelAnimationFrame(rafId);
      ribbonObserver?.disconnect();
      window.removeEventListener('resize', handleResize);
      renderer?.domElement.removeEventListener('webglcontextlost', handleContextLost);
      renderer?.domElement.removeEventListener('webglcontextrestored', handleContextRestored);

      dustGeo.dispose();
      dustMat.dispose();
      ballGeo.dispose();
      ballMat.dispose();
      ballTextures.map.dispose();
      ballTextures.bumpMap.dispose();
      ballTextures.roughnessMap.dispose();
      coronaGeo.dispose();
      coronaMat.dispose();
      flameGeo.dispose();
      flameMat.dispose();
      emberGeo.dispose();
      emberMat.dispose();
      envTarget.dispose();
      renderer?.dispose();
      if (renderer && renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [active]);

  if (!active) return null;

  return (
    <div
      className={`fixed inset-0 z-[110] flex flex-col items-center justify-center overflow-hidden bg-[#020612] select-none transition-all duration-300 ${
        isClosing ? 'opacity-0 scale-110 pointer-events-none' : 'opacity-100 scale-100'
      }`}
    >
      {/* Sci-Fi Ambient Radial Nebula Backdrop (below WebGL canvas) */}
      <div
        aria-hidden="true"
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(ellipse 85% 60% at 50% 48%, rgba(234, 88, 12, 0.14) 0%, rgba(14, 116, 144, 0.14) 38%, rgba(2, 6, 18, 0.98) 80%)',
        }}
      />

      {/* Sci-Fi Perspective Horizon Grid Floor (subtle depth cue) */}
      <div
        aria-hidden="true"
        className="absolute inset-x-0 bottom-0 h-[36vh] pointer-events-none opacity-25"
        style={{
          backgroundImage:
            'linear-gradient(to right, rgba(56, 189, 248, 0.25) 1px, transparent 1px), linear-gradient(to bottom, rgba(56, 189, 248, 0.25) 1px, transparent 1px)',
          backgroundSize: '42px 42px',
          transform: 'perspective(380px) rotateX(68deg) translateY(38%)',
          maskImage: 'linear-gradient(to bottom, transparent 0%, black 65%)',
          WebkitMaskImage: 'linear-gradient(to bottom, transparent 0%, black 65%)',
        }}
      />

      {/* Layer 1 (z-10): 3D WebGL Living Flame + Spinning Football Stage */}
      <div ref={stageRef} className="absolute inset-0 z-10 pointer-events-none" />

      {/* Fallback atmospheric glow if WebGL context lost */}
      {webglLost && (
        <div
          aria-hidden="true"
          className="absolute inset-0 z-10 pointer-events-none flex items-center justify-center"
        >
          <div className="w-64 h-64 rounded-full bg-gradient-to-tr from-red-600/40 via-amber-500/35 to-yellow-300/20 animate-pulse" />
        </div>
      )}

      {/* Top-Left Corner: Registration Page Title Badge OR Locked Participant Name Badge with White Border */}
      {isRegisterMode ? (
        <div
          dir={lang === 'AR' ? 'rtl' : 'ltr'}
          className="fixed top-[max(0.75rem,env(safe-area-inset-top))] left-3 sm:left-5 z-30 flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-[#07152f]/85 border-2 border-white shadow-[0_0_16px_rgba(255,255,255,0.38)] backdrop-blur-md"
        >
          <span className="w-6 h-6 rounded-full border-2 border-white bg-gradient-to-br from-amber-400 to-yellow-500 text-black flex items-center justify-center shrink-0">
            <UserPlus className="w-3.5 h-3.5" />
          </span>
          <span className="text-xs sm:text-sm font-black text-white tracking-wide whitespace-nowrap">
            {lang === 'AR' ? 'صفحة التسجيل' : 'Page d’inscription'}
          </span>
        </div>
      ) : (
        participantProfile && (
          <div className="fixed top-[max(0.75rem,env(safe-area-inset-top))] left-3 sm:left-5 z-30 max-w-[calc(100vw-8.25rem)] flex flex-col items-start gap-2">
            <button
              type="button"
              onClick={() => {
                audioService.playClick();
                if (onReturnToRegistration) {
                  setShowReturnToRegisterConfirm((prev) => !prev);
                }
              }}
              dir="ltr"
              aria-expanded={showReturnToRegisterConfirm}
              title={
                lang === 'AR'
                  ? `اسم المشارك المثبت: ${participantProfile.fullName} — انقر للرجوع إلى صفحة التسجيل للتثبت`
                  : `Participant enregistré : ${participantProfile.fullName} — Cliquez pour revenir à la vérification`
              }
              aria-label={
                lang === 'AR'
                  ? `اسم المشارك: ${participantProfile.fullName}`
                  : `Participant : ${participantProfile.fullName}`
              }
              className="max-w-full flex items-center gap-2 pl-1.5 pr-3 py-1 rounded-2xl bg-gradient-to-r from-[#07152f]/90 via-[#0d2248]/85 to-[#07152f]/90 border-2 border-white shadow-[0_0_18px_rgba(255,255,255,0.42)] backdrop-blur-md cursor-pointer hover:brightness-110 active:scale-95 transition-all"
            >
              <span className="w-7 h-7 rounded-full border-2 border-white bg-[#0a1d42] text-yellow-300 flex items-center justify-center shrink-0 shadow-[inset_0_0_8px_rgba(255,255,255,0.28)]">
                <UserCheck className="w-3.5 h-3.5" />
              </span>
              <span
                dir="auto"
                className="text-xs sm:text-sm font-black text-white tracking-wide truncate drop-shadow-[0_1px_4px_rgba(0,0,0,0.95)]"
              >
                {participantProfile.fullName}
              </span>
            </button>

            {showReturnToRegisterConfirm && onReturnToRegistration && (
              <div
                dir={lang === 'AR' ? 'rtl' : 'ltr'}
                className="rounded-2xl bg-[#07152f]/95 border-2 border-white/90 shadow-[0_12px_28px_rgba(0,0,0,0.8)] backdrop-blur-md p-2.5 space-y-2 min-w-[215px]"
              >
                <p className="text-[11px] font-black text-amber-200 px-1">
                  {lang === 'AR'
                    ? 'الرجوع إلى صفحة التسجيل للتثبت؟'
                    : 'Retourner à la page d’inscription ?'}
                </p>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      audioService.playClick();
                      setShowReturnToRegisterConfirm(false);
                      void onReturnToRegistration();
                    }}
                    className="flex-1 min-h-[40px] px-3 py-1.5 rounded-xl bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-500 border border-white text-black text-xs font-black cursor-pointer active:scale-95 transition-all"
                  >
                    {lang === 'AR' ? 'رجوع للتثبت' : 'Vérifier'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      audioService.playClick();
                      setShowReturnToRegisterConfirm(false);
                    }}
                    className="min-h-[40px] px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/40 text-white text-xs font-bold cursor-pointer active:scale-95 transition-all"
                  >
                    {lang === 'AR' ? 'إلغاء' : 'Annuler'}
                  </button>
                </div>
              </div>
            )}
          </div>
        )
      )}

      {/* Language Toggle AR / FR on Intro & Registration Stage */}
      {onChangeLang && (
        <div className="fixed top-[max(0.75rem,env(safe-area-inset-top))] right-3 sm:right-5 z-30">
          <LanguageToggleButton lang={lang} onChangeLang={onChangeLang} />
        </div>
      )}

      {/* Layer 2 & 3 (z-20): Logo + PROMOSPORT at top, followed by Registration Form OR Home Notifications Bar */}
      <div
        className={`relative z-20 flex flex-col items-center w-full max-w-xl px-4 ${
          isRegisterMode
            ? 'justify-start sm:justify-center max-h-full overflow-y-auto pt-14 pb-6 sm:py-8 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]'
            : 'justify-center'
        }`}
      >
        {isRegisterMode ? (
          <div className="flex flex-col items-center justify-center w-full pt-1 pb-1">
            {/* TOP: Stationary Royal Ruby & Gold "MB" Shield */}
            <div
              className={`relative mb-2 sm:mb-3 flex items-center justify-center transition-all duration-700 ease-out ${
                mbRevealed
                  ? 'opacity-100 translate-y-0 scale-95 sm:scale-100'
                  : 'opacity-0 -translate-y-12 scale-50 pointer-events-none'
              }`}
            >
              <div className="relative z-10">
                <MbLogo size="xl" showLaser={false} showArrows={true} showPlaque={true} />
              </div>
            </div>

            {/* CENTER: Official PROMOSPORT 3D Ribbon Banner */}
            <div
              ref={ribbonRef}
              dir="ltr"
              className="relative w-full max-w-[360px] sm:max-w-[460px] flex items-center justify-center my-2 sm:my-3"
            >
              <div
                aria-hidden="true"
                className="absolute -inset-x-6 -inset-y-4 pointer-events-none"
                style={{
                  background:
                    'radial-gradient(ellipse 75% 55% at 55% 50%, rgba(249, 115, 22, 0.28) 0%, transparent 72%)',
                }}
              />
              <svg
                viewBox="0 0 640 156"
                className="w-full h-auto drop-shadow-[0_14px_32px_rgba(0,0,0,0.88)] overflow-visible"
              >
                <defs>
                  <linearGradient id="ribbonFrameGradReg" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#f8fafc" />
                    <stop offset="28%" stopColor="#cbd5e1" />
                    <stop offset="52%" stopColor="#fef08a" />
                    <stop offset="76%" stopColor="#94a3b8" />
                    <stop offset="100%" stopColor="#e2e8f0" />
                  </linearGradient>
                  <linearGradient id="ribbonBodyGradReg" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#081229" />
                    <stop offset="20%" stopColor="#0f2347" />
                    <stop offset="50%" stopColor="#1e1b4b" />
                    <stop offset="78%" stopColor="#7f1d1d" />
                    <stop offset="100%" stopColor="#991b1b" />
                  </linearGradient>
                  <linearGradient id="ribbonGlossGradReg" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="rgba(255,255,255,0.42)" />
                    <stop offset="55%" stopColor="rgba(255,255,255,0.08)" />
                    <stop offset="100%" stopColor="rgba(255,255,255,0)" />
                  </linearGradient>
                  <linearGradient id="promoWordGradReg" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#ffffff" />
                    <stop offset="35%" stopColor="#fca5a5" />
                    <stop offset="70%" stopColor="#ef4444" />
                    <stop offset="100%" stopColor="#b91c1c" />
                  </linearGradient>
                  <linearGradient id="sportWordGradReg" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#ffffff" />
                    <stop offset="45%" stopColor="#f8fafc" />
                    <stop offset="78%" stopColor="#fde047" />
                    <stop offset="100%" stopColor="#f59e0b" />
                  </linearGradient>
                  <linearGradient id="wingRedGradReg" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#dc2626" />
                    <stop offset="60%" stopColor="#ef4444" />
                    <stop offset="100%" stopColor="#f59e0b" />
                  </linearGradient>
                </defs>
                <polygon points="10,58 76,42 62,114 2,114" fill="url(#wingRedGradReg)" opacity="0.92" />
                <polygon points="576,42 638,42 628,114 562,114" fill="url(#wingRedGradReg)" opacity="0.95" />
                <path
                  d="M 48 36 C 195 22, 445 22, 598 36 L 578 122 C 435 109, 205 109, 28 122 Z"
                  fill="url(#ribbonFrameGradReg)"
                  stroke="#020617"
                  strokeWidth="3"
                />
                <path
                  d="M 54 42 C 198 29, 442 29, 591 42 L 573 116 C 432 103, 208 103, 36 116 Z"
                  fill="url(#ribbonBodyGradReg)"
                  stroke="rgba(253, 224, 71, 0.55)"
                  strokeWidth="1.6"
                />
                <path
                  d="M 58 44 C 198 32, 442 32, 586 44 L 580 74 C 440 64, 200 64, 48 74 Z"
                  fill="url(#ribbonGlossGradReg)"
                />
                <g transform="translate(88, 79)">
                  <circle cx="0" cy="0" r="19" fill="#b91c1c" stroke="#fef08a" strokeWidth="2.2" />
                  <circle cx="1.5" cy="0" r="11" fill="#ffffff" />
                  <circle cx="5" cy="0" r="8.5" fill="#b91c1c" />
                  <polygon
                    points="7,-4 8.2,-1.2 11.2,-1 8.8,0.9 9.7,3.8 7,2.1 4.3,3.8 5.2,0.9 2.8,-1 5.8,-1.2"
                    fill="#ffffff"
                  />
                </g>
                <g transform="translate(342, 91) skewX(-9)">
                  <text
                    x="3"
                    y="4"
                    textAnchor="middle"
                    fontFamily="Chakra Petch, Impact, Arial Black, sans-serif"
                    fontSize="50"
                    fontWeight="900"
                    letterSpacing="2.5"
                    fill="#020617"
                    opacity="0.92"
                  >
                    PROMOSPORT
                  </text>
                  <text
                    x="0"
                    y="0"
                    textAnchor="middle"
                    fontFamily="Chakra Petch, Impact, Arial Black, sans-serif"
                    fontSize="50"
                    fontWeight="900"
                    letterSpacing="2.5"
                    stroke="#0f172a"
                    strokeWidth="2.2"
                    paintOrder="stroke"
                  >
                    <tspan fill="url(#promoWordGradReg)">PROMO</tspan>
                    <tspan fill="url(#sportWordGradReg)">SPORT</tspan>
                  </text>
                </g>
                <path
                  d="M 46 112 C 208 100, 432 100, 566 112"
                  fill="none"
                  stroke="#facc15"
                  strokeWidth="2"
                  opacity="0.82"
                />
              </svg>
            </div>
          </div>
        ) : (
          <button
            type="button"
            onClick={onEnterGrille}
            aria-label={
              lang === 'AR'
                ? 'افتح واجهة القصاصة - بروموسبور'
                : 'Ouvrir la grille Promosport'
            }
            className="flex flex-col items-center justify-center w-full pt-2 pb-1 cursor-pointer group focus:outline-none"
          >
            {/* TOP: Stationary Royal Ruby & Gold "MB" Shield with golden orbital light rings (no radial blur/radiations, no shield spin, fixed colors) */}
            <div
              className={`relative mb-3 sm:mb-4 flex items-center justify-center transition-all duration-700 ease-out ${
                mbRevealed
                  ? 'opacity-100 translate-y-0 scale-100'
                  : 'opacity-0 -translate-y-12 scale-50 pointer-events-none'
              }`}
            >
              <div className="relative z-10 group-hover:scale-105 transition-transform duration-300">
                <MbLogo size="xl" showLaser={false} showArrows={true} showPlaque={true} />
              </div>
            </div>

          {/* CENTER: Clean Official PROMOSPORT 3D Ribbon Banner */}
          <div
            ref={ribbonRef}
            dir="ltr"
            className="relative w-full max-w-[390px] sm:max-w-[480px] flex items-center justify-center my-4 transition-transform duration-300 group-hover:scale-[1.03] group-active:scale-[0.98]"
          >
            {/* Ambient warm glow directly behind ribbon linking it visually to the 3D flames */}
            <div
              aria-hidden="true"
              className="absolute -inset-x-6 -inset-y-4 pointer-events-none"
              style={{
                background:
                  'radial-gradient(ellipse 75% 55% at 55% 50%, rgba(249, 115, 22, 0.28) 0%, transparent 72%)',
              }}
            />

            {/* Metallic 3D Curved PROMOSPORT Banner Ribbon */}
            <svg
              viewBox="0 0 640 156"
              className="w-full h-auto drop-shadow-[0_14px_32px_rgba(0,0,0,0.88)] overflow-visible"
            >
              <defs>
                <linearGradient id="ribbonFrameGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#f8fafc" />
                  <stop offset="28%" stopColor="#cbd5e1" />
                  <stop offset="52%" stopColor="#fef08a" />
                  <stop offset="76%" stopColor="#94a3b8" />
                  <stop offset="100%" stopColor="#e2e8f0" />
                </linearGradient>

                <linearGradient id="ribbonBodyGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#081229" />
                  <stop offset="20%" stopColor="#0f2347" />
                  <stop offset="50%" stopColor="#1e1b4b" />
                  <stop offset="78%" stopColor="#7f1d1d" />
                  <stop offset="100%" stopColor="#991b1b" />
                </linearGradient>

                <linearGradient id="ribbonGlossGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="rgba(255,255,255,0.42)" />
                  <stop offset="55%" stopColor="rgba(255,255,255,0.08)" />
                  <stop offset="100%" stopColor="rgba(255,255,255,0)" />
                </linearGradient>

                <linearGradient id="promoWordGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#ffffff" />
                  <stop offset="35%" stopColor="#fca5a5" />
                  <stop offset="70%" stopColor="#ef4444" />
                  <stop offset="100%" stopColor="#b91c1c" />
                </linearGradient>

                <linearGradient id="sportWordGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#ffffff" />
                  <stop offset="45%" stopColor="#f8fafc" />
                  <stop offset="78%" stopColor="#fde047" />
                  <stop offset="100%" stopColor="#f59e0b" />
                </linearGradient>

                <linearGradient id="wingRedGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#dc2626" />
                  <stop offset="60%" stopColor="#ef4444" />
                  <stop offset="100%" stopColor="#f59e0b" />
                </linearGradient>
              </defs>

              <polygon points="10,58 76,42 62,114 2,114" fill="url(#wingRedGrad)" opacity="0.92" />
              <polygon points="576,42 638,42 628,114 562,114" fill="url(#wingRedGrad)" opacity="0.95" />

              <path
                d="M 48 36 C 195 22, 445 22, 598 36 L 578 122 C 435 109, 205 109, 28 122 Z"
                fill="url(#ribbonFrameGrad)"
                stroke="#020617"
                strokeWidth="3"
              />

              <path
                d="M 54 42 C 198 29, 442 29, 591 42 L 573 116 C 432 103, 208 103, 36 116 Z"
                fill="url(#ribbonBodyGrad)"
                stroke="rgba(253, 224, 71, 0.55)"
                strokeWidth="1.6"
              />

              <path
                d="M 58 44 C 198 32, 442 32, 586 44 L 580 74 C 440 64, 200 64, 48 74 Z"
                fill="url(#ribbonGlossGrad)"
              />

              {/* Tunisian Crescent & Star Sport Crest Badge */}
              <g transform="translate(88, 79)">
                <circle cx="0" cy="0" r="19" fill="#b91c1c" stroke="#fef08a" strokeWidth="2.2" />
                <circle cx="1.5" cy="0" r="11" fill="#ffffff" />
                <circle cx="5" cy="0" r="8.5" fill="#b91c1c" />
                <polygon
                  points="7,-4 8.2,-1.2 11.2,-1 8.8,0.9 9.7,3.8 7,2.1 4.3,3.8 5.2,0.9 2.8,-1 5.8,-1.2"
                  fill="#ffffff"
                />
              </g>

              {/* Bold Italic Bevelled PROMOSPORT Wordmark */}
              <g transform="translate(342, 91) skewX(-9)">
                <text
                  x="3"
                  y="4"
                  textAnchor="middle"
                  fontFamily="Chakra Petch, Impact, Arial Black, sans-serif"
                  fontSize="50"
                  fontWeight="900"
                  letterSpacing="2.5"
                  fill="#020617"
                  opacity="0.92"
                >
                  PROMOSPORT
                </text>

                <text
                  x="0"
                  y="0"
                  textAnchor="middle"
                  fontFamily="Chakra Petch, Impact, Arial Black, sans-serif"
                  fontSize="50"
                  fontWeight="900"
                  letterSpacing="2.5"
                  stroke="#0f172a"
                  strokeWidth="2.2"
                  paintOrder="stroke"
                >
                  <tspan fill="url(#promoWordGrad)">PROMO</tspan>
                  <tspan fill="url(#sportWordGrad)">SPORT</tspan>
                </text>
              </g>

              <path
                d="M 46 112 C 208 100, 432 100, 566 112"
                fill="none"
                stroke="#facc15"
                strokeWidth="2"
                opacity="0.82"
              />
            </svg>
          </div>

          </button>
        )}

        {/* CONDITIONAL BELOW LOGO/PROMOSPORT: ONE-TIME REGISTRATION FORM vs HOME NOTIFICATIONS BAR */}
        {isRegisterMode ? (
          <div
            dir={lang === 'AR' ? 'rtl' : 'ltr'}
            className="w-full max-w-[440px] mt-2 sm:mt-3 rounded-2xl backdrop-blur-md bg-gradient-to-br from-[#07152f]/72 via-[#0b224a]/60 to-[#040d21]/78 border border-sky-300/75 shadow-[0_14px_34px_rgba(0,0,0,0.72),inset_0_0_18px_rgba(56,189,248,0.2)] p-4 sm:p-5 space-y-3.5"
          >
            {/* Card Header Row: : تسجيل جديد + أيقونة مسجل */}
            <div className="flex items-center justify-between gap-2 pb-2.5 border-b border-white/15">
              <button
                type="button"
                onClick={handleSelectNewRegistration}
                className={`min-h-[44px] px-2.5 py-1.5 rounded-xl flex items-center gap-2 transition-all cursor-pointer active:scale-95 ${
                  !isRegisteredLookupOpen
                    ? 'bg-white/12 border border-amber-300/75 shadow-[0_0_12px_rgba(250,204,21,0.28)]'
                    : 'bg-transparent border border-transparent hover:bg-white/10 opacity-85 hover:opacity-100'
                }`}
              >
                <span className="w-8 h-8 rounded-xl bg-gradient-to-br from-yellow-300 via-amber-400 to-yellow-500 text-black flex items-center justify-center shadow-[0_0_12px_rgba(250,204,21,0.65)] shrink-0">
                  <UserPlus className="w-4 h-4" />
                </span>
                <span className="text-sm sm:text-base font-black text-white tracking-wide drop-shadow-[0_1px_4px_rgba(0,0,0,0.95)]">
                  {lang === 'AR' ? ': تسجيل جديد' : 'Nouvelle inscription :'}
                </span>
              </button>

              <button
                type="button"
                onClick={handleOpenRegisteredLookup}
                aria-expanded={isRegisteredLookupOpen}
                className={`min-h-[44px] px-3 py-1.5 rounded-xl border-2 flex items-center gap-1.5 text-xs sm:text-sm font-black transition-all cursor-pointer active:scale-95 shrink-0 ${
                  isRegisteredLookupOpen
                    ? 'bg-gradient-to-r from-sky-400/25 via-amber-400/20 to-sky-400/25 border-white text-yellow-200 shadow-[0_0_16px_rgba(250,204,21,0.45)]'
                    : 'bg-[#040d22]/80 hover:bg-[#081a3d] border-white/80 text-white shadow-[0_4px_14px_rgba(0,0,0,0.45)]'
                }`}
              >
                <KeyRound className="w-4 h-4 text-yellow-300 shrink-0" />
                <span>{lang === 'AR' ? 'مسجل' : 'Inscrit'}</span>
              </button>
            </div>

            {isRegisteredLookupOpen ? (
              <form onSubmit={handleVerifySubmit} noValidate className="space-y-3.5">
                {/* Framed Icon Container for Registered Name + Two Digits */}
                <div className="rounded-2xl border-2 border-white/90 bg-[#040d22]/85 p-3.5 shadow-[0_8px_22px_rgba(0,0,0,0.55),inset_0_0_14px_rgba(255,255,255,0.08)] space-y-2">
                  <label
                    htmlFor="promosport-registered-verify-name"
                    className="flex items-center gap-1.5 text-xs sm:text-sm font-black text-yellow-300"
                  >
                    <KeyRound className="w-4 h-4 text-sky-300 shrink-0" />
                    <span>
                      {lang === 'AR'
                        ? 'اسم صاحب التطبيق مع الرقمين'
                        : 'Nom du participant avec les 2 chiffres'}
                    </span>
                  </label>

                  <input
                    ref={verifyInputRef}
                    id="promosport-registered-verify-name"
                    type="text"
                    required
                    maxLength={48}
                    autoComplete="off"
                    dir="auto"
                    value={verifyInput}
                    onChange={(e) => {
                      setVerifyInput(e.target.value);
                      if (verifyError) setVerifyError(null);
                    }}
                    placeholder={
                      lang === 'AR' ? 'مثال: أحمد 47 أو أحمد47' : 'Ex : Ahmed 47 ou Ahmed47'
                    }
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#030a1b]/95 border-2 border-sky-300/75 focus:border-white focus:outline-none text-white placeholder:text-slate-400 text-sm font-bold shadow-[inset_0_2px_8px_rgba(0,0,0,0.7)] transition-colors"
                  />

                  {verifyError && (
                    <div
                      role="alert"
                      className="flex items-center gap-2 px-3 py-2 rounded-xl bg-red-950/90 border border-red-400/85 text-red-100 text-xs sm:text-sm font-black"
                    >
                      <AlertCircle className="w-4 h-4 text-red-300 shrink-0" />
                      <span>{verifyError}</span>
                    </div>
                  )}
                </div>

                {/* Centered Submit Button: فتح */}
                <div className="flex justify-center pt-0.5">
                  <button
                    type="submit"
                    disabled={isVerifying}
                    className="min-w-[175px] min-h-[44px] px-7 py-2.5 rounded-2xl bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-500 hover:from-yellow-200 hover:to-amber-300 disabled:opacity-65 border-2 border-white text-black font-black text-sm sm:text-base shadow-[0_0_22px_rgba(250,204,21,0.75)] flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-95"
                  >
                    <Unlock className="w-4 h-4 shrink-0" />
                    <span>
                      {isVerifying
                        ? lang === 'AR'
                          ? 'جارٍ التحقق...'
                          : 'Vérification...'
                        : lang === 'AR'
                          ? 'فتح'
                          : 'Ouvrir'}
                    </span>
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleRegistrationSubmit} noValidate className="space-y-3.5">
                {/* Mandatory Input: : اسم المشارك */}
                <div className="space-y-1.5">
                  <label
                    htmlFor="promosport-participant-name"
                    className="flex items-center gap-1.5 text-xs sm:text-sm font-black text-yellow-300"
                  >
                    <UserCheck className="w-4 h-4 text-sky-300 shrink-0" />
                    <span>{lang === 'AR' ? ': اسم المشارك' : 'Nom du participant :'}</span>
                    <span className="text-red-400 font-black" aria-hidden="true">
                      *
                    </span>
                  </label>

                  <input
                    id="promosport-participant-name"
                    type="text"
                    required
                    maxLength={40}
                    autoComplete="name"
                    dir="auto"
                    value={participantInput}
                    onChange={(e) => {
                      setParticipantInput(e.target.value);
                      if (registrationError) setRegistrationError(null);
                    }}
                    placeholder={
                      lang === 'AR'
                        ? 'اكتب اسم المشارك هنا (إجباري)...'
                        : 'Saisissez votre nom (obligatoire)...'
                    }
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#030a1b]/90 border-2 border-sky-300/60 focus:border-white focus:outline-none text-white placeholder:text-slate-400 text-sm font-bold shadow-[inset_0_2px_8px_rgba(0,0,0,0.65)] transition-colors"
                  />

                  <p className="text-[10.5px] text-sky-100/80 font-semibold leading-relaxed">
                    {lang === 'AR'
                      ? 'سيتم إضافة رقمين عشوائيين تلقائياً لتمييز اسمك وتثبيته نهائياً دون إمكانية تغييره.'
                      : 'Deux chiffres aléatoires uniques seront ajoutés et verrouillés définitivement avec votre nom.'}
                  </p>
                </div>

                {registrationError && (
                  <div
                    role="alert"
                    className="flex items-center gap-2 px-3 py-2 rounded-xl bg-red-950/85 border border-red-400/80 text-red-100 text-xs font-bold"
                  >
                    <AlertCircle className="w-4 h-4 text-red-300 shrink-0" />
                    <span>{registrationError}</span>
                  </div>
                )}

                {/* Centered Submit Button: تسجيل */}
                <div className="flex justify-center pt-1">
                  <button
                    type="submit"
                    disabled={isRegistering}
                    className="min-w-[175px] min-h-[44px] px-7 py-2.5 rounded-2xl bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-500 hover:from-yellow-200 hover:to-amber-300 disabled:opacity-65 border-2 border-white text-black font-black text-sm sm:text-base shadow-[0_0_22px_rgba(250,204,21,0.75)] flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-95"
                  >
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>
                      {isRegistering
                        ? lang === 'AR'
                          ? 'جارٍ التسجيل...'
                          : 'Inscription...'
                        : lang === 'AR'
                          ? 'تسجيل'
                          : 'S’inscrire'}
                    </span>
                  </button>
                </div>
              </form>
            )}
          </div>
        ) : (
          /* FROSTED GLASS NOTIFICATIONS BAR DIRECTLY BELOW PROMOSPORT FRAME */
          <div
            dir={lang === 'AR' ? 'rtl' : 'ltr'}
            className="w-full max-w-[440px] mt-3 rounded-2xl backdrop-blur-md bg-gradient-to-br from-[#07152f]/58 via-[#0b224a]/46 to-[#040d21]/62 border border-sky-300/65 shadow-[0_10px_28px_rgba(0,0,0,0.6),inset_0_0_16px_rgba(56,189,248,0.16)] p-2.5 sm:p-3 space-y-2"
          >
            {/* Strip Header: Centered "تنبيه حي" + Clear Old Notifications Icon */}
            <div className="relative flex items-center justify-between gap-2 pb-1.5 border-b border-white/15">
              <div className="flex items-center gap-1.5 shrink-0">
                <Bell className="w-3.5 h-3.5 text-yellow-300 shrink-0" />
                <span className="text-[11px] font-mono font-black text-amber-200 tabular-nums">
                  {liveNotifications.length}
                </span>
              </div>

              <span className="text-[11px] sm:text-xs font-black text-white tracking-wide drop-shadow-[0_1px_4px_rgba(0,0,0,0.95)] truncate">
                {lang === 'AR'
                  ? 'تنبيه حي • الصفحة الرئيسية وبقية الخانات'
                  : 'Alertes en direct • Accueil & Grilles'}
              </span>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  audioService.playClick();
                  onClearNotifications?.();
                }}
                disabled={liveNotifications.length === 0}
                title={
                  lang === 'AR'
                    ? 'فسخ الإشعارات القديمة وإظهار الإشعارات الجديدة دوماً'
                    : 'Effacer les anciennes alertes'
                }
                aria-label={lang === 'AR' ? 'فسخ الإشعارات القديمة' : 'Effacer les alertes'}
                className="min-h-[30px] px-2 py-1 rounded-xl bg-red-600/25 hover:bg-red-600/80 disabled:opacity-40 disabled:cursor-not-allowed border border-red-400/70 text-red-100 text-[10.5px] font-black flex items-center gap-1 transition-all cursor-pointer active:scale-95 shrink-0"
              >
                <Trash2 className="w-3 h-3 shrink-0" />
                <span>{lang === 'AR' ? 'فسخ' : 'Effacer'}</span>
              </button>
            </div>

            {/* Live Always-Updating Feed (New notifications always appear automatically, even after clearing) */}
            {liveNotifications.length === 0 ? (
              <div className="py-2.5 text-center text-[11px] text-sky-100/85 font-bold">
                {lang === 'AR'
                  ? 'لا توجد إشعارات حالياً — ستظهر الإشعارات الجديدة هنا دوماً فور وصولها.'
                  : 'Aucune alerte pour le moment — les nouvelles alertes s’afficheront ici automatiquement.'}
              </div>
            ) : (
              <div className="space-y-1.5 max-h-32 overflow-y-auto [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
                {liveNotifications.map((item) => {
                  const isGoal = item.kind === 'goal';
                  const isGrille = item.kind === 'grille' || item.kind === 'winners';
                  const isMessage = item.kind === 'message';
                  return (
                    <div
                      key={item.id}
                      role="button"
                      tabIndex={0}
                      onClick={() => onOpenNotification?.(item)}
                      onKeyDown={(event) => {
                        if (event.key === 'Enter' || event.key === ' ') {
                          event.preventDefault();
                          onOpenNotification?.(item);
                        }
                      }}
                      aria-label={
                        lang === 'AR'
                          ? `${item.title}. انقر للانتقال إلى الصفحة المناسبة`
                          : `${item.title}. Cliquer pour ouvrir`
                      }
                      title={lang === 'AR' ? 'انقر للانتقال إلى الصفحة المطلوبة' : 'Cliquer pour ouvrir'}
                      className={`flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-xl border cursor-pointer hover:ring-2 hover:ring-yellow-300/70 active:scale-[0.99] transition-all ${
                        isMessage
                          ? 'bg-emerald-500/20 border-emerald-400/70'
                          : isGoal
                          ? 'bg-amber-500/18 border-amber-400/55'
                          : isGrille
                          ? 'bg-cyan-500/15 border-cyan-400/50'
                          : 'bg-slate-900/65 border-white/15'
                      }`}
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <span
                          className={`shrink-0 w-5 h-5 rounded-lg flex items-center justify-center ${
                            isMessage
                              ? 'bg-emerald-400 text-black'
                              : isGoal
                              ? 'bg-amber-400 text-black'
                              : isGrille
                              ? 'bg-cyan-400 text-black'
                              : 'bg-emerald-500 text-black'
                          }`}
                        >
                          {isMessage ? (
                            <Mail className="w-3 h-3" />
                          ) : isGoal ? (
                            <Zap className="w-3 h-3" />
                          ) : isGrille ? (
                            <Trophy className="w-3 h-3" />
                          ) : (
                            <Flame className="w-3 h-3" />
                          )}
                        </span>
                        <div className="min-w-0">
                          <div className="text-[11px] font-black text-white truncate flex items-center gap-1.5">
                            <span className="truncate">{item.title}</span>
                            {isMessage && item.senderFullName && (
                              <span
                                dir="ltr"
                                className="shrink-0 px-1.5 py-0.2 rounded-md bg-yellow-400/20 border border-yellow-300/60 text-yellow-200 text-[9.5px] font-black"
                              >
                                {item.senderFullName}
                              </span>
                            )}
                          </div>
                          <div className="text-[9.5px] text-sky-100/80 truncate">
                            {item.message}
                          </div>
                        </div>
                      </div>
                      <div className="shrink-0 flex flex-col items-end gap-0.5">
                        {item.scoreLabel && (
                          <span
                            dir="ltr"
                            className="text-[10px] font-mono font-black text-yellow-200 tabular-nums"
                          >
                            {item.scoreLabel}
                          </span>
                        )}
                        <span
                          dir="ltr"
                          className="text-[9px] font-mono text-amber-200/90 tabular-nums"
                        >
                          {item.timestamp}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
