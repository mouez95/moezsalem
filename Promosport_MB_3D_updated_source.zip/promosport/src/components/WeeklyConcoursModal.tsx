/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  X,
  ArrowRight,
  Lock,
  Smartphone,
  LayoutGrid,
  Ticket,
  CheckCircle2,
  Trash2,
  Edit3,
  Save,
  Settings,
  Download,
  Check,
  FolderArchive,
  Coins,
  Receipt,
  Hash,
  Package,
  PhoneCall,
  CheckSquare,
  RefreshCw,
  KeyRound,
  Delete,
  Unlock,
  Radio,
  Clock,
  Bell,
  Mail,
  Send,
  UserCheck,
  Users,
} from 'lucide-react';
import {
  WeeklyConcours,
  WeeklyConcoursMatch,
  UserBetSlip,
  AppSettings,
  PromosportGrille,
  LiveNotificationItem,
  ParticipantProfile,
  RegisteredDirectoryUser,
  SlipMessageRecord,
} from '../types/promosport';
import {
  INITIAL_WEEKLY_CONCOURS,
  INITIAL_GRILLES,
  getOrderedRecentTirageGrilles,
} from '../services/promosportData';
import {
  loadUserSlips,
  saveOrUpdateSlip,
  deleteSlip,
  clearAllSlips,
  loadAppSettings,
  saveAppSettings,
  DEFAULT_APP_SETTINGS,
} from '../services/storageService';
import { calculatePromosportPrice } from '../services/pricingService';
import { evaluateConcoursRealTime, computeResultSign } from '../services/matchLiveService';
import { computeSlipSummaryStats } from '../services/slipStatsService';
import { audioService } from '../services/audioService';
import {
  formatConcoursPlusOneLabel,
  formatUtcPlusOneClock,
  formatUtcPlusOneDateString,
  formatUtcPlusOneShortTime,
  parseTunisDateTimeToUtcMs,
  useUtcClock,
} from '../services/timeUtils';
import { syncAppChangesToWorkspace } from '../services/offlineExportService';
import { MbLogo } from './MbLogo';
import { BroadcastScoreboardMatch } from './BroadcastScoreboardMatch';
import { PromosportUnifiedBadge } from './PromosportUnifiedBadge';
import { Grille3DWheelView } from './Grille3DWheelView';
import { SavedSlipFullPageView } from './SavedSlipFullPageView';
import { SlipSummaryBadges } from './SlipSummaryBadges';
import { PinterestScoreboardCard } from './PinterestScoreboardCard';
import { TirageFrozenSnapshotCard } from './TirageFrozenSnapshotCard';
import { AppInstallPromptHub } from './AppInstallPromptHub';
import { SaveSlipFieryPortal3D } from './SaveSlipFieryPortal3D';
import { LiveMatchesScanView } from './LiveMatchesScanView';
import { SlipMessagesLogView } from './SlipMessagesLogView';
import { LanguageToggleButton } from './LanguageToggleButton';
import {
  fetchRegisteredUsersDirectory,
  sendSlipToParticipant,
  markSlipMessageSaved,
  deleteSlipMessage,
} from '../services/slipMessagesService';
import {
  translateTeamToArabic,
  translateTeamToFrench,
} from '../services/teamTranslationService';

interface WeeklyConcoursModalProps {
  isOpen: boolean;
  onClose: () => void;
  concours: WeeklyConcours;
  onUpdateConcours?: (updated: WeeklyConcours) => void;
  grilles?: PromosportGrille[];
  onRefreshSync?: () => Promise<void> | void;
  initialTab?: 'grille' | 'tirage' | 'live' | 'settings' | 'apk';
  onTabChange?: (tab: 'grille' | 'tirage' | 'live' | 'settings' | 'apk') => void;
  appSettings?: AppSettings;
  onUpdateAppSettings?: (settings: AppSettings) => void;
  externalEntryPhase?: 'idle' | 'waiting' | 'descending';
  asMainPage?: boolean;
  onOpenNotifications?: (section?: 'live' | 'general') => void;
  hasUnreadAlerts?: boolean;
  onOpenIntroStage?: () => void;
  liveNotifications?: LiveNotificationItem[];
  liveUnreadCount?: number;
  generalUnreadCount?: number;
  onClearLiveNotifications?: () => void;
  onMarkLiveNotificationsRead?: () => void;
  onAppendLiveNotification?: (
    item: Omit<LiveNotificationItem, 'timestamp' | 'createdAtMs'>,
    options?: { silent?: boolean }
  ) => void;
  onScanEnabledChange?: (enabled: boolean) => void;
  onOpenLiveNotification?: (item: LiveNotificationItem) => void;
  highlightedTab?: 'grille' | 'tirage' | 'live' | 'apk' | 'messages' | null;
  lang?: 'AR' | 'FR';
  onChangeLang?: (lang: 'AR' | 'FR') => void;
  participantProfile?: ParticipantProfile | null;
  sentMessages?: SlipMessageRecord[];
  receivedMessages?: SlipMessageRecord[];
  messagesServerError?: string | null;
  messagesUnreadCount?: number;
  openMessagesLogSignal?: number;
  onMarkMessagesRead?: () => void;
  onRefreshMessages?: () => Promise<void> | void;
  onSlipMessageSent?: (msg: SlipMessageRecord) => void;
  onMessagesChanged?: () => Promise<void> | void;
}

const PROTECTED_TABS_PIN = '1777';
const LANGUAGE_STORAGE_KEY = 'promosport_display_language_v1';

export const WeeklyConcoursModal: React.FC<WeeklyConcoursModalProps> = ({
  isOpen,
  onClose,
  concours,
  grilles = INITIAL_GRILLES,
  onRefreshSync,
  initialTab = 'grille',
  onTabChange,
  appSettings: initialAppSettings,
  onUpdateAppSettings,
  externalEntryPhase = 'idle',
  asMainPage = false,
  onOpenNotifications,
  onOpenIntroStage,
  liveNotifications = [],
  liveUnreadCount = 0,
  generalUnreadCount = 0,
  onClearLiveNotifications,
  onMarkLiveNotificationsRead,
  onAppendLiveNotification,
  onScanEnabledChange,
  onOpenLiveNotification,
  highlightedTab = null,
  lang: externalLang,
  onChangeLang,
  participantProfile = null,
  sentMessages = [],
  receivedMessages = [],
  messagesServerError = null,
  messagesUnreadCount = 0,
  openMessagesLogSignal = 0,
  onMarkMessagesRead,
  onRefreshMessages,
  onSlipMessageSent,
  onMessagesChanged,
}) => {
  const onRefreshSyncRef = useRef(onRefreshSync);
  onRefreshSyncRef.current = onRefreshSync;
  const lastTirageAutoSyncMsRef = useRef<number>(0);

  // Active competition synced from parent concours (default international Concours No 936)
  const [activeConcours, setActiveConcours] = useState<WeeklyConcours>(
    concours || INITIAL_WEEKLY_CONCOURS
  );
  const prevConcoursNumRef = useRef<number>((concours || INITIAL_WEEKLY_CONCOURS).number);

  useEffect(() => {
    if (concours) {
      if (prevConcoursNumRef.current !== concours.number) {
        // Silent rollover: reset temporary selections when a new concours arrives
        setCurrentSelections({});
        setEditingSlipId(null);
        prevConcoursNumRef.current = concours.number;
      }
      setActiveConcours(concours);
    }
  }, [concours]);

  // Bottom navigation: 'grille' | 'tirage' | 'live' | 'apk' (Settings lives inside 'apk' as an unlocked sub-page)
  const [activeBottomNav, setActiveBottomNav] = useState<'grille' | 'tirage' | 'live' | 'apk'>(
    initialTab === 'settings' ? 'apk' : initialTab
  );
  const { timePlusOne } = useUtcClock(1000);
  const [liveBadgeCount, setLiveBadgeCount] = useState<number>(0);
  const [promptSubPage, setPromptSubPage] = useState<'hub' | 'settings'>(
    initialTab === 'settings' ? 'settings' : 'hub'
  );
  const prevInitialTabRef = useRef(initialTab);

  // Password lock (PIN: 1777) protecting only the Prompt/APK hub (Settings sub-page opens freely without PIN)
  const [isProtectedTabsUnlocked, setIsProtectedTabsUnlocked] = useState<boolean>(false);
  const [pinInput, setPinInput] = useState<string>('');
  const [pinError, setPinError] = useState<string | null>(null);

  // Synchronous effective concours number so Tirage updates on the exact same frame as a new concours rollover
  const effectiveConcoursNumber = concours?.number ?? activeConcours.number;
  const expectedPrevTirageNumber = effectiveConcoursNumber - 1;

  // Strictly lock Tirage to the immediate preceding grille (e.g. 936 while 937 is active)
  const recentGrilles = useMemo(
    () => getOrderedRecentTirageGrilles(grilles, effectiveConcoursNumber),
    [grilles, effectiveConcoursNumber]
  );

  const activeTirage = recentGrilles[0];

  const [isRefreshingTirage, setIsRefreshingTirage] = useState<boolean>(false);

  const handleRefreshTirageFromSite = async () => {
    if (isRefreshingTirage) return;
    setIsRefreshingTirage(true);
    try {
      if (onRefreshSyncRef.current) {
        await onRefreshSyncRef.current();
      }
    } finally {
      setIsRefreshingTirage(false);
    }
  };

  const isTirageOfficialFrozen = Boolean(
    activeTirage &&
      activeTirage.status === 'official' &&
      activeTirage.winnersFormatted !== 'قيد التحديد الرسمي'
  );

  const isMissingExpectedPrevTirage = !activeTirage || activeTirage.number !== expectedPrevTirageNumber;

  // Throttled check when opening Tirage IF expected previous grille (N - 1) is missing OR payouts have NOT yet published
  // Once official N - 1 payouts appear, stop refreshing and leave Tirage frozen as a static image
  useEffect(() => {
    if (!isOpen || activeBottomNav !== 'tirage' || !onRefreshSyncRef.current) return;
    if (!isMissingExpectedPrevTirage && isTirageOfficialFrozen) return;
    const now = Date.now();
    const cooldownMs = isMissingExpectedPrevTirage ? 3500 : 8000;
    if (now - lastTirageAutoSyncMsRef.current < cooldownMs) return;
    lastTirageAutoSyncMsRef.current = now;
    void onRefreshSyncRef.current();
  }, [isOpen, activeBottomNav, isTirageOfficialFrozen, isMissingExpectedPrevTirage, expectedPrevTirageNumber]);

  // Sub-tabs in Grille view: 'mondiale' | 'nationale' | 'slips'
  const [grilleSubTab, setGrilleSubTab] = useState<'mondiale' | 'nationale' | 'slips'>('mondiale');

  // National check states (when no national concours is published)
  const [isCheckingNational, setIsCheckingNational] = useState<boolean>(false);
  const [lastNationalCheckTime, setLastNationalCheckTime] = useState<string>('');

  // Language toggle: AR / FR, synchronized with parent and persisted between launches
  const [internalLang, setInternalLang] = useState<'AR' | 'FR'>(() => {
    try {
      return localStorage.getItem(LANGUAGE_STORAGE_KEY) === 'FR' ? 'FR' : 'AR';
    } catch {
      return 'AR';
    }
  });
  const lang: 'AR' | 'FR' = externalLang ?? internalLang;
  const handleChangeLang = (next: 'AR' | 'FR') => {
    setInternalLang(next);
    try {
      localStorage.setItem(LANGUAGE_STORAGE_KEY, next);
    } catch {
      // Ignore private-mode storage restrictions.
    }
    onChangeLang?.(next);
  };
  useEffect(() => {
    try {
      localStorage.setItem(LANGUAGE_STORAGE_KEY, lang);
    } catch {
      // Ignore private-mode storage restrictions.
    }
  }, [lang]);

  const handleRefreshNational = async () => {
    audioService.playClick();
    setIsCheckingNational(true);
    try {
      if (onRefreshSync) {
        await onRefreshSync();
      }
    } finally {
      setIsCheckingNational(false);
      const timeStr = `${formatUtcPlusOneClock()} +1`;
      setLastNationalCheckTime(timeStr);
      audioService.playChime();
      setSlipNoticeMessage(
        lang === 'AR'
          ? 'تم التحقق بنجاح من موقع promosport-pronostic.com — القصاصة الوطنية غير منشورة حالياً.'
          : 'Vérifié sur promosport-pronostic.com — aucune grille nationale publiée actuellement.'
      );
      setTimeout(() => setSlipNoticeMessage(null), 4000);
    }
  };

  // Floating glass ribbon open/close state in Grille (auto-closes on scroll, opens manually)
  const [isGrilleRibbonOpen, setIsGrilleRibbonOpen] = useState<boolean>(true);

  const triggerGrilleIconFlash = (e: React.MouseEvent<HTMLDivElement>) => {
    if (activeBottomNav !== 'grille' || selectedFullSlip) return;
    const targetEl = (e.target as HTMLElement | null)?.closest(
      'button, [role="button"], [data-flash-icon]'
    ) as HTMLElement | null;
    if (!targetEl || targetEl.dataset.noFlash === 'true') return;

    window.requestAnimationFrame(() => {
      targetEl.classList.remove('grille-icon-flash');
      targetEl.classList.add('grille-icon-flash');
      window.setTimeout(() => {
        targetEl.classList.remove('grille-icon-flash');
      }, 260);
    });
  };

  // App Settings state
  const [settings, setSettings] = useState<AppSettings>(() => initialAppSettings || loadAppSettings());
  const [settingsSavedAlert, setSettingsSavedAlert] = useState<boolean>(false);

  // Slips from storage (strictly NO virtual/dummy slips)
  const [userSlips, setUserSlips] = useState<UserBetSlip[]>(() => loadUserSlips());
  const [editingSlipId, setEditingSlipId] = useState<string | null>(null);
  const [slipNoticeMessage, setSlipNoticeMessage] = useState<string | null>(null);

  // 3D Save Slip Transition: 'idle' -> 'bursting' (page shatters w/ money & fiery portal opens) -> 'descending' (fresh page drops from top)
  const [saveTransitionPhase, setSaveTransitionPhase] = useState<'idle' | 'bursting' | 'descending'>('idle');
  const [showFierySavePortal, setShowFierySavePortal] = useState<boolean>(false);
  const saveTransitionTimersRef = useRef<number[]>([]);

  useEffect(() => {
    if (!isOpen) {
      saveTransitionTimersRef.current.forEach((id) => window.clearTimeout(id));
      saveTransitionTimersRef.current = [];
      setSaveTransitionPhase('idle');
      setShowFierySavePortal(false);
    }
    return () => {
      saveTransitionTimersRef.current.forEach((id) => window.clearTimeout(id));
      saveTransitionTimersRef.current = [];
    };
  }, [isOpen]);

  // Selected choices map: matchId -> array of choices ('1' | 'X' | '2')
  const [currentSelections, setCurrentSelections] = useState<Record<number, ('1' | 'X' | '2')[]>>({});

  // Expanded slip in Saved Slips page
  const [expandedSlipId, setExpandedSlipId] = useState<string | null>(null);
  // Full-page active slip view
  const [selectedFullSlip, setSelectedFullSlip] = useState<UserBetSlip | null>(null);

  // Slip Messages Log (سجل الرسائل) & Read-Only Message Viewer
  const [isMessagesLogOpen, setIsMessagesLogOpen] = useState<boolean>(false);
  const [selectedMessageSlip, setSelectedMessageSlip] = useState<{
    msg: SlipMessageRecord;
    direction: 'incoming' | 'sent';
  } | null>(null);
  const [isRefreshingMessages, setIsRefreshingMessages] = useState<boolean>(false);

  // Inline Per-Slip Send Picker State
  const [activeSendSlipId, setActiveSendSlipId] = useState<string | null>(null);
  const [sendRecipientInput, setSendRecipientInput] = useState<string>('');
  const [sendSelectedUser, setSendSelectedUser] = useState<RegisteredDirectoryUser | null>(null);
  const [directoryUsers, setDirectoryUsers] = useState<RegisteredDirectoryUser[]>([]);
  const [isLoadingDirectory, setIsLoadingDirectory] = useState<boolean>(false);
  const [isSendingSlip, setIsSendingSlip] = useState<boolean>(false);
  const [sendSlipError, setSendSlipError] = useState<string | null>(null);

  const lastMessagesSignalRef = useRef<number>(0);
  useEffect(() => {
    if (openMessagesLogSignal > 0 && openMessagesLogSignal !== lastMessagesSignalRef.current) {
      lastMessagesSignalRef.current = openMessagesLogSignal;
      setSelectedFullSlip(null);
      setSelectedMessageSlip(null);
      setActiveBottomNav('grille');
      setGrilleSubTab('slips');
      setIsMessagesLogOpen(true);
      onMarkMessagesRead?.();
      void onRefreshMessages?.();
    } else if (openMessagesLogSignal === 0) {
      lastMessagesSignalRef.current = 0;
    }
  }, [openMessagesLogSignal, onMarkMessagesRead, onRefreshMessages]);

  useEffect(() => {
    if (!activeSendSlipId) return;
    let active = true;
    setIsLoadingDirectory(true);
    const timer = window.setTimeout(() => {
      void fetchRegisteredUsersDirectory(sendRecipientInput, participantProfile?.id).then(
        (users) => {
          if (active) {
            setDirectoryUsers(users);
            setIsLoadingDirectory(false);
          }
        }
      );
    }, 120);
    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [activeSendSlipId, sendRecipientInput, participantProfile?.id]);

  const [goalFlashMatchIds, setGoalFlashMatchIds] = useState<Record<number, number>>({});
  const prevScoresRef = useRef<Record<number, { h: number; a: number; hasScore: boolean; status: string }> | null>(null);

  // Real-time evaluated concours (re-evaluates cleanly whenever live feed updates activeConcours)
  const liveConcours = useMemo(
    () => evaluateConcoursRealTime(activeConcours, Date.now(), null),
    [activeConcours]
  );

  // Resolve exact concours (active live or archived Tirage) matching a saved slip's grilleNumber
  const resolveConcoursForSlip = (slip: UserBetSlip): WeeklyConcours => {
    if (slip.grilleNumber === liveConcours.number) {
      return liveConcours;
    }
    const archived = grilles.find((g) => g.number === slip.grilleNumber);
    if (!archived) {
      return liveConcours;
    }
    const archivedUtcMs = parseTunisDateTimeToUtcMs(archived.date);
    const archivedDate = archivedUtcMs
      ? formatUtcPlusOneDateString(archivedUtcMs)
      : archived.date.split(' ')[0] || archived.date;
    const archivedTime = archivedUtcMs
      ? `${formatUtcPlusOneShortTime(archivedUtcMs)} +1`
      : archived.date.split('à ')[1]
      ? `${archived.date.split('à ')[1]} +1`
      : '15:00 +1';

    return {
      number: archived.number,
      category: 'international',
      title: `Concours International N° ${archived.number}`,
      season: liveConcours.season || 'Saison 2026-2027',
      fullDateFormatted: formatConcoursPlusOneLabel(archived.date),
      dateStr: archivedDate,
      closingTimeStr: archivedTime,
      cagnotteEstimate: archived.cagnotteFormatted,
      sourceUrl: archived.sourceUrl || liveConcours.sourceUrl,
      matches: archived.matches.map((m) => {
        const scoreMatch = String(m.score || '').match(/^(\d+)\s*[-:]\s*(\d+)$/);
        const hasValidScore = Boolean(scoreMatch);
        const resolvedResult =
          m.result ||
          (hasValidScore ? computeResultSign(Number(scoreMatch![1]), Number(scoreMatch![2])) : null);
        return {
          id: m.id,
          homeTeam: m.homeTeam,
          homeTeamFr: m.homeTeamFr,
          homeLogo: m.homeLogo || 'CLUB',
          awayTeam: m.awayTeam,
          awayTeamFr: m.awayTeamFr,
          awayLogo: m.awayLogo || 'CLUB',
          date: archivedDate,
          time: archivedTime,
          dayTime: archivedTime,
          kickoffTimestamp: archivedUtcMs || 0,
          status: hasValidScore || resolvedResult !== null ? ('finished' as const) : ('scheduled' as const),
          score: hasValidScore ? `${scoreMatch![1]} - ${scoreMatch![2]}` : '- - -',
          scoreHome: hasValidScore ? scoreMatch![1] : undefined,
          scoreAway: hasValidScore ? scoreMatch![2] : undefined,
          competition: m.competition || `المسابقة العالمية #${archived.number}`,
          competitionFr: m.competitionFr || `CONCOURS INT #${archived.number}`,
          result: resolvedResult,
          prob1: 40,
          probX: 30,
          prob2: 30,
        };
      }),
    };
  };

  // Detect live goal scored: 7s blazing flame + shake + water droplet chime (strictly verified scores only)
  useEffect(() => {
    const nextScores: Record<number, { h: number; a: number; hasScore: boolean; status: string }> = {};
    const scoredNow: number[] = [];

    liveConcours.matches.forEach((m) => {
      const hasScore =
        !m.isDelayed &&
        m.scoreHome !== undefined &&
        m.scoreAway !== undefined &&
        /^\d+$/.test(String(m.scoreHome)) &&
        /^\d+$/.test(String(m.scoreAway));
      const h = hasScore ? Number(m.scoreHome) : 0;
      const a = hasScore ? Number(m.scoreAway) : 0;
      nextScores[m.id] = { h, a, hasScore, status: m.status };

      const prev = prevScoresRef.current?.[m.id];
      if (
        prev &&
        hasScore &&
        (m.status === 'live' || (prev.status === 'live' && m.status === 'finished')) &&
        ((prev.hasScore && (h > prev.h || a > prev.a)) || (!prev.hasScore && (h > 0 || a > 0)))
      ) {
        scoredNow.push(m.id);
      }
    });

    prevScoresRef.current = nextScores;

    if (scoredNow.length > 0) {
      const stamp = Date.now();
      setGoalFlashMatchIds((prev) => {
        const updated = { ...prev };
        scoredNow.forEach((id) => {
          updated[id] = stamp;
        });
        return updated;
      });
      scoredNow.forEach((id) => {
        window.setTimeout(() => {
          setGoalFlashMatchIds((prev) => {
            if (prev[id] !== stamp) return prev;
            const copy = { ...prev };
            delete copy[id];
            return copy;
          });
        }, 7000);
      });
    }
  }, [liveConcours]);

  // Automatic betting & editing lock:
  // Locked automatically from kickoff of the 1st match until end of last match / appearance of a new concours.
  const hasFirstMatchStarted = useMemo(
    () => liveConcours.matches.some((m) => m.status === 'live' || m.status === 'finished'),
    [liveConcours]
  );
  const isBettingLocked = hasFirstMatchStarted;

  // Sync external settings & always bind concoursNumber to active new concours without resetting active tab
  useEffect(() => {
    if (isOpen) {
      setSettings((prev) => {
        const base = initialAppSettings || prev;
        if (base.concoursNumber === liveConcours.number && initialAppSettings) {
          return initialAppSettings;
        }
        return { ...base, concoursNumber: liveConcours.number };
      });
    }
  }, [isOpen, initialAppSettings, liveConcours.number]);

  // Sync tab only when modal opens or parent explicitly changes initialTab
  useEffect(() => {
    if (isOpen) {
      setUserSlips(loadUserSlips());
      if (prevInitialTabRef.current !== initialTab) {
        prevInitialTabRef.current = initialTab;
        if (initialTab === 'settings') {
          setActiveBottomNav('apk');
          setPromptSubPage('settings');
        } else if (initialTab) {
          setActiveBottomNav(initialTab);
          if (initialTab === 'apk') {
            setPromptSubPage('hub');
          }
        }
        setPinError(null);
      }
    } else {
      setIsProtectedTabsUnlocked(false);
      setPinInput('');
      setPinError(null);
    }
  }, [isOpen, initialTab]);

  const handlePinChange = (rawValue: string) => {
    const cleaned = rawValue.replace(/\D/g, '').slice(0, 6);
    setPinInput(cleaned);
    if (cleaned === PROTECTED_TABS_PIN) {
      audioService.playChime();
      setIsProtectedTabsUnlocked(true);
      setPinInput('');
      setPinError(null);
      return;
    }
    if (cleaned.length >= 4) {
      setPinError(
        lang === 'AR'
          ? 'كلمة السر غير صحيحة — أدخل 1777 لفتح الخانة'
          : 'Code PIN incorrect — saisissez 1777'
      );
    } else {
      setPinError(null);
    }
  };

  const handlePinSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    audioService.playClick();
    if (pinInput === PROTECTED_TABS_PIN) {
      audioService.playChime();
      setIsProtectedTabsUnlocked(true);
      setPinInput('');
      setPinError(null);
    } else {
      setPinError(
        lang === 'AR'
          ? 'كلمة السر غير صحيحة — الرجاء إدخال 1777'
          : 'Code PIN incorrect — saisissez 1777'
      );
      setPinInput('');
    }
  };

  if (!isOpen) return null;

  // Calculate doubles and triples in current selections
  let countDoubles = 0;
  let countTriples = 0;
  let totalSelections = 0;

  Object.values(currentSelections).forEach((sel) => {
    if (sel && sel.length > 0) {
      totalSelections++;
      if (sel.length === 2) countDoubles++;
      if (sel.length === 3) countTriples++;
    }
  });

  // Calculate pricing using settings rates
  const pricing = calculatePromosportPrice(
    countDoubles,
    countTriples,
    settings.columnRate,
    settings.baseFee
  );

  // Helper to translate team names
  const getTeamName = (teamName: string, frName?: string) => {
    return lang === 'AR'
      ? translateTeamToArabic(teamName, frName)
      : translateTeamToFrench(teamName, frName);
  };

  const getDisplaySlipName = (name: string) =>
    lang === 'FR'
      ? name.replace(/^قصاصة مسجلة رقم\s*/i, 'Fiche N° ')
      : name.replace(/^Fiche N°\s*/i, 'قصاصة مسجلة رقم ');

  const showTemporaryNotice = (msg: string) => {
    setSlipNoticeMessage(msg);
    setTimeout(() => {
      setSlipNoticeMessage(null);
    }, 4000);
  };

  // Toggle match choice
  const toggleSelection = (matchId: number, sign: '1' | 'X' | '2') => {
    if (isBettingLocked) {
      audioService.playClick();
      showTemporaryNotice(
        lang === 'AR'
          ? 'تم قفل تعمير وتعديل القصاصات تلقائياً من بداية أول مقابلة حتى نهاية آخر المقابلات.'
          : 'Remplissage et modification verrouillés dès le coup d’envoi du 1er match.'
      );
      return;
    }
    audioService.playClick();

    setCurrentSelections((prev) => {
      const current = prev[matchId] || [];
      let updated: ('1' | 'X' | '2')[];

      if (current.includes(sign)) {
        updated = current.filter((s) => s !== sign);
      } else {
        updated = [...current, sign];
      }

      return {
        ...prev,
        [matchId]: updated,
      };
    });
  };

  // Clear selections
  const handleClearSelections = () => {
    audioService.playClick();
    setCurrentSelections({});
    setEditingSlipId(null);
  };

  // Save current slip with 3D exploding money shower, fiery rotating full-screen beam, and fresh page descent
  const handleSaveSlip = () => {
    if (saveTransitionPhase !== 'idle') return;
    if (isBettingLocked) {
      audioService.playClick();
      showTemporaryNotice(
        lang === 'AR'
          ? 'تم قفل تسجيل وتعديل القصاصات تلقائياً عند بداية أول مقابلة حتى نهاية آخر المقابلات.'
          : 'Enregistrement et modification verrouillés dès le coup d’envoi.'
      );
      return;
    }
    if (totalSelections < 13) {
      audioService.playClick();
      showTemporaryNotice(
        lang === 'AR'
          ? `الرجاء إكمال تعمير الـ 13 مباراة لحفظ القصاصة (المكتملة حالياً: ${totalSelections} / 13).`
          : `Veuillez compléter les 13 matchs pour valider (${totalSelections} / 13).`
      );
      return;
    }

    const nextSlipNumber = userSlips.length + 1;
    const nowDate = Date.now();
    const nowClock = `${formatUtcPlusOneClock(nowDate)} +1`;
    const newSlip: UserBetSlip = {
      id: editingSlipId || `slip-${nowDate}`,
      grilleNumber: activeConcours.number,
      name: `قصاصة مسجلة رقم ${nextSlipNumber}`,
      createdAt: `${formatUtcPlusOneDateString(nowDate)} • ${formatUtcPlusOneShortTime(nowDate)} +1`,
      updatedAt: nowClock,
      selections: currentSelections,
      betType: countTriples > 0 ? 'triple' : countDoubles > 0 ? 'double' : 'single',
      totalCombinations: pricing.combinations,
      totalCostDt: pricing.priceTnd,
      isLocked: isBettingLocked,
    };

    const updated = saveOrUpdateSlip(newSlip);
    setUserSlips(updated);
    void syncAppChangesToWorkspace({
      appSettings: settings,
      userSlips: updated,
      concours: activeConcours,
    });

    // Clear any leftover timers before starting cinematic 3D transition
    saveTransitionTimersRef.current.forEach((id) => window.clearTimeout(id));
    saveTransitionTimersRef.current = [];

    // Play synchronized roaring flame + shattering money sparkles + settle chime
    audioService.playFieryMoneyBurst();
    setShowFierySavePortal(true);
    setSaveTransitionPhase('bursting');

    // Phase 2 (~1900ms): Swap to fresh empty slip and drop normal page down from the top while beam dissolves
    const tDescend = window.setTimeout(() => {
      setCurrentSelections({});
      setEditingSlipId(null);
      setActiveBottomNav('grille');
      setGrilleSubTab('mondiale');
      setSelectedFullSlip(null);
      setSaveTransitionPhase('descending');
    }, 1900);

    // Phase 3 (~3100ms): Settle page to normal natural position and dispose 3D portal
    const tFinish = window.setTimeout(() => {
      setSaveTransitionPhase('idle');
      setShowFierySavePortal(false);
      showTemporaryNotice(
        lang === 'AR'
          ? `تم تسجيل القصاصة بنجاح! تم فتح تعمير قصاصة جديدة فارغة رقم ${updated.length + 1}`
          : `Fiche enregistrée ! Nouvelle grille vierge N° ${updated.length + 1} ouverte.`
      );
    }, 3100);

    saveTransitionTimersRef.current.push(tDescend, tFinish);
  };

  // Delete saved slip (immediately without blocking confirm dialog in iframe)
  const handleDeleteSlip = (slipId: string) => {
    audioService.playClick();
    const updated = deleteSlip(slipId);
    setUserSlips(updated);
    void syncAppChangesToWorkspace({
      appSettings: settings,
      userSlips: updated,
      concours: activeConcours,
    });
    if (editingSlipId === slipId) {
      setEditingSlipId(null);
      setCurrentSelections({});
    }
    if (expandedSlipId === slipId) {
      setExpandedSlipId(updated.length > 0 ? updated[0].id : null);
    }
    setSlipNoticeMessage(
      lang === 'AR' ? 'تم فسخ القصاصة بنجاح من السجل!' : 'Fiche supprimée de l’historique !'
    );
    setTimeout(() => {
      setSlipNoticeMessage(null);
    }, 3000);
  };

  // Delete all saved slips
  const handleClearAllSlips = () => {
    audioService.playClick();
    const updated = clearAllSlips();
    setUserSlips(updated);
    void syncAppChangesToWorkspace({
      appSettings: settings,
      userSlips: updated,
      concours: activeConcours,
    });
    setEditingSlipId(null);
    setCurrentSelections({});
    setExpandedSlipId(null);
    setSlipNoticeMessage(
      lang === 'AR' ? 'تم فسخ جميع القصاصات بنجاح من السجل!' : 'Toutes les fiches ont été supprimées !'
    );
    setTimeout(() => {
      setSlipNoticeMessage(null);
    }, 3000);
  };

  // Edit saved slip (only before first kickoff!)
  const handleEditSlip = (slip: UserBetSlip) => {
    if (isBettingLocked) {
      audioService.playClick();
      showTemporaryNotice(
        lang === 'AR'
          ? 'لا يمكن تعديل أي قصاصة عند بداية أول مقابلة حتى نهاية آخر المقابلات (يُسمح بالفسخ فقط).'
          : 'Modification impossible après le coup d’envoi (suppression uniquement).'
      );
      return;
    }
    audioService.playClick();
    setEditingSlipId(slip.id);
    setCurrentSelections(slip.selections);
    setActiveBottomNav('grille');
    setGrilleSubTab('mondiale');
  };

  const handleToggleSendForSlip = (slipId: string) => {
    audioService.playClick();
    if (activeSendSlipId === slipId) {
      setActiveSendSlipId(null);
      setSendSlipError(null);
      return;
    }
    setActiveSendSlipId(slipId);
    setSendRecipientInput('');
    setSendSelectedUser(null);
    setSendSlipError(null);
  };

  const handleConfirmSendSlip = async (slip: UserBetSlip, slipNumber: number) => {
    // Always activate rapid mechanical sprayer / machine-gun send sound
    audioService.playMachineGunBurst();

    if (!participantProfile) {
      setSendSlipError(
        lang === 'FR'
          ? 'Veuillez enregistrer votre nom de participant d’abord.'
          : 'يرجى تسجيل اسم صاحب التطبيق أولاً.'
      );
      return;
    }
    if (isSendingSlip) return;

    setSendSlipError(null);
    setIsSendingSlip(true);
    try {
      const res = await sendSlipToParticipant({
        sender: participantProfile,
        recipientFullNameInput: sendRecipientInput,
        recipientId: sendSelectedUser?.id,
        slip,
        slipNumber,
        slipNumberLabel: getDisplaySlipName(slip.name),
        concoursSnapshot: resolveConcoursForSlip(slip),
        lang,
      });

      if (!res.ok || !res.message) {
        setSendSlipError(
          res.error ||
            (lang === 'FR' ? 'Impossible d’envoyer la fiche.' : 'تعذر إرسال القصاصة إلى هذا المستخدم.')
        );
        return;
      }

      onSlipMessageSent?.(res.message);
      setActiveSendSlipId(null);
      setSendRecipientInput('');
      setSendSelectedUser(null);
      setSendSlipError(null);
      showTemporaryNotice(
        lang === 'AR'
          ? `تم إرسال القصاصة #${slipNumber} إلى (${res.message.recipientFullName}) وحفظها في سجل الرسائل.`
          : `Fiche N° ${slipNumber} envoyée à (${res.message.recipientFullName}).`
      );
    } finally {
      setIsSendingSlip(false);
    }
  };

  const handleSaveReceivedSlipToMySlips = async (msg: SlipMessageRecord) => {
    const nextNum = userSlips.length + 1;
    const nowDate = Date.now();
    const copiedSlip: UserBetSlip = {
      ...msg.slip,
      id: `slip-imp-${msg.id}-${nowDate}`,
      name: `قصاصة مسجلة رقم ${nextNum}`,
      createdAt: `${formatUtcPlusOneDateString(nowDate)} • ${formatUtcPlusOneShortTime(nowDate)} +1`,
      updatedAt: `${formatUtcPlusOneClock(nowDate)} +1`,
      selections: { ...msg.slip.selections },
    };
    const updated = saveOrUpdateSlip(copiedSlip);
    setUserSlips(updated);
    void syncAppChangesToWorkspace({
      appSettings: settings,
      userSlips: updated,
      concours: activeConcours,
    });

    if (participantProfile) {
      await markSlipMessageSaved(msg.id, participantProfile.id);
      await onMessagesChanged?.();
    }

    setSelectedMessageSlip((prev) =>
      prev && prev.msg.id === msg.id
        ? { ...prev, msg: { ...prev.msg, savedToSlipsByRecipient: true } }
        : prev
    );

    audioService.playChime();
    showTemporaryNotice(
      lang === 'AR'
        ? `تم حفظ القصاصة الواردة من (${msg.senderFullName}) في قصاصاتي المسجلة برقم #${nextNum}.`
        : `Fiche de (${msg.senderFullName}) enregistrée dans vos fiches (N° ${nextNum}).`
    );
  };

  const handleDeleteMessageFromLog = async (messageId: string) => {
    if (!participantProfile) return;
    await deleteSlipMessage(messageId, participantProfile.id);
    await onMessagesChanged?.();
    if (selectedMessageSlip?.msg.id === messageId) {
      setSelectedMessageSlip(null);
    }
    showTemporaryNotice(
      lang === 'AR' ? 'تم فسخ القصاصة من سجل الرسائل بنجاح.' : 'Message supprimé du journal.'
    );
  };

  const handleRefreshMessagesClick = async () => {
    if (!onRefreshMessages || isRefreshingMessages) return;
    setIsRefreshingMessages(true);
    try {
      await onRefreshMessages();
    } finally {
      setIsRefreshingMessages(false);
    }
  };

  // Save Settings handler
  const handleSaveAppSettings = () => {
    audioService.playClick();
    saveAppSettings(settings);
    if (onUpdateAppSettings) {
      onUpdateAppSettings(settings);
    }
    void syncAppChangesToWorkspace({
      appSettings: settings,
      userSlips,
      concours: activeConcours,
    });
    audioService.playChime();
    setSettingsSavedAlert(true);
    setTimeout(() => setSettingsSavedAlert(false), 3000);
  };

  // Reset Settings handler
  const handleResetAppSettings = () => {
    audioService.playClick();
    setSettings(DEFAULT_APP_SETTINGS);
    saveAppSettings(DEFAULT_APP_SETTINGS);
    if (onUpdateAppSettings) {
      onUpdateAppSettings(DEFAULT_APP_SETTINGS);
    }
    void syncAppChangesToWorkspace({
      appSettings: DEFAULT_APP_SETTINGS,
      userSlips,
      concours: activeConcours,
    });
  };

  // Render National Unavailable view with exact screenshot and refresh button
  const renderNationalUnavailableView = () => {
    const checkDisplay =
      lastNationalCheckTime ||
      (lang === 'AR' ? 'اليوم (تحديث مستمر)' : 'Aujourd’hui (en direct)');

    return (
      <div className="flex flex-col items-center justify-center p-2 sm:p-4 text-center space-y-4 animate-fade-in max-w-lg mx-auto">
        {/* Exact official screenshot from user: Screenshot_20261103_235250_Chrome_4fcf597e.jpg */}
        <div className="relative group w-full max-w-[340px] sm:max-w-[360px] rounded-3xl overflow-hidden border-2 border-yellow-400/90 shadow-[0_0_35px_rgba(234,179,8,0.5)] bg-[#030918]">
          <img
            src="/assets/aistudio/Screenshot_20261103_235250_Chrome_4fcf597e.jpg"
            alt="Aucun match national dans ce tirage - Promosport Tunisie"
            className="w-full h-auto object-contain block select-none"
          />
          <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-black/30 via-transparent to-white/10" />
        </div>

        {/* Interactive "تحديث جديد" (Refresh) Button & Status */}
        <div className="w-full max-w-[360px] space-y-2.5">
          <button
            onClick={handleRefreshNational}
            disabled={isCheckingNational}
            className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-yellow-400 via-amber-400 to-yellow-500 hover:from-yellow-300 hover:to-amber-400 text-black font-black text-xs sm:text-sm shadow-[0_0_25px_rgba(241,184,22,0.85)] active:scale-95 transition-all flex items-center justify-center gap-2.5 disabled:opacity-70 cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${isCheckingNational ? 'animate-spin' : ''}`} />
            <span>
              {isCheckingNational
                ? lang === 'AR'
                  ? 'جارٍ فحص promosport-pronostic.com...'
                  : 'Vérification sur promosport-pronostic.com...'
                : lang === 'AR'
                  ? 'تحديث جديد وفحص المسابقة الوطنية'
                  : 'Actualiser & vérifier le Concours National'}
            </span>
          </button>

          {/* Live notification box */}
          <div
            className={`p-3 rounded-2xl bg-black/75 border border-yellow-500/40 ${
              lang === 'AR' ? 'text-right' : 'text-left'
            } text-[11px] text-gray-300 space-y-1.5 shadow-md`}
          >
            <div className="flex items-center justify-between text-yellow-300 font-bold">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-yellow-400 animate-pulse" />
                <span>
                  {lang === 'AR' ? 'حالة المسابقة الوطنية:' : 'Statut Concours National :'}
                </span>
              </span>
              <span className="font-mono text-[10px] text-cyan-300" dir="ltr">
                {checkDisplay}
              </span>
            </div>
            <p className="text-[10px] text-gray-400 leading-relaxed">
              {lang === 'AR' ? (
                <>
                  الموقع المعتمد{' '}
                  <strong className="text-white">promosport-pronostic.com/welcome/promosport</strong>{' '}
                  يظهر القصاصة العالمية الحالية فقط (المسابقة {liveConcours.number}). لا توجد مسابقة للبطولة الوطنية منشورة حالياً.
                </>
              ) : (
                <>
                  Le site officiel{' '}
                  <strong className="text-white">promosport-pronostic.com/welcome/promosport</strong>{' '}
                  affiche uniquement la grille internationale (Concours {liveConcours.number}). Aucun concours national publié actuellement.
                </>
              )}
            </p>
          </div>

          {/* Quick link button to switch to International Grille */}
          <button
            onClick={() => {
              audioService.playClick();
              setActiveConcours(concours || INITIAL_WEEKLY_CONCOURS);
              setGrilleSubTab('mondiale');
            }}
            className="w-full py-2.5 px-3 rounded-xl bg-sky-950/70 hover:bg-sky-900/80 border border-sky-400/60 text-cyan-300 font-bold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>
              {lang === 'AR'
                ? `الانتقال إلى القصاصة العالمية ${liveConcours.number} المتاحة`
                : `Aller à la Grille Internationale ${liveConcours.number}`}
            </span>
          </button>
        </div>
      </div>
    );
  };

  return (
    <div
      role={asMainPage ? 'main' : 'dialog'}
      aria-modal={asMainPage ? undefined : true}
      dir={lang === 'AR' ? 'rtl' : 'ltr'}
      className={`fixed inset-0 ${
        asMainPage ? 'z-20 bg-[#020612]' : 'z-50 bg-black/95 animate-fade-in'
      } flex items-center justify-center p-0 sm:p-2 font-sans select-none overflow-hidden`}
    >
      {/* 3D Fiery Rotating Luminous Beam + Flying Money Burst Overlay (mounts only during active save transition) */}
      <SaveSlipFieryPortal3D active={showFierySavePortal} />

      {/* 3D Broadcast Stadium Shell Container - Fully responsive for all mobile screens */}
      <div
        onClickCapture={triggerGrilleIconFlash}
        className={`relative flex flex-col bg-[#050e20] border-0 sm:border-2 sm:border-sky-400/80 shadow-[0_0_80px_rgba(56,189,248,0.5)] overflow-hidden transition-all duration-300 w-full max-w-2xl sm:max-w-3xl modal-h-full sm:rounded-3xl ${
          saveTransitionPhase === 'bursting'
            ? 'slip-page-explode pointer-events-none'
            : saveTransitionPhase === 'descending' || externalEntryPhase === 'descending'
              ? 'slip-page-descend'
              : externalEntryPhase === 'waiting'
                ? 'opacity-0'
                : ''
        }`}
      >
        {/* CONDITIONAL: READ-ONLY MESSAGE SLIP VIEW OR FULL SLIP PAGE VIEW OR REGULAR MODAL BODY */}
        {selectedMessageSlip ? (
          <SavedSlipFullPageView
            slip={selectedMessageSlip.msg.slip}
            concours={
              selectedMessageSlip.msg.slip.grilleNumber === liveConcours.number
                ? liveConcours
                : selectedMessageSlip.msg.concoursSnapshot ||
                  resolveConcoursForSlip(selectedMessageSlip.msg.slip)
            }
            lang={lang}
            onChangeLang={handleChangeLang}
            readOnly={true}
            backLabel={lang === 'AR' ? 'سجل الرسائل' : 'Messages'}
            messageMeta={{
              direction: selectedMessageSlip.direction,
              senderFullName: selectedMessageSlip.msg.senderFullName,
              recipientFullName: selectedMessageSlip.msg.recipientFullName,
              sentAtDisplay: selectedMessageSlip.msg.sentAtDisplay,
              alreadySavedToSlips: selectedMessageSlip.msg.savedToSlipsByRecipient,
            }}
            onBackToSlips={() => {
              setSelectedMessageSlip(null);
              setActiveBottomNav('grille');
              setGrilleSubTab('slips');
              setIsMessagesLogOpen(true);
            }}
            onBackToGrille={() => {
              setSelectedMessageSlip(null);
              setIsMessagesLogOpen(false);
              setActiveBottomNav('grille');
              setGrilleSubTab('mondiale');
            }}
            onUpdateSlip={() => {
              // Strictly read-only: modifications are disabled on message slips
            }}
            onSaveMessageToMySlips={
              selectedMessageSlip.direction === 'incoming'
                ? () => void handleSaveReceivedSlipToMySlips(selectedMessageSlip.msg)
                : undefined
            }
            onDeleteSlip={() => {
              void handleDeleteMessageFromLog(selectedMessageSlip.msg.id);
            }}
            getTeamName={getTeamName}
            isKickoffStarted={true}
            columnRate={settings.columnRate}
            baseFee={settings.baseFee}
            goalFlashMatchIds={goalFlashMatchIds}
          />
        ) : selectedFullSlip ? (
          <SavedSlipFullPageView
            slip={selectedFullSlip}
            concours={resolveConcoursForSlip(selectedFullSlip)}
            lang={lang}
            onChangeLang={handleChangeLang}
            onBackToSlips={() => {
              setSelectedFullSlip(null);
              setActiveBottomNav('grille');
              setGrilleSubTab('slips');
            }}
            onBackToGrille={() => {
              setSelectedFullSlip(null);
              setActiveBottomNav('grille');
              setActiveConcours(concours || INITIAL_WEEKLY_CONCOURS);
              setGrilleSubTab('mondiale');
            }}
            onUpdateSlip={(updatedSlip) => {
              const updated = saveOrUpdateSlip(updatedSlip);
              setUserSlips(updated);
              setSelectedFullSlip(updatedSlip);
              void syncAppChangesToWorkspace({
                appSettings: settings,
                userSlips: updated,
                concours: activeConcours,
              });
            }}
            onDeleteSlip={(slipId) => {
              handleDeleteSlip(slipId);
              setSelectedFullSlip(null);
            }}
            getTeamName={getTeamName}
            isKickoffStarted={isBettingLocked}
            columnRate={settings.columnRate}
            baseFee={settings.baseFee}
            goalFlashMatchIds={goalFlashMatchIds}
          />
        ) : (
          <>
            {/* 1. TOP HEADER WITH MB LOGO + SAVED SLIPS ICON ON ITS LEFT & GOLDEN BOX */}
            <div className="shrink-0 px-2 sm:px-5 pt-[max(0.5rem,env(safe-area-inset-top))] pb-2 sm:py-2.5 bg-gradient-to-r from-[#040a18] via-[#091a38] to-[#040a18] border-b border-yellow-500/50 flex items-center justify-between gap-1.5 sm:gap-2 shadow-md">
              
              {/* MB LOGO + SAVED SLIPS ICON TO ITS LEFT (Always visible at top across all tabs) */}
              <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    audioService.playClick();
                    onOpenIntroStage?.();
                  }}
                  title={lang === 'AR' ? 'فتح واجهة التطبيق التقديمية' : 'Écran d’accueil'}
                  aria-label={lang === 'AR' ? 'فتح واجهة التطبيق التقديمية' : 'Écran d’accueil'}
                  className="rounded-full p-0.5 cursor-pointer hover:scale-105 active:scale-95 transition-transform focus:outline-none shrink-0"
                >
                  <MbLogo size="md" showLaser={true} />
                </button>

                {/* أيقونة القصاصات المسجلة دوماً في جميع الخانات بجانب شعار MB */}
                <button
                  type="button"
                  data-no-flash="true"
                  onClick={() => {
                    audioService.playClick();
                    setSelectedFullSlip(null);
                    setActiveBottomNav('grille');
                    setGrilleSubTab('slips');
                    onTabChange?.('grille');
                  }}
                  title={lang === 'AR' ? 'القصاصات المسجلة' : 'Fiches enregistrées'}
                  aria-label={lang === 'AR' ? 'القصاصات المسجلة' : 'Fiches enregistrées'}
                  className={`relative min-h-[44px] min-w-[44px] px-2 sm:px-2.5 py-1.5 rounded-xl border-2 flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 shrink-0 ${
                    activeBottomNav === 'grille' && grilleSubTab === 'slips'
                      ? 'bg-gradient-to-br from-yellow-300 via-amber-400 to-yellow-500 text-black border-white shadow-[0_0_16px_rgba(250,204,21,0.85)]'
                      : 'bg-black/65 hover:bg-amber-500/20 border-yellow-400/80 text-yellow-300 hover:text-white shadow-[0_0_12px_rgba(250,204,21,0.35)]'
                  }`}
                >
                  <FolderArchive className="w-4 h-4 shrink-0" />
                  <span className="hidden min-[460px]:inline text-[10.5px] sm:text-xs font-black whitespace-nowrap">
                    {lang === 'AR' ? 'القصاصات' : 'Fiches'}
                  </span>
                  <span
                    dir="ltr"
                    className={`min-w-[18px] h-[18px] px-1 rounded-full font-mono text-[10px] font-black flex items-center justify-center tabular-nums ${
                      activeBottomNav === 'grille' && grilleSubTab === 'slips'
                        ? 'bg-black text-yellow-300'
                        : 'bg-yellow-400 text-black'
                    }`}
                  >
                    {userSlips.length}
                  </span>
                </button>

                {!asMainPage && (
                  <button
                    type="button"
                    onClick={() => {
                      audioService.playClick();
                      onClose();
                    }}
                    title={lang === 'AR' ? 'رجوع إلى القائمة' : 'Retour au menu'}
                    className="min-w-[44px] min-h-[44px] p-2 sm:p-2.5 rounded-xl bg-gradient-to-br from-amber-500/20 via-red-950/60 to-slate-900 border-2 border-yellow-400/80 text-yellow-200 hover:text-white hover:border-yellow-300 shadow-[0_0_14px_rgba(250,204,21,0.45)] active:scale-95 transition-all cursor-pointer flex items-center justify-center shrink-0"
                  >
                    <ArrowRight
                      className={`w-5 h-5 sm:w-6 sm:h-6 ${lang === 'FR' ? 'rotate-180' : ''}`}
                    />
                  </button>
                )}
              </div>

              {/* APP NAME, PHONE & ACTIVE NEW CONCOURS NUMBER + LANGUAGE TOGGLE */}
              <div className="flex items-center gap-1.5 sm:gap-2.5 min-w-0 justify-end">
                {/* Golden Box: Phone + Live +1 Clock + Always Active New Concours Number */}
                <div
                  className={`px-2 sm:px-2.5 py-1 rounded-xl bg-black/80 border border-yellow-400/70 shadow-[0_0_12px_rgba(241,184,22,0.4)] ${
                    lang === 'AR' ? 'text-right' : 'text-left'
                  } min-w-0 max-w-[44vw] sm:max-w-none`}
                >
                  <div className="text-[10px] sm:text-[11px] font-black text-yellow-300 tracking-wide leading-tight truncate">
                    {settings.appName} | {settings.phoneNumber}
                  </div>
                  <div className="text-[8.5px] sm:text-[9.5px] text-gray-300 font-mono mt-0.5 flex items-center justify-end gap-1 sm:gap-1.5 whitespace-nowrap">
                    <span
                      dir="ltr"
                      title={lang === 'AR' ? 'التوقيت +1' : 'Heure +1'}
                      className="inline-flex items-center gap-0.5 text-amber-300 font-black tabular-nums"
                    >
                      <Clock className="w-2.5 h-2.5 text-amber-300 shrink-0" />
                      <span>{timePlusOne} +1</span>
                    </span>
                    <span className="text-slate-500">•</span>
                    <span className="text-yellow-300 font-black tabular-nums">
                      {lang === 'AR'
                        ? `قصاصة ${liveConcours.number}`
                        : `Grille ${liveConcours.number}`}
                    </span>
                  </div>
                </div>

                {/* Language Toggle AR / FR */}
                <LanguageToggleButton lang={lang} onChangeLang={handleChangeLang} compact />
              </div>
            </div>

        {/* 4. MAIN BODY CONTAINER (Full height behind transparent floating bottom glass bar) */}
        {activeBottomNav === 'grille' && grilleSubTab === 'mondiale' ? (
          /* GRILLE VIEW (خانة القصاصة): انسياب عمودي عادي تحت الشريط العلوي الشفاف والشريط السفلي الزجاجي */
          <div className="flex-1 relative overflow-hidden flex flex-col">
            {slipNoticeMessage && (
              <div className="absolute bottom-24 inset-x-3 z-40 p-2 rounded-xl bg-emerald-950/95 border border-emerald-400 text-emerald-200 font-bold text-xs flex items-center justify-between shadow-[0_0_15px_rgba(16,185,129,0.5)] animate-fade-in">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{slipNoticeMessage}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setSlipNoticeMessage(null)}
                  className="text-gray-400 hover:text-white p-0.5 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            <Grille3DWheelView
              matches={liveConcours.matches}
              lang={lang}
              isBettingLocked={isBettingLocked}
              selections={currentSelections}
              onToggleSelection={toggleSelection}
              getTeamName={getTeamName}
              goalFlashMatchIds={goalFlashMatchIds}
              onScrollHideTopBar={() => setIsGrilleRibbonOpen(false)}
              topOverlayContent={
                <PromosportUnifiedBadge
                  concours={liveConcours}
                  cagnotte={liveConcours.cagnotteEstimate}
                  lang={lang}
                  isKickoffStarted={isBettingLocked}
                  activeSubTab={grilleSubTab}
                  isOpen={isGrilleRibbonOpen}
                  onToggleOpen={setIsGrilleRibbonOpen}
                  onSelectSubTab={(tab) => {
                    audioService.playClick();
                    if (tab === 'slips') {
                      setGrilleSubTab('slips');
                    } else if (tab === 'mondiale') {
                      setActiveConcours(concours || INITIAL_WEEKLY_CONCOURS);
                      setGrilleSubTab('mondiale');
                    } else if (tab === 'nationale') {
                      setGrilleSubTab('nationale');
                    }
                  }}
                  slipsCount={userSlips.length}
                  showTabs={true}
                  transparentFloating={true}
                  showBettingControls={true}
                  totalSelections={totalSelections}
                  countDoubles={countDoubles}
                  countTriples={countTriples}
                  combinationsCount={pricing.combinations}
                  formattedPriceTnd={pricing.formattedTnd}
                  onSaveSlip={handleSaveSlip}
                  onClearSelections={handleClearSelections}
                />
              }
            />
          </div>
        ) : activeBottomNav === 'live' ? (
          /* LIVE TAB (المباشر): full-height viewport with floating glass scanner overlay & scrollable matches */
          <div className="flex-1 relative overflow-hidden flex flex-col">
            <LiveMatchesScanView
              lang={lang}
              getTeamName={getTeamName}
              onLiveCountChange={setLiveBadgeCount}
              liveNotifications={liveNotifications}
              unreadNotificationsCount={liveUnreadCount}
              onOpenNotification={onOpenLiveNotification}
              onClearNotifications={onClearLiveNotifications}
              onMarkNotificationsRead={onMarkLiveNotificationsRead}
              onAppendLiveNotification={onAppendLiveNotification}
              onOpenNotificationSettings={() => onOpenNotifications?.('live')}
              onScanEnabledChange={onScanEnabledChange}
            />
          </div>
        ) : (
        <div className="flex-1 overflow-y-auto overflow-x-hidden relative overscroll-contain [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
          
          {/* 2. UNIFIED PROMOSPORT CAGNOTTE & GRILLE BADGE */}
          {activeBottomNav !== 'apk' && activeBottomNav !== 'tirage' && (
            <div className="relative z-20 w-full bg-transparent">
              <PromosportUnifiedBadge
                concours={liveConcours}
                cagnotte={liveConcours.cagnotteEstimate}
                tirageGrille={null}
                onRefreshTirage={undefined}
                isRefreshingTirage={isRefreshingTirage}
                lang={lang}
                isKickoffStarted={isBettingLocked}
                activeSubTab={grilleSubTab}
                onSelectSubTab={(tab) => {
                  audioService.playClick();
                  if (tab === 'slips') {
                    setActiveBottomNav('grille');
                    setGrilleSubTab('slips');
                  } else if (tab === 'mondiale') {
                    setActiveConcours(concours || INITIAL_WEEKLY_CONCOURS);
                    setGrilleSubTab('mondiale');
                  } else if (tab === 'nationale') {
                    setGrilleSubTab('nationale');
                  }
                }}
                slipsCount={userSlips.length}
                showTabs={activeBottomNav === 'grille'}
              />
            </div>
          )}

          <div className={`${activeBottomNav === 'grille' ? 'px-0 py-2' : 'p-2 sm:p-4'} pb-[100px] space-y-2.5`}>

          {/* ========================================================= */}
          {/* TAB 2: GRILLE (القصاصة) - Interactive Betting or Saved Slips */}
          {/* ========================================================= */}
          {activeBottomNav === 'grille' && (
            <>
              {grilleSubTab === 'nationale' ? (
                renderNationalUnavailableView()
              ) : grilleSubTab === 'slips' ? (
                isMessagesLogOpen ? (
                  <SlipMessagesLogView
                    lang={lang}
                    sentMessages={sentMessages}
                    receivedMessages={receivedMessages}
                    serverError={messagesServerError}
                    liveConcours={liveConcours}
                    grilles={grilles}
                    isRefreshing={isRefreshingMessages}
                    onRefresh={() => void handleRefreshMessagesClick()}
                    onBackToSlips={() => setIsMessagesLogOpen(false)}
                    onOpenMessageSlip={(msg, direction) =>
                      setSelectedMessageSlip({ msg, direction })
                    }
                    onSaveToMySlips={handleSaveReceivedSlipToMySlips}
                    onDeleteMessage={handleDeleteMessageFromLog}
                  />
                ) : (
                <div className="space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2 px-3 sm:px-4">
                    <h3 className="text-sm font-black text-yellow-400 flex items-center gap-2">
                      <FolderArchive className="w-4 h-4 shrink-0" />
                      <span>
                        {lang === 'AR'
                          ? `سجل القصاصات المسجلة (${userSlips.length})`
                          : `Fiches enregistrées (${userSlips.length})`}
                      </span>
                    </h3>

                    <div className="flex items-center gap-2 flex-wrap">
                      {/* أيقونة سجل الرسائل مفعلة مع الخادم */}
                      <button
                        type="button"
                        onClick={() => {
                          audioService.playClick();
                          setIsMessagesLogOpen(true);
                          onMarkMessagesRead?.();
                          void handleRefreshMessagesClick();
                        }}
                        className="relative min-h-[40px] px-3 py-1.5 rounded-xl bg-gradient-to-r from-sky-500/25 via-cyan-500/20 to-sky-500/25 hover:from-sky-500 hover:to-cyan-500 border-2 border-cyan-300 text-cyan-100 hover:text-black text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer active:scale-95 shadow-[0_0_14px_rgba(34,211,238,0.35)] whitespace-nowrap"
                      >
                        <Mail className="w-4 h-4 shrink-0" />
                        <span>{lang === 'AR' ? 'سجل الرسائل' : 'Messages'}</span>
                        <span
                          dir="ltr"
                          className="min-w-[20px] h-[20px] px-1 rounded-full bg-yellow-400 text-black font-mono text-[10px] font-black flex items-center justify-center tabular-nums"
                        >
                          {messagesUnreadCount > 0
                            ? messagesUnreadCount
                            : receivedMessages.length + sentMessages.length}
                        </span>
                      </button>

                      {userSlips.length > 0 && (
                        <button
                          type="button"
                          onClick={handleClearAllSlips}
                          className="min-h-[40px] px-2.5 py-1 rounded-xl bg-red-950/70 hover:bg-red-800 border border-red-500/60 text-red-300 hover:text-white text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer active:scale-95 shadow whitespace-nowrap"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>{lang === 'AR' ? 'فسخ جميع القصاصات' : 'Tout supprimer'}</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {slipNoticeMessage && (
                    <div className="p-2.5 rounded-xl bg-emerald-950/90 border border-emerald-500 text-emerald-200 font-bold text-xs flex items-center justify-between shadow-[0_0_15px_rgba(16,185,129,0.5)] animate-fade-in">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span>{slipNoticeMessage}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setSlipNoticeMessage(null)}
                        className="text-gray-400 hover:text-white p-0.5 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}

                  {userSlips.length === 0 ? (
                    <div className="p-8 rounded-2xl bg-[#071328] border border-white/10 text-center space-y-3">
                      <div className="w-12 h-12 rounded-full bg-white/5 border border-white/20 mx-auto flex items-center justify-center text-gray-400">
                        <FolderArchive className="w-6 h-6" />
                      </div>
                      <p className="text-sm text-gray-300 font-bold">
                        {lang === 'AR'
                          ? 'لا توجد قصاصات مسجلة حالياً'
                          : 'Aucune fiche enregistrée'}
                      </p>
                      <p className="text-xs text-gray-400">
                        {lang === 'AR'
                          ? 'قم بتعمير القصاصة العالمية أو الوطنية واضغط "تسجيل القصاصة" لحفظها هنا بالترتيب.'
                          : 'Remplissez une grille internationale puis appuyez sur « Valider » pour l’enregistrer ici.'}
                      </p>
                      <button
                        onClick={() => setGrilleSubTab('mondiale')}
                        className="px-4 py-2 rounded-xl bg-gradient-to-r from-yellow-400 to-amber-500 text-black font-black text-xs shadow-md cursor-pointer"
                      >
                        {lang === 'AR' ? 'تعمير قصاصة جديدة' : 'Remplir une nouvelle grille'}
                      </button>
                    </div>
                  ) : (
                    userSlips.map((slip, slipIndex) => {
                      const isExpanded = expandedSlipId === slip.id;
                      const isSendRowOpen = activeSendSlipId === slip.id;
                      const slipConcours = resolveConcoursForSlip(slip);
                      const slipStats = computeSlipSummaryStats(
                        slip.selections,
                        slipConcours,
                        slip.grilleNumber || liveConcours.number
                      );

                      return (
                        <div
                          key={slip.id}
                          className="rounded-2xl bg-[#08152e] border-2 border-yellow-500/60 overflow-hidden shadow-lg"
                        >
                          {/* Slip Header - Clicking opens full page 13-match view */}
                          <div
                            onClick={() => {
                              audioService.playClick();
                              setSelectedFullSlip(slip);
                            }}
                            className="p-3 bg-gradient-to-r from-[#091a38] via-[#0c2450] to-[#091a38] flex flex-col gap-2.5 cursor-pointer hover:bg-sky-950/60 transition-colors group"
                          >
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex items-start gap-2 min-w-0">
                                {/* أيقونة ترقيم كل قصاصة مسجلة + بجانبها أيقونة إرسال */}
                                <div className="flex items-center gap-1.5 shrink-0 mt-0.5">
                                  <div className="w-8 h-8 rounded-xl bg-yellow-400 text-black font-black text-xs flex items-center justify-center shadow tabular-nums">
                                    #{slipIndex + 1}
                                  </div>

                                  <button
                                    type="button"
                                    data-no-flash="true"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleToggleSendForSlip(slip.id);
                                    }}
                                    aria-expanded={isSendRowOpen}
                                    title={
                                      lang === 'AR'
                                        ? `إرسال القصاصة #${slipIndex + 1} إلى مشارك في الخادم`
                                        : `Envoyer la fiche N° ${slipIndex + 1}`
                                    }
                                    className={`min-h-[34px] px-2.5 py-1 rounded-xl border-2 font-black text-[11px] flex items-center gap-1 transition-all cursor-pointer active:scale-95 whitespace-nowrap ${
                                      isSendRowOpen
                                        ? 'bg-gradient-to-r from-cyan-300 to-sky-400 text-black border-white shadow-[0_0_12px_rgba(34,211,238,0.85)]'
                                        : 'bg-[#061530] hover:bg-sky-500 hover:text-black border-cyan-300/90 text-cyan-200 shadow'
                                    }`}
                                  >
                                    <Send className="w-3.5 h-3.5 shrink-0" />
                                    <span>{lang === 'AR' ? 'إرسال' : 'Envoyer'}</span>
                                  </button>
                                </div>

                                <div className="min-w-0">
                                  <div className="flex flex-wrap items-center gap-1.5">
                                    <h4 className="font-black text-xs sm:text-sm text-yellow-300">
                                      {getDisplaySlipName(slip.name)}
                                    </h4>
                                    <span className="px-2 py-0.5 rounded-md bg-cyan-500/20 border border-cyan-400/80 text-cyan-200 font-mono font-black text-[10px] sm:text-[11px] whitespace-nowrap">
                                      {lang === 'AR'
                                        ? `المسابقة #${slip.grilleNumber || liveConcours.number}`
                                        : `Concours N° ${slip.grilleNumber || liveConcours.number}`}
                                    </span>
                                  </div>
                                  <div className="text-[10px] text-gray-400 flex items-center gap-2 mt-0.5 flex-wrap">
                                    <span>
                                      {lang === 'AR'
                                        ? `بتاريخ: ${slip.createdAt}`
                                        : `Le : ${slip.createdAt}`}
                                    </span>
                                    <span>•</span>
                                    <span className="text-cyan-400 font-mono">
                                      {lang === 'AR'
                                        ? `${slip.totalCombinations} عمود`
                                        : `${slip.totalCombinations} col.`}
                                    </span>
                                  </div>
                                </div>
                              </div>

                              <div className="flex items-center gap-1.5 shrink-0">
                                {!isBettingLocked && (
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleEditSlip(slip);
                                    }}
                                    title={
                                      lang === 'AR'
                                        ? 'تعديل القصاصة (متاح قبل بداية المباريات)'
                                        : 'Modifier la fiche (avant le coup d’envoi)'
                                    }
                                    className="p-1.5 rounded-lg bg-sky-500/20 text-sky-300 hover:bg-sky-500 hover:text-black transition-colors cursor-pointer"
                                  >
                                    <Edit3 className="w-4 h-4" />
                                  </button>
                                )}

                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleDeleteSlip(slip.id);
                                  }}
                                  title={
                                    lang === 'AR'
                                      ? 'فسخ القصاصة نهائياً (متاح في أي وقت)'
                                      : 'Supprimer définitivement la fiche'
                                  }
                                  className="px-2.5 py-1 rounded-xl bg-red-600/30 hover:bg-red-600 border border-red-500/60 text-red-200 hover:text-white transition-all flex items-center gap-1.5 text-xs font-bold shadow-md cursor-pointer active:scale-95"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                  <span>{lang === 'AR' ? 'فسخ القصاصة' : 'Supprimer'}</span>
                                </button>
                              </div>
                            </div>

                            {/* سطر إدخال اسم اختيار المستخدم من الخادم بنفس التطبيق مع أيقونة إرسال */}
                            {isSendRowOpen && (
                              <div
                                onClick={(e) => e.stopPropagation()}
                                className="rounded-xl bg-[#040d21]/95 border-2 border-cyan-400/85 p-2.5 space-y-2 shadow-inner"
                              >
                                <div className="flex items-center justify-between gap-2 text-[11px] font-black text-cyan-200">
                                  <span className="flex items-center gap-1.5">
                                    <Users className="w-3.5 h-3.5 text-yellow-300 shrink-0" />
                                    <span>
                                      {lang === 'AR'
                                        ? `إرسال القصاصة #${slipIndex + 1} (13 فريق) إلى مستخدم مسجل من الخادم:`
                                        : `Envoyer la fiche N° ${slipIndex + 1} à un participant inscrit :`}
                                    </span>
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setActiveSendSlipId(null);
                                      setSendSlipError(null);
                                    }}
                                    aria-label={lang === 'AR' ? 'إغلاق' : 'Fermer'}
                                    className="p-1 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 cursor-pointer"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                </div>

                                <form
                                  onSubmit={(e) => {
                                    e.preventDefault();
                                    void handleConfirmSendSlip(slip, slipIndex + 1);
                                  }}
                                  className="flex items-center gap-1.5"
                                >
                                  <input
                                    type="text"
                                    dir="auto"
                                    value={sendRecipientInput}
                                    onChange={(e) => {
                                      setSendRecipientInput(e.target.value);
                                      setSendSelectedUser(null);
                                      if (sendSlipError) setSendSlipError(null);
                                    }}
                                    placeholder={
                                      lang === 'AR'
                                        ? 'اكتب أو اختر اسم المستخدم مع الرقمين (مثال: أحمد 47)...'
                                        : 'Nom du participant + 2 chiffres...'
                                    }
                                    className="flex-1 min-w-0 min-h-[42px] px-3 py-2 rounded-xl bg-[#020817] border border-sky-400/75 focus:border-white text-white placeholder:text-slate-400 text-xs font-bold outline-none"
                                  />
                                  <button
                                    type="submit"
                                    disabled={isSendingSlip}
                                    className="min-h-[42px] px-3.5 py-2 rounded-xl bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-500 hover:brightness-105 disabled:opacity-60 border border-white text-black font-black text-xs flex items-center gap-1.5 cursor-pointer active:scale-95 transition-all whitespace-nowrap shrink-0"
                                  >
                                    <Send className="w-3.5 h-3.5 shrink-0" />
                                    <span>
                                      {isSendingSlip
                                        ? lang === 'AR'
                                          ? 'جارٍ الإرسال...'
                                          : 'Envoi...'
                                        : lang === 'AR'
                                          ? 'إرسال'
                                          : 'Envoyer'}
                                    </span>
                                  </button>
                                </form>

                                {/* Server Registered Users Suggestions */}
                                <div className="space-y-1">
                                  <div className="text-[10px] font-bold text-sky-200/80">
                                    {isLoadingDirectory
                                      ? lang === 'AR'
                                        ? 'جارٍ جلب المستخدمين المسجلين من الخادم...'
                                        : 'Chargement des utilisateurs du serveur...'
                                      : directoryUsers.length > 0
                                        ? lang === 'AR'
                                          ? 'المستخدمون المسجلون على الخادم (انقر للاختيار):'
                                          : 'Participants inscrits sur le serveur :'
                                        : lang === 'AR'
                                          ? 'لا يوجد مستخدمون آخرون مسجلون حالياً — يمكنك كتابة الاسم مع الرقمين.'
                                          : 'Aucun autre participant inscrit pour le moment.'}
                                  </div>

                                  {directoryUsers.length > 0 && (
                                    <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
                                      {directoryUsers.map((u) => {
                                        const isPicked = sendSelectedUser?.id === u.id;
                                        return (
                                          <button
                                            key={u.id}
                                            type="button"
                                            onClick={() => {
                                              audioService.playClick();
                                              setSendSelectedUser(u);
                                              setSendRecipientInput(u.fullName);
                                              if (sendSlipError) setSendSlipError(null);
                                            }}
                                            className={`min-h-[34px] px-2.5 py-1 rounded-xl border text-xs font-black flex items-center gap-1.5 cursor-pointer transition-all active:scale-95 ${
                                              isPicked
                                                ? 'bg-emerald-400 text-black border-white shadow'
                                                : 'bg-[#081736] hover:bg-sky-800/80 text-white border-sky-400/65'
                                            }`}
                                          >
                                            <UserCheck className="w-3.5 h-3.5 shrink-0" />
                                            <span dir="auto">{u.fullName}</span>
                                          </button>
                                        );
                                      })}
                                    </div>
                                  )}
                                </div>

                                {sendSlipError && (
                                  <div
                                    role="alert"
                                    className="px-2.5 py-1.5 rounded-lg bg-red-950/90 border border-red-400/80 text-red-100 text-[11px] font-bold"
                                  >
                                    {sendSlipError}
                                  </div>
                                )}
                              </div>
                            )}

                            {/* Slip Price Icon + Persistent Doubles/Triples/Singles + Live/Final Errors & Correct Counts Underneath */}
                            <div className="flex flex-col items-start gap-1.5 pt-1 border-t border-white/10">
                              <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-xl bg-black/65 border border-emerald-400/65 shadow-sm">
                                <Receipt className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                                <span className="text-[10px] text-gray-300 font-bold">
                                  {lang === 'AR' ? 'ثمن القصاصة:' : 'Prix:'}
                                </span>
                                <span className="font-mono text-xs font-black text-emerald-300 tabular-nums" dir="ltr">
                                  {slip.totalCostDt.toFixed(3)} TND
                                </span>
                              </div>

                              <SlipSummaryBadges stats={slipStats} lang={lang} compact />
                            </div>
                          </div>

                          {/* Expanded 13 Matches View with ✓ / ✗ */}
                          {isExpanded && (
                            <div className="px-0 py-2 bg-black/60 border-t border-white/10 space-y-1.5">
                              <div className="text-[11px] text-gray-300 font-bold px-3 pb-1 flex justify-between">
                                <span>
                                  {lang === 'AR'
                                    ? 'المقابلات الـ 13 مع علامات الصح والخطأ والنتائج الرسمية:'
                                    : 'Les 13 matchs avec pronostics et résultats officiels :'}
                                </span>
                                <span className="text-yellow-400">
                                  {lang === 'AR'
                                    ? `قصاصة مسابقة ${slip.grilleNumber}`
                                    : `Concours ${slip.grilleNumber}`}
                                </span>
                              </div>

                              {resolveConcoursForSlip(slip).matches.map((m) => {
                                const userChoices = slip.selections[m.id] || [];
                                return (
                                  <BroadcastScoreboardMatch
                                    key={m.id}
                                    match={m}
                                    lang={lang}
                                    mode="slip"
                                    isKickoffStarted={isBettingLocked}
                                    slipChoices={userChoices}
                                    getTeamName={getTeamName}
                                    justScoredGoal={Boolean(goalFlashMatchIds[m.id])}
                                  />
                                );
                              })}

                              {/* Footer Action: Delete Slip at any time */}
                              <div className="pt-2 flex items-center justify-between border-t border-white/10 px-3">
                                <span className="text-[10px] text-gray-400">
                                  {lang === 'AR'
                                    ? 'يمكن فسخ أي قصاصة مسجلة في أي وقت'
                                    : 'Suppression possible à tout moment'}
                                </span>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleDeleteSlip(slip.id);
                                  }}
                                  className="px-3 py-1 rounded-xl bg-red-600/40 hover:bg-red-600 border border-red-500 text-red-200 hover:text-white transition-all flex items-center gap-1.5 text-xs font-bold shadow cursor-pointer active:scale-95"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                  <span>
                                    {lang === 'AR'
                                      ? 'فسخ هذه القصاصة نهائياً'
                                      : 'Supprimer définitivement'}
                                  </span>
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })
                  )}
                </div>
                )
              ) : null}
            </>
          )}

          {/* ========================================================= */}
          {/* TAB 3: TIRAGE (صورة جامدة فقط بدون بث مباشر — تحديث القيمة المالية والمرابيح فقط عند عدم ظهورها) */}
          {/* ========================================================= */}
          {activeBottomNav === 'tirage' && activeTirage && (
            <TirageFrozenSnapshotCard
              grille={activeTirage}
              lang={lang}
              getTeamName={getTeamName}
              isRefreshingPayouts={isRefreshingTirage}
              onRefreshPayoutsOnly={
                !isTirageOfficialFrozen ? handleRefreshTirageFromSite : undefined
              }
            />
          )}

          {activeBottomNav === 'tirage' && !activeTirage && (
            <div className="rounded-2xl bg-[#08152e]/90 border-2 border-yellow-400/60 p-6 text-center space-y-3">
              <p className="text-sm font-black text-yellow-300">
                {lang === 'AR'
                  ? 'جاري مزامنة القصاصة السابقة الأخيرة من الموقع...'
                  : 'Synchronisation du dernier tirage depuis le site...'}
              </p>
              <button
                type="button"
                onClick={handleRefreshTirageFromSite}
                disabled={isRefreshingTirage}
                className="min-h-[44px] px-4 py-2 rounded-xl inline-flex items-center gap-2 text-xs font-black bg-yellow-400 text-black hover:bg-yellow-300 cursor-pointer disabled:opacity-60"
              >
                <RefreshCw className={`w-4 h-4 ${isRefreshingTirage ? 'animate-spin' : ''}`} />
                <span>
                  {lang === 'AR' ? 'تحديث القصاصة السابقة الآن' : 'Actualiser le tirage'}
                </span>
              </button>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 4: PROMPT / APK HUB + NEW UNLOCKED SETTINGS SUB-PAGE  */}
          {/* ========================================================= */}
          {activeBottomNav === 'apk' && (
            <div className="space-y-3">
              {/* Sub-Page Switcher inside Prompt Tab: Hub (PIN 1777) vs Settings (Unlocked without PIN) */}
              <div className="grid grid-cols-2 gap-2 p-1.5 rounded-2xl bg-[#071328] border border-sky-400/40 shadow-md">
                <button
                  type="button"
                  onClick={() => {
                    audioService.playClick();
                    setPromptSubPage('hub');
                  }}
                  className={`min-h-[44px] px-3 py-2 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-95 ${
                    promptSubPage === 'hub'
                      ? 'bg-gradient-to-r from-cyan-400 to-sky-500 text-black shadow-[0_0_14px_rgba(34,211,238,0.5)]'
                      : 'text-gray-300 hover:text-white bg-black/30'
                  }`}
                >
                  <Smartphone className="w-4 h-4 shrink-0" />
                  <span>{lang === 'AR' ? 'التثبيت وحزمة ZIP' : 'Installation & Pack ZIP'}</span>
                  {!isProtectedTabsUnlocked && (
                    <Lock className={`w-3.5 h-3.5 shrink-0 ${promptSubPage === 'hub' ? 'text-black' : 'text-yellow-400'}`} />
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    audioService.playClick();
                    setPromptSubPage('settings');
                  }}
                  className={`min-h-[44px] px-3 py-2 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-95 ${
                    promptSubPage === 'settings'
                      ? 'bg-gradient-to-r from-yellow-400 via-amber-400 to-yellow-500 text-black shadow-[0_0_16px_rgba(250,204,21,0.55)]'
                      : 'text-yellow-300/90 hover:text-yellow-200 bg-black/30'
                  }`}
                >
                  <Settings className="w-4 h-4 shrink-0" />
                  <span>{lang === 'AR' ? 'صفحة الإعدادات (مفتوحة)' : 'Paramètres (Ouverts)'}</span>
                </button>
              </div>

              {promptSubPage === 'settings' ? (
                /* UNLOCKED SETTINGS SUB-PAGE (opens freely without PIN) */
                <div className="space-y-3">
                  <div className="p-3.5 rounded-2xl bg-gradient-to-r from-[#0a1b38] via-[#0f2854] to-[#0a1b38] border border-yellow-500/50 flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-9 h-9 rounded-xl bg-yellow-400 text-black flex items-center justify-center shrink-0">
                        <Settings className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <h3 className="font-black text-sm text-yellow-300">
                          {lang === 'AR'
                            ? 'إعدادات التطبيق والقصاصات (مفتوحة بدون رقم سري)'
                            : 'Paramètres Application & Grilles (Sans code PIN)'}
                        </h3>
                        <p className="text-[11px] text-gray-300">
                          {lang === 'AR'
                            ? 'تعديل هوية التطبيق، معرف الحزمة، رقم الهاتف وضوابط القصاصات'
                            : 'Identité de l’app, Package ID, téléphone et tarification des fiches'}
                        </p>
                      </div>
                    </div>

                    {settingsSavedAlert && (
                      <span className="px-3 py-1 rounded-full bg-emerald-500 text-black font-black text-xs animate-bounce">
                        {lang === 'AR' ? 'تم الحفظ بنجاح!' : 'Enregistré avec succès !'}
                      </span>
                    )}
                  </div>

                  <div className="space-y-2.5">
                    {/* 1. اسم التطبيق */}
                    <div className="p-3 rounded-2xl bg-[#08152e] border border-white/10 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <Smartphone className="w-4 h-4 text-cyan-400 shrink-0" />
                        <div className="min-w-0">
                          <label className="text-xs font-bold text-gray-300 block">
                            {lang === 'AR' ? 'اسم التطبيق' : 'Nom de l’application'}
                          </label>
                          <span className="text-[10px] text-gray-400 block truncate">
                            {lang === 'AR'
                              ? 'الاسم الظاهر في الواجهة وشريط المهام'
                              : 'Nom affiché dans l’interface et l’en-tête'}
                          </span>
                        </div>
                      </div>
                      <input
                        type="text"
                        value={settings.appName}
                        onChange={(e) => setSettings({ ...settings, appName: e.target.value })}
                        className={`w-32 min-[380px]:w-44 sm:w-60 shrink-0 px-3 py-1.5 rounded-xl bg-black/70 border border-white/20 text-xs text-white ${
                          lang === 'AR' ? 'text-right' : 'text-left'
                        } focus:border-yellow-400 outline-none`}
                      />
                    </div>

                    {/* 2. معرف الحزمة */}
                    <div className="p-3 rounded-2xl bg-[#08152e] border border-white/10 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <Package className="w-4 h-4 text-yellow-400 shrink-0" />
                        <div className="min-w-0">
                          <label className="text-xs font-bold text-gray-300 block">
                            {lang === 'AR' ? 'معرف الحزمة (Package ID)' : 'Identifiant (Package ID)'}
                          </label>
                          <span className="text-[10px] text-gray-400 block truncate">
                            {lang === 'AR'
                              ? 'معرف أندرويد لتطبيق الـ APK'
                              : 'Identifiant Android du paquet APK'}
                          </span>
                        </div>
                      </div>
                      <input
                        type="text"
                        value={settings.packageId}
                        onChange={(e) => setSettings({ ...settings, packageId: e.target.value })}
                        className="w-32 min-[380px]:w-44 sm:w-60 shrink-0 px-3 py-1.5 rounded-xl bg-black/70 border border-white/20 text-xs font-mono text-cyan-300 text-left focus:border-yellow-400 outline-none"
                        dir="ltr"
                      />
                    </div>

                    {/* 3. رقم الهاتف */}
                    <div className="p-3 rounded-2xl bg-[#08152e] border border-white/10 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <PhoneCall className="w-4 h-4 text-emerald-400 shrink-0" />
                        <div className="min-w-0">
                          <label className="text-xs font-bold text-gray-300 block">
                            {lang === 'AR' ? 'رقم الهاتف' : 'Téléphone'}
                          </label>
                          <span className="text-[10px] text-gray-400 block truncate">
                            {lang === 'AR'
                              ? 'الرقم المذهب الظاهر في أعلى الواجهة'
                              : 'Numéro doré affiché en haut de l’écran'}
                          </span>
                        </div>
                      </div>
                      <input
                        type="text"
                        value={settings.phoneNumber}
                        onChange={(e) => setSettings({ ...settings, phoneNumber: e.target.value })}
                        className="w-32 min-[380px]:w-44 sm:w-60 shrink-0 px-3 py-1.5 rounded-xl bg-black/70 border border-white/20 text-xs font-mono font-bold text-emerald-400 text-center focus:border-yellow-400 outline-none"
                        dir="ltr"
                      />
                    </div>

                    {/* 4. رقم القصاصة */}
                    <div className="p-3 rounded-2xl bg-[#08152e] border border-white/10 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <Hash className="w-4 h-4 text-amber-400 shrink-0" />
                        <div className="min-w-0">
                          <label className="text-xs font-bold text-gray-300 block">
                            {lang === 'AR' ? 'رقم القصاصة' : 'Numéro du concours'}
                          </label>
                          <span className="text-[10px] text-gray-400 block truncate">
                            {lang === 'AR'
                              ? `ترقيم المسابقة الحالية (مثل ${liveConcours.number})`
                              : `Concours actif (ex. ${liveConcours.number})`}
                          </span>
                        </div>
                      </div>
                      <input
                        type="number"
                        value={settings.concoursNumber}
                        onChange={(e) => setSettings({ ...settings, concoursNumber: Number(e.target.value) })}
                        className="w-24 sm:w-32 shrink-0 px-3 py-1.5 rounded-xl bg-black/70 border border-white/20 text-xs font-mono font-bold text-yellow-300 text-center focus:border-yellow-400 outline-none"
                      />
                    </div>

                    {/* 5. تسعيرة العمود */}
                    <div className="p-3 rounded-2xl bg-[#08152e] border border-white/10 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <Coins className="w-4 h-4 text-yellow-400 shrink-0" />
                        <div className="min-w-0">
                          <label className="text-xs font-bold text-gray-300 block">
                            {lang === 'AR' ? 'تسعيرة العمود (د.ت)' : 'Tarif par colonne (TND)'}
                          </label>
                          <span className="text-[10px] text-gray-400 block truncate">
                            {lang === 'AR'
                              ? 'المعادلة الرسمية: 0.150 دينار للعمود'
                              : 'Formule officielle : 0.150 TND / colonne'}
                          </span>
                        </div>
                      </div>
                      <input
                        type="number"
                        step="0.010"
                        value={settings.columnRate}
                        onChange={(e) => setSettings({ ...settings, columnRate: parseFloat(e.target.value) || 0.150 })}
                        className="w-24 sm:w-32 shrink-0 px-3 py-1.5 rounded-xl bg-black/70 border border-white/20 text-xs font-mono font-bold text-cyan-300 text-center focus:border-yellow-400 outline-none"
                      />
                    </div>

                    {/* 6. معلوم القصاصة */}
                    <div className="p-3 rounded-2xl bg-[#08152e] border border-white/10 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <Receipt className="w-4 h-4 text-pink-400 shrink-0" />
                        <div className="min-w-0">
                          <label className="text-xs font-bold text-gray-300 block">
                            {lang === 'AR'
                              ? 'معلوم القصاصة (الطابع الجبائي د.ت)'
                              : 'Timbre fiscal / Frais (TND)'}
                          </label>
                          <span className="text-[10px] text-gray-400 block truncate">
                            {lang === 'AR'
                              ? 'المعلوم الثابت: 0.250 دينار لكل قصاصة'
                              : 'Frais fixe : 0.250 TND par fiche'}
                          </span>
                        </div>
                      </div>
                      <input
                        type="number"
                        step="0.010"
                        value={settings.baseFee}
                        onChange={(e) => setSettings({ ...settings, baseFee: parseFloat(e.target.value) || 0.250 })}
                        className="w-24 sm:w-32 shrink-0 px-3 py-1.5 rounded-xl bg-black/70 border border-white/20 text-xs font-mono font-bold text-pink-300 text-center focus:border-yellow-400 outline-none"
                      />
                    </div>

                    {/* 7. تفعيل سجل القصاصات */}
                    <div className="p-3 rounded-2xl bg-[#08152e] border border-white/10 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0" />
                        <div className="min-w-0">
                          <label className="text-xs font-bold text-gray-300 block">
                            {lang === 'AR' ? 'تفعيل سجل القصاصات' : 'Historique des fiches'}
                          </label>
                          <span className="text-[10px] text-gray-400 block truncate">
                            {lang === 'AR'
                              ? 'إظهار تبويب القصاصات المسجلة واسترجاعها'
                              : 'Afficher et restaurer l’onglet des fiches'}
                          </span>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          audioService.playClick();
                          setSettings({ ...settings, enableSlipsHistory: !settings.enableSlipsHistory });
                        }}
                        className={`shrink-0 px-3 py-1 rounded-xl text-xs font-black transition-all cursor-pointer ${
                          settings.enableSlipsHistory
                            ? 'bg-emerald-500 text-black shadow-[0_0_10px_rgba(16,185,129,0.7)]'
                            : 'bg-white/10 text-gray-400'
                        }`}
                      >
                        {settings.enableSlipsHistory
                          ? lang === 'AR'
                            ? 'مفعل ✓'
                            : 'Activé ✓'
                          : lang === 'AR'
                            ? 'معطل ✗'
                            : 'Désactivé ✗'}
                      </button>
                    </div>
                  </div>

                  <div className="pt-2 flex items-center justify-between gap-3">
                    <button
                      type="button"
                      onClick={handleSaveAppSettings}
                      className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-yellow-400 via-amber-400 to-yellow-500 text-black font-black text-xs shadow-[0_0_15px_rgba(241,184,22,0.7)] hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Save className="w-4 h-4" />
                      <span>
                        {lang === 'AR' ? 'حفظ وتطبيق الإعدادات' : 'Enregistrer & Appliquer'}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={handleResetAppSettings}
                      className="py-2.5 px-4 rounded-xl bg-white/10 hover:bg-white/20 text-gray-300 text-xs font-bold transition-all cursor-pointer"
                    >
                      {lang === 'AR' ? 'استعادة الافتراضي' : 'Réinitialiser'}
                    </button>
                  </div>
                </div>
              ) : !isProtectedTabsUnlocked ? (
                /* PIN 1777 GATE FOR APK/ZIP PROMPT HUB */
                <div className="py-4 sm:py-6 px-2 flex flex-col items-center justify-center min-h-[48dvh]">
                  <form
                    onSubmit={handlePinSubmit}
                    className="w-full max-w-sm rounded-3xl bg-[#08152e] border-2 border-yellow-400/80 p-5 sm:p-6 shadow-[0_0_40px_rgba(241,184,22,0.3)] space-y-4 text-center"
                  >
                    <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-br from-yellow-300 via-amber-400 to-yellow-600 text-black flex items-center justify-center shadow-[0_0_20px_rgba(241,184,22,0.75)] border-2 border-yellow-100">
                      <Lock className="w-7 h-7" />
                    </div>

                    <div className="space-y-1">
                      <h3 className="font-black text-base text-yellow-300">
                        {lang === 'AR'
                          ? 'خانة برومبت APK محمية بكلمة سر'
                          : 'Onglet Prompt APK protégé par code PIN'}
                      </h3>
                      <p className="text-[11px] text-gray-300 leading-relaxed">
                        {lang === 'AR'
                          ? 'أدخل كلمة السر لفتح مركز التثبيت وحزمة ZIP، أو افتح الإعدادات مباشرة بدون رقم سري أعلاه'
                          : 'Saisissez le code PIN pour ouvrir l’espace ZIP/APK, ou ouvrez les Paramètres librement ci-dessus.'}
                      </p>
                    </div>

                    <div className="space-y-2">
                      <div className="relative">
                        <KeyRound
                          className={`w-4 h-4 text-yellow-400 absolute ${
                            lang === 'AR' ? 'right-3.5' : 'left-3.5'
                          } top-1/2 -translate-y-1/2 pointer-events-none`}
                        />
                        <input
                          type="password"
                          inputMode="numeric"
                          maxLength={6}
                          value={pinInput}
                          onChange={(e) => handlePinChange(e.target.value)}
                          placeholder="••••"
                          dir="ltr"
                          className="w-full py-2.5 px-10 rounded-xl bg-black/80 border-2 border-sky-400/60 focus:border-yellow-400 text-center font-mono text-xl font-black tracking-[0.45em] text-yellow-300 outline-none shadow-inner"
                        />
                      </div>

                      {pinError && (
                        <div className="text-xs font-bold text-red-300 bg-red-950/60 border border-red-500/60 rounded-xl py-1.5 px-3">
                          {pinError}
                        </div>
                      )}
                    </div>

                    <div className="grid grid-cols-3 gap-2 pt-1" dir="ltr">
                      {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
                        <button
                          key={digit}
                          type="button"
                          onClick={() => {
                            audioService.playClick();
                            handlePinChange(pinInput + digit);
                          }}
                          className="min-h-[44px] rounded-xl bg-[#0b1f42] hover:bg-[#123166] active:scale-95 border border-sky-400/40 hover:border-yellow-400 text-white font-mono font-black text-lg transition-all cursor-pointer shadow"
                        >
                          {digit}
                        </button>
                      ))}
                      <button
                        type="button"
                        onClick={() => {
                          audioService.playClick();
                          setPinInput('');
                          setPinError(null);
                        }}
                        className="min-h-[44px] rounded-xl bg-red-950/60 hover:bg-red-900/80 active:scale-95 border border-red-500/40 text-red-200 font-bold text-xs transition-all cursor-pointer"
                      >
                        {lang === 'AR' ? 'مسح' : 'Effacer'}
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          audioService.playClick();
                          handlePinChange(pinInput + '0');
                        }}
                        className="min-h-[44px] rounded-xl bg-[#0b1f42] hover:bg-[#123166] active:scale-95 border border-sky-400/40 hover:border-yellow-400 text-white font-mono font-black text-lg transition-all cursor-pointer shadow"
                      >
                        0
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          audioService.playClick();
                          setPinInput((prev) => prev.slice(0, -1));
                          setPinError(null);
                        }}
                        title={lang === 'AR' ? 'حذف رقم' : 'Supprimer un chiffre'}
                        className="min-h-[44px] rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 border border-white/20 text-gray-200 flex items-center justify-center transition-all cursor-pointer"
                      >
                        <Delete className="w-5 h-5" />
                      </button>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-2.5 rounded-xl bg-gradient-to-r from-yellow-400 via-amber-400 to-yellow-500 text-black font-black text-sm shadow-[0_0_18px_rgba(241,184,22,0.75)] hover:brightness-105 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Unlock className="w-4 h-4" />
                      <span>{lang === 'AR' ? 'فتح الخانة' : 'Déverrouiller'}</span>
                    </button>
                  </form>
                </div>
              ) : (
                <div className="space-y-2.5">
                  <div className="flex justify-end">
                    <button
                      type="button"
                      onClick={() => {
                        audioService.playClick();
                        setIsProtectedTabsUnlocked(false);
                        setPinInput('');
                      }}
                      className="px-3 py-1 rounded-xl bg-[#08152e] hover:bg-[#0f254d] border border-yellow-400/50 text-yellow-300 text-[11px] font-bold flex items-center gap-1.5 cursor-pointer active:scale-95 transition-all"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>{lang === 'AR' ? 'قفل خانة برومبت' : 'Verrouiller Prompt'}</span>
                    </button>
                  </div>
                  <AppInstallPromptHub
                    settings={settings}
                    userSlips={userSlips}
                    concours={liveConcours}
                    lang={lang}
                  />
                </div>
              )}
            </div>
          )}

          </div>
        </div>
        )}

        {/* 6. BOTTOM TRANSPARENT GLASS 5-TABS NAVIGATION BAR (القصاصة | Tirage | المباشر | التنبيهات | برومبت APK) */}
        <div className="absolute bottom-0 inset-x-0 px-1.5 sm:px-2 pt-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] bg-white/[0.06] backdrop-blur-md border-t border-sky-400/50 shadow-[0_-8px_28px_rgba(0,0,0,0.45)] grid grid-cols-5 gap-1 select-none z-30">

          {/* 1. القصاصة / Grille */}
          <button
            type="button"
            data-no-flash="true"
            onClick={() => {
              audioService.playClick();
              setActiveBottomNav('grille');
              onTabChange?.('grille');
            }}
            style={highlightedTab === 'grille' ? { outline: '3px solid #fde047', outlineOffset: '2px', animation: 'pulse 1s ease-in-out infinite' } : undefined}
            className={`min-h-[54px] flex flex-col items-center justify-center py-1 px-1 rounded-xl border-2 transition-all cursor-pointer ${
              activeBottomNav === 'grille'
                ? 'bg-sky-500/25 border-sky-300 text-yellow-300 font-black shadow-[0_0_16px_rgba(56,189,248,0.65)]'
                : 'bg-black/30 hover:bg-sky-500/15 border-sky-400/85 text-sky-100 hover:text-white shadow-[0_0_10px_rgba(56,189,248,0.28)]'
            }`}
          >
            <div
              className={`w-7 h-7 rounded-lg border-2 flex items-center justify-center mb-0.5 transition-all ${
                activeBottomNav === 'grille'
                  ? 'border-sky-300 bg-[#f1b816] text-black shadow-[0_0_10px_rgba(241,184,22,0.85)]'
                  : 'border-sky-400 bg-sky-500/15 text-sky-200'
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
            </div>
            <span className="text-[10px] sm:text-[10.5px] font-black drop-shadow-[0_1px_3px_rgba(0,0,0,0.95)] whitespace-nowrap">
              {lang === 'AR' ? 'القصاصة' : 'Grille'}
            </span>
          </button>

          {/* 2. Tirage */}
          <button
            type="button"
            data-no-flash="true"
            onClick={() => {
              audioService.playClick();
              setActiveBottomNav('tirage');
              onTabChange?.('tirage');
            }}
            style={highlightedTab === 'tirage' ? { outline: '3px solid #fde047', outlineOffset: '2px', animation: 'pulse 1s ease-in-out infinite' } : undefined}
            className={`min-h-[54px] flex flex-col items-center justify-center py-1 px-1 rounded-xl border-2 transition-all cursor-pointer ${
              activeBottomNav === 'tirage'
                ? 'bg-sky-500/25 border-sky-300 text-cyan-200 font-black shadow-[0_0_16px_rgba(56,189,248,0.65)]'
                : 'bg-black/30 hover:bg-sky-500/15 border-sky-400/85 text-sky-100 hover:text-white shadow-[0_0_10px_rgba(56,189,248,0.28)]'
            }`}
          >
            <div
              className={`w-7 h-7 rounded-lg border-2 flex items-center justify-center mb-0.5 transition-all ${
                activeBottomNav === 'tirage'
                  ? 'border-sky-300 bg-cyan-400 text-black shadow-[0_0_10px_rgba(34,211,238,0.85)]'
                  : 'border-sky-400 bg-sky-500/15 text-sky-200'
              }`}
            >
              <Ticket className="w-4 h-4" />
            </div>
            <span className="text-[10px] sm:text-[10.5px] font-black drop-shadow-[0_1px_3px_rgba(0,0,0,0.95)] whitespace-nowrap">
              Tirage
            </span>
          </button>

          {/* 3. المباشر / Direct */}
          <button
            type="button"
            data-no-flash="true"
            onClick={() => {
              audioService.playClick();
              setActiveBottomNav('live');
              onTabChange?.('live');
            }}
            style={highlightedTab === 'live' ? { outline: '3px solid #fde047', outlineOffset: '2px', animation: 'pulse 1s ease-in-out infinite' } : undefined}
            className={`relative min-h-[54px] flex flex-col items-center justify-center py-1 px-1 rounded-xl border-2 transition-all cursor-pointer ${
              activeBottomNav === 'live'
                ? 'bg-emerald-500/25 border-sky-300 text-emerald-200 font-black shadow-[0_0_18px_rgba(16,185,129,0.75)]'
                : 'bg-black/30 hover:bg-sky-500/15 border-sky-400/85 text-sky-100 hover:text-white shadow-[0_0_10px_rgba(56,189,248,0.28)]'
            }`}
          >
            {liveBadgeCount > 0 && (
              <span className="absolute top-1 left-1.5 flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-85" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400 border border-black" />
              </span>
            )}
            <div
              className={`w-7 h-7 rounded-lg border-2 flex items-center justify-center mb-0.5 transition-all ${
                activeBottomNav === 'live'
                  ? 'border-sky-300 bg-emerald-400 text-black shadow-[0_0_10px_rgba(16,185,129,0.9)]'
                  : 'border-sky-400 bg-sky-500/15 text-emerald-300'
              }`}
            >
              <Radio className="w-4 h-4" />
            </div>
            <span className="text-[10px] sm:text-[10.5px] font-black drop-shadow-[0_1px_3px_rgba(0,0,0,0.95)] whitespace-nowrap">
              {lang === 'AR' ? 'المباشر' : 'Direct'}
            </span>
          </button>

          {/* 4. التنبيهات / Alertes */}
          <button
            type="button"
            data-no-flash="true"
            onClick={() => {
              audioService.playClick();
              onOpenNotifications?.(activeBottomNav === 'live' ? 'live' : 'general');
            }}
            title={
              activeBottomNav === 'live'
                ? lang === 'AR'
                  ? 'إشعارات وتنبيهات خانة المباشر وحدها'
                  : 'Notifications & alertes du Direct uniquement'
                : lang === 'AR'
                  ? 'إشعارات وتنبيهات بقية الخانات والصفحة الرئيسية'
                  : 'Notifications des autres onglets & accueil'
            }
            aria-label={
              lang === 'AR' ? 'إعدادات التنبيهات والأصوات' : 'Paramètres des alertes et sons'
            }
            className="relative min-h-[54px] flex flex-col items-center justify-center py-1 px-1 rounded-xl border-2 border-yellow-400/80 bg-black/30 text-yellow-200 hover:bg-yellow-500/15 hover:border-yellow-200 transition-all cursor-pointer active:scale-95"
          >
            {(activeBottomNav === 'live' ? liveUnreadCount : generalUnreadCount) > 0 && (
              <span
                dir="ltr"
                className="absolute top-1 left-1 min-w-[16px] h-[16px] px-1 rounded-full bg-red-600 border border-yellow-200 text-white font-mono text-[9px] font-black flex items-center justify-center tabular-nums shadow"
              >
                {(activeBottomNav === 'live' ? liveUnreadCount : generalUnreadCount) > 99
                  ? '99+'
                  : activeBottomNav === 'live'
                    ? liveUnreadCount
                    : generalUnreadCount}
              </span>
            )}
            <div className="w-7 h-7 rounded-lg border-2 border-yellow-400 bg-yellow-500/15 text-yellow-200 flex items-center justify-center mb-0.5">
              <Bell className="w-4 h-4" />
            </div>
            <span className="text-[9px] sm:text-[10px] font-black drop-shadow-[0_1px_3px_rgba(0,0,0,0.95)] whitespace-nowrap">
              {lang === 'AR' ? 'التنبيهات' : 'Alertes'}
            </span>
          </button>

          {/* 5. برومبت APK / Prompt APK */}
          <button
            type="button"
            data-no-flash="true"
            onClick={() => {
              audioService.playClick();
              setPinError(null);
              setActiveBottomNav('apk');
              onTabChange?.('apk');
            }}
            style={highlightedTab === 'apk' ? { outline: '3px solid #fde047', outlineOffset: '2px', animation: 'pulse 1s ease-in-out infinite' } : undefined}
            className={`min-h-[54px] flex flex-col items-center justify-center py-1 px-1 rounded-xl border-2 transition-all cursor-pointer ${
              activeBottomNav === 'apk'
                ? 'bg-sky-500/25 border-sky-300 text-cyan-200 font-black shadow-[0_0_16px_rgba(56,189,248,0.65)]'
                : 'bg-black/30 hover:bg-sky-500/15 border-sky-400/85 text-sky-100 hover:text-white shadow-[0_0_10px_rgba(56,189,248,0.28)]'
            }`}
          >
            <div
              className={`w-7 h-7 rounded-lg border-2 flex items-center justify-center mb-0.5 transition-all ${
                activeBottomNav === 'apk'
                  ? 'border-sky-300 bg-cyan-400 text-black shadow-[0_0_10px_rgba(34,211,238,0.85)]'
                  : 'border-sky-400 bg-sky-500/15 text-sky-200'
              }`}
            >
              <Smartphone className="w-4 h-4" />
            </div>
            <span className="text-[10px] sm:text-[10.5px] font-black drop-shadow-[0_1px_3px_rgba(0,0,0,0.95)] whitespace-nowrap">
              {lang === 'AR' ? 'برومبت APK' : 'Prompt APK'}
            </span>
          </button>

        </div>
          </>
        )}

      </div>
    </div>
  );
};
