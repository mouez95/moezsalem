/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import {
  ArrowRight,
  Trash2,
  Edit3,
  Save,
  Trophy,
  Check,
  ChevronDown,
  ChevronUp,
  Receipt,
  Calendar,
  LayoutGrid,
  Clock,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  BookmarkPlus,
  Radio,
  UserCheck,
  Send,
} from 'lucide-react';
import { UserBetSlip, WeeklyConcours } from '../types/promosport';
import { MbLogo } from './MbLogo';
import { PinterestScoreboardCard } from './PinterestScoreboardCard';
import { audioService } from '../services/audioService';
import { calculatePromosportPrice } from '../services/pricingService';
import { computeSlipSummaryStats } from '../services/slipStatsService';
import { SlipSummaryBadges } from './SlipSummaryBadges';
import { formatConcoursPlusOneLabel, formatUtcPlusOneClock, useUtcClock } from '../services/timeUtils';
import { LanguageToggleButton } from './LanguageToggleButton';
import confetti from 'canvas-confetti';

interface SavedSlipFullPageViewProps {
  slip: UserBetSlip;
  concours: WeeklyConcours;
  lang: 'AR' | 'FR';
  onBackToSlips: () => void;
  onBackToGrille: () => void;
  onUpdateSlip: (updatedSlip: UserBetSlip) => void;
  onDeleteSlip: (slipId: string) => void;
  getTeamName: (teamName: string, frName?: string) => string;
  isKickoffStarted?: boolean;
  columnRate?: number;
  baseFee?: number;
  goalFlashMatchIds?: Record<number, number>;
  onChangeLang?: (lang: 'AR' | 'FR') => void;
  readOnly?: boolean;
  backLabel?: string;
  messageMeta?: {
    direction: 'incoming' | 'sent';
    senderFullName: string;
    recipientFullName: string;
    sentAtDisplay: string;
    alreadySavedToSlips?: boolean;
  };
  onSaveMessageToMySlips?: () => void;
}

const MIN_SLIP_ZOOM = 0.3;
const MAX_SLIP_ZOOM = 1.6;
const SLIP_ZOOM_STEP = 0.1;
const SLIP_ZOOM_STORAGE_KEY = 'promosport_slip_zoom_v1';
const SLIP_TIMEDATE_BAR_STORAGE_KEY = 'promosport_slip_timedate_bar_v1';

const clampSlipZoom = (val: number): number => {
  const clamped = Math.min(MAX_SLIP_ZOOM, Math.max(MIN_SLIP_ZOOM, val));
  return Math.round(clamped * 100) / 100;
};

const loadInitialSlipZoom = (): number => {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return 1;
    const raw = window.localStorage.getItem(SLIP_ZOOM_STORAGE_KEY);
    if (!raw) return 1;
    const parsed = Number(raw);
    return Number.isFinite(parsed) ? clampSlipZoom(parsed) : 1;
  } catch {
    return 1;
  }
};

const loadInitialSlipTimeDateBarVisible = (): boolean => {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return true;
    const raw = window.localStorage.getItem(SLIP_TIMEDATE_BAR_STORAGE_KEY);
    return raw === null ? true : raw === '1';
  } catch {
    return true;
  }
};

export const SavedSlipFullPageView: React.FC<SavedSlipFullPageViewProps> = ({
  slip,
  concours,
  lang,
  onBackToSlips,
  onBackToGrille,
  onUpdateSlip,
  onDeleteSlip,
  getTeamName,
  isKickoffStarted = false,
  columnRate = 0.150,
  baseFee = 0.250,
  goalFlashMatchIds = {},
  onChangeLang,
  readOnly = false,
  backLabel,
  messageMeta,
  onSaveMessageToMySlips,
}) => {
  const isReadOnly = Boolean(readOnly);
  // Toggle for Floating Shaded-Black Glass Saved Slip Ribbon (إظهار وإخفاء شريط القصاصة المسجلة يدوياً)
  const [isGrandPrizeOpen, setIsGrandPrizeOpen] = useState<boolean>(true);
  const { timePlusOne } = useUtcClock(1000);

  // Editing mode state (disabled strictly in readOnly mode)
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const effectiveIsEditing = isReadOnly ? false : isEditing;
  const [editedSelections, setEditedSelections] = useState<Record<number, ('1' | 'X' | '2')[]>>(() => ({
    ...slip.selections,
  }));
  const [saveSuccessNotice, setSaveSuccessNotice] = useState<boolean>(false);

  // Floating glass overlay stack height measurement ref
  const topOverlayRef = useRef<HTMLDivElement>(null);
  const [topOverlayHeight, setTopOverlayHeight] = useState<number>(220);

  // Scroll + Zoom + Time/Date bar toggle refs & state
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const zoomViewportRef = useRef<HTMLDivElement>(null);
  const scaledWrapperRef = useRef<HTMLDivElement>(null);
  const matchesContentRef = useRef<HTMLDivElement>(null);
  const numericInputRef = useRef<HTMLInputElement>(null);

  const [zoom, setZoom] = useState<number>(loadInitialSlipZoom);
  const [isZoomBarOpen, setIsZoomBarOpen] = useState<boolean>(true);
  const [zoomTextInput, setZoomTextInput] = useState<string>(() =>
    String(Math.round(loadInitialSlipZoom() * 100))
  );
  const [viewportWidth, setViewportWidth] = useState<number>(0);
  const [unscaledHeight, setUnscaledHeight] = useState<number>(0);
  const zoomRef = useRef<number>(zoom);
  zoomRef.current = zoom;

  const [isTimeDateBarVisible, setIsTimeDateBarVisible] = useState<boolean>(
    loadInitialSlipTimeDateBarVisible
  );
  const [anchorCardIndex, setAnchorCardIndex] = useState<number | null>(null);
  const [hasToggledTimeDateBar, setHasToggledTimeDateBar] = useState<boolean>(false);
  const pendingScrollAnchorRef = useRef<{
    el: HTMLElement;
    prevTop: number;
  } | null>(null);
  const activeAnchorRafRef = useRef<number | null>(null);
  const lastScrollTopRef = useRef<number>(0);

  // Desktop mouse drag-to-scroll refs
  const isMouseDownRef = useRef<boolean>(false);
  const startYRef = useRef<number>(0);
  const startXRef = useRef<number>(0);
  const scrollTopRef = useRef<number>(0);
  const scrollLeftRef = useRef<number>(0);

  const cancelActiveScrollAnchor = useCallback(() => {
    if (activeAnchorRafRef.current !== null) {
      window.cancelAnimationFrame(activeAnchorRafRef.current);
      activeAnchorRafRef.current = null;
    }
  }, []);

  useEffect(() => cancelActiveScrollAnchor, [cancelActiveScrollAnchor]);

  const measureOverlayHeight = useCallback(() => {
    if (topOverlayRef.current) {
      const h = topOverlayRef.current.offsetHeight;
      if (h > 0) {
        setTopOverlayHeight((prev) => (prev !== h ? h : prev));
      }
    }
  }, []);

  useEffect(() => {
    const rafId = window.requestAnimationFrame(measureOverlayHeight);
    window.addEventListener('resize', measureOverlayHeight);
    let observer: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined' && topOverlayRef.current) {
      observer = new ResizeObserver(measureOverlayHeight);
      observer.observe(topOverlayRef.current);
    }
    return () => {
      window.cancelAnimationFrame(rafId);
      window.removeEventListener('resize', measureOverlayHeight);
      observer?.disconnect();
    };
  }, [measureOverlayHeight, isGrandPrizeOpen, isZoomBarOpen, lang]);

  const measureMatchesBox = useCallback(() => {
    if (zoomViewportRef.current) {
      const nextWidth = zoomViewportRef.current.clientWidth;
      if (nextWidth > 0) {
        setViewportWidth((prev) => (prev !== nextWidth ? nextWidth : prev));
      }
    }
    if (matchesContentRef.current) {
      const nextHeight = matchesContentRef.current.offsetHeight;
      if (nextHeight > 0) {
        setUnscaledHeight((prev) => (prev !== nextHeight ? nextHeight : prev));
      }
    }
  }, []);

  useEffect(() => {
    const rafId = window.requestAnimationFrame(measureMatchesBox);
    window.addEventListener('resize', measureMatchesBox);
    let observer: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      observer = new ResizeObserver(() => {
        measureMatchesBox();
      });
      if (zoomViewportRef.current) observer.observe(zoomViewportRef.current);
      if (matchesContentRef.current) observer.observe(matchesContentRef.current);
    }
    return () => {
      window.cancelAnimationFrame(rafId);
      window.removeEventListener('resize', measureMatchesBox);
      observer?.disconnect();
    };
  }, [
    measureMatchesBox,
    zoom,
    concours.matches.length,
    lang,
    isEditing,
    isTimeDateBarVisible,
    topOverlayHeight,
  ]);

  const updateZoom = useCallback((next: number | ((prev: number) => number)) => {
    const resolved = typeof next === 'function' ? next(zoomRef.current) : next;
    const clamped = clampSlipZoom(resolved);
    zoomRef.current = clamped;
    setZoom(clamped);
    setZoomTextInput(String(Math.round(clamped * 100)));
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem(SLIP_ZOOM_STORAGE_KEY, String(clamped));
      }
    } catch {
      // ignore storage errors
    }
  }, []);

  const handleApplyNumericZoom = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    audioService.playClick();
    const cleaned = zoomTextInput.replace(/[^\d]/g, '');
    const parsed = Number(cleaned);
    if (cleaned.length > 0 && Number.isFinite(parsed) && parsed > 0) {
      const clampedPct = Math.min(160, Math.max(30, Math.round(parsed)));
      updateZoom(clampedPct / 100);
      setZoomTextInput(String(clampedPct));
    } else {
      setZoomTextInput(String(Math.round(zoom * 100)));
    }
    numericInputRef.current?.blur();
  };

  // Desktop Ctrl+Wheel / trackpad pinch zoom on the matches area
  useEffect(() => {
    const el = zoomViewportRef.current;
    if (!el) return;

    const handleWheel = (e: WheelEvent) => {
      if (!e.ctrlKey && !e.metaKey) return;
      e.preventDefault();
      const delta = -e.deltaY * 0.0025;
      if (Math.abs(delta) > 0.001) {
        updateZoom((prev) => prev + delta);
      }
    };

    el.addEventListener('wheel', handleWheel, { passive: false });
    return () => {
      el.removeEventListener('wheel', handleWheel);
    };
  }, [updateZoom]);

  // Reset horizontal scroll when zooming back to <= 100%
  useEffect(() => {
    if (zoom <= 1.001 && zoomViewportRef.current && zoomViewportRef.current.scrollLeft !== 0) {
      zoomViewportRef.current.scrollLeft = 0;
    }
  }, [zoom]);

  const handleToggleTimeDateBar = useCallback(
    (anchorEl?: HTMLElement | null, clickedIndex?: number) => {
      audioService.playClick();
      cancelActiveScrollAnchor();
      if (anchorEl && scrollContainerRef.current) {
        pendingScrollAnchorRef.current = {
          el: anchorEl,
          prevTop: anchorEl.getBoundingClientRect().top,
        };
      } else {
        pendingScrollAnchorRef.current = null;
      }
      setAnchorCardIndex(typeof clickedIndex === 'number' ? clickedIndex : null);
      setHasToggledTimeDateBar(true);
      setIsTimeDateBarVisible((prev) => {
        const next = !prev;
        try {
          if (typeof window !== 'undefined' && window.localStorage) {
            window.localStorage.setItem(SLIP_TIMEDATE_BAR_STORAGE_KEY, next ? '1' : '0');
          }
        } catch {
          // ignore storage errors
        }
        return next;
      });
    },
    [cancelActiveScrollAnchor]
  );

  // Keep clicked match pixel-locked in its exact screen position throughout gradual sequential toggle
  useLayoutEffect(() => {
    const pending = pendingScrollAnchorRef.current;
    pendingScrollAnchorRef.current = null;
    const container = scrollContainerRef.current;
    if (!pending || !container || !pending.el.isConnected) return;

    const syncAnchorFrame = () => {
      const c = scrollContainerRef.current;
      if (!c || !pending.el.isConnected) return;
      const currentZoom = zoomRef.current;
      if (Math.abs(currentZoom - 1) >= 0.01 && scaledWrapperRef.current && matchesContentRef.current) {
        const nextUnscaledH = matchesContentRef.current.offsetHeight;
        if (nextUnscaledH > 0) {
          scaledWrapperRef.current.style.height = `${Math.ceil(nextUnscaledH * currentZoom)}px`;
        }
      }

      const afterTop = pending.el.getBoundingClientRect().top;
      const deltaY = afterTop - pending.prevTop;
      if (Math.abs(deltaY) > 0.25) {
        c.scrollTop = Math.max(0, c.scrollTop + deltaY);
        lastScrollTopRef.current = c.scrollTop;
      }
    };

    syncAnchorFrame();
    const endTime = performance.now() + 1500;
    const tick = () => {
      syncAnchorFrame();
      if (performance.now() < endTime) {
        activeAnchorRafRef.current = window.requestAnimationFrame(tick);
      } else {
        activeAnchorRafRef.current = null;
        measureMatchesBox();
      }
    };
    activeAnchorRafRef.current = window.requestAnimationFrame(tick);
  }, [isTimeDateBarVisible, measureMatchesBox]);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!scrollContainerRef.current) return;
    if ((e.target as HTMLElement | null)?.closest('button, input, a, select, textarea')) return;
    isMouseDownRef.current = true;
    startYRef.current = e.pageY - scrollContainerRef.current.offsetTop;
    scrollTopRef.current = scrollContainerRef.current.scrollTop;
    if (zoomViewportRef.current) {
      startXRef.current = e.pageX - zoomViewportRef.current.offsetLeft;
      scrollLeftRef.current = zoomViewportRef.current.scrollLeft;
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isMouseDownRef.current || !scrollContainerRef.current) return;
    const y = e.pageY - scrollContainerRef.current.offsetTop;
    const deltaY = y - startYRef.current;
    const x = zoomViewportRef.current ? e.pageX - zoomViewportRef.current.offsetLeft : 0;
    const deltaX = zoomViewportRef.current ? x - startXRef.current : 0;
    if (Math.abs(deltaY) <= 4 && Math.abs(deltaX) <= 4) return;
    e.preventDefault();
    cancelActiveScrollAnchor();
    scrollContainerRef.current.scrollTop = scrollTopRef.current - deltaY * 1.3;
    lastScrollTopRef.current = scrollContainerRef.current.scrollTop;

    if (zoomRef.current > 1.001 && zoomViewportRef.current) {
      zoomViewportRef.current.scrollLeft = scrollLeftRef.current - deltaX * 1.2;
    }
  };

  const handleMouseUp = () => {
    isMouseDownRef.current = false;
  };

  const handleToggleRibbon = () => {
    audioService.playClick();
    setIsGrandPrizeOpen((prev) => !prev);
  };

  const handleToggleZoomBar = () => {
    audioService.playClick();
    setIsZoomBarOpen((prev) => !prev);
  };

  // Toggle selection when editing (strictly disabled in readOnly mode)
  const handleToggleSelection = (matchId: number, sign: '1' | 'X' | '2') => {
    if (isReadOnly || isKickoffStarted) return;
    audioService.playClick();
    setEditedSelections((prev) => {
      const current = prev[matchId] || [];
      let updated: ('1' | 'X' | '2')[];
      if (current.includes(sign)) {
        updated = current.filter((s) => s !== sign);
        if (updated.length === 0) {
          updated = [sign];
        }
      } else {
        updated = [...current, sign];
      }
      return { ...prev, [matchId]: updated };
    });
  };

  // Calculate stats on edited or saved selections
  const activeSelections = effectiveIsEditing ? editedSelections : slip.selections;

  let countDoubles = 0;
  let countTriples = 0;
  Object.values(activeSelections).forEach((sel) => {
    if (sel && sel.length > 0) {
      if (sel.length === 2) countDoubles++;
      if (sel.length === 3) countTriples++;
    }
  });

  const pricing = calculatePromosportPrice(countDoubles, countTriples, columnRate, baseFee);
  const slipStats = computeSlipSummaryStats(activeSelections, concours, slip.grilleNumber);

  // Save modified slip
  const handleSaveModifiedSlip = () => {
    if (isReadOnly || isKickoffStarted) return;
    audioService.playClick();
    const updatedSlip: UserBetSlip = {
      ...slip,
      selections: editedSelections,
      betType: countTriples > 0 ? 'triple' : countDoubles > 0 ? 'double' : 'single',
      totalCombinations: pricing.combinations,
      totalCostDt: pricing.priceTnd,
      updatedAt: `${formatUtcPlusOneClock()} +1`,
    };

    onUpdateSlip(updatedSlip);
    audioService.playChime();
    confetti({
      particleCount: 40,
      spread: 60,
      colors: ['#f1b816', '#38bdf8', '#10b981'],
    });

    setIsEditing(false);
    setSaveSuccessNotice(true);
    setTimeout(() => setSaveSuccessNotice(false), 2500);
  };

  const displaySlipName =
    lang === 'AR'
      ? slip.name.replace(/^Fiche N°\s*/i, 'قصاصة مسجلة رقم ')
      : slip.name.replace(/^قصاصة مسجلة رقم\s*/i, 'Fiche N° ');

  const isDefaultZoom = Math.abs(zoom - 1) < 0.01;
  const isZoomedIn = zoom > 1.001;
  const zoomPercent = Math.round(zoom * 100);
  const trackProgressPct = Math.min(100, Math.max(0, ((zoomPercent - 30) / (160 - 30)) * 100));
  const scaledHeight = unscaledHeight > 0 ? Math.ceil(unscaledHeight * zoom) : 0;
  const unscaledEdgeToEdgeWidth =
    !isDefaultZoom && viewportWidth > 0
      ? Math.floor((viewportWidth / zoom) * 100) / 100
      : viewportWidth > 0
      ? viewportWidth
      : 0;
  const isZoomCompact = isZoomedIn && unscaledEdgeToEdgeWidth > 0 && unscaledEdgeToEdgeWidth < 360;
  const baseTopPad = topOverlayHeight + 10;
  const compensatedTopPad = !isDefaultZoom ? Math.round(baseTopPad / zoom) : baseTopPad;
  const compensatedBottomPad = !isDefaultZoom ? Math.round(24 / zoom) : undefined;

  return (
    <div
      dir={lang === 'AR' ? 'rtl' : 'ltr'}
      className="relative flex flex-col h-full bg-[#030918] text-white animate-fade-in overflow-hidden select-none"
    >

      {/* 1. TOP HEADER NAVIGATION BAR */}
      <div className="relative shrink-0 px-2 sm:px-4 pt-[max(0.5rem,env(safe-area-inset-top))] pb-2 sm:py-2.5 bg-gradient-to-r from-[#040c1e] via-[#091a38] to-[#040c1e] border-b border-sky-400/50 shadow-lg z-50">
        <div className="flex flex-nowrap items-center justify-between gap-1.5 sm:gap-2.5 w-full">
          {/* Back button (القصاصات / سجل الرسائل) */}
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              onBackToSlips();
            }}
            className="flex-1 min-h-[44px] flex items-center justify-center gap-1 sm:gap-1.5 px-2 sm:px-4 py-2 rounded-xl bg-[#0e2246] hover:bg-[#15346a] border border-sky-400 text-cyan-300 hover:text-white font-black text-[12.5px] sm:text-[15px] transition-all active:scale-95 shadow-md cursor-pointer whitespace-nowrap"
          >
            <ArrowRight className={`w-[17px] h-[17px] sm:w-[19px] sm:h-[19px] text-cyan-300 shrink-0 ${lang === 'FR' ? 'rotate-180' : ''}`} />
            <span>{backLabel || (lang === 'AR' ? 'القصاصات' : 'Fiches')}</span>
          </button>

          {!isReadOnly ? (
            <>
              {/* القصاصة / Grille */}
              <button
                type="button"
                onClick={() => {
                  audioService.playClick();
                  onBackToGrille();
                }}
                className="flex-1 min-h-[44px] flex items-center justify-center gap-1 sm:gap-1.5 px-2 sm:px-4 py-2 rounded-xl bg-gradient-to-r from-sky-600/30 to-blue-700/40 hover:from-sky-500 hover:to-blue-600 border border-sky-400 text-sky-200 hover:text-white font-black text-[13px] sm:text-[15px] transition-all active:scale-95 shadow-md cursor-pointer whitespace-nowrap"
              >
                <LayoutGrid className="w-[17px] h-[17px] sm:w-[19px] sm:h-[19px] text-yellow-300 shrink-0" />
                <span>{lang === 'AR' ? 'القصاصة' : 'Grille'}</span>
              </button>

              {/* تعديل / حفظ */}
              {!isKickoffStarted && (!isEditing ? (
                <button
                  type="button"
                  onClick={() => {
                    audioService.playClick();
                    setIsEditing(true);
                  }}
                  className="flex-1 min-h-[44px] flex items-center justify-center gap-1 sm:gap-1.5 px-2 sm:px-4 py-2 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black font-black text-[13px] sm:text-[15px] transition-all shadow-[0_0_12px_rgba(241,184,22,0.65)] cursor-pointer active:scale-95 whitespace-nowrap"
                >
                  <Edit3 className="w-[17px] h-[17px] sm:w-[19px] sm:h-[19px] shrink-0" />
                  <span>{lang === 'AR' ? 'تعديل' : 'Modifier'}</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleSaveModifiedSlip}
                  className="flex-1 min-h-[44px] flex items-center justify-center gap-1 sm:gap-1.5 px-2 sm:px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 text-black font-black text-[13px] sm:text-[15px] transition-all shadow-[0_0_14px_rgba(16,185,129,0.85)] cursor-pointer active:scale-95 whitespace-nowrap"
                >
                  <Save className="w-[17px] h-[17px] sm:w-[19px] sm:h-[19px] shrink-0" />
                  <span>{lang === 'AR' ? 'حفظ' : 'Valider'}</span>
                </button>
              ))}
            </>
          ) : (
            <>
              {/* Read-Only Live Tracking Indicator */}
              <div className="min-h-[44px] px-2.5 sm:px-3 py-1.5 rounded-xl bg-amber-500/15 border border-amber-400/70 text-amber-200 font-black text-[11px] sm:text-xs flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0">
                <Radio className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                <span>{lang === 'AR' ? 'مباشر فقط' : 'Direct seul'}</span>
              </div>

              {/* Save to My Saved Slips (only for incoming slips) */}
              {messageMeta?.direction === 'incoming' && onSaveMessageToMySlips && (
                <button
                  type="button"
                  disabled={Boolean(messageMeta.alreadySavedToSlips)}
                  onClick={() => {
                    audioService.playClick();
                    onSaveMessageToMySlips();
                  }}
                  className={`flex-1 min-h-[44px] flex items-center justify-center gap-1 sm:gap-1.5 px-2 sm:px-3.5 py-2 rounded-xl font-black text-[12px] sm:text-[14px] transition-all whitespace-nowrap ${
                    messageMeta.alreadySavedToSlips
                      ? 'bg-emerald-950/80 border border-emerald-400/70 text-emerald-200 cursor-default'
                      : 'bg-gradient-to-r from-emerald-400 to-green-500 hover:brightness-105 border border-white text-black shadow-[0_0_14px_rgba(16,185,129,0.75)] cursor-pointer active:scale-95'
                  }`}
                >
                  <BookmarkPlus className="w-4 h-4 shrink-0" />
                  <span>
                    {messageMeta.alreadySavedToSlips
                      ? lang === 'AR' ? 'محفوظة في قصاصاتي' : 'Enregistrée'
                      : lang === 'AR' ? 'حفظ في قصاصاتي' : 'Enregistrer'}
                  </span>
                </button>
              )}
            </>
          )}

          {/* فسخ */}
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              onDeleteSlip(slip.id);
            }}
            className="flex-1 min-h-[44px] flex items-center justify-center gap-1 sm:gap-1.5 px-2 sm:px-4 py-2 rounded-xl bg-red-600/35 hover:bg-red-600 border border-red-400 text-red-100 hover:text-white font-black text-[13px] sm:text-[15px] transition-all active:scale-95 cursor-pointer shadow-md whitespace-nowrap"
            title={lang === 'AR' ? 'فسخ القصاصة' : 'Supprimer la fiche'}
          >
            <Trash2 className="w-[17px] h-[17px] sm:w-[19px] sm:h-[19px] shrink-0" />
            <span>{lang === 'AR' ? 'فسخ' : 'Suppr.'}</span>
          </button>
        </div>
      </div>

      {/* Save Success Notice */}
      {saveSuccessNotice && (
        <div className="shrink-0 p-2 bg-emerald-950/95 border-b border-emerald-400 text-emerald-300 text-xs font-bold text-center flex items-center justify-center gap-1.5 animate-fade-in z-30">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{lang === 'AR' ? 'تم حفظ تعديل القصاصة بنجاح!' : 'Fiche mise à jour avec succès !'}</span>
        </div>
      )}

      {/* 2. VIEWPORT WRAPPER: ALL MATCHES PASS UNDERNEATH THE SHADED-BLACK GLASS SAVED SLIP RIBBON + ZOOM BAR */}
      <div className="relative flex-1 overflow-hidden">
        {/* FLOATING TOP OVERLAY STACK: RIBBON / COLLAPSED PILLS + EDGE-TO-EDGE ZOOM BAR */}
        <div
          ref={topOverlayRef}
          onTouchMove={(e) => e.stopPropagation()}
          onWheel={(e) => e.stopPropagation()}
          className="absolute top-0 inset-x-0 z-40 pointer-events-none flex flex-col"
        >
          {/* COMPACT FLOATING REOPEN PILL + ALWAYS-VISIBLE ZOOM ICON WHEN RIBBON IS HIDDEN */}
          {!isGrandPrizeOpen && (
            <div className="pt-1.5 pb-1 flex flex-wrap items-center justify-center gap-1.5 px-2">
              <button
                type="button"
                aria-expanded={false}
                onClick={handleToggleRibbon}
                className="pointer-events-auto min-h-[38px] px-3.5 py-1.5 rounded-full backdrop-blur-lg bg-black/85 hover:bg-black/95 border-2 border-yellow-400/90 text-yellow-300 font-black text-xs shadow-[0_6px_22px_rgba(0,0,0,0.8)] flex items-center gap-1.5 cursor-pointer active:scale-95 transition-all whitespace-nowrap"
                title={lang === 'AR' ? 'النقر لإظهار شريط القصاصة المسجلة' : 'Afficher le bandeau de la fiche'}
              >
                <Trophy className="w-4 h-4 text-yellow-300 shrink-0" />
                <span>{lang === 'AR' ? 'إظهار الجائزة' : 'Afficher Cagnotte'}</span>
                <ChevronDown className="w-4 h-4 text-yellow-300 shrink-0" />
              </button>

              {/* Always-visible Zoom Icon */}
              <button
                type="button"
                data-no-flash="true"
                onClick={handleToggleZoomBar}
                aria-expanded={isZoomBarOpen}
                title={
                  isZoomBarOpen
                    ? lang === 'AR' ? 'إغلاق شريط الزوم' : 'Masquer la barre de zoom'
                    : lang === 'AR' ? 'فتح شريط الزوم (30% - 160%)' : 'Ouvrir le zoom (30% - 160%)'
                }
                className={`pointer-events-auto min-h-[38px] px-3 py-1.5 rounded-full backdrop-blur-lg border-2 font-black text-xs shadow-[0_6px_22px_rgba(0,0,0,0.8)] flex items-center gap-1.5 cursor-pointer active:scale-95 transition-all whitespace-nowrap ${
                  isZoomBarOpen
                    ? 'bg-gradient-to-r from-cyan-400 to-sky-500 text-black border-white shadow-[0_0_16px_rgba(34,211,238,0.85)]'
                    : 'bg-black/85 hover:bg-cyan-950/90 text-cyan-200 border-cyan-400/85'
                }`}
              >
                <ZoomIn className="w-4 h-4 shrink-0" />
                <span>{lang === 'AR' ? 'زوم' : 'Zoom'}</span>
                <span className="font-mono tabular-nums text-[11px]" dir="ltr">
                  {zoomPercent}%
                </span>
              </button>

              {onChangeLang && (
                <div className="pointer-events-auto">
                  <LanguageToggleButton lang={lang} onChangeLang={onChangeLang} compact />
                </div>
              )}
            </div>
          )}

          {/* FLOATING SHADED-BLACK GLASS SAVED SLIP RIBBON */}
          {isGrandPrizeOpen && (
            <div className="px-1.5 sm:px-3 pt-1.5 pb-1">
              <div className="pointer-events-auto relative rounded-2xl backdrop-blur-lg bg-gradient-to-b from-black/90 via-black/82 to-black/88 border-2 border-yellow-400/85 shadow-[0_14px_36px_rgba(0,0,0,0.88),inset_0_0_20px_rgba(255,255,255,0.08)] px-2.5 sm:px-4 py-2.5 space-y-2.5">
                {/* Top Metadata Line + Zoom Icon + Language Toggle + إخفاء الجائزة */}
                <div className="flex flex-wrap items-start justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2 min-w-0">
                    <MbLogo size="sm" showLaser={true} />
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="px-2 py-0.5 rounded-lg bg-yellow-400 text-black font-black text-xs shadow-sm">
                          {displaySlipName}
                        </span>
                        <span className="text-[11px] font-mono text-cyan-300 font-bold">
                          {lang === 'AR' ? `مسابقة #${slip.grilleNumber}` : `Concours #${slip.grilleNumber}`}
                        </span>
                      </div>
                      <div className="text-[10.5px] text-gray-200 flex flex-wrap items-center gap-1.5 mt-0.5 font-medium">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3 text-yellow-400 shrink-0" />
                          <span>{lang === 'AR' ? 'تاريخ التعمير:' : 'Créée le :'} {slip.createdAt}</span>
                        </span>
                        <span className="font-mono text-[10px] px-1.5 py-0.5 rounded-md bg-amber-500/15 border border-amber-400/50 inline-flex items-center gap-1 tabular-nums text-amber-200" dir="ltr">
                          <Clock className="w-3 h-3 text-amber-300" />
                          <span>{timePlusOne} +1</span>
                        </span>
                        <span className="text-[10px] text-yellow-200/90 font-mono" dir="ltr">
                          ({formatConcoursPlusOneLabel(concours.closingTimeStr || concours.fullDateFormatted)})
                        </span>
                      </div>
                      {messageMeta && (
                        <div className="mt-1 pt-1 border-t border-white/15 flex flex-wrap items-center gap-x-2.5 gap-y-0.5 text-[11px] font-black">
                          <span className="inline-flex items-center gap-1 text-yellow-300">
                            <UserCheck className="w-3.5 h-3.5 text-sky-300 shrink-0" />
                            <span>
                              {lang === 'AR'
                                ? `المرسل: ${messageMeta.senderFullName}`
                                : `Expéditeur : ${messageMeta.senderFullName}`}
                            </span>
                          </span>
                          <span className="text-white/40" aria-hidden="true">·</span>
                          <span className="inline-flex items-center gap-1 text-cyan-200">
                            <Send className="w-3 h-3 shrink-0" />
                            <span>
                              {lang === 'AR'
                                ? `المستورد / المستلم: ${messageMeta.recipientFullName}`
                                : `Destinataire : ${messageMeta.recipientFullName}`}
                            </span>
                          </span>
                          <span className="text-white/40" aria-hidden="true">·</span>
                          <span className="text-emerald-200 font-mono" dir="ltr">
                            {messageMeta.sentAtDisplay}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Always-visible Zoom Icon + Language Switch + Hide Ribbon Button */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      data-no-flash="true"
                      onClick={handleToggleZoomBar}
                      aria-expanded={isZoomBarOpen}
                      title={
                        isZoomBarOpen
                          ? lang === 'AR' ? 'إغلاق شريط الزوم' : 'Masquer le zoom'
                          : lang === 'AR' ? 'فتح شريط الزوم (30% - 160%)' : 'Ouvrir le zoom (30% - 160%)'
                      }
                      className={`min-h-[38px] px-2.5 py-1.5 rounded-xl border font-black text-[11px] flex items-center gap-1 transition-all cursor-pointer active:scale-95 whitespace-nowrap ${
                        isZoomBarOpen
                          ? 'bg-gradient-to-r from-cyan-300 to-sky-400 text-black border-white shadow-[0_0_14px_rgba(34,211,238,0.85)]'
                          : 'bg-black/70 hover:bg-cyan-950/90 text-cyan-200 border-cyan-400/80'
                      }`}
                    >
                      <ZoomIn className="w-3.5 h-3.5 shrink-0" />
                      <span>{lang === 'AR' ? 'زوم' : 'Zoom'}</span>
                      <span className="font-mono tabular-nums text-[10.5px]" dir="ltr">
                        {zoomPercent}%
                      </span>
                    </button>

                    {onChangeLang && (
                      <LanguageToggleButton lang={lang} onChangeLang={onChangeLang} compact />
                    )}

                    <button
                      type="button"
                      aria-expanded={true}
                      onClick={handleToggleRibbon}
                      className="shrink-0 min-h-[38px] flex items-center gap-1 px-2.5 sm:px-3 py-1.5 rounded-xl bg-black/70 hover:bg-black/90 border border-yellow-400/85 text-yellow-300 font-black text-[11px] sm:text-xs shadow-[0_0_12px_rgba(241,184,22,0.35)] cursor-pointer active:scale-95 transition-all whitespace-nowrap"
                      title={lang === 'AR' ? 'النقر لإخفاء شريط القصاصة المسجلة' : 'Masquer le bandeau'}
                    >
                      <Trophy className="w-3.5 h-3.5 text-yellow-300 shrink-0" />
                      <span>{lang === 'AR' ? 'إخفاء الجائزة' : 'Masquer'}</span>
                      <ChevronUp className="w-3.5 h-3.5 shrink-0" />
                    </button>
                  </div>
                </div>

                {/* CENTERED UNIFIED +20% ENLARGED CARD: الجائزة الكبرى + ثمن القصاصة متجاوران في أيقونة واحدة في الوسط */}
                <div className="flex justify-center w-full">
                  <div className="inline-flex items-center justify-center gap-3 sm:gap-5 px-3.5 sm:px-6 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500/30 via-yellow-400/20 to-emerald-500/30 border-2 border-yellow-300/90 shadow-[0_0_22px_rgba(241,184,22,0.45),inset_0_1px_0_rgba(255,255,255,0.2)] max-w-full">
                    {/* الجائزة الكبرى (+20%) */}
                    <div className={`flex items-center gap-2 sm:gap-2.5 min-w-0 ${lang === 'AR' ? 'text-right' : 'text-left'}`}>
                      <Trophy className="w-6 h-6 text-yellow-300 shrink-0 drop-shadow-[0_0_8px_rgba(250,204,21,0.75)]" />
                      <div className="min-w-0">
                        <span className="text-[10.5px] sm:text-xs font-black text-yellow-200 block leading-tight uppercase whitespace-nowrap">
                          {lang === 'AR' ? 'الجائزة الكبرى' : 'CAGNOTTE'}
                        </span>
                        <span className="font-mono text-sm sm:text-lg font-black text-white tracking-wider tabular-nums drop-shadow-[0_0_8px_#f1b816] whitespace-nowrap" dir="ltr">
                          {concours.cagnotteEstimate}
                        </span>
                      </div>
                    </div>

                    <div className="h-9 w-px bg-yellow-300/50 shrink-0" />

                    {/* ثمن القصاصة (+20%) */}
                    <div className={`flex items-center gap-2 sm:gap-2.5 min-w-0 ${lang === 'AR' ? 'text-right' : 'text-left'}`}>
                      <Receipt className="w-6 h-6 text-emerald-300 shrink-0 drop-shadow-[0_0_8px_rgba(16,185,129,0.65)]" />
                      <div className="min-w-0">
                        <span className="text-[10.5px] sm:text-xs font-black text-emerald-200 block leading-tight whitespace-nowrap">
                          {lang === 'AR' ? 'ثمن القصاصة' : 'PRIX FICHE'}
                        </span>
                        <span className="font-mono text-sm sm:text-lg font-black text-emerald-300 tabular-nums whitespace-nowrap" dir="ltr">
                          {pricing.priceTnd.toFixed(3)} DT
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* FULL-WIDTH CENTERED ROWS: الثنائيات والثلاثيات والفردي + الأخطاء والصحيحة بعرض الصفحة */}
                <SlipSummaryBadges stats={slipStats} lang={lang} fullWidth />
              </div>
            </div>
          )}

          {/* COMPACT EDGE-TO-EDGE FROSTED ZOOM BAR (30% - 160%, مفعّل دوماً) */}
          {isZoomBarOpen && (
            <div
              data-no-flash="true"
              className="pointer-events-auto w-full px-1.5 sm:px-3 pt-0.5 pb-1"
            >
              <form
                onSubmit={handleApplyNumericZoom}
                dir="ltr"
                className="w-full flex items-center gap-1 py-1 px-1 rounded-2xl backdrop-blur-md bg-[#040c1f]/82 border border-cyan-400/75 shadow-[0_6px_22px_rgba(0,0,0,0.55)]"
              >
                <button
                  type="button"
                  data-no-flash="true"
                  disabled={zoom <= MIN_SLIP_ZOOM}
                  onClick={() => {
                    audioService.playClick();
                    updateZoom((prev) => prev - SLIP_ZOOM_STEP);
                  }}
                  title={lang === 'AR' ? 'تصغير القصاصة حتى 30%' : 'Dézoomer (30%)'}
                  aria-label="تصغير القصاصة المسجلة"
                  className="min-w-[36px] h-[34px] px-1.5 bg-[#07152f]/80 hover:bg-[#0b224a] border border-sky-400/75 text-sky-100 hover:text-white flex items-center justify-center active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shrink-0 rounded-xl"
                >
                  <ZoomOut className="w-4 h-4" />
                </button>

                <div className="relative flex-1 min-w-[28px] h-[34px] flex items-center px-1.5 pointer-events-none select-none">
                  <div className="relative w-full h-2 rounded-full bg-black/60 border border-sky-400/50 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-cyan-400 via-yellow-400 to-amber-500 transition-all duration-150"
                      style={{ width: `${trackProgressPct}%` }}
                    />
                  </div>
                  <div
                    className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-3.5 h-3.5 rounded-full bg-gradient-to-b from-yellow-300 to-amber-500 border-2 border-white shadow-[0_0_8px_rgba(250,204,21,0.85)] transition-all duration-150"
                    style={{ left: `calc(${trackProgressPct}% * 0.88 + 6%)` }}
                  />
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <div className="relative flex items-center">
                    <input
                      ref={numericInputRef}
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      maxLength={3}
                      value={zoomTextInput}
                      onChange={(e) => setZoomTextInput(e.target.value.replace(/[^\d]/g, '').slice(0, 3))}
                      onMouseDown={(e) => e.stopPropagation()}
                      onClick={(e) => e.stopPropagation()}
                      aria-label="نسبة الزوم بالأرقام من 30 إلى 160"
                      placeholder="30-160"
                      style={{ userSelect: 'text', WebkitUserSelect: 'text' }}
                      className="w-[52px] h-[32px] pr-4 pl-1 rounded-lg bg-black/70 border border-sky-400/80 focus:border-yellow-400 text-center font-mono tabular-nums text-xs font-black text-yellow-300 outline-none select-text"
                    />
                    <span className="absolute right-1 text-[10px] font-black text-gray-300 pointer-events-none">
                      %
                    </span>
                  </div>

                  <button
                    type="submit"
                    data-no-flash="true"
                    className="min-h-[32px] px-2.5 rounded-lg bg-gradient-to-r from-yellow-400 to-amber-500 hover:brightness-105 text-black font-black text-[11px] shadow active:scale-95 transition-all cursor-pointer whitespace-nowrap"
                  >
                    {lang === 'AR' ? 'تنفيذ' : 'OK'}
                  </button>

                  {!isDefaultZoom && (
                    <button
                      type="button"
                      data-no-flash="true"
                      onClick={() => {
                        audioService.playClick();
                        updateZoom(1);
                      }}
                      title={lang === 'AR' ? 'إعادة الضبط 100%' : 'Reset 100%'}
                      aria-label="إعادة الضبط 100%"
                      className="min-w-[28px] h-[32px] rounded-lg bg-black/65 hover:bg-amber-500/35 border border-yellow-400/70 text-yellow-300 flex items-center justify-center active:scale-95 transition-all cursor-pointer shrink-0"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>
                  )}

                  <button
                    type="button"
                    data-no-flash="true"
                    onClick={handleToggleZoomBar}
                    title={lang === 'AR' ? 'إغلاق شريط الزوم' : 'Masquer'}
                    aria-label="إغلاق شريط الزوم"
                    className="min-w-[28px] h-[32px] rounded-lg bg-black/55 hover:bg-white/15 border border-white/30 text-white flex items-center justify-center active:scale-95 transition-all cursor-pointer shrink-0"
                  >
                    <ChevronUp className="w-3.5 h-3.5" />
                  </button>
                </div>

                <button
                  type="button"
                  data-no-flash="true"
                  disabled={zoom >= MAX_SLIP_ZOOM}
                  onClick={() => {
                    audioService.playClick();
                    updateZoom((prev) => prev + SLIP_ZOOM_STEP);
                  }}
                  title={lang === 'AR' ? 'تكبير القصاصة' : 'Zoomer'}
                  aria-label="تكبير القصاصة المسجلة"
                  className="min-w-[36px] h-[34px] px-1.5 bg-[#07152f]/80 hover:bg-[#0b224a] border border-sky-400/75 text-sky-100 hover:text-white flex items-center justify-center active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shrink-0 rounded-xl"
                >
                  <ZoomIn className="w-4 h-4" />
                </button>
              </form>
            </div>
          )}
        </div>

        {/* SCROLLABLE 13-MATCH CONTAINER (تمر جميع هياكل وأسماء ونتائج المباريات تحت الشريط وتدعم الزوم وتبديل شريط التوقيت والتاريخ) */}
        <div
          ref={scrollContainerRef}
          onWheel={(e) => {
            if (!e.ctrlKey && !e.metaKey) {
              cancelActiveScrollAnchor();
            }
          }}
          onTouchStart={() => {
            cancelActiveScrollAnchor();
          }}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          className="relative z-0 isolate h-full overflow-y-auto overflow-x-hidden overscroll-contain cursor-grab active:cursor-grabbing [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]"
          style={{
            WebkitOverflowScrolling: 'touch',
          }}
        >
          <div
            ref={zoomViewportRef}
            dir="ltr"
            className="w-full overflow-x-hidden [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]"
            style={{
              touchAction: 'pan-y',
              WebkitOverflowScrolling: 'touch',
            }}
          >
            <div
              ref={scaledWrapperRef}
              style={{
                position: 'relative',
                width: '100%',
                height: !isDefaultZoom && scaledHeight > 0 ? `${scaledHeight}px` : 'auto',
              }}
            >
              <div
                ref={matchesContentRef}
                className="px-1 sm:px-2 pb-6 space-y-4"
                style={
                  isDefaultZoom
                    ? {
                        position: 'relative',
                        width: '100%',
                        paddingTop: `${baseTopPad}px`,
                      }
                    : {
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        width: unscaledEdgeToEdgeWidth > 0 ? `${unscaledEdgeToEdgeWidth}px` : '100%',
                        paddingTop: `${compensatedTopPad}px`,
                        paddingBottom: compensatedBottomPad ? `${compensatedBottomPad}px` : undefined,
                        transform: `scale(${zoom})`,
                        transformOrigin: 'top left',
                        willChange: 'transform',
                      }
                }
              >
                {concours.matches.map((match, matchIdx) => {
                  const userChoices = activeSelections[match.id] || [];
                  const justScoredGoal = Boolean(goalFlashMatchIds[match.id]);
                  const timeDateDelayMs =
                    anchorCardIndex !== null
                      ? Math.min(Math.abs(matchIdx - anchorCardIndex), 12) * 75
                      : Math.min(matchIdx, 12) * 75;

                  return (
                    <div
                      id={`slip-match-${match.id}`}
                      key={match.id}
                      className="relative w-full"
                      dir="ltr"
                    >
                      <PinterestScoreboardCard
                        match={match}
                        lang={lang}
                        mode="slip"
                        isBettingLocked={isReadOnly || isKickoffStarted}
                        slipChoices={userChoices}
                        isEditingSlip={effectiveIsEditing}
                        onToggleSelection={handleToggleSelection}
                        getTeamName={getTeamName}
                        justScoredGoal={justScoredGoal}
                        isZoomCompact={isZoomCompact}
                        showTimeDateBar={isTimeDateBarVisible}
                        onToggleTimeDateBar={handleToggleTimeDateBar}
                        cardIndex={matchIdx}
                        timeDateTransitionDelayMs={timeDateDelayMs}
                        animateTimeDateBar={hasToggledTimeDateBar}
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
