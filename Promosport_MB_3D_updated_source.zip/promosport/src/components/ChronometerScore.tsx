/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

interface ChronometerScoreProps {
  value: string; // e.g. "2-1", "0-0", "- -"
  size?: 'xs' | 'md' | 'lg';
  isGoalFlash?: boolean;
  isLive?: boolean;
}

type SegmentKey = 'a' | 'b' | 'c' | 'd' | 'e' | 'f' | 'g';

const SEGMENT_MAP: Record<string, SegmentKey[]> = {
  '0': ['a', 'b', 'c', 'd', 'e', 'f'],
  '1': ['b', 'c'],
  '2': ['a', 'b', 'g', 'e', 'd'],
  '3': ['a', 'b', 'g', 'c', 'd'],
  '4': ['f', 'g', 'b', 'c'],
  '5': ['a', 'f', 'g', 'c', 'd'],
  '6': ['a', 'f', 'g', 'e', 'c', 'd'],
  '7': ['a', 'b', 'c'],
  '8': ['a', 'b', 'c', 'd', 'e', 'f', 'g'],
  '9': ['a', 'b', 'c', 'd', 'f', 'g'],
  '-': ['g'],
};

const SEGMENT_POLYGONS: Record<SegmentKey, string> = {
  a: '5,2 19,2 16.5,5.5 7.5,5.5',
  b: '20,3 22,5.5 21,17.5 18.5,18.5 17,16.5 17.8,6',
  c: '18.5,19.5 21,20.5 20,32.5 17.8,35 16.2,32 17,21.5',
  d: '7.5,32.5 16.5,32.5 19,36 5,36',
  e: '3,20.5 5.5,19.5 6.8,21.5 6,32 3.8,35 2,32.5',
  f: '4,5.5 6.5,3 7.8,6 7,16.5 5.5,18.5 3,17.5',
  g: '6.2,19 8.2,17 15.8,17 17.8,19 15.8,21 8.2,21',
};

const ALL_SEGMENTS: SegmentKey[] = ['a', 'b', 'c', 'd', 'e', 'f', 'g'];

const ChronometerDigit: React.FC<{
  char: string;
  activeColor: string;
  glowColor: string;
  className: string;
}> = ({ char, activeColor, glowColor, className }) => {
  const activeSegments = SEGMENT_MAP[char] ?? [];

  if (char === ':') {
    return (
      <svg viewBox="0 0 10 38" className={`${className} w-[7px] sm:w-[9px] shrink-0`} aria-hidden="true">
        <circle cx="5" cy="12" r="2.2" fill={activeColor} />
        <circle cx="5" cy="26" r="2.2" fill={activeColor} />
      </svg>
    );
  }

  return (
    <svg
      viewBox="0 0 24 38"
      className={`${className} shrink-0 overflow-visible`}
      style={{ filter: `drop-shadow(0 0 4px ${glowColor})` }}
      aria-hidden="true"
    >
      {ALL_SEGMENTS.map((seg) => {
        const isOn = activeSegments.includes(seg);
        return (
          <polygon
            key={seg}
            points={SEGMENT_POLYGONS[seg]}
            fill={isOn ? activeColor : 'rgba(255,255,255,0.09)'}
          />
        );
      })}
    </svg>
  );
};

export const ChronometerScore: React.FC<ChronometerScoreProps> = ({
  value,
  size = 'lg',
  isGoalFlash = false,
  isLive = false,
}) => {
  const tokens = value.replace(/\s+/g, '').split('');

  const activeColor = isGoalFlash
    ? '#fde047'
    : isLive
    ? '#6ee7b7'
    : '#ffffff';

  const glowColor = isGoalFlash
    ? 'rgba(250, 204, 21, 0.95)'
    : isLive
    ? 'rgba(52, 211, 153, 0.78)'
    : 'rgba(255, 255, 255, 0.45)';

  // +20% enlarged digital chronometer dimensions compared to previous text-2xl (24px -> 29px) & text-[28px] (28px -> 34px)
  // For slip ('md'): text-xl/text-2xl (20px/24px -> 25px/29px); for live 50% compact ('xs'): 15px/18px
  const digitSizeClass =
    size === 'xs'
      ? 'h-[15px] w-[9px] sm:h-[18px] sm:w-[11px]'
      : size === 'md'
      ? 'h-[25px] w-[15px] sm:h-[29px] sm:w-[18px]'
      : 'h-[29px] w-[18px] sm:h-[34px] sm:w-[21px]';

  return (
    <div
      className={`inline-flex items-center justify-center ${
        size === 'xs' ? 'gap-[1px]' : 'gap-[2px] sm:gap-[3px]'
      } -skew-x-[7deg] transition-transform ${
        isGoalFlash ? 'scale-110' : ''
      }`}
      aria-label={value}
      dir="ltr"
    >
      {tokens.map((ch, idx) =>
        ch === '-' ? (
          <svg
            key={`${idx}-${ch}`}
            viewBox="0 0 14 38"
            className={`${
              size === 'xs'
                ? 'h-[15px] w-[5px] sm:h-[18px] sm:w-[6px]'
                : size === 'md'
                ? 'h-[25px] w-[9px] sm:h-[29px] sm:w-[11px]'
                : 'h-[29px] w-[10px] sm:h-[34px] sm:w-[12px]'
            } shrink-0 overflow-visible`}
            style={{ filter: `drop-shadow(0 0 3px ${glowColor})` }}
            aria-hidden="true"
          >
            <polygon points="2,19 4,17 10,17 12,19 10,21 4,21" fill={activeColor} />
          </svg>
        ) : (
          <ChronometerDigit
            key={`${idx}-${ch}`}
            char={ch}
            activeColor={activeColor}
            glowColor={glowColor}
            className={digitSizeClass}
          />
        )
      )}
    </div>
  );
};
