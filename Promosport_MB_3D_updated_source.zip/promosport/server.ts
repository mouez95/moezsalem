/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import 'dotenv/config';
import express from 'express';
import { createServer as createHttpServer } from 'node:http';
import path from 'node:path';
import fs from 'node:fs/promises';
import { existsSync } from 'node:fs';
import os from 'node:os';
import { randomInt } from 'node:crypto';
import { exec } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';
import * as webpush from 'web-push';
import JSZip from 'jszip';
import {
  INITIAL_GRILLES,
  INITIAL_WEEKLY_CONCOURS,
  archiveConcoursToGrille,
  mergeGrilleArchives,
} from './src/services/promosportData.ts';
import { evaluateConcoursRealTime, isConcoursCompletelyFinished } from './src/services/matchLiveService.ts';
import { enrichConcoursWithDirectLiveFeeds, mergeConcoursPreservingScores } from './src/services/liveFootballFeed.ts';
import {
  fetchPromosportPronosticFullScan,
  scanPromosportLiveCatalogHtml,
  fetchRapidLiveMap,
  applyRapidToLiveMatches,
  PROMOSPORT_PRONOSTIC_HOME_URL,
} from './src/services/promosportSiteParser.ts';
import {
  normalizeConcoursTranslations,
  normalizeGrilleTranslations,
  translateCompetitionToArabic,
  translateTeamToArabic,
} from './src/services/teamTranslationService.ts';
import type {
  PromosportGrille,
  WeeklyConcours,
  SiteLiveMatch,
  SiteLiveScanPayload,
  ParticipantProfile,
  SlipMessageRecord,
  UserBetSlip,
} from './src/types/promosport.ts';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3000;

interface ServerSyncCache {
  activeConcours: WeeklyConcours;
  grilles: PromosportGrille[];
  syncedAt: string;
  lastAttemptMs: number;
  lastRemoteSuccessMs: number;
}

const syncCache: ServerSyncCache = {
  activeConcours: INITIAL_WEEKLY_CONCOURS,
  grilles: [...INITIAL_GRILLES],
  syncedAt: new Date().toISOString(),
  lastAttemptMs: 0,
  lastRemoteSuccessMs: 0,
};

const TIRAGE_ARCHIVE_STORE_PATH = path.join(os.tmpdir(), 'promosport-tirage-archive.json');
let inFlightProbePromise: Promise<void> | null = null;

async function initSyncArchiveStore(): Promise<void> {
  try {
    if (!existsSync(TIRAGE_ARCHIVE_STORE_PATH)) return;
    const raw = await fs.readFile(TIRAGE_ARCHIVE_STORE_PATH, 'utf-8');
    const parsed = JSON.parse(raw) as { activeConcours?: WeeklyConcours; grilles?: PromosportGrille[] };
    if (
      parsed.activeConcours &&
      typeof parsed.activeConcours.number === 'number' &&
      parsed.activeConcours.number >= INITIAL_WEEKLY_CONCOURS.number &&
      Array.isArray(parsed.activeConcours.matches) &&
      parsed.activeConcours.matches.length > 0
    ) {
      syncCache.activeConcours = normalizeConcoursTranslations(parsed.activeConcours);
    }
    if (Array.isArray(parsed.grilles) && parsed.grilles.length > 0) {
      syncCache.grilles = mergeGrilleArchives(INITIAL_GRILLES, parsed.grilles).map(
        normalizeGrilleTranslations
      );
    }
  } catch {
    // ignore cache read errors
  }
}

async function persistSyncArchiveStore(): Promise<void> {
  try {
    await fs.writeFile(
      TIRAGE_ARCHIVE_STORE_PATH,
      JSON.stringify({
        activeConcours: syncCache.activeConcours,
        grilles: syncCache.grilles.slice(0, 15),
        updatedAt: syncCache.syncedAt,
      }),
      'utf-8'
    );
  } catch {
    // ignore disk cache write errors
  }
}

// ============================================================================
// PARTICIPANT UNIQUE REGISTRATION REGISTRY (Durable Workspace JSON + Verify)
// ============================================================================
const PARTICIPANTS_STORE_PATH = path.resolve(__dirname, 'PARTICIPANTS_REGISTRY.json');
const LEGACY_PARTICIPANTS_STORE_PATH = path.join(os.tmpdir(), 'promosport-participants-registry.json');
const participantsByDevice = new Map<string, ParticipantProfile>();
const deviceAliasToParticipantId = new Map<string, string>();
const usedParticipantFullNames = new Set<string>();
const participantsByNormalizedFull = new Map<string, ParticipantProfile>();
const participantsByCompactFull = new Map<string, ParticipantProfile>();

function normalizeArabicDigits(value: string): string {
  return String(value || '')
    .replace(/[\u0660-\u0669]/g, (ch) => String(ch.charCodeAt(0) - 0x0660))
    .replace(/[\u06F0-\u06F9]/g, (ch) => String(ch.charCodeAt(0) - 0x06f0));
}

function normalizeParticipantKey(name: string): string {
  return normalizeArabicDigits(name)
    .trim()
    .replace(/\s+/g, ' ')
    .toLocaleLowerCase('ar');
}

function compactParticipantKey(name: string): string {
  return normalizeParticipantKey(name).replace(/\s+/g, '');
}

function cleanParticipantBaseName(raw: string): string {
  return normalizeArabicDigits(raw)
    .replace(/[\r\n\t]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 40);
}

function indexRegisteredParticipant(p: ParticipantProfile): void {
  participantsByDevice.set(p.id, p);
  const normKey = normalizeParticipantKey(p.fullName);
  const compactKey = compactParticipantKey(p.fullName);
  usedParticipantFullNames.add(normKey);
  participantsByNormalizedFull.set(normKey, p);
  if (!participantsByCompactFull.has(compactKey)) {
    participantsByCompactFull.set(compactKey, p);
  }
}

async function initParticipantsStore(): Promise<void> {
  const loadFromFile = async (filePath: string): Promise<boolean> => {
    try {
      if (!existsSync(filePath)) return false;
      const raw = await fs.readFile(filePath, 'utf-8');
      const parsed = JSON.parse(raw) as {
        participants?: ParticipantProfile[];
        deviceAliases?: Record<string, string>;
      };
      if (Array.isArray(parsed.participants)) {
        for (const p of parsed.participants) {
          if (
            p &&
            typeof p.id === 'string' &&
            p.id.trim() &&
            typeof p.baseName === 'string' &&
            typeof p.suffixDigits === 'string' &&
            /^\d{2}$/.test(p.suffixDigits) &&
            typeof p.fullName === 'string' &&
            p.fullName.trim()
          ) {
            indexRegisteredParticipant(p);
          }
        }
      }
      if (parsed.deviceAliases && typeof parsed.deviceAliases === 'object') {
        for (const [aliasId, ownerId] of Object.entries(parsed.deviceAliases)) {
          if (aliasId && ownerId && participantsByDevice.has(ownerId)) {
            deviceAliasToParticipantId.set(aliasId, ownerId);
          }
        }
      }
      return true;
    } catch {
      return false;
    }
  };

  const loadedMain = await loadFromFile(PARTICIPANTS_STORE_PATH);
  const loadedLegacy = await loadFromFile(LEGACY_PARTICIPANTS_STORE_PATH);
  if (!loadedMain && loadedLegacy && participantsByDevice.size > 0) {
    await persistParticipantsStore();
  }
}

async function persistParticipantsStore(): Promise<void> {
  try {
    const tmpPath = `${PARTICIPANTS_STORE_PATH}.tmp`;
    await fs.writeFile(
      tmpPath,
      JSON.stringify(
        {
          participants: Array.from(participantsByDevice.values()),
          deviceAliases: Object.fromEntries(deviceAliasToParticipantId.entries()),
          updatedAt: new Date().toISOString(),
        },
        null,
        2
      ),
      'utf-8'
    );
    await fs.rename(tmpPath, PARTICIPANTS_STORE_PATH);
  } catch {
    // ignore registry write errors
  }
}

function findRegisteredParticipantByInput(rawInput: string): ParticipantProfile | null {
  const cleaned = normalizeArabicDigits(rawInput)
    .replace(/[\r\n\t]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!cleaned) return null;
  // Require trailing 2 digits to match "name + 2 digits"
  if (!/\d{2}$/.test(cleaned)) return null;

  const normKey = normalizeParticipantKey(cleaned);
  const exactMatch = participantsByNormalizedFull.get(normKey);
  if (exactMatch) return exactMatch;

  const compactKey = compactParticipantKey(cleaned);
  return participantsByCompactFull.get(compactKey) || null;
}

// ============================================================================
// SLIP MESSAGES REGISTRY & REAL-TIME SSE STREAM (سجل الرسائل المرسلة والمستوردة)
// ============================================================================
const MESSAGES_STORE_PATH = path.resolve(__dirname, 'SLIPS_MESSAGES_REGISTRY.json');
const slipMessagesStore: SlipMessageRecord[] = [];
const messageStreamClients = new Map<string, Set<express.Response>>();

function formatTunisiaDateTimeDisplay(ms = Date.now()): string {
  const d = new Date(ms + 60 * 60 * 1000);
  const dd = String(d.getUTCDate()).padStart(2, '0');
  const mm = String(d.getUTCMonth() + 1).padStart(2, '0');
  const yyyy = d.getUTCFullYear();
  const hh = String(d.getUTCHours()).padStart(2, '0');
  const min = String(d.getUTCMinutes()).padStart(2, '0');
  const ss = String(d.getUTCSeconds()).padStart(2, '0');
  return `${dd}/${mm}/${yyyy} • ${hh}:${min}:${ss} +1`;
}

function resolveCanonicalParticipant(
  participantOrDeviceId?: string,
  fullNameHint?: string
): ParticipantProfile | null {
  const rawId = String(participantOrDeviceId || '').trim();
  if (rawId) {
    const direct = participantsByDevice.get(rawId);
    if (direct) return direct;
    const aliasedOwnerId = deviceAliasToParticipantId.get(rawId);
    if (aliasedOwnerId) {
      const aliased = participantsByDevice.get(aliasedOwnerId);
      if (aliased) return aliased;
    }
  }
  if (fullNameHint) {
    const matched = findRegisteredParticipantByInput(fullNameHint);
    if (matched) return matched;
  }
  return null;
}

async function initMessagesStore(): Promise<void> {
  try {
    if (!existsSync(MESSAGES_STORE_PATH)) return;
    const raw = await fs.readFile(MESSAGES_STORE_PATH, 'utf-8');
    const parsed = JSON.parse(raw) as { messages?: SlipMessageRecord[] };
    if (Array.isArray(parsed.messages)) {
      slipMessagesStore.splice(0, slipMessagesStore.length);
      for (const msg of parsed.messages) {
        if (
          msg &&
          typeof msg.id === 'string' &&
          typeof msg.senderId === 'string' &&
          typeof msg.recipientId === 'string' &&
          msg.slip &&
          typeof msg.slip === 'object'
        ) {
          slipMessagesStore.push(msg);
        }
      }
    }
  } catch {
    // ignore corrupt messages store
  }
}

async function persistMessagesStore(): Promise<void> {
  try {
    const tmpPath = `${MESSAGES_STORE_PATH}.tmp`;
    await fs.writeFile(
      tmpPath,
      JSON.stringify(
        {
          messages: slipMessagesStore.slice(0, 500),
          updatedAt: new Date().toISOString(),
        },
        null,
        2
      ),
      'utf-8'
    );
    await fs.rename(tmpPath, MESSAGES_STORE_PATH);
  } catch {
    // ignore message store write errors
  }
}

function pushMessageSseEvent(
  canonicalParticipantId: string,
  eventName: 'new-message' | 'message-updated',
  payload: unknown
): void {
  const clients = messageStreamClients.get(canonicalParticipantId);
  if (!clients || clients.size === 0) return;
  const serialized = `event: ${eventName}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const res of Array.from(clients)) {
    try {
      res.write(serialized);
    } catch {
      clients.delete(res);
    }
  }
}

function shuffleArray<T>(arr: T[]): T[] {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = randomInt(0, i + 1);
    const tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
  }
  return arr;
}

function pickUniqueTwoDigitSuffix(baseName: string, preferredDigits?: string): string | null {
  const twoDigitPrimary = shuffleArray(Array.from({ length: 90 }, (_, idx) => String(10 + idx)));
  const twoDigitSecondary = shuffleArray(Array.from({ length: 10 }, (_, idx) => `0${idx}`));
  const candidates = [...twoDigitPrimary, ...twoDigitSecondary];

  if (preferredDigits && /^\d{2}$/.test(preferredDigits)) {
    const ordered = [preferredDigits, ...candidates.filter((d) => d !== preferredDigits)];
    for (const suffix of ordered) {
      const candidateFull = `${baseName} ${suffix}`;
      if (!usedParticipantFullNames.has(normalizeParticipantKey(candidateFull))) {
        return suffix;
      }
    }
    return null;
  }

  for (const suffix of candidates) {
    const candidateFull = `${baseName} ${suffix}`;
    if (!usedParticipantFullNames.has(normalizeParticipantKey(candidateFull))) {
      return suffix;
    }
  }
  return null;
}

// ============================================================================
// SERVER WEB PUSH (VAPID) ENGINE — Delivers desktop notifications when closed
// ============================================================================
interface PushStoreFile {
  publicKey: string;
  privateKey: string;
  subscriptions: webpush.PushSubscription[];
}

const PUSH_STORE_PATH = path.join(os.tmpdir(), 'promosport-tunisie-push-store.json');
let pushKeys: { publicKey: string; privateKey: string } | null = null;
let vapidConfigured = false;
const pushSubscriptions = new Map<string, webpush.PushSubscription>();

function normalizeVapidKey(raw?: string): string {
  return String(raw || '')
    .trim()
    .replace(/^['"]|['"]$/g, '')
    .replace(/\s+/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/g, '');
}

function tryConfigureVapid(publicKey: string, privateKey: string): boolean {
  const pub = normalizeVapidKey(publicKey);
  const priv = normalizeVapidKey(privateKey);
  if (!pub || !priv) return false;
  try {
    webpush.setVapidDetails('mailto:alerts@promosport-tunisie.local', pub, priv);
    pushKeys = { publicKey: pub, privateKey: priv };
    vapidConfigured = true;
    return true;
  } catch {
    return false;
  }
}

async function initPushStore(): Promise<void> {
  let storedKeys: { publicKey: string; privateKey: string } | null = null;

  try {
    if (existsSync(PUSH_STORE_PATH)) {
      const raw = await fs.readFile(PUSH_STORE_PATH, 'utf-8');
      const parsed = JSON.parse(raw) as Partial<PushStoreFile>;
      if (parsed.publicKey && parsed.privateKey) {
        storedKeys = { publicKey: parsed.publicKey, privateKey: parsed.privateKey };
      }
      if (Array.isArray(parsed.subscriptions)) {
        for (const sub of parsed.subscriptions) {
          if (sub && typeof sub.endpoint === 'string') {
            pushSubscriptions.set(sub.endpoint, sub);
          }
        }
      }
    }
  } catch {
    // ignore corrupt push store file
  }

  const envPub = normalizeVapidKey(
    process.env.VAPID_PUBLIC_KEY || process.env.VAPI_PUBLIV_KEY || process.env.VAPID_PUBLIV_KEY
  );
  const envPriv = normalizeVapidKey(process.env.VAPID_PRIVATE_KEY);

  if (envPub && envPriv && tryConfigureVapid(envPub, envPriv)) {
    return;
  }

  if (storedKeys && tryConfigureVapid(storedKeys.publicKey, storedKeys.privateKey)) {
    return;
  }

  const generated = webpush.generateVAPIDKeys();
  if (tryConfigureVapid(generated.publicKey, generated.privateKey)) {
    await persistPushStore();
  }
}

async function persistPushStore(): Promise<void> {
  if (!pushKeys) return;
  const payload: PushStoreFile = {
    publicKey: pushKeys.publicKey,
    privateKey: pushKeys.privateKey,
    subscriptions: Array.from(pushSubscriptions.values()),
  };
  await fs.writeFile(PUSH_STORE_PATH, JSON.stringify(payload), 'utf-8').catch(() => {});
}

async function broadcastDesktopPush(payload: {
  title: string;
  body: string;
  concoursNumber?: number;
  tag?: string;
  targetTab?: 'grille' | 'tirage' | 'live' | 'apk';
}): Promise<number> {
  if (!pushKeys || pushSubscriptions.size === 0) return 0;
  const messageStr = JSON.stringify(payload);
  let sentCount = 0;
  const expiredEndpoints: string[] = [];

  await Promise.all(
    Array.from(pushSubscriptions.entries()).map(async ([endpoint, sub]) => {
      try {
        await webpush.sendNotification(sub, messageStr, { TTL: 1800 });
        sentCount += 1;
      } catch (err: unknown) {
        const statusCode = (err as { statusCode?: number })?.statusCode;
        if (statusCode === 404 || statusCode === 410) {
          expiredEndpoints.push(endpoint);
        }
      }
    })
  );

  if (expiredEndpoints.length > 0) {
    for (const ep of expiredEndpoints) {
      pushSubscriptions.delete(ep);
    }
    void persistPushStore();
  }
  return sentCount;
}

// Baseline snapshots for detecting server-side goal, new grille, and winners events
let serverPrevConcoursNumber = INITIAL_WEEKLY_CONCOURS.number;
let serverPrevActivePrize = {
  concoursNumber: INITIAL_WEEKLY_CONCOURS.number,
  value: String(INITIAL_WEEKLY_CONCOURS.cagnotteEstimate || '').trim(),
};
const serverPrevMatchSnap = new Map<number, { status: string; home: number; away: number; hasScore: boolean }>();
let serverPrevWinnersSig = '';
const serverPrevLiveCatalogScores = new Map<string, { home: number; away: number }>();

function evaluateAndDispatchConcoursPushes(concours: WeeklyConcours, grilles: PromosportGrille[]): void {
  if (pushSubscriptions.size === 0) {
    serverPrevConcoursNumber = concours.number;
    serverPrevActivePrize = {
      concoursNumber: concours.number,
      value: String(concours.cagnotteEstimate || '').trim(),
    };
    serverPrevMatchSnap.clear();
    for (const m of concours.matches) {
      const hasScore = !m.isDelayed && m.scoreHome !== undefined && m.scoreAway !== undefined;
      serverPrevMatchSnap.set(m.id, {
        status: m.status,
        home: Number(m.scoreHome || 0),
        away: Number(m.scoreAway || 0),
        hasScore,
      });
    }
    return;
  }

  const currentPrize = String(concours.cagnotteEstimate || '').trim();
  if (
    serverPrevActivePrize.concoursNumber === concours.number &&
    serverPrevActivePrize.value &&
    currentPrize &&
    currentPrize !== serverPrevActivePrize.value &&
    !/^(—|-|غير محدد|قيد التحديد الرسمي)$/i.test(currentPrize)
  ) {
    void broadcastDesktopPush({
      title: `تحديث قيمة الجائزة الكبرى — القصاصة ${concours.number}`,
      body: `القيمة الجديدة للجائزة الكبرى: ${currentPrize}`,
      concoursNumber: concours.number,
      tag: `jackpot-${concours.number}-${currentPrize.replace(/\s+/g, '-')}`,
      targetTab: 'grille',
    });
  }
  serverPrevActivePrize = { concoursNumber: concours.number, value: currentPrize };

  // 1. New Concours / Grille published
  if (concours.number > serverPrevConcoursNumber) {
    serverPrevConcoursNumber = concours.number;
    const prevNum = concours.number - 1;
    void broadcastDesktopPush({
      title: `قصاصة جديدة رقم ${concours.number} في خانة القصاصة`,
      body: `الجائزة الكبرى ${concours.cagnotteEstimate} • القصاصة السابقة رقم ${prevNum} ظاهرة الآن في خانة Tirage`,
      concoursNumber: concours.number,
      tag: `grille-${concours.number}`,
      targetTab: 'grille',
    });
  }

  // 2. Live Goal / Full-Time / Kickoff events in Active Concours
  const isBaselineEmpty = serverPrevMatchSnap.size === 0;
  for (const m of concours.matches) {
    const hasScore =
      !m.isDelayed &&
      m.scoreHome !== undefined &&
      m.scoreAway !== undefined &&
      /^\d+$/.test(String(m.scoreHome)) &&
      /^\d+$/.test(String(m.scoreAway));
    const curH = hasScore ? Number(m.scoreHome) : 0;
    const curA = hasScore ? Number(m.scoreAway) : 0;
    const prev = serverPrevMatchSnap.get(m.id);

    if (!isBaselineEmpty && prev && !m.isDelayed && hasScore) {
      const hNameAr = translateTeamToArabic(m.homeTeam, m.homeTeamFr);
      const aNameAr = translateTeamToArabic(m.awayTeam, m.awayTeamFr);
      if (
        (m.status === 'live' || (prev.status === 'live' && m.status === 'finished')) &&
        ((prev.hasScore && (curH > prev.home || curA > prev.away)) || (!prev.hasScore && (curH > 0 || curA > 0)))
      ) {
        void broadcastDesktopPush({
          title: `هدف الآن! ${hNameAr} ${curH} - ${curA} ${aNameAr}`,
          body: `القصاصة ${concours.number} • الدقيقة ${m.liveMinute || "1'"}`,
          concoursNumber: concours.number,
          tag: `goal-${concours.number}-${m.id}-${curH}-${curA}`,
          targetTab: 'live',
        });
      } else if (prev.status !== 'finished' && m.status === 'finished') {
        void broadcastDesktopPush({
          title: `نهاية المقابلة: ${hNameAr} ${curH} - ${curA} ${aNameAr}`,
          body: `القصاصة ${concours.number} • النتيجة (${m.result || '-'})`,
          concoursNumber: concours.number,
          tag: `ft-${concours.number}-${m.id}`,
          targetTab: 'live',
        });
      }
    }

    serverPrevMatchSnap.set(m.id, {
      status: m.status,
      home: curH,
      away: curA,
      hasScore,
    });
  }

  // 3. Official Winners / Financial Payouts Published
  const latestOfficial = grilles.find(
    (g) => g.number < concours.number && g.status === 'official' && g.winnersFormatted && g.winnersFormatted !== 'قيد التحديد الرسمي'
  );
  if (latestOfficial) {
    const sig = `${latestOfficial.number}:${latestOfficial.winnersCount}:${latestOfficial.prizePerWinner}`;
    if (serverPrevWinnersSig && serverPrevWinnersSig !== sig) {
      void broadcastDesktopPush({
        title: `إعلان المرابيح — قصاصة رقم ${latestOfficial.number}`,
        body: `المرابيح: ${latestOfficial.winnersFormatted} • نصيب الفائز: ${latestOfficial.prizePerWinnerFormatted}`,
        concoursNumber: latestOfficial.number,
        tag: `winners-${latestOfficial.number}`,
        targetTab: 'tirage',
      });
    }
    serverPrevWinnersSig = sig;
  }
}

function evaluateAndDispatchLiveCatalogPushes(payload: SiteLiveScanPayload): void {
  const isBaseline = serverPrevLiveCatalogScores.size === 0;
  for (const m of payload.matches) {
    if (!m.hasVerifiedScore || m.status !== 'live') continue;
    const h = Number(m.scoreHome || 0);
    const a = Number(m.scoreAway || 0);
    const prev = serverPrevLiveCatalogScores.get(m.siteMatchId);
    if (!isBaseline && pushSubscriptions.size > 0 && prev && (h > prev.home || a > prev.away)) {
      const hNameAr = translateTeamToArabic(m.homeTeam, m.homeTeamFr);
      const aNameAr = translateTeamToArabic(m.awayTeam, m.awayTeamFr);
      const compAr = translateCompetitionToArabic(m.competition || 'مباشر', m.competitionFr);
      void broadcastDesktopPush({
        title: `هدف مباشر! ${hNameAr} ${h} - ${a} ${aNameAr}`,
        body: `${compAr} • الدقيقة ${m.liveMinute || "1'"}`,
        tag: `live-goal-${m.siteMatchId}-${h}-${a}`,
        targetTab: 'live',
      });
    }
    serverPrevLiveCatalogScores.set(m.siteMatchId, { home: h, away: a });
  }
}

/**
 * Permanently scans https://www.promosport-pronostic.com/welcome/promosport
 * (plus rapid live endpoint & scoreboards) for:
 * - New active grilles (auto-download & immediate promotion without delay)
 * - Immediate rollover archiving of superseded grilles into Tirage (even before winnersCount appears)
 * - Live match scores, minutes, half-times, and official payouts/winnersCount
 */
function probeOfficialPromosportSite(): Promise<void> {
  if (inFlightProbePromise) {
    return inFlightProbePromise;
  }

  inFlightProbePromise = (async () => {
    const nowMs = Date.now();
    syncCache.lastAttemptMs = nowMs;

    try {
      const siteScan = await fetchPromosportPronosticFullScan();

      // 1. Archive & promote if a newer concours appeared on promosport-pronostic.com
      if (siteScan.activeConcours) {
        if (siteScan.activeConcours.number > syncCache.activeConcours.number) {
          const matchingResult = siteScan.grilles.find(
            (g) => g.number === syncCache.activeConcours.number
          );
          const archivedPrev = archiveConcoursToGrille(syncCache.activeConcours, matchingResult);
          syncCache.grilles = mergeGrilleArchives(syncCache.grilles, [archivedPrev]);
          syncCache.activeConcours = siteScan.activeConcours;
        } else if (siteScan.activeConcours.number === syncCache.activeConcours.number) {
          syncCache.activeConcours = mergeConcoursPreservingScores(
            syncCache.activeConcours,
            siteScan.activeConcours
          );
        }
        syncCache.lastRemoteSuccessMs = nowMs;
      }

      // 2. Merge latest official/pending Tirage grilles from site
      if (siteScan.grilles.length > 0) {
        syncCache.grilles = mergeGrilleArchives(syncCache.grilles, siteScan.grilles);
        syncCache.lastRemoteSuccessMs = nowMs;
      }

      // 3. Enrich active concours matches with real-time verified scores (no fake assumptions)
      const { concours: enriched, matchedCount } = await enrichConcoursWithDirectLiveFeeds(
        syncCache.activeConcours
      );
      syncCache.activeConcours = enriched;
      if (matchedCount > 0) {
        syncCache.lastRemoteSuccessMs = nowMs;
      }
    } catch {
      // Keep clean cached state if upstream site is temporarily unreachable
    }

    try {
      // Evaluate with strict zero-assumption evaluator and normalize Arabic/French team translations
      const evaluatedConcours = normalizeConcoursTranslations(
        evaluateConcoursRealTime(syncCache.activeConcours, nowMs, null)
      );
      syncCache.activeConcours = evaluatedConcours;

      const archivedExtra: PromosportGrille[] = [];
      if (isConcoursCompletelyFinished(evaluatedConcours, nowMs)) {
        const existing = syncCache.grilles.find((g) => g.number === evaluatedConcours.number);
        archivedExtra.push(archiveConcoursToGrille(evaluatedConcours, existing));
      }

      syncCache.grilles = mergeGrilleArchives(INITIAL_GRILLES, [
        ...syncCache.grilles,
        ...archivedExtra,
      ]).map(normalizeGrilleTranslations);

      // Strictly enforce that N - 1 is present in Tirage archive whenever active concours is N
      const expectedPrevNum = evaluatedConcours.number - 1;
      if (
        expectedPrevNum === INITIAL_WEEKLY_CONCOURS.number &&
        !syncCache.grilles.some((g) => g.number === expectedPrevNum)
      ) {
        syncCache.grilles = mergeGrilleArchives(syncCache.grilles, [
          archiveConcoursToGrille(INITIAL_WEEKLY_CONCOURS),
        ]).map(normalizeGrilleTranslations);
      }

      syncCache.syncedAt = new Date(nowMs).toISOString();
      evaluateAndDispatchConcoursPushes(syncCache.activeConcours, syncCache.grilles);
      void persistSyncArchiveStore();
    } catch (err) {
      console.warn('[probeOfficialPromosportSite] evaluation error:', err);
    }
  })().finally(() => {
    inFlightProbePromise = null;
  });

  return inFlightProbePromise;
}

interface ServerLiveMatchesCache {
  baseMatches: SiteLiveMatch[];
  payload: SiteLiveScanPayload;
  lastCatalogMs: number;
  lastRapidMs: number;
}

const liveMatchesCache: ServerLiveMatchesCache = {
  baseMatches: [],
  payload: {
    matches: [],
    leagues: [],
    liveCount: 0,
    totalCount: 0,
    scannedAt: new Date().toISOString(),
    sourceUrl: PROMOSPORT_PRONOSTIC_HOME_URL,
  },
  lastCatalogMs: 0,
  lastRapidMs: 0,
};

let inFlightLiveCatalogPromise: Promise<void> | null = null;

async function refreshLiveMatchesCache(forceCatalogScan = false): Promise<SiteLiveScanPayload> {
  const nowMs = Date.now();
  const needCatalog =
    forceCatalogScan ||
    liveMatchesCache.baseMatches.length === 0 ||
    nowMs - liveMatchesCache.lastCatalogMs > 20000;

  if (needCatalog) {
    if (!inFlightLiveCatalogPromise) {
      inFlightLiveCatalogPromise = (async () => {
        try {
          const [catalog, rapid] = await Promise.all([
            scanPromosportLiveCatalogHtml(),
            fetchRapidLiveMap(),
          ]);
          if (catalog.length > 0) {
            liveMatchesCache.baseMatches = catalog;
            liveMatchesCache.lastCatalogMs = Date.now();
          }
          if (liveMatchesCache.baseMatches.length > 0) {
            liveMatchesCache.payload = applyRapidToLiveMatches(liveMatchesCache.baseMatches, rapid);
            liveMatchesCache.lastRapidMs = Date.now();
            evaluateAndDispatchLiveCatalogPushes(liveMatchesCache.payload);
          }
        } catch {
          // Keep existing cached payload on transient upstream error
        }
      })().finally(() => {
        inFlightLiveCatalogPromise = null;
      });
    }
    await Promise.race([
      inFlightLiveCatalogPromise,
      new Promise<void>((resolve) => setTimeout(resolve, 6500)),
    ]);
    return liveMatchesCache.payload;
  }

  // Moment-by-moment rapid live update (every ~2.5s)
  if (nowMs - liveMatchesCache.lastRapidMs > 2500 && liveMatchesCache.baseMatches.length > 0) {
    try {
      const rapid = await fetchRapidLiveMap();
      liveMatchesCache.payload = applyRapidToLiveMatches(liveMatchesCache.baseMatches, rapid);
      liveMatchesCache.lastRapidMs = Date.now();
      evaluateAndDispatchLiveCatalogPushes(liveMatchesCache.payload);
    } catch {
      // Preserve last valid snapshot
    }
  }

  return liveMatchesCache.payload;
}

const execAsync = promisify(exec);
let activeDistBuild: Promise<void> | null = null;

interface ExportDistFile {
  path: string;
  base64: string;
  size: number;
}

async function getLatestMtimeMs(targetPath: string): Promise<number> {
  try {
    const stat = await fs.stat(targetPath);
    let newest = stat.mtimeMs;
    if (stat.isDirectory()) {
      const entries = await fs.readdir(targetPath, { withFileTypes: true });
      for (const entry of entries) {
        if (entry.name === 'node_modules' || entry.name === 'dist' || entry.name.startsWith('.')) {
          continue;
        }
        const childNewest = await getLatestMtimeMs(path.join(targetPath, entry.name));
        if (childNewest > newest) newest = childNewest;
      }
    }
    return newest;
  } catch {
    return 0;
  }
}

async function ensureBuiltDist(forceFresh = false): Promise<string> {
  const distDir = path.resolve(__dirname, 'dist');
  const distIndex = path.join(distDir, 'index.html');

  let needsBuild = forceFresh || !existsSync(distIndex);
  if (!needsBuild) {
    const distStat = await fs.stat(distIndex).catch(() => null);
    const distMtime = distStat ? distStat.mtimeMs : 0;
    const watchedPaths = ['src', 'public', 'index.html', 'vite.config.ts', 'package.json'];
    const mtimes = await Promise.all(watchedPaths.map((p) => getLatestMtimeMs(path.resolve(__dirname, p))));
    const newestSourceMtime = Math.max(...mtimes);
    if (newestSourceMtime > distMtime) {
      needsBuild = true;
    }
  }

  if (needsBuild) {
    if (!activeDistBuild) {
      activeDistBuild = execAsync('npx vite build', {
        cwd: __dirname,
        maxBuffer: 1024 * 1024 * 10,
      })
        .then(() => undefined)
        .finally(() => {
          activeDistBuild = null;
        });
    }
    await activeDistBuild;
  }

  return distDir;
}

async function collectDistFiles(dir: string, rootDir: string, out: ExportDistFile[]): Promise<void> {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    const relPath = path.relative(rootDir, fullPath).replace(/\\/g, '/');

    if (relPath === 'assets/aistudio' || relPath.startsWith('assets/aistudio/')) {
      continue;
    }

    if (entry.isDirectory()) {
      await collectDistFiles(fullPath, rootDir, out);
    } else if (entry.isFile()) {
      const buf = await fs.readFile(fullPath);
      out.push({
        path: relPath,
        base64: buf.toString('base64'),
        size: buf.length,
      });
    }
  }
}

const ANDROID_PACKAGE_ID_REGEX = /^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+$/;
let lastAutoSyncAt = new Date().toISOString();

function escapeXml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

async function readJsonSafe<T>(filePath: string, fallback: T): Promise<T> {
  try {
    if (!existsSync(filePath)) return fallback;
    const raw = await fs.readFile(filePath, 'utf-8');
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

interface SyncWorkspacePayload {
  appSettings?: Record<string, unknown>;
  notificationSettings?: Record<string, unknown>;
  userSlips?: unknown[];
  concours?: WeeklyConcours;
  activeConcours?: WeeklyConcours;
  activeUrl?: string;
  promptSpec?: string;
  offlineHtml?: string;
}

async function copyDirFiltered(srcDir: string, destDir: string, relBase = ''): Promise<number> {
  await fs.mkdir(destDir, { recursive: true });
  const entries = await fs.readdir(srcDir, { withFileTypes: true });
  let count = 0;

  for (const entry of entries) {
    const rel = relBase ? `${relBase}/${entry.name}` : entry.name;
    if (rel === 'assets/aistudio' || rel.startsWith('assets/aistudio/')) continue;

    const srcPath = path.join(srcDir, entry.name);
    const destPath = path.join(destDir, entry.name);

    if (entry.isDirectory()) {
      count += await copyDirFiltered(srcPath, destPath, rel);
    } else if (entry.isFile()) {
      await fs.copyFile(srcPath, destPath);
      count += 1;
    }
  }
  return count;
}

async function syncDistToCapacitorAssets(distDir: string): Promise<number> {
  const androidPublicDir = path.resolve(__dirname, 'android/app/src/main/assets/public');
  await fs.rm(androidPublicDir, { recursive: true, force: true }).catch(() => {});
  const copied = await copyDirFiltered(distDir, androidPublicDir);

  const bootstrapPath = path.resolve(__dirname, 'APP_BOOTSTRAP.json');
  if (existsSync(bootstrapPath)) {
    await fs.copyFile(bootstrapPath, path.join(androidPublicDir, 'promosport-bootstrap.json')).catch(() => {});
  }
  return copied;
}

async function syncWorkspaceAndCapacitor(payload: SyncWorkspacePayload = {}): Promise<{
  syncedAt: string;
  packageId: string;
  appName: string;
  slipsCount: number;
  concoursNumber: number;
}> {
  const existingAppSettings = await readJsonSafe<Record<string, unknown>>(
    path.resolve(__dirname, 'APP_SETTINGS.json'),
    {
      appName: 'بروموسبور تونس - MB Football',
      packageId: 'com.promosport.tunisie.mb',
      phoneNumber: '51155580',
      concoursNumber: syncCache.activeConcours.number,
      columnRate: 0.15,
      baseFee: 0.25,
      enableSlipsHistory: true,
    }
  );

  const existingNotifSettings = await readJsonSafe<Record<string, unknown>>(
    path.resolve(__dirname, 'NOTIFICATION_SETTINGS.json'),
    {
      notifyNewGrille: true,
      notifyOfficialResults: true,
      notifyJackpotRollover: true,
      notifyClosingCountdown: true,
      soundEnabled: true,
      pushNotificationsEnabled: true,
      notificationSoundEnabled: true,
      notificationSoundStyle: 'golden-chime',
      notificationSoundDurationSeconds: 2,
      goalSoundEnabled: true,
      goalSoundDurationSeconds: 2,
      goalSoundStyle: 'water-droplet',
      clickSoundEnabled: true,
      clickSoundStyle: 'soft-tap',
      durationSeconds: 10,
      checkIntervalMinutes: 15,
      autoUpdateActive: true,
    }
  );

  const existingSlips = await readJsonSafe<unknown[]>(
    path.resolve(__dirname, 'SAVED_USER_SLIPS.json'),
    []
  );

  const existingBootstrap = await readJsonSafe<Record<string, unknown>>(
    path.resolve(__dirname, 'APP_BOOTSTRAP.json'),
    {}
  );

  const mergedAppSettings = {
    ...existingAppSettings,
    ...(payload.appSettings && typeof payload.appSettings === 'object' ? payload.appSettings : {}),
  };

  const mergedNotifSettings = {
    ...existingNotifSettings,
    ...(payload.notificationSettings && typeof payload.notificationSettings === 'object'
      ? payload.notificationSettings
      : {}),
  };

  const nextSlips = Array.isArray(payload.userSlips) ? payload.userSlips : existingSlips;
  const nextConcours =
    payload.activeConcours || payload.concours || (existingBootstrap.activeConcours as WeeklyConcours | undefined) || syncCache.activeConcours;
  const rawPackageId = String(mergedAppSettings.packageId || 'com.promosport.tunisie.mb').trim();
  const validPackageId = ANDROID_PACKAGE_ID_REGEX.test(rawPackageId)
    ? rawPackageId
    : 'com.promosport.tunisie.mb';
  const appName = String(mergedAppSettings.appName || 'بروموسبور تونس - MB Football').trim() || 'بروموسبور تونس - MB Football';
  const syncedAt = new Date().toISOString();
  lastAutoSyncAt = syncedAt;

  const bootstrapPayload = {
    available: true,
    exportId: `sync-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    exportedAt: syncedAt,
    remoteSyncOrigin: payload.activeUrl || (existingBootstrap.remoteSyncOrigin as string | undefined) || '',
    protectedPin: '1777',
    appSettings: { ...mergedAppSettings, packageId: validPackageId, appName },
    notificationSettings: mergedNotifSettings,
    userSlips: nextSlips,
    activeConcours: nextConcours,
    lastNotifiedSignature: existingBootstrap.lastNotifiedSignature ?? null,
    autoCommands: {
      liveScoreTickerMs: 1000,
      upstreamSyncMs: 10000,
      goalFlameDurationMs: 7000,
      goalAudio: mergedNotifSettings.goalSoundStyle || 'water-droplet',
      clickSoundEnabled: mergedNotifSettings.clickSoundEnabled !== false,
      clickSoundStyle: mergedNotifSettings.clickSoundStyle || 'soft-tap',
      autoActivateSlipsAndSettings: true,
      autoOpenBrowserOnServerStart: true,
      autoEnableNotifications: Boolean(mergedNotifSettings.pushNotificationsEnabled),
    },
  };

  const bootstrapJson = JSON.stringify(bootstrapPayload, null, 2);

  await Promise.all([
    fs.writeFile(path.resolve(__dirname, 'APP_SETTINGS.json'), JSON.stringify(bootstrapPayload.appSettings, null, 2), 'utf-8'),
    fs.writeFile(path.resolve(__dirname, 'NOTIFICATION_SETTINGS.json'), JSON.stringify(mergedNotifSettings, null, 2), 'utf-8'),
    fs.writeFile(path.resolve(__dirname, 'SAVED_USER_SLIPS.json'), JSON.stringify(nextSlips, null, 2), 'utf-8'),
    fs.writeFile(path.resolve(__dirname, 'APP_BOOTSTRAP.json'), bootstrapJson, 'utf-8'),
    fs.writeFile(path.resolve(__dirname, 'public/promosport-bootstrap.json'), bootstrapJson, 'utf-8'),
  ]);

  if (typeof payload.promptSpec === 'string' && payload.promptSpec.trim().length > 0) {
    await fs.writeFile(path.resolve(__dirname, 'PROMPT_SPECIFICATION.txt'), payload.promptSpec, 'utf-8');
  }

  if (typeof payload.offlineHtml === 'string' && payload.offlineHtml.trim().length > 0) {
    const htmlFilename = `Promosport_MB_3D_Offline_App_${nextConcours.number || 936}.html`;
    await fs.writeFile(path.resolve(__dirname, htmlFilename), payload.offlineHtml, 'utf-8');
  }

  // Sync Capacitor root & Android asset config
  const capConfigPath = path.resolve(__dirname, 'capacitor.config.json');
  const capConfig = await readJsonSafe<Record<string, unknown>>(capConfigPath, {
    appId: validPackageId,
    appName,
    webDir: 'dist',
    bundledWebRuntime: false,
    server: {
      androidScheme: 'https',
      allowNavigation: ['*'],
      cleartext: true,
    },
  });
  capConfig.appId = validPackageId;
  capConfig.appName = appName;
  capConfig.webDir = 'dist';
  capConfig.bundledWebRuntime = false;
  const capConfigStr = `${JSON.stringify(capConfig, null, 2)}\n`;
  await fs.writeFile(capConfigPath, capConfigStr, 'utf-8');

  const androidCapConfigPath = path.resolve(__dirname, 'android/app/src/main/assets/capacitor.config.json');
  if (existsSync(path.dirname(androidCapConfigPath))) {
    await fs.writeFile(androidCapConfigPath, capConfigStr, 'utf-8');
  }

  // Sync Android strings.xml
  const stringsPath = path.resolve(__dirname, 'android/app/src/main/res/values/strings.xml');
  if (existsSync(stringsPath)) {
    const escapedName = escapeXml(appName);
    const escapedPkg = escapeXml(validPackageId);
    const xml = `<?xml version='1.0' encoding='utf-8'?>\n<resources>\n    <string name="app_name">${escapedName}</string>\n    <string name="title_activity_main">${escapedName}</string>\n    <string name="package_name">${escapedPkg}</string>\n    <string name="custom_url_scheme">${escapedPkg}</string>\n</resources>\n`;
    await fs.writeFile(stringsPath, xml, 'utf-8');
  }

  // Sync Android build.gradle namespace & applicationId
  const gradlePath = path.resolve(__dirname, 'android/app/build.gradle');
  if (existsSync(gradlePath)) {
    const rawGradle = await fs.readFile(gradlePath, 'utf-8');
    const updatedGradle = rawGradle
      .replace(/namespace\s+"[^"]+"/, `namespace "${validPackageId}"`)
      .replace(/applicationId\s+"[^"]+"/, `applicationId "${validPackageId}"`);
    if (updatedGradle !== rawGradle) {
      await fs.writeFile(gradlePath, updatedGradle, 'utf-8');
    }
  }

  return {
    syncedAt,
    packageId: validPackageId,
    appName,
    slipsCount: nextSlips.length,
    concoursNumber: Number(nextConcours.number || syncCache.activeConcours.number),
  };
}

async function addDirectoryToZip(
  zip: JSZip,
  absDir: string,
  zipPrefix: string,
  options: { skipDirs?: Set<string>; skipPaths?: string[] } = {}
): Promise<number> {
  if (!existsSync(absDir)) return 0;
  const entries = await fs.readdir(absDir, { withFileTypes: true });
  let count = 0;

  for (const entry of entries) {
    if (options.skipDirs && options.skipDirs.has(entry.name)) {
      continue;
    }

    const fullPath = path.join(absDir, entry.name);
    const zipPath = zipPrefix ? `${zipPrefix}/${entry.name}` : entry.name;

    if (options.skipPaths && options.skipPaths.some((skip) => zipPath === skip || zipPath.startsWith(`${skip}/`))) {
      continue;
    }

    if (entry.isDirectory()) {
      count += await addDirectoryToZip(zip, fullPath, zipPath, options);
    } else if (entry.isFile()) {
      const buf = await fs.readFile(fullPath);
      const isExecutable = zipPath === 'android/gradlew' || zipPath.endsWith('.sh');
      zip.file(zipPath, buf, isExecutable ? { unixPermissions: 0o755 } : undefined);
      count += 1;
    }
  }

  return count;
}

async function countFilesMatching(dir: string, predicate: (rel: string) => boolean, prefix = ''): Promise<number> {
  if (!existsSync(dir)) return 0;
  const entries = await fs.readdir(dir, { withFileTypes: true });
  let count = 0;
  for (const entry of entries) {
    const rel = prefix ? `${prefix}/${entry.name}` : entry.name;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      count += await countFilesMatching(full, predicate, rel);
    } else if (entry.isFile() && predicate(rel)) {
      count += 1;
    }
  }
  return count;
}

async function startServer() {
  await Promise.all([
    initPushStore(),
    initSyncArchiveStore(),
    initParticipantsStore(),
    initMessagesStore(),
  ]);

  const app = express();
  const httpServer = createHttpServer(app);
  app.use(express.json({ limit: '15mb' }));

  // Always-on server monitor so subscribed desktop OS clients receive goals & new grilles even when app is closed
  setInterval(() => {
    if (pushSubscriptions.size > 0) {
      void probeOfficialPromosportSite().catch(() => {});
      void refreshLiveMatchesCache(false).catch(() => {});
    }
  }, 25000);

  // Desktop / OS Web Push API (VAPID public key, subscribe, unsubscribe, test)
  app.use('/api/push', (req, res, next) => {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    if (req.method === 'OPTIONS') {
      res.status(204).end();
      return;
    }
    next();
  });

  app.get('/api/push/vapid-public-key', (_req, res) => {
    res.json({
      publicKey: vapidConfigured ? pushKeys?.publicKey || null : null,
      supported: Boolean(vapidConfigured && pushKeys?.publicKey),
    });
  });

  app.post('/api/push/subscribe', async (req, res) => {
    const sub = req.body?.subscription as webpush.PushSubscription | undefined;
    if (
      !sub ||
      typeof sub.endpoint !== 'string' ||
      !sub.endpoint.startsWith('http') ||
      !sub.keys?.p256dh ||
      !sub.keys?.auth
    ) {
      res.status(400).json({ ok: false, error: 'Invalid subscription' });
      return;
    }
    pushSubscriptions.set(sub.endpoint, sub);
    await persistPushStore();
    res.json({ ok: true, subscribersCount: pushSubscriptions.size });
  });

  app.post('/api/push/unsubscribe', async (req, res) => {
    const endpoint = req.body?.endpoint as string | undefined;
    if (endpoint) {
      pushSubscriptions.delete(endpoint);
      await persistPushStore();
    }
    res.json({ ok: true });
  });

  app.post('/api/push/test', async (req, res) => {
    const title = String(req.body?.title || `إشعارات بروموسبور نشطة — قصاصة ${syncCache.activeConcours.number}`);
    const body = String(req.body?.body || 'ستصلك إشعارات الأهداف والقصاصات الجديدة على سطح المكتب دائماً.');
    const concoursNumber = Number(req.body?.concoursNumber || syncCache.activeConcours.number);
    const sent = await broadcastDesktopPush({
      title,
      body,
      concoursNumber,
      tag: `test-${Date.now()}`,
    });
    res.json({ ok: true, sent, subscribersCount: pushSubscriptions.size });
  });

  // Live continuous & scheduled Promosport sync endpoint (bounded wait + coalesced upstream probes)
  app.get('/api/promosport/sync', async (req, res) => {
    const force = req.query.refresh === '1';
    const ageMs = Date.now() - syncCache.lastAttemptMs;

    if (force || ageMs > 10000) {
      const probePromise = probeOfficialPromosportSite();
      // Never block client HTTP responses beyond 4s waiting on upstream third-party timeouts
      await Promise.race([
        probePromise,
        new Promise<void>((resolve) => setTimeout(resolve, 4000)),
      ]);
    } else {
      const nowMs = Date.now();
      syncCache.activeConcours = evaluateConcoursRealTime(syncCache.activeConcours, nowMs, null);
      syncCache.syncedAt = new Date(nowMs).toISOString();
    }

    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.json({
      activeConcours: syncCache.activeConcours,
      grilles: syncCache.grilles,
      syncedAt: syncCache.syncedAt,
      source: syncCache.lastRemoteSuccessMs > 0 ? 'server-live' : 'server-cache',
    });
  });

  // Real-time promosport-pronostic.com full scan + moment-by-moment live scores endpoint
  app.get('/api/promosport/live-matches', async (req, res) => {
    const forceScan = req.query.scan === '1';
    const payload = await refreshLiveMatchesCache(forceScan);
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.json(payload);
  });

  // Unique Participant Registration (one-time per device, auto-appends 2 unique random digits, immutable)
  app.use('/api/participant', (req, res, next) => {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    if (req.method === 'OPTIONS') {
      res.status(204).end();
      return;
    }
    next();
  });

  app.get('/api/participant/profile', (req, res) => {
    const deviceId = String(req.query.deviceId || '').trim();
    if (!deviceId) {
      res.status(400).json({ ok: false, error: 'Missing deviceId' });
      return;
    }
    const direct = participantsByDevice.get(deviceId);
    const aliasedId = deviceAliasToParticipantId.get(deviceId);
    const existing = direct || (aliasedId ? participantsByDevice.get(aliasedId) : undefined) || null;
    res.json({ ok: true, profile: existing });
  });

  app.post('/api/participant/verify', async (req, res) => {
    const rawInput = String(req.body?.fullNameInput || '');
    const rawDeviceId = String(req.body?.deviceId || '').trim();
    const matched = findRegisteredParticipantByInput(rawInput);

    if (!matched) {
      res.status(404).json({
        ok: false,
        registered: false,
        code: 'NOT_REGISTERED',
        error: 'غير مسجل أعد المحاولة',
      });
      return;
    }

    if (rawDeviceId && rawDeviceId.length >= 6 && rawDeviceId !== matched.id) {
      deviceAliasToParticipantId.set(rawDeviceId.slice(0, 120), matched.id);
      await persistParticipantsStore();
    }

    res.json({
      ok: true,
      registered: true,
      profile: { ...matched, syncedToServer: true },
    });
  });

  app.post('/api/participant/register', async (req, res) => {
    const rawBaseName = String(req.body?.baseName || '');
    const baseName = cleanParticipantBaseName(rawBaseName);
    const rawDeviceId = String(req.body?.deviceId || '').trim();
    const deviceId =
      rawDeviceId && rawDeviceId.length >= 6
        ? rawDeviceId.slice(0, 120)
        : `dev-${Date.now()}-${randomInt(100000, 999999)}`;
    const preferredDigits =
      typeof req.body?.preferredSuffixDigits === 'string' && /^\d{2}$/.test(req.body.preferredSuffixDigits)
        ? req.body.preferredSuffixDigits
        : undefined;

    // Write-once immutability: once registered on a device, never replace name or 2 digits
    const aliasedOwnerId = deviceAliasToParticipantId.get(deviceId);
    const alreadyForDevice =
      participantsByDevice.get(deviceId) ||
      (aliasedOwnerId ? participantsByDevice.get(aliasedOwnerId) : undefined);
    if (alreadyForDevice) {
      res.json({
        ok: true,
        alreadyRegistered: true,
        profile: { ...alreadyForDevice, syncedToServer: true },
      });
      return;
    }

    if (!baseName) {
      res.status(400).json({
        ok: false,
        code: 'NAME_REQUIRED',
        error: 'اسم المشارك إجباري، يرجى كتابة اسمك أولاً.',
      });
      return;
    }

    const suffixDigits = pickUniqueTwoDigitSuffix(baseName, preferredDigits);
    if (!suffixDigits) {
      res.status(409).json({
        ok: false,
        code: 'NAME_EXHAUSTED',
        error: 'هذا الاسم مستعمل بجميع الأرقام المتاحة، يرجى إضافة اللقب أو حرف لتمييز اسمك.',
      });
      return;
    }

    const fullName = `${baseName} ${suffixDigits}`;
    const profile: ParticipantProfile = {
      id: deviceId,
      baseName,
      suffixDigits,
      fullName,
      registeredAt: new Date().toISOString(),
      syncedToServer: true,
    };

    indexRegisteredParticipant(profile);
    await persistParticipantsStore();

    res.json({
      ok: true,
      alreadyRegistered: false,
      profile,
    });
  });

  // Registered Server Users Directory (for selecting recipient inside صفحة القصاصات)
  app.get('/api/participant/directory', (req, res) => {
    const queryRaw = String(req.query.q || '');
    const excludeRaw = String(req.query.excludeId || '').trim();
    const excludeCanonical = excludeRaw ? resolveCanonicalParticipant(excludeRaw)?.id || excludeRaw : '';
    const normQuery = normalizeParticipantKey(queryRaw);
    const compactQuery = compactParticipantKey(queryRaw);

    const users = Array.from(participantsByDevice.values())
      .filter((p) => {
        if (excludeCanonical && p.id === excludeCanonical) return false;
        if (!normQuery) return true;
        return (
          normalizeParticipantKey(p.fullName).includes(normQuery) ||
          compactParticipantKey(p.fullName).includes(compactQuery)
        );
      })
      .map((p) => ({
        id: p.id,
        baseName: p.baseName,
        suffixDigits: p.suffixDigits,
        fullName: p.fullName,
      }))
      .sort((a, b) => a.fullName.localeCompare(b.fullName, 'ar'));

    res.json({ ok: true, users });
  });

  // Slip Messages API (سجل الرسائل: إرسال / استقبال مباشر SSE / حفظ / فسخ)
  app.use('/api/messages', (req, res, next) => {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    if (req.method === 'OPTIONS') {
      res.status(204).end();
      return;
    }
    next();
  });

  app.get('/api/messages/stream', (req, res) => {
    const rawPid = String(req.query.participantId || req.query.deviceId || '').trim();
    const rawName = String(req.query.fullName || '').trim();
    const resolved = resolveCanonicalParticipant(rawPid, rawName);
    const channelId = resolved?.id || rawPid;
    if (!channelId) {
      res.status(400).end();
      return;
    }

    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders?.();

    let bucket = messageStreamClients.get(channelId);
    if (!bucket) {
      bucket = new Set();
      messageStreamClients.set(channelId, bucket);
    }
    bucket.add(res);

    res.write(`event: connected\ndata: ${JSON.stringify({ participantId: channelId })}\n\n`);

    const keepAliveId = setInterval(() => {
      try {
        res.write(': ping\n\n');
      } catch {
        clearInterval(keepAliveId);
      }
    }, 20000);

    req.on('close', () => {
      clearInterval(keepAliveId);
      const current = messageStreamClients.get(channelId);
      if (current) {
        current.delete(res);
        if (current.size === 0) {
          messageStreamClients.delete(channelId);
        }
      }
    });
  });

  app.get('/api/messages/list', (req, res) => {
    const rawPid = String(req.query.participantId || req.query.deviceId || '').trim();
    const rawName = String(req.query.fullName || '').trim();
    const resolved = resolveCanonicalParticipant(rawPid, rawName);
    const participantId = resolved?.id || rawPid;
    if (!participantId) {
      res.status(400).json({ ok: false, sent: [], received: [], error: 'Missing participantId' });
      return;
    }

    const sent = slipMessagesStore.filter(
      (m) => m.senderId === participantId && !m.deletedBySender
    );
    const received = slipMessagesStore.filter(
      (m) => m.recipientId === participantId && !m.deletedByRecipient
    );

    res.json({
      ok: true,
      participantId,
      sent,
      received,
    });
  });

  app.post('/api/messages/send', async (req, res) => {
    const body = (req.body || {}) as {
      senderId?: string;
      senderFullName?: string;
      recipientId?: string;
      recipientFullNameInput?: string;
      slipNumber?: number;
      slipNumberLabel?: string;
      slip?: UserBetSlip;
      concoursSnapshot?: WeeklyConcours;
    };

    const sender = resolveCanonicalParticipant(body.senderId, body.senderFullName);
    if (!sender) {
      res.status(400).json({
        ok: false,
        code: 'SENDER_NOT_REGISTERED',
        error: 'تعذر التحقق من حساب المرسل المسجل.',
      });
      return;
    }

    const recipientById = body.recipientId
      ? resolveCanonicalParticipant(body.recipientId)
      : null;
    const recipient =
      recipientById ||
      (body.recipientFullNameInput
        ? findRegisteredParticipantByInput(body.recipientFullNameInput)
        : null);

    if (!recipient) {
      res.status(404).json({
        ok: false,
        code: 'RECIPIENT_NOT_FOUND',
        error: 'هذا المستخدم غير مسجل في الخادم — تحقق من الاسم مع الرقمين.',
      });
      return;
    }

    const slip = body.slip;
    if (!slip || typeof slip !== 'object' || !slip.selections || typeof slip.grilleNumber !== 'number') {
      res.status(400).json({
        ok: false,
        code: 'INVALID_SLIP',
        error: 'بيانات القصاصة غير مكتملة للإرسال.',
      });
      return;
    }

    const slipNumber = Number.isFinite(Number(body.slipNumber)) && Number(body.slipNumber) > 0
      ? Number(body.slipNumber)
      : 1;
    const slipNumberLabel =
      String(body.slipNumberLabel || '').trim() || `قصاصة مسجلة رقم ${slipNumber}`;
    const nowMs = Date.now();
    const msgRecord: SlipMessageRecord = {
      id: `smsg-${nowMs}-${randomInt(1000, 9999)}`,
      senderId: sender.id,
      senderFullName: sender.fullName,
      recipientId: recipient.id,
      recipientFullName: recipient.fullName,
      slipNumber,
      slipNumberLabel,
      slip: {
        ...slip,
        selections: { ...slip.selections },
      },
      concoursSnapshot: body.concoursSnapshot || syncCache.activeConcours,
      sentAtIso: new Date(nowMs).toISOString(),
      sentAtDisplay: formatTunisiaDateTimeDisplay(nowMs),
      savedToSlipsByRecipient: false,
      deletedBySender: false,
      deletedByRecipient: false,
    };

    slipMessagesStore.unshift(msgRecord);
    if (slipMessagesStore.length > 500) {
      slipMessagesStore.length = 500;
    }
    await persistMessagesStore();

    pushMessageSseEvent(recipient.id, 'new-message', msgRecord);
    pushMessageSseEvent(sender.id, 'message-updated', { action: 'sent', message: msgRecord });

    res.json({
      ok: true,
      message: msgRecord,
    });
  });

  app.post('/api/messages/mark-saved', async (req, res) => {
    const messageId = String(req.body?.messageId || '').trim();
    const rawPid = String(req.body?.participantId || '').trim();
    const resolved = resolveCanonicalParticipant(rawPid);
    const pid = resolved?.id || rawPid;
    const target = slipMessagesStore.find((m) => m.id === messageId && m.recipientId === pid);
    if (!target) {
      res.status(404).json({ ok: false });
      return;
    }
    target.savedToSlipsByRecipient = true;
    await persistMessagesStore();
    pushMessageSseEvent(pid, 'message-updated', { action: 'saved', messageId });
    res.json({ ok: true, message: target });
  });

  app.post('/api/messages/delete', async (req, res) => {
    const messageId = String(req.body?.messageId || '').trim();
    const rawPid = String(req.body?.participantId || '').trim();
    const resolved = resolveCanonicalParticipant(rawPid);
    const pid = resolved?.id || rawPid;
    const idx = slipMessagesStore.findIndex((m) => m.id === messageId);
    if (idx < 0) {
      res.status(404).json({ ok: false });
      return;
    }
    const target = slipMessagesStore[idx];
    let changed = false;
    if (target.senderId === pid) {
      target.deletedBySender = true;
      changed = true;
    }
    if (target.recipientId === pid) {
      target.deletedByRecipient = true;
      changed = true;
    }
    if (!changed) {
      res.status(403).json({ ok: false });
      return;
    }
    if (target.deletedBySender && target.deletedByRecipient) {
      slipMessagesStore.splice(idx, 1);
    }
    await persistMessagesStore();
    pushMessageSseEvent(pid, 'message-updated', { action: 'deleted', messageId });
    res.json({ ok: true });
  });

  // Auto-bootstrap recorded ZIP configuration & slips on new device launch
  app.get('/api/promosport/bootstrap', async (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Access-Control-Allow-Origin', '*');
    const bootstrapPath = path.resolve(__dirname, 'APP_BOOTSTRAP.json');
    if (existsSync(bootstrapPath)) {
      try {
        const raw = await fs.readFile(bootstrapPath, 'utf-8');
        const parsed = JSON.parse(raw);
        res.json({ available: true, ...parsed });
        return;
      } catch {
        // Fallback below
      }
    }
    res.json({ available: false });
  });

  // Auto-sync live edits, slips, settings & Capacitor Android metadata
  app.post('/api/export/sync-state', async (req, res) => {
    try {
      const result = await syncWorkspaceAndCapacitor((req.body || {}) as SyncWorkspacePayload);
      res.setHeader('Cache-Control', 'no-store');
      res.json({ ok: true, ...result });
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Sync state error';
      res.status(500).json({ ok: false, error: msg });
    }
  });

  // Real-time Android Capacitor & PWA readiness audit for the UI checklist
  app.get('/api/export/readiness', async (_req, res) => {
    try {
      const resDir = path.resolve(__dirname, 'android/app/src/main/res');
      const manifestPath = path.resolve(__dirname, 'android/app/src/main/AndroidManifest.xml');
      const manifestRaw = existsSync(manifestPath) ? await fs.readFile(manifestPath, 'utf-8') : '';
      const appSettings = await readJsonSafe<Record<string, unknown>>(
        path.resolve(__dirname, 'APP_SETTINGS.json'),
        {}
      );
      const slips = await readJsonSafe<unknown[]>(path.resolve(__dirname, 'SAVED_USER_SLIPS.json'), []);

      const [iconCount, splashCount] = await Promise.all([
        countFilesMatching(resDir, (rel) => /^mipmap-[^/]+\/ic_launcher.*\.png$/i.test(rel)),
        countFilesMatching(resDir, (rel) => /^drawable[^/]*\/splash\.png$/i.test(rel)),
      ]);

      res.setHeader('Cache-Control', 'no-store');
      res.json({
        ready:
          existsSync(path.resolve(__dirname, 'android/gradlew')) &&
          existsSync(path.resolve(__dirname, '.github/workflows/build-android-apk.yml')) &&
          iconCount >= 15 &&
          splashCount >= 6,
        hasGradleWrapper: existsSync(path.resolve(__dirname, 'android/gradlew')),
        hasWorkflow: existsSync(path.resolve(__dirname, '.github/workflows/build-android-apk.yml')),
        hasInternetPermission: manifestRaw.includes('android.permission.INTERNET'),
        hasNotificationPermission: manifestRaw.includes('android.permission.POST_NOTIFICATIONS'),
        hasCapacitorAssetsPublic: existsSync(path.resolve(__dirname, 'android/app/src/main/assets/public/index.html')),
        distBuilt: existsSync(path.resolve(__dirname, 'dist/index.html')),
        iconCount,
        splashCount,
        slipsCount: Array.isArray(slips) ? slips.length : 0,
        packageId: String(appSettings.packageId || 'com.promosport.tunisie.mb'),
        appName: String(appSettings.appName || 'بروموسبور تونس - MB Football'),
        lastAutoSyncAt,
      });
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Readiness check error';
      res.status(500).json({ ready: false, error: msg });
    }
  });

  // Export COMPLETE auto-synced ZIP package (dist/ + src/ + public/ + full android/ Capacitor + offline HTML + bootstrap)
  app.post('/api/export/full-zip', async (req, res) => {
    try {
      const payload = (req.body || {}) as SyncWorkspacePayload;
      const syncResult = await syncWorkspaceAndCapacitor(payload);
      const distDir = await ensureBuiltDist(true);
      const androidAssetsCount = await syncDistToCapacitorAssets(distDir);

      const zip = new JSZip();
      let fileCount = 0;

      // 1. Freshly compiled production dist/ (excludes aistudio media scratch)
      fileCount += await addDirectoryToZip(zip, distDir, 'dist', {
        skipPaths: ['dist/assets/aistudio'],
      });

      // 2. Complete source tree & public PWA assets
      fileCount += await addDirectoryToZip(zip, path.resolve(__dirname, 'src'), 'src');
      fileCount += await addDirectoryToZip(zip, path.resolve(__dirname, 'public'), 'public', {
        skipPaths: ['public/assets/aistudio'],
      });

      // 3. Complete Android Capacitor workspace (with synced assets/public, covers, icons, manifest, gradle)
      fileCount += await addDirectoryToZip(zip, path.resolve(__dirname, 'android'), 'android', {
        skipDirs: new Set(['.gradle', 'build', '.cxx', '.idea', 'local.properties']),
        skipPaths: [
          'android/app/src/main/assets/public/assets/aistudio',
          'android/keystore.properties',
          'android/app/release.keystore',
        ],
      });

      // 4. Cloud APK CI workflow & local helper scripts
      fileCount += await addDirectoryToZip(zip, path.resolve(__dirname, '.github'), '.github');
      fileCount += await addDirectoryToZip(zip, path.resolve(__dirname, 'scripts'), 'scripts');

      // 5. Essential root configs, docs, server, & recorded state
      const htmlFilename = `Promosport_MB_3D_Offline_App_${syncResult.concoursNumber}.html`;
      const rootFiles = [
        'index.html',
        'package.json',
        'package-lock.json',
        'tsconfig.json',
        'vite.config.ts',
        'capacitor.config.json',
        'server.ts',
        'metadata.json',
        'start-ready-app.mjs',
        '.env.example',
        'README.md',
        'README_ANDROID_AND_WEB_BUILD.md',
        'READ_ME_FIRST_AR.txt',
        'APP_BOOTSTRAP.json',
        'APP_SETTINGS.json',
        'NOTIFICATION_SETTINGS.json',
        'SAVED_USER_SLIPS.json',
        'PROMPT_SPECIFICATION.txt',
        htmlFilename,
      ];

      for (const rel of rootFiles) {
        const abs = path.resolve(__dirname, rel);
        if (existsSync(abs)) {
          const buf = await fs.readFile(abs);
          zip.file(rel, buf);
          fileCount += 1;
        }
      }

      const zipBuffer = await zip.generateAsync({
        type: 'nodebuffer',
        compression: 'DEFLATE',
        compressionOptions: { level: 6 },
        platform: 'UNIX',
      });

      const downloadName = `Promosport_MB_3D_Full_Package_${syncResult.concoursNumber}.zip`;
      res.setHeader('Cache-Control', 'no-store');
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="${downloadName}"`);
      res.setHeader('Content-Length', String(zipBuffer.length));
      res.setHeader('X-Bundle-File-Count', String(fileCount));
      res.setHeader('X-Android-Assets-Count', String(androidAssetsCount));
      res.send(zipBuffer);
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Full ZIP export failed';
      res.status(500).json({ error: msg });
    }
  });

  // Export compiled production dist/ app bundle for full-app ZIP download (compat fallback)
  app.get('/api/export/built-bundle', async (req, res) => {
    try {
      const forceFresh = req.query.fresh === '1';
      const distDir = await ensureBuiltDist(forceFresh);
      await syncDistToCapacitorAssets(distDir);
      const files: ExportDistFile[] = [];
      await collectDistFiles(distDir, distDir, files);

      const extraPaths = [
        'start-ready-app.mjs',
        'scripts/check-and-build-apk.mjs',
        '.github/workflows/build-android-apk.yml',
        'README_ANDROID_AND_WEB_BUILD.md',
        'capacitor.config.json',
        'package.json',
      ];
      const extras: ExportDistFile[] = [];
      for (const relPath of extraPaths) {
        const absPath = path.resolve(__dirname, relPath);
        if (existsSync(absPath)) {
          try {
            const buf = await fs.readFile(absPath);
            extras.push({
              path: relPath,
              base64: buf.toString('base64'),
              size: buf.length,
            });
          } catch {
            // ignore optional file read failures
          }
        }
      }

      res.setHeader('Cache-Control', 'no-store');
      res.json({
        builtAt: new Date().toISOString(),
        freshRebuild: forceFresh,
        fileCount: files.length,
        files,
        extras,
      });
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Build bundle error';
      res.status(500).json({ error: msg, files: [] });
    }
  });

  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const isHmrDisabled = process.env.DISABLE_HMR === 'true';
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      plugins: isHmrDisabled
        ? [
            {
              name: 'disable-hmr-websocket-client',
              enforce: 'post',
              transform(code, id) {
                if (id.replace(/\\/g, '/').endsWith('/vite/dist/client/client.mjs')) {
                  const patched = code.replace(
                    /const transport = normalizeModuleRunnerTransport\(\(\(\) => \{[\s\S]*?\}\)\(\)\);/,
                    'const transport = normalizeModuleRunnerTransport({ async connect() {}, async disconnect() {}, send() {} });'
                  );
                  if (patched !== code) {
                    return { code: patched, map: null };
                  }
                }
                return undefined;
              },
            },
          ]
        : [],
      server: {
        middlewareMode: true,
        allowedHosts: true,
        hmr: isHmrDisabled ? false : { server: httpServer },
        ws: isHmrDisabled ? false : { server: httpServer },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  httpServer.on('error', (err) => {
    console.error('HTTP server error:', err);
  });

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Promosport Tunisie server running on http://0.0.0.0:${PORT}`);
    // Warm cache right after port is bound so startup is instantaneous
    void probeOfficialPromosportSite().catch(() => {});
  });
}

startServer().catch((err) => {
  console.error('Failed to start Promosport Tunisie server:', err);
  process.exit(1);
});
