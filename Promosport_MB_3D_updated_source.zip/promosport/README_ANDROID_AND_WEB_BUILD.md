# بروموسبور تونس - MB Football - Complete Archive (Built App + Zero-SDK Cloud APK)

> **تنبيه بيئة البناء:** في حال ظهرت رسالة *"بيئة البناء لا تحتوي على Android SDK و Gradle"*، يحتوي هذا الأرشيف على **التطبيق المبني كاملاً في `dist/`** مع مُشغّل مباشر بدون تثبيت، ومسارات التحويل السحابي إلى `.APK`.

## 0. تشغيل التطبيق المبني الكامل فوراً مع التفعيل التلقائي (بدون تثبيت أو بناء!)
```bash
node start-ready-app.mjs
```
- يقوم تلقائياً بفتح المتصفح، عرض رابط الهاتف عبر Wi-Fi، تشغيل خادم التحديث الحي للنتائج (/api/promosport/sync)، واسترجاع الإعدادات والقصاصات والأوامر المسجلة من `APP_BOOTSTRAP.json` تلقائياً.
- أضف `--no-open` إذا أردت تشغيل الخادم بدون فتح المتصفح آلياً.
- أو افتح الملف `Promosport_MB_3D_Offline_App_936.html` مباشرة في Google Chrome على الهاتف.

## 1. تشغيل التطبيق الكامل من المصدر (Web + PWA + Live Sync Server)
```bash
npm install
npm run build
npm start
```

## 2. فحص البيئة والبناء الآمن (لا يتوقف عند غياب Android SDK)
```bash
node scripts/check-and-build-apk.mjs
```

## 3. التحويل السحابي إلى Android APK / AAB موقّع (بدون Android SDK محلياً!)
- **الطريقة السحابية A (GitHub Actions — نسخة موقّعة رسمية `app-release.apk` + `app-release.aab`):**
  1. أنشئ مفتاح التوقيع الخاص بك مرة واحدة:
     ```bash
     keytool -genkeypair -v -keystore android/app/release.keystore -alias promosport-mb -keyalg RSA -keysize 2048 -validity 10000
     ```
  2. حوّل الملف إلى Base64 (`base64 -w 0 android/app/release.keystore`) وأضف الأسرار التالية في GitHub (`Settings > Secrets and variables > Actions`):
     - `ANDROID_KEYSTORE_BASE64`
     - `ANDROID_KEYSTORE_PASSWORD`
     - `ANDROID_KEY_ALIAS`
     - `ANDROID_KEY_PASSWORD`
  3. ارفع المشروع إلى GitHub، وسيقوم `.github/workflows/build-android-apk.yml` ببناء **`app-release.apk`** و **`app-release.aab`** الموقّعين تلقائياً (أو `app-debug.apk` إذا لم تضف الأسرار بعد).
- **الطريقة السحابية B (PWABuilder):**
  افتح الرابط: https://www.pwabuilder.com/?url=https%3A%2F%2Fais-pre-b626zjidlsk6zuvgqqipok-214381466247.europe-west2.run.app واضغط Package for Android لتوليد ملف `.apk` و `.aab` موقّع خلال ثوانٍ.

## 4. البناء المحلي الموقّع (عند توفر Android Studio + Java 17 + Gradle)
```bash
npm install
npm run build
npx cap copy android
cp android/keystore.properties.example android/keystore.properties
# عدّل android/keystore.properties وأدخل storePassword و keyAlias و keyPassword
cd android && ./gradlew assembleRelease bundleRelease
```
