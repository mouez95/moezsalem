package com.promosport.tunisie.mb;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
