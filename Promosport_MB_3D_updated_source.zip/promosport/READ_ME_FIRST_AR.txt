حزمة Promosport MB 3D الكاملة

محتويات الحزمة:
- release/Promosport_MB_3D.apk : التطبيق الجاهز للتثبيت على Android (نسخة Debug).
- src/ و public/ : ملفات التطبيق ومكوّناته وأيقوناته.
- dist/ : نسخة الويب المبنية التي يستخدمها تطبيق Android.
- android/ : مشروع Capacitor/Gradle الكامل مع Gradle Wrapper.
- ملفات package.json و package-lock.json وملفات الإعداد والبناء والخادم والبيانات الأصلية.

التثبيت:
انقل ملف release/Promosport_MB_3D.apk إلى هاتف Android وافتحه، ثم اسمح بالتثبيت من هذا المصدر إذا طلب النظام ذلك.

إعادة البناء من المصدر:
ثبّت Node.js وAndroid SDK وJDK 21، ثم من مجلد الحزمة نفّذ:
  npm ci
  npm run build
  npx cap sync android
  cd android
  ./gradlew assembleDebug

الناتج المعتاد:
  android/app/build/outputs/apk/debug/app-debug.apk

ملاحظة: APK موقّع بمفتاح Debug للتثبيت والتجربة اليدوية، وليس توقيع إصدار متجر Google Play.
